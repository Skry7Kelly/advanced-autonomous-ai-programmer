import { remember, recall } from "@/lib/fly";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const query = url.searchParams.get("q") ?? "";
  const kind = url.searchParams.get("kind") ?? undefined;
  if (query.length < 2) return Response.json({ items: [], hint: "передайте ?q= для семантического поиска по памяти роя" });
  const items = await recall(query, { limit: 12, kind });
  return Response.json({
    query,
    items: items.map((i) => ({ id: i.id, kind: i.kind, score: Number(i.score.toFixed(4)), text: i.text.slice(0, 600), meta: i.meta })),
  });
}

export async function POST(request: Request) {
  let body: { text?: string; kind?: string; projectId?: number } = {};
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "некорректный JSON" }, { status: 400 });
  }
  const text = (body.text ?? "").trim();
  if (text.length < 4) return Response.json({ error: "слишком короткая заметка" }, { status: 400 });
  const row = await remember({ text, kind: body.kind ?? "note", projectId: body.projectId ?? null });
  return Response.json({ stored: { id: row.id, kind: row.kind } }, { status: 201 });
}
