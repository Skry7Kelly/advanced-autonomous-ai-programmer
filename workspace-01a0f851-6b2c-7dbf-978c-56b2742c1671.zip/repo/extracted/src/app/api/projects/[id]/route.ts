import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { artifacts, chats, events, forgedModules, projects, sources, tasks } from "@/db/schema";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(_request: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) return Response.json({ error: "плохой id" }, { status: 400 });
  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project) return Response.json({ error: "проект не найден" }, { status: 404 });

  const [fileList, sourceRows, forgeRows, taskRows, eventRows, chatRows] = await Promise.all([
    db
      .select({
        id: artifacts.id,
        path: artifacts.path,
        language: artifacts.language,
        bytes: artifacts.bytes,
        sha256: artifacts.sha256,
        origin: artifacts.origin,
        agent: artifacts.agent,
      })
      .from(artifacts)
      .where(eq(artifacts.projectId, projectId))
      .orderBy(asc(artifacts.path)),
    db.select().from(sources).where(eq(sources.projectId, projectId)).orderBy(desc(sources.score)).limit(120),
    db
      .select({
        id: forgedModules.id,
        capability: forgedModules.capability,
        name: forgedModules.name,
        rationale: forgedModules.rationale,
        bytes: forgedModules.bytes,
      })
      .from(forgedModules)
      .where(eq(forgedModules.projectId, projectId)),
    db.select().from(tasks).where(eq(tasks.projectId, projectId)).orderBy(asc(tasks.ordinal)),
    db.select().from(events).where(eq(events.projectId, projectId)).orderBy(asc(events.id)).limit(400),
    db.select().from(chats).where(eq(chats.projectId, projectId)).orderBy(asc(chats.id)).limit(400),
  ]);

  return Response.json({
    project,
    files: fileList,
    sources: sourceRows,
    forged: forgeRows,
    tasks: taskRows,
    events: eventRows,
    chats: chatRows,
  });
}

export async function DELETE(_request: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) return Response.json({ error: "плохой id" }, { status: 400 });
  await Promise.all([
    db.delete(artifacts).where(eq(artifacts.projectId, projectId)),
    db.delete(events).where(eq(events.projectId, projectId)),
    db.delete(sources).where(eq(sources.projectId, projectId)),
    db.delete(tasks).where(eq(tasks.projectId, projectId)),
    db.delete(forgedModules).where(eq(forgedModules.projectId, projectId)),
    db.delete(chats).where(eq(chats.projectId, projectId)),
  ]);
  await db.delete(projects).where(eq(projects.id, projectId));
  return Response.json({ ok: true });
}
