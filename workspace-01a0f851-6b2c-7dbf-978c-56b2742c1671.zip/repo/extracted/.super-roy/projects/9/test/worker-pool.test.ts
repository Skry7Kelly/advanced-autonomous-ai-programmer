import test from 'node:test';
import assert from 'node:assert/strict';
import { mapPool, chunk } from '../src/modules/worker-pool.js';

test('сохраняет порядок при параллельной работе', async () => {
  const { results, errors } = await mapPool([1, 2, 3, 4], 2, async (n) => n * 10);
  assert.deepEqual(results, [10, 20, 30, 40]);
  assert.equal(errors.length, 0);
  assert.deepEqual(chunk([1, 2, 3], 2), [[1, 2], [3]]);
});