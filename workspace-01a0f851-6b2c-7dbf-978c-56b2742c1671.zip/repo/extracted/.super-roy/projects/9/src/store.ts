import { join } from 'node:path';
import { JsonlStore } from './modules/json-store.js';
import { appConfig } from './config.js';

export interface StoredRecord {
  id: string;
  createdAt: string;
  updatedAt: string;
  [key: string]: unknown;
}

export interface Repository<T extends StoredRecord> {
  create: (input: Omit<T, 'id' | 'createdAt' | 'updatedAt'>) => Promise<T>;
  list: (opts?: { limit?: number; offset?: number; where?: (item: T) => boolean }) => Promise<{ items: T[]; total: number }>;
  get: (id: string) => Promise<T | null>;
  update: (id: string, patch: Partial<T>) => Promise<T | null>;
  remove: (id: string) => Promise<boolean>;
  count: () => Promise<number>;
  file: string;
}

export function createRepository<T extends StoredRecord>(name: string): Repository<T> {
  const file = join(appConfig.DATA_DIR, name + '.jsonl');
  const store = new JsonlStore<T>(file);
  const newId = (): string => name.slice(0, 3) + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  return {
    file,
    async create(input) {
      const now = new Date().toISOString();
      const record = { ...input, id: newId(), createdAt: now, updatedAt: now } as T;
      await store.append(record);
      return record;
    },
    async list(opts = {}) {
      const all = await store.readAll();
      const filtered = opts.where ? all.filter(opts.where) : all;
      const start = opts.offset ?? 0;
      const items = filtered.slice(start, start + (opts.limit ?? 50));
      return { items, total: filtered.length };
    },
    async get(id) {
      const all = await store.readAll();
      return all.find((item) => item.id === id) ?? null;
    },
    async update(id, patch) {
      const all = await store.readAll();
      let updated: T | null = null;
      const next = all.map((item) => {
        if (item.id !== id) return item;
        updated = { ...item, ...patch, id, updatedAt: new Date().toISOString() } as T;
        return updated;
      });
      if (!updated) return null;
      await store.rewrite(next);
      return updated;
    },
    async remove(id) {
      const all = await store.readAll();
      const next = all.filter((item) => item.id !== id);
      if (next.length === all.length) return false;
      await store.rewrite(next);
      return true;
    },
    async count() {
      return (await store.readAll()).length;
    },
  };
}

export type AnyRepo = Repository<StoredRecord>;