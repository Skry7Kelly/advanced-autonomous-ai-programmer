# Исследование источников для «REST API трекера привычек: пользователи»

Разведчик роя обошёл PirateFace.co (индекс суверенных моделей), GitHub, npm, Hacker News и StackOverflow.

## Найденные репозитории и материалы

| Источник | Название | Метрика | Смысл |
| --- | --- | --- | --- |
| github | [firecrawl/firecrawl](https://github.com/firecrawl/firecrawl) | 187424 | 🔥 Supercharge your AI agents with data from the web and beyond. A web data API to search, scrape, and access more sourc |
| github | [open-webui/open-webui](https://github.com/open-webui/open-webui) | 153714 | User-friendly AI Interface (Supports Ollama, OpenAI API, ...) · Python · обновлён 2026-10-01 · ai,llm,llm-ui,llm-webui |
| github | [Comfy-Org/ComfyUI](https://github.com/Comfy-Org/ComfyUI) | 135734 | The most powerful and modular diffusion model GUI, api and backend with a graph/nodes interface. The fastest local infer |
| github | [earendil-works/pi](https://github.com/earendil-works/pi) | 110974 | AI agent toolkit: unified LLM API, agent loop, TUI, coding agent CLI · TypeScript · MIT · обновлён 2026-10-01 |
| github | [Kogenos/TicTacToe-WEB](https://github.com/Kogenos/TicTacToe-WEB) | 0 | REST API для игры в крестики-нолики на Go: JWT авторизация, PostgreSQL, минимакс (AI), поддержка игр человек-человек и ч |
| github | [Beedgee/FunPayCortex](https://github.com/Beedgee/FunPayCortex) | 34 | 🚀 Мощный Telegram-бот для FunPay на Python. Автоматизация торговли: автовыдача, плагины, статистика, прокси, мульти-адм |
| github | [ClickHouse/ClickHouse](https://github.com/ClickHouse/ClickHouse) | 50181 | ClickHouse® is a real-time analytics database management system · C++ · Apache-2.0 · обновлён 2026-10-01 · ai,analytics, |
| github | [chudo-arky/rwa-plugin-live-flow](https://github.com/chudo-arky/rwa-plugin-live-flow) | 9 | Плагин remnawave-admin: живая схема VPN-трафика — пользователи (мобильные / Wi-Fi) → ноды → выход, онлайн и скорость из  |
| github | [coreyhaines31/marketingskills](https://github.com/coreyhaines31/marketingskills) | 52105 | Marketing skills for Claude Code and AI agents. CRO, copywriting, SEO, analytics, and growth engineering. · JavaScript · |
| github | [GooDwiNehaa/JWT-Auth-Access-and-Refresh-tokens-ASP-NET-Core-and-React-](https://github.com/GooDwiNehaa/JWT-Auth-Access-and-Refresh-tokens-ASP-NET-Core-and-React-) | 8 | Аутентификация и авторизация на основе JWT Access Token и Refresh Token. · C# · обновлён 2022-09-26 · access-token,asp-n |
| github | [public-apis/public-apis](https://github.com/public-apis/public-apis) | 485059 | A collective list of free APIs · Python · MIT · обновлён 2026-09-28 · api,apis,dataset,development |
| hn | [Google’s copying of the Java SE API was fair use [pdf]](https://www.supremecourt.gov/opinions/20pdf/18-956_d18f.pdf) | 4103 | обсуждение на Hacker News |
| stackoverflow | [How do I get a YouTube video thumbnail from the YouTube API?](https://stackoverflow.com/questions/2068344/how-do-i-get-a-youtube-video-thumbnail-from-the-youtube-api) | 2857 | есть принятый ответ |
| github | [apache/superset](https://github.com/apache/superset) | 74996 | Apache Superset is a Data Visualization and Data Exploration Platform · Python · Apache-2.0 · обновлён 2026-10-01 · anal |
| github | [pathwaycom/pathway](https://github.com/pathwaycom/pathway) | 62204 | Python ETL framework for stream processing, real-time analytics, LLM pipelines, and RAG. · Python · обновлён 2026-10-01  |
| github | [grafana/grafana](https://github.com/grafana/grafana) | 77032 | The open and composable observability and data visualization platform. Visualize metrics, logs, and traces from multiple |
| hn | [Bose has released API docs and opened the API for its EoL SoundTouch speakers](https://arstechnica.com/gadgets/2026/01/bose-open-sources-its-soundtouch-home-theater-smart-speakers-ahead-of-eol/) | 2532 | обсуждение на Hacker News |
| hn | [Lyrebird – An API to copy the voice of anyone](https://lyrebird.ai/demo) | 1401 | обсуждение на Hacker News |
| hn | [Hacker News API](http://blog.ycombinator.com/hacker-news-api) | 1714 | обсуждение на Hacker News |
| hn | [Bruno: Fast and Git-friendly open-source API client (Postman alternative)](https://www.usebruno.com/) | 1538 | обсуждение на Hacker News |
| hn | [Introducing ChatGPT and Whisper APIs](https://openai.com/blog/introducing-chatgpt-and-whisper-apis) | 1423 | обсуждение на Hacker News |
| npm | [@ai-sdk/amazon-bedrock](https://github.com/vercel/ai) | 0 | The **[Amazon Bedrock provider](https://ai-sdk.dev/providers/ai-sdk-providers/amazon-bedrock)** for the [AI SDK](https:/ |
| github | [XuMuK1/psmo](https://github.com/XuMuK1/psmo) | 59 | Ресурсы курса "Прикладная статистика в машинном обучении"(2023) · Jupyter Notebook · MIT · обновлён 2026-09-05 |
| github | [ars-anosov/docker-hlds16](https://github.com/ars-anosov/docker-hlds16) | 23 | Сервер Counter Strike v.1.6 + статистика PsychoStats v.3.2.2b · Pawn · обновлён 2021-10-20 |
| github | [Platun0v/yandex_music_statistics](https://github.com/Platun0v/yandex_music_statistics) | 20 | Статистика прослушанных песен яндекс музыки · Python · обновлён 2020-10-08 |
| github | [Pozdniakov/tidy_stats](https://github.com/Pozdniakov/tidy_stats) | 18 | Анализ данных и статистика в R · Python · GPL-3.0 · обновлён 2026-09-29 |
| github | [PashkaVRN/foodgram-project-react](https://github.com/PashkaVRN/foodgram-project-react) | 16 | На этом сервисе пользователи могут публиковать рецепты, подписываться на публикации других пользователей, добавлять понр |
| github | [ValentinaBuddha/java-explore-with-me](https://github.com/ValentinaBuddha/java-explore-with-me) | 11 | Дипломный проект курса Java-разработка на Яндекс Практикуме. Backend для приложения - афиши, в котором пользователи могу |
| github | [VadimVolkovsky/yatube_project](https://github.com/VadimVolkovsky/yatube_project) | 10 | Социальная сеть, в которой пользователи могут зарегистрироваться и вести свой блог, а также комментировать записи других |
| github | [yakser/django-websocket-chat](https://github.com/yakser/django-websocket-chat) | 10 | Текстовый чат, основанный на веб-сокетах. Пользователи могут общаться друг с другом, создавать группы и каналы · Python  |
| github | [wizarsi/Spring-React-web-application](https://github.com/wizarsi/Spring-React-web-application) | 5 | 🍃⚛️ REST сервис, backend Spring. Авторизация Spring Security и jwt. Фронтенд React · JavaScript · обновлён 2022-06-09 · |
| github | [SergeyKozlovskiy/rslang](https://github.com/SergeyKozlovskiy/rslang) | 5 | RS Lang – приложение для изучения иностранных слов, включающее электронный учебник с базой слов для изучения, мини-игры  |
| github | [magistar0/infa100](https://github.com/magistar0/infa100) | 4 | ИНФА100 – компьютерная программа для подготовки к ЕГЭ, которая позволит удовлетворить такие потребности при подготовке,  |
| npm | [@opentelemetry/api](git+https://github.com/open-telemetry/opentelemetry-js.git) | 0 | Public API for OpenTelemetry |
| npm | [@microsoft/teams.api](git+https://github.com/microsoft/teams.ts.git) | 0 | <p>     <a href="https://www.npmjs.com/package/@microsoft/teams.api" target="_blank">         <img src="https://img.shie |
| github | [MagentaFNS/LogLine](https://github.com/MagentaFNS/LogLine) | 3 | LogLine — это трекер разработчика, который превращает хаос ежедневного кодинга в понятную картину прогресса.  Вместо тог |
| npm | [node-addon-api](git://github.com/nodejs/node-addon-api.git) | 0 | Node.js API (Node-API) |
| npm | [@vue/devtools-api](git+https://github.com/vuejs/devtools.git) | 0 | > Plugins API for easier DevTools integrations. |
| npm | [api](git+https://github.com/readmeio/api.git) | 0 | Magical SDK generation from an OpenAPI definition 🪄 |
| npm | [@webassemblyjs/helper-api-error](git+https://github.com/xtuc/webassemblyjs.git) | 0 | Common API errors |

## Локальные модели

- **ISTA-DASLab/Qwen3.8-Flash-Next-GSQ-RCO-Coder-GGUF** — 30 GB, 3 сидов. `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:d91faad0a0a8fcb9eece9441d49b011e423f418d&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FISTA-DASLab%2FQwen3.8-Flash-Next-GSQ-RCO-Coder-GGUF%2F04d8b36b50cc0479fda9214a378336f89b356d67%2F"`
- **Qwen/Qwen2.5-Coder-7B-Instruct-GGUF** — 15 GB, 2 сидов. `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:556995f1e8b9265253ca819f8f6b5133ba427848&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FQwen%2FQwen2.5-Coder-7B-Instruct-GGUF%2F13fb94bfda8c8cf22497dc57b78f391a9acb426a%2F"`
- **Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF** — 1.9 GB, 2 сидов. `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:0b7c54e97fef910575c92974f8cd88d713401962&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FQwen%2FQwen2.5-Coder-1.5B-Instruct-GGUF%2Ff86cb2c1fa58255f8052cc32aeede1b7482d4361%2F"`
- **unsloth/Qwen3-Coder-30B-A3B-Instruct-GGUF** — 50 GB, 1 сидов. `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:f29eca18c9bb3794241fab70b359c1316a9b2510&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2Funsloth%2FQwen3-Coder-30B-A3B-Instruct-GGUF%2Fb17cb02dd882d5b6ab62fc777ad2995f19668350%2F"`

## Что внедряем

- [firecrawl/firecrawl](https://github.com/firecrawl/firecrawl) — 🔥 Supercharge your AI agents with data from the web and beyond. A web data API to search, scrape, and access more sources. · TypeScript · AGPL-3.0 · обновлён 2026-10-01 · ai,ai-agents,ai-crawler,ai-scraping. Подключение: `git clone https://github.com/firecrawl/firecrawl.git vendor/firecrawl`
- [open-webui/open-webui](https://github.com/open-webui/open-webui) — User-friendly AI Interface (Supports Ollama, OpenAI API, ...) · Python · обновлён 2026-10-01 · ai,llm,llm-ui,llm-webui. Подключение: `git clone https://github.com/open-webui/open-webui.git vendor/open-webui`
- [Comfy-Org/ComfyUI](https://github.com/Comfy-Org/ComfyUI) — The most powerful and modular diffusion model GUI, api and backend with a graph/nodes interface. The fastest local inference engine in the world. · Python · GPL-3.0 · обновлён 2026-10-01 · ai,comfy,comfyui,python. Подключение: `git clone https://github.com/Comfy-Org/ComfyUI.git vendor/ComfyUI`
- [earendil-works/pi](https://github.com/earendil-works/pi) — AI agent toolkit: unified LLM API, agent loop, TUI, coding agent CLI · TypeScript · MIT · обновлён 2026-10-01. Подключение: `git clone https://github.com/earendil-works/pi.git vendor/pi`