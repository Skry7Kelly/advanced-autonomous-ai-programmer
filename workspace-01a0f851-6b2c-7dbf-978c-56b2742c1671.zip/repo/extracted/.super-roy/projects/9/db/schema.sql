-- Схема для продакшн-перехода с JSONL на PostgreSQL

CREATE TABLE IF NOT EXISTS items (
  id BIGSERIAL PRIMARY KEY,
  title text,
  status text,
  payload jsonb,
  created_at timestamptz default now()
);

CREATE TABLE IF NOT EXISTS runs (
  id BIGSERIAL PRIMARY KEY,
  target_id bigint,
  state text,
  log jsonb,
  started_at timestamptz,
  finished_at timestamptz
);

CREATE TABLE IF NOT EXISTS events_log (
  id BIGSERIAL PRIMARY KEY,
  actor text,
  action text,
  payload jsonb,
  created_at timestamptz default now()
);
