"use client";

import { useMemo } from "react";
import CodeMirror from "@uiw/react-codemirror";
import { javascript } from "@codemirror/lang-javascript";
import { json } from "@codemirror/lang-json";
import { markdown } from "@codemirror/lang-markdown";
import { css } from "@codemirror/lang-css";
import { html } from "@codemirror/lang-html";
import { python } from "@codemirror/lang-python";
import { sql } from "@codemirror/lang-sql";
import { EditorView } from "@codemirror/view";
import type { Extension } from "@codemirror/state";

const theme = EditorView.theme(
  {
    "&": { backgroundColor: "#0d1018", color: "#dbe2f2" },
    ".cm-content": { caretColor: "#7dd3fc", padding: "10px 0" },
    ".cm-cursor, .cm-dropCursor": { borderLeftColor: "#7dd3fc", borderLeftWidth: "2px" },
    "&.cm-focused .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection": { backgroundColor: "rgba(125, 211, 252, 0.16)" },
    ".cm-gutters": { backgroundColor: "#0d1018", color: "#3d465c", border: "none" },
    ".cm-activeLine": { backgroundColor: "rgba(125, 211, 252, 0.045)" },
    ".cm-activeLineGutter": { backgroundColor: "rgba(125, 211, 252, 0.06)", color: "#8b95ad" },
    ".cm-lineNumbers .cm-gutterElement": { padding: "0 14px 0 12px", fontSize: "11.5px" },
    ".cm-foldPlaceholder": { backgroundColor: "#202636", border: "none", color: "#8b95ad" },
    ".cm-selectionMatch": { backgroundColor: "rgba(167, 139, 250, 0.15)" },
    ".cm-matchingBracket, .cm-nonmatchingBracket": { backgroundColor: "transparent", outline: "1px solid rgba(125,211,252,.4)", color: "inherit" },
    ".cm-tooltip": { backgroundColor: "#171c28", border: "1px solid #262d40", borderRadius: "8px" },
    ".cm-tooltip-autocomplete ul li[aria-selected]": { backgroundColor: "#202636", color: "#7dd3fc" },
  },
  { dark: true },
);

const highlights: Record<string, Extension[]> = {
  typescript: [javascript({ typescript: true, jsx: true })],
  javascript: [javascript({ jsx: true })],
  json: [json()],
  markdown: [markdown()],
  css: [css()],
  html: [html()],
  python: [python()],
  sql: [sql()],
  text: [],
};

export default function CodeEditor({
  path,
  value,
  language,
  onChange,
  onSave,
}: {
  path: string;
  value: string;
  language: string;
  onChange: (value: string) => void;
  onSave: () => void;
}) {
  const extensions = useMemo(() => [...(highlights[language] ?? highlights.text), theme, EditorView.lineWrapping], [language]);

  return (
    <CodeMirror
      key={path}
      value={value}
      height="100%"
      theme="none"
      extensions={extensions}
      onChange={onChange}
      basicSetup={{
        lineNumbers: true,
        foldGutter: true,
        highlightActiveLine: true,
        autocompletion: true,
        bracketMatching: true,
        closeBrackets: true,
        highlightSelectionMatches: true,
        searchKeymap: true,
        tabSize: 2,
      }}
    />
  );
}
