import { ProxyAgent, fetch as undiciFetch } from "undici";
import { eq, sql } from "@/db/orm";
import { db } from "@/db";
import { proxies } from "@/db/schema";

export const UA =
  "SuperRoy-Swarm/1.0 (+autonomous dev swarm; research; contact: local)";

export interface FetchOpts {
  timeoutMs?: number;
  useProxy?: boolean;
  headers?: Record<string, string>;
  method?: string;
  body?: string;
}

const agentCache = new Map<string, ProxyAgent>();

function agentFor(proxyUrl: string): ProxyAgent {
  const cached = agentCache.get(proxyUrl);
  if (cached) return cached;
  const agent = new ProxyAgent({ uri: proxyUrl, requestTls: { rejectUnauthorized: false } });
  agentCache.set(proxyUrl, agent);
  return agent;
}

function envProxies(): string[] {
  const raw = [
    process.env.PROXY_LIST,
    process.env.HTTPS_PROXY,
    process.env.https_proxy,
    process.env.HTTP_PROXY,
    process.env.http_proxy,
  ]
    .filter(Boolean)
    .join(",");
  return raw
    .split(/[\s,\n]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 3);
}

export async function proxyPool(): Promise<{ url: string; failCount: number }[]> {
  const rows = await db
    .select()
    .from(proxies)
    .where(sql`${proxies.status} <> 'dead'`)
    .orderBy(proxies.failCount)
    .limit(24);
  const fromDb = rows.map((r) => ({ url: r.url, failCount: r.failCount }));
  const seen = new Set(fromDb.map((r) => r.url));
  for (const url of envProxies()) {
    if (!seen.has(url)) fromDb.push({ url, failCount: 0 });
  }
  return fromDb;
}

export interface NetResult {
  ok: boolean;
  status: number;
  text: string;
  via: string;
  ms: number;
  error?: string;
}

/** Ходит в интернет: сначала напрямую, при провале — по пулу прокси. */
export async function netFetch(url: string, opts: FetchOpts = {}): Promise<NetResult> {
  const timeoutMs = opts.timeoutMs ?? 12000;
  const started = Date.now();
  const attempts: (string | null)[] = [null];
  if (opts.useProxy) {
    const pool = await proxyPool();
    attempts.push(...pool.map((p) => p.url));
  }
  let lastError = "no attempts";
  for (const proxy of attempts) {
    const t0 = Date.now();
    try {
      const dispatcher = proxy ? agentFor(proxy) : undefined;
      const res = await undiciFetch(url, {
        method: opts.method ?? "GET",
        headers: {
          "user-agent": UA,
          accept: "*/*",
          "accept-encoding": "gzip, deflate, br",
          ...(opts.headers ?? {}),
        },
        body: opts.body,
        signal: AbortSignal.timeout(timeoutMs),
        dispatcher,
      } as Parameters<typeof undiciFetch>[1]);
      const text = await res.text();
      const ms = Date.now() - t0;
      if (proxy) {
        await db
          .update(proxies)
          .set({ okCount: sql`${proxies.okCount} + 1`, latencyMs: ms, status: "alive", lastCheckedAt: new Date() })
          .where(eq(proxies.url, proxy));
      }
      return { ok: res.ok, status: res.status, text, via: proxy ?? "direct", ms };
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
      if (proxy) {
        await db
          .update(proxies)
          .set({ failCount: sql`${proxies.failCount} + 1`, status: "flaky", lastCheckedAt: new Date() })
          .where(eq(proxies.url, proxy));
      }
    }
  }
  return { ok: false, status: 0, text: "", via: "none", ms: Date.now() - started, error: lastError };
}

const memo = new Map<string, { at: number; value: unknown }>();

export async function cachedJson<T>(key: string, ttlMs: number, loader: () => Promise<T>): Promise<T> {
  const hit = memo.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.value as T;
  const value = await loader();
  memo.set(key, { at: Date.now(), value });
  return value;
}

export async function getJson<T>(url: string, opts: FetchOpts = {}): Promise<T | null> {
  const res = await netFetch(url, opts);
  if (!res.ok) return null;
  try {
    return JSON.parse(res.text) as T;
  } catch {
    return null;
  }
}

export async function checkEndpoint(url: string, useProxy: boolean, timeoutMs = 9000) {
  const local = /127\.0\.0\.1|localhost/.test(url);
  const res = await netFetch(url, { timeoutMs: local ? Math.min(timeoutMs, 1800) : timeoutMs, useProxy });
  return {
    ok: res.ok,
    status: res.status,
    ms: res.ms,
    via: res.via,
    error: res.error,
    text: res.text.slice(0, 400_000),
  };
}
