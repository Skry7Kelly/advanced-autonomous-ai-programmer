import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { JsonlStore } from '../src/modules/json-store.js';

test('append и выборка', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'jsonl-'));
  const store = new JsonlStore<{ id: string; kind: string }>(join(dir, 'log.jsonl'));
  await store.append({ id: 'a', kind: 'x' });
  await store.append({ id: 'b', kind: 'y' });
  const onlyY = await store.query({ where: (r) => r.kind === 'y' });
  assert.equal(onlyY.length, 1);
  assert.equal(onlyY[0].id, 'b');
});