"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { Badge, Panel } from "@/components/ui";
import type { EventRow, Spec } from "@/lib/types";

interface ProjectPayload {
  project: {
    id: number;
    name: string;
    brief: string;
    kind: string;
    language: string;
    status: string;
    stage: string;
    progress: number;
    spec: Spec | null;
    qa: { score: number; findings: { id: string; severity: string; file?: string; message: string; fixed: boolean }[]; checks: string[]; files: number; bytes: number } | null;
    stats: Record<string, number> | null;
    error: string | null;
    settings: Record<string, unknown> | null;
  };
  files: { id: number; path: string; language: string; bytes: number; sha256: string; origin: string; agent: string }[];
  sources: { id: number; provider: string; title: string; url: string; subtitle: string; metric: number; metricLabel: string; score: number; flyScore: number; decision: string; reason: string }[];
  forged: { id: number; capability: string; name: string; rationale: string; bytes: number }[];
  tasks: { id: number; title: string; detail: string; agent: string; status: string }[];
  events: EventRow[];
}

const TABS = ["Ход работы", "Спецификация", "Источники", "Модули", "Файлы", "QA"] as const;
type Tab = (typeof TABS)[number];

const AGENT_TONE: Record<string, string> = {
  ARCHITECT: "text-sky-300",
  SCOUT: "text-cyan-300",
  FLY: "text-lime-300",
  FORGE: "text-amber-300",
  ENGINEER: "text-emerald-300",
  CRITIC: "text-rose-300",
  INTEGRATOR: "text-violet-300",
};

export default function ProjectClient({ projectId }: { projectId: number }) {
  const [data, setData] = useState<ProjectPayload | null>(null);
  const [live, setLive] = useState<EventRow[]>([]);
  const [state, setState] = useState({ status: "unknown", progress: 0, stage: "" });
  const [tab, setTab] = useState<Tab>("Ход работы");
  const [selected, setSelected] = useState<string | null>(null);
  const [fileContent, setFileContent] = useState<string>("");
  const [restarting, setRestarting] = useState(false);
  const [zipBusy, setZipBusy] = useState(false);
  const [zipError, setZipError] = useState<string | null>(null);
  const streamRef = useRef<EventSource | null>(null);

  const load = useCallback(async () => {
    const res = await fetch(`/api/projects/${projectId}`).then((r) => r.json());
    if (res.error) {
      setData(null);
      return;
    }
    setData(res as ProjectPayload);
    setLive(res.events ?? []);
    setState({ status: res.project.status, progress: res.project.progress, stage: res.project.stage });
    if ((res.files ?? []).length > 0) setSelected((prev) => prev ?? res.files[0].path);
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const es = new EventSource(`/api/projects/${projectId}/stream`);
    streamRef.current = es;
    es.onmessage = (message) => {
      try {
        const payload = JSON.parse(message.data) as { type: string; event?: EventRow; status?: string; progress?: number; stage?: string };
        if (payload.type === "event" && payload.event) {
          const row = payload.event;
          setLive((prev) => (prev.some((e) => e.id === row.id) ? prev : [...prev, row]));
        }
        if (payload.type === "state" && payload.status) {
          setState({ status: payload.status, progress: payload.progress ?? 0, stage: payload.stage ?? "" });
        }
      } catch {
        // игнорируем битые кадры
      }
    };
    es.onerror = () => {
      // браузер сам переподключится; если стрим закрылся навсегда, обновим снимок
      setTimeout(() => void load(), 2500);
    };
    return () => {
      es.close();
      streamRef.current = null;
    };
  }, [projectId, load]);

  useEffect(() => {
    if (!selected) return;
    void fetch(`/api/projects/${projectId}/file?path=${encodeURIComponent(selected)}`)
      .then((r) => r.json())
      .then((d) => setFileContent(d.content ?? `// ${d.error ?? "нет содержимого"}`))
      .catch(() => setFileContent("// не удалось прочитать файл"));
  }, [selected, projectId]);

  const restart = useCallback(async () => {
    setRestarting(true);
    await fetch(`/api/projects/${projectId}/build`, { method: "POST" });
    setTimeout(() => void load(), 1200);
    setRestarting(false);
  }, [projectId, load]);

  const downloadZip = useCallback(async () => {
    setZipBusy(true);
    setZipError(null);
    try {
      const res = await fetch(`/api/projects/${projectId}/bundle`, { cache: "no-store" });
      const type = res.headers.get("content-type") ?? "";
      if (!res.ok || !type.includes("zip")) {
        const text = await res.text();
        setZipError(text.slice(0, 280) || `ошибка ${res.status}`);
        return;
      }
      const blob = await res.blob();
      if (blob.size < 80) {
        setZipError("архив пустой — дождитесь окончания сборки");
        return;
      }
      const cd = res.headers.get("content-disposition") ?? "";
      const match = cd.match(/filename=\"([^\"]+)\"/);
      const name = match?.[1] ?? `super-roy-${projectId}.zip`;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = name;
      a.rel = "noopener";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1500);
    } catch (error) {
      setZipError(error instanceof Error ? error.message : String(error));
    } finally {
      setZipBusy(false);
    }
  }, [projectId]);

  const spec = data?.project.spec ?? null;
  const grouped = useMemo(() => {
    const byFolder = new Map<string, typeof data extends null ? never : NonNullable<ProjectPayload["files"]>>();
    for (const file of data?.files ?? []) {
      const dir = file.path.split("/").slice(0, -1).join("/") || "/";
      const list = byFolder.get(dir) ?? [];
      list.push(file);
      byFolder.set(dir, list);
    }
    return [...byFolder.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [data]);

  const running = state.status === "running" || state.status === "queued";

  return (
    <main className="mx-auto max-w-[1400px] px-4 py-6 sm:px-6">
      <header className="mb-5 flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <Link href="/projects" className="text-[11px] text-[#5f738a] hover:text-sky-300">
              ← проекты
            </Link>
            <h1 className="text-xl font-bold text-[#e8f1fa]">
              #{projectId} {data?.project.name ?? "загрузка…"}
            </h1>
            <Badge tone={state.status === "done" ? "lime" : state.status === "failed" ? "red" : state.status === "running" ? "cyan" : "slate"}>
              {state.status} · {state.stage || "—"}
            </Badge>
            {data?.project.qa && <Badge tone={data.project.qa.score >= 80 ? "lime" : "amber"}>QA {data.project.qa.score}/100</Badge>}
          </div>
          <p className="mt-2 max-w-4xl text-[12px] leading-relaxed text-[#7d93ab]">{data?.project.brief}</p>
          <div className="mt-2 h-1.5 w-full max-w-2xl overflow-hidden rounded bg-[#141d27]">
            <div className={`h-full rounded bg-lime-400 transition-all duration-500 ${running ? "sweep relative" : ""}`} style={{ width: `${Math.max(3, state.progress)}%` }} />
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {running && <span className="rounded-lg border border-sky-500/40 bg-sky-500/10 px-3 py-2 text-[11px] text-sky-300 uppercase">рой работает…</span>}
          <button
            onClick={() => void restart()}
            disabled={restarting || running}
            className="rounded-lg border border-lime-500/50 bg-lime-500/10 px-3 py-2 text-[11px] tracking-wide text-lime-300 uppercase hover:bg-lime-500/20 disabled:opacity-40"
          >
            {restarting ? "…" : "перезапустить рой"}
          </button>
          <button
            type="button"
            onClick={() => void downloadZip()}
            disabled={zipBusy || (data?.files.length ?? 0) === 0}
            className="rounded-lg border border-lime-500/50 bg-lime-500/10 px-3 py-2 text-[11px] tracking-wide text-lime-300 uppercase hover:bg-lime-500/20 disabled:opacity-40"
          >
            {zipBusy ? "собираю zip…" : "скачать zip"}
          </button>
        </div>
      </header>
      {zipError && (
        <div className="mb-4 rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-[12px] text-amber-200">{zipError}</div>
      )}

      {data?.project.error && (
        <div className="mb-4 rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-[12px] whitespace-pre-wrap text-red-200">
          {data.project.error}
        </div>
      )}

      {data?.project.stats && (
        <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
          {[
            ["файлов", data.project.stats.files],
            ["КБ кода", (data.project.stats.bytes / 1024).toFixed(1)],
            ["модулей выковано", data.project.stats.forged],
            ["источников", data.project.stats.sources],
            ["принято к внедрению", data.project.stats.adopted],
            ["моделей найдено", data.project.stats.models],
            ["эндпоинтов", data.project.stats.endpoints],
            ["QA", data.project.stats.qaScore],
          ].map(([label, value]) => (
            <div key={String(label)} className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
              <div className="text-[10px] tracking-wider text-[#5f738a] uppercase">{label}</div>
              <div className="mt-0.5 text-base font-semibold text-[#dbe4ee]">{value}</div>
            </div>
          ))}
        </div>
      )}

      <nav className="mb-4 flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`rounded-lg border px-3 py-1.5 text-[11px] tracking-wide uppercase transition ${
              tab === t ? "border-sky-500/60 bg-sky-500/10 text-sky-300" : "border-[#1b2531] bg-[#0b1017] text-[#7d93ab] hover:text-[#a9c3da]"
            }`}
          >
            {t}
            {t === "Модули" && data ? ` (${data.forged.length})` : ""}
            {t === "Источники" && data ? ` (${data.sources.length})` : ""}
            {t === "Файлы" && data ? ` (${data.files.length})` : ""}
          </button>
        ))}
      </nav>

      {tab === "Ход работы" && (
        <Panel title="Живой лог роя" subtitle="События приходят по SSE напрямую из работающих агентов.">
          <div className="max-h-[620px] space-y-1.5 overflow-auto">
            {live.length === 0 && <p className="text-[12px] text-[#5f738a]">Ожидание событий…</p>}
            {live.map((e) => (
              <div key={e.id} className="flex gap-3 border-b border-[#121a24] pb-1.5 text-[12px] last:border-0">
                <span className="w-20 shrink-0 text-[10px] text-[#4d5f74]">{e.createdAt ? new Date(e.createdAt).toLocaleTimeString("ru-RU") : ""}</span>
                <span className={`w-24 shrink-0 text-[10px] uppercase ${AGENT_TONE[e.agent] ?? "text-[#8ba3bb]"}`}>{e.agent}</span>
                <span className="w-24 shrink-0 text-[10px] text-[#5f738a]">{e.stage}</span>
                <span className={`flex-1 ${e.level === "error" ? "text-red-300" : e.level === "warn" ? "text-amber-300" : e.level === "success" ? "text-lime-200" : "text-[#c9d7e5]"}`}>
                  {e.message}
                </span>
              </div>
            ))}
          </div>
        </Panel>
      )}

      {tab === "Спецификация" && spec && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Panel title="Цели">
            <ul className="space-y-1 text-[12px] text-[#c9d7e5]">
              {spec.goals.map((g, i) => (
                <li key={i}>▸ {g}</li>
              ))}
            </ul>
            <h3 className="mt-4 text-[11px] tracking-wider text-[#5f738a] uppercase">Не делаем</h3>
            <ul className="mt-1 space-y-1 text-[12px] text-[#7d93ab]">
              {spec.nonGoals.map((g, i) => (
                <li key={i}>— {g}</li>
              ))}
            </ul>
          </Panel>
          <Panel title="Модули">
            <div className="space-y-2 text-[12px]">
              {spec.modules.map((m) => (
                <div key={m.path} className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <code className="text-[#dbe4ee]">{m.path}</code>
                    <Badge tone={m.origin === "forged" ? "amber" : m.origin === "adopted" ? "cyan" : "slate"}>{m.origin}</Badge>
                  </div>
                  <p className="mt-1 text-[11px] text-[#7d93ab]">{m.purpose}</p>
                  <p className="mt-1 text-[11px] text-[#5f738a]">API: {m.publicApi.join(", ")}</p>
                </div>
              ))}
            </div>
          </Panel>
          <Panel title="Хранилище">
            <div className="space-y-3 text-[12px]">
              {spec.tables.map((t) => (
                <div key={t.name}>
                  <div className="flex items-center gap-2">
                    <code className="text-lime-300">{t.name}</code>
                    <span className="text-[11px] text-[#5f738a]">{t.reason}</span>
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {t.columns.map((c) => (
                      <span key={c.name} className="rounded border border-[#1b2531] bg-[#0a0f16] px-2 py-0.5 text-[11px] text-[#a9c3da]">
                        {c.name}: {c.type}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Panel>
          <Panel title="Эндпоинты и CLI">
            <div className="max-h-72 space-y-1 overflow-auto text-[12px]">
              {spec.endpoints.map((e) => (
                <div key={`${e.method}${e.path}`} className="flex flex-wrap items-center gap-2 border-b border-[#121a24] py-1 last:border-0">
                  <Badge tone={e.method === "GET" ? "cyan" : e.method === "DELETE" ? "red" : "lime"}>{e.method}</Badge>
                  <code className="text-[#dbe4ee]">{e.path}</code>
                  <span className="text-[11px] text-[#5f738a]">{e.purpose}</span>
                </div>
              ))}
            </div>
            <h3 className="mt-4 text-[11px] tracking-wider text-[#5f738a] uppercase">Команды</h3>
            <ul className="mt-1 space-y-1 text-[12px] text-[#c9d7e5]">
              {spec.cli.map((c) => (
                <li key={c.command}>
                  <code className="text-lime-300">{c.command}</code> — {c.purpose}
                </li>
              ))}
            </ul>
          </Panel>
          <Panel title="Этапы">
            <ol className="space-y-2 text-[12px]">
              {spec.milestones.map((m) => (
                <li key={m.index} className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
                  <div className="text-[#dbe4ee]">
                    {m.index}. {m.title}
                  </div>
                  <ul className="mt-1 space-y-0.5 text-[11px] text-[#7d93ab]">
                    {m.tasks.map((t, i) => (
                      <li key={i}>— {t}</li>
                    ))}
                  </ul>
                  <div className="mt-1 text-[11px] text-lime-300/80">готово, когда: {m.doneWhen}</div>
                </li>
              ))}
            </ol>
          </Panel>
          <Panel title="Риски, модели и мозг мухи">
            <table className="w-full text-left text-[12px]">
              <tbody>
                {spec.risks.map((r) => (
                  <tr key={r.risk} className="border-b border-[#121a24] align-top last:border-0">
                    <td className="py-1 pr-2 text-[#c9d7e5]">{r.risk}</td>
                    <td className="py-1 pr-2">
                      <Badge tone={r.impact === "high" ? "red" : r.impact === "medium" ? "amber" : "slate"}>{r.impact}</Badge>
                    </td>
                    <td className="py-1 text-[11px] text-[#7d93ab]">{r.mitigation}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {spec.models.length > 0 && (
              <>
                <h3 className="mt-4 text-[11px] tracking-wider text-lime-300 uppercase">Локальные модели (PirateFace.co)</h3>
                <div className="mt-1 space-y-2 text-[12px]">
                  {spec.models.map((m) => (
                    <div key={m.name} className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-[#dbe4ee]">{m.name}</span>
                        <span className="text-[11px] text-[#5f738a]">
                          {m.sizeGB} GB · {m.seeds} сидов
                        </span>
                      </div>
                      <div className="text-[11px] text-[#7d93ab]">{m.role}</div>
                      <code className="mt-1 block overflow-x-auto rounded bg-[#070b11] p-1 text-[10px] text-[#8ba3bb]">{m.cmd}</code>
                    </div>
                  ))}
                </div>
              </>
            )}
            <h3 className="mt-4 text-[11px] tracking-wider text-lime-300 uppercase">Ускорение</h3>
            <p className="mt-1 text-[12px] text-[#7d93ab]">{spec.fly.note}</p>
            <ul className="mt-1 space-y-0.5 text-[11px] text-[#8ba3bb]">
              {spec.fly.accelerations.map((a) => (
                <li key={a}>▸ {a}</li>
              ))}
            </ul>
          </Panel>
        </div>
      )}

      {tab === "Источники" && data && (
        <Panel title="Что нашла разведка" subtitle="PirateFace.co · GitHub · npm · Hacker News · StackOverflow, с оценкой релевантности и вкладом мозга мухи.">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[12px]">
              <thead className="bg-[#0a0f16] text-[10px] tracking-wider text-[#5f738a] uppercase">
                <tr>
                  <th className="px-3 py-2">решение</th>
                  <th className="px-3 py-2">источник</th>
                  <th className="px-3 py-2">находка</th>
                  <th className="px-3 py-2">метрика</th>
                  <th className="px-3 py-2">score / муха</th>
                </tr>
              </thead>
              <tbody>
                {data.sources.map((s) => (
                  <tr key={s.id} className="border-t border-[#141d27] align-top">
                    <td className="px-3 py-2">
                      <Badge tone={s.decision === "adopted" ? "lime" : s.decision === "model" ? "amber" : "slate"}>{s.decision}</Badge>
                      {s.reason && <div className="mt-1 text-[10px] text-[#5f738a]">{s.reason}</div>}
                    </td>
                    <td className="px-3 py-2">
                      <Badge tone={s.provider === "github" ? "cyan" : s.provider === "pirateface" ? "lime" : "slate"}>{s.provider}</Badge>
                    </td>
                    <td className="px-3 py-2">
                      <a href={s.url} target="_blank" rel="noreferrer" className="text-sky-300 hover:underline">
                        {s.title}
                      </a>
                      <div className="text-[11px] text-[#5f738a]">{s.subtitle.slice(0, 160)}</div>
                    </td>
                    <td className="px-3 py-2 text-[#a9c3da]">
                      {s.metric} {s.metricLabel}
                    </td>
                    <td className="px-3 py-2 text-[#a9c3da]">
                      {s.score} / {s.flyScore}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      )}

      {tab === "Модули" && data && (
        <Panel title="Выкованные модули" subtitle="Модули, которых не было в открытом доступе: рой собрал их сам, с тестами.">
          <div className="space-y-3">
            {data.forged.map((f) => (
              <div key={f.id} className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[13px] text-[#dbe4ee]">
                    {f.capability} → <code className="text-amber-300">{f.name}</code>
                  </span>
                  <span className="text-[11px] text-[#5f738a]">{f.bytes} байт + тест</span>
                </div>
                <p className="mt-1 text-[11px] leading-relaxed text-[#7d93ab]">{f.rationale}</p>
                <button
                  onClick={() => {
                    setTab("Файлы");
                    setSelected(`src/modules/${f.capability}.ts`);
                  }}
                  className="mt-2 text-[11px] text-sky-300 hover:underline"
                >
                  открыть код
                </button>
              </div>
            ))}
          </div>
        </Panel>
      )}

      {tab === "Файлы" && data && (
        <div className="grid gap-4 lg:grid-cols-[320px_minmax(0,1fr)]">
          <Panel title="Дерево проекта">
            <div className="max-h-[600px] overflow-auto text-[12px]">
              {grouped.map(([dir, files]) => (
                <div key={dir} className="mb-2">
                  <div className="text-[10px] tracking-wider text-[#5f738a] uppercase">{dir}</div>
                  {(files as ProjectPayload["files"]).map((file) => (
                    <button
                      key={file.id}
                      onClick={() => setSelected(file.path)}
                      className={`block w-full truncate rounded px-2 py-1 text-left hover:bg-[#111a26] ${selected === file.path ? "bg-[#111a26] text-sky-300" : "text-[#a9c3da]"}`}
                    >
                      {file.path.split("/").pop()}{" "}
                      <span className="text-[10px] text-[#4d5f74]">{file.bytes}b</span>{" "}
                      {file.origin === "forged" && <span className="text-[10px] text-amber-300">◆</span>}
                    </button>
                  ))}
                </div>
              ))}
              {data.files.length === 0 && <p className="text-[12px] text-[#5f738a]">Файлов пока нет — запустите рой.</p>}
            </div>
          </Panel>
          <Panel
            title={selected ?? "файл"}
            right={
              selected && (
                <div className="flex gap-2">
                  <button
                    onClick={() => void navigator.clipboard.writeText(fileContent)}
                    className="rounded border border-[#26344a] px-2 py-1 text-[10px] text-[#a9c3da] uppercase hover:text-sky-300"
                  >
                    копировать
                  </button>
                </div>
              )
            }
          >
            <pre className="max-h-[600px] overflow-auto rounded-lg border border-[#1b2531] bg-[#070b11] p-3 text-[11px] text-[#c9d7e5]">
              <code>{fileContent || "выберите файл слева"}</code>
            </pre>
          </Panel>
        </div>
      )}

      {tab === "QA" && data && (
        <Panel title="Отчёт критика" subtitle="Проверки на заглушки, баланс скобок, разрешимость импортов, покрытие эндпоинтов и тестов.">
          <div className="grid gap-4 lg:grid-cols-2">
            <div>
              <h3 className="text-[11px] tracking-wider text-[#5f738a] uppercase">Выполненные проверки</h3>
              <ul className="mt-2 space-y-1 text-[12px] text-[#c9d7e5]">
                {(data.project.qa?.checks ?? []).map((c) => (
                  <li key={c}>✓ {c}</li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-[11px] tracking-wider text-[#5f738a] uppercase">Находки ({data.project.qa?.findings.length ?? 0})</h3>
              <div className="mt-2 space-y-1 text-[12px]">
                {(data.project.qa?.findings ?? []).length === 0 && <p className="text-lime-300">Проблем не найдено.</p>}
                {(data.project.qa?.findings ?? []).map((f) => (
                  <div key={f.id} className="rounded border border-[#1b2531] bg-[#0a0f16] px-2 py-1">
                    <Badge tone={f.severity === "blocker" ? "red" : f.severity === "warn" ? "amber" : "slate"}>{f.severity}</Badge>{" "}
                    <span className="text-[11px] text-[#a9c3da]">{f.file ? `${f.file}: ` : ""}{f.message}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Panel>
      )}
    </main>
  );
}
