import { PROVIDER_DEFS } from "@/lib/providers";
import { deleteSecret, listSecrets, upsertSecret } from "@/lib/secrets";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  const stored = await listSecrets();
  const byEnv = new Map(stored.map((s) => [s.envKey, s]));
  const slots = PROVIDER_DEFS.filter((d) => d.envKey).map((d) => {
    const row = byEnv.get(d.envKey);
    return {
      provider: d.key,
      label: d.label,
      envKey: d.envKey,
      model: d.model,
      note: d.note,
      hasValue: Boolean(row?.hasValue),
      masked: row?.masked ?? "",
      fromEnv: row?.fromEnv ?? Boolean(process.env[d.envKey]),
    };
  });
  const extras = stored.filter((s) => !slots.some((x) => x.envKey === s.envKey));
  return Response.json({ slots, extras });
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as {
    envKey?: string;
    value?: string;
    label?: string;
    hint?: string;
  };
  if (!body.envKey || !body.value) {
    return Response.json({ error: "нужны envKey и value" }, { status: 400 });
  }
  try {
    await upsertSecret(body.envKey, body.value, body.label, body.hint);
    return Response.json({ ok: true, envKey: body.envKey });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : String(error) }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  const url = new URL(request.url);
  const envKey = url.searchParams.get("envKey") ?? "";
  if (!envKey) return Response.json({ error: "нет envKey" }, { status: 400 });
  await deleteSecret(envKey);
  return Response.json({ ok: true });
}
