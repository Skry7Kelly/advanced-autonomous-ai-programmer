import { PLANS } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  return Response.json({ plans: [PLANS.free, PLANS.pro, PLANS.team] });
}
