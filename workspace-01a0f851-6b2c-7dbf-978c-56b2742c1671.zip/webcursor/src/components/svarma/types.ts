/** Общие клиентские типы Svarma (даты приходят строками по JSON). */

export type ProjectRow = {
  id: number;
  name: string;
  brief: string;
  kind: string;
  language: string;
  status: string;
  stage: string;
  progress: number;
  spec: SpecData | null;
  briefParsed: unknown;
  qa: QaData | null;
  settings: SettingsData | null;
  stats: Record<string, number> | null;
  error: string | null;
  createdAt: string;
  updatedAt: string;
};

export type SpecData = {
  title: string;
  slug: string;
  summary: string;
  goals: string[];
  nonGoals: string[];
  modules: { name: string; path: string; purpose: string; origin: string }[];
  tables: { name: string; reason: string; columns: { name: string; type: string; note: string }[] }[];
  endpoints: { method: string; path: string; purpose: string }[];
  milestones: { index: number; title: string; tasks: string[]; doneWhen: string }[];
  risks: { risk: string; impact: string; mitigation: string }[];
  integrations: { name: string; url: string; stars: number; why: string }[];
  fly: { brains: number; generation: number; fitness: number; accelerations: string[] };
};

export type QaData = {
  score: number;
  findings: { id: string; severity: string; file?: string; message: string; fixed: boolean }[];
  files: number;
  bytes: number;
  checks: string[];
};

export type SettingsData = {
  targetLanguage: string;
  searchDepth: number;
  maxAdopt: number;
  useProxy: boolean;
  flyBoost: boolean;
  allowForge: boolean;
  cloudLlm: boolean;
  localLlm: boolean;
};

export type FileRow = {
  id: number;
  path: string;
  language: string;
  bytes: number;
  sha256: string;
  origin: string;
  agent: string;
};

export type EventRow = {
  id: number;
  projectId: number;
  runId: number | null;
  level: "info" | "warn" | "error" | "success";
  agent: string;
  stage: string;
  message: string;
  data: unknown;
  createdAt: string | null;
};

export type TaskRow = {
  id: number;
  projectId: number;
  ordinal: number;
  title: string;
  detail: string;
  agent: string;
  status: string;
  artifactPath: string | null;
};

export type SourceRow = {
  id: number;
  provider: string;
  title: string;
  url: string;
  subtitle: string;
  metric: number;
  metricLabel: string;
  score: number;
  decision: string;
  reason: string;
};

export type ChatRow = {
  id: number;
  projectId: number;
  role: string;
  content: string;
  provider: string;
  createdAt: string;
};

export type ForgedRow = {
  id: number;
  capability: string;
  name: string;
  rationale: string;
  bytes: number;
};

export type ProjectDetail = {
  project: ProjectRow;
  files: FileRow[];
  sources: SourceRow[];
  forged: ForgedRow[];
  tasks: TaskRow[];
  events: EventRow[];
  chats: ChatRow[];
};

export type DiffLine = { kind: "add" | "del" | "ctx"; text: string };

export type ProposedPatch = {
  action: "write" | "delete";
  path: string;
  isNew: boolean;
  additions: number;
  deletions: number;
  diff: DiffLine[];
};

export type RawPatch = { action: "write" | "delete"; path: string; content?: string };

export type AgentEvent =
  | { type: "status"; text: string; icon?: string }
  | { type: "provider"; provider: string; model: string }
  | { type: "build-started" }
  | { type: "answer"; text: string }
  | { type: "changed"; changed: string[] }
  | { type: "patches"; summary: string; patches: ProposedPatch[]; raw: RawPatch[]; provider: string }
  | { type: "spec"; spec: SpecData; notes: string[] }
  | { type: "skills"; skills: string[] }
  | { type: "error"; message: string }
  | { type: "done"; result: { mode: string; changed: string[]; provider: string } };

export type ChatMode = "agent" | "architect" | "ask";

export type ProviderInfo = {
  key: string;
  label: string;
  kind: string;
  model: string;
  status: string;
  latencyMs: number | null;
  detail: string;
  keyless: boolean;
  envKey: string;
};

export type SkillInfo = {
  name: string;
  description: string;
  source: "builtin" | "github";
  enabled: boolean;
  files: number;
  bytes: number;
};

export type KeySlot = {
  provider: string;
  label: string;
  envKey: string;
  model: string;
  note: string;
  hasValue: boolean;
  masked: string;
  fromEnv: boolean;
};

/** Сообщение в UI-чате (из БД + эфемерные стриминговые). */
export type UiMessage =
  | { kind: "row"; row: ChatRow }
  | { kind: "status"; id: number; text: string; icon?: string }
  | { kind: "provider"; id: number; provider: string; model: string }
  | { kind: "build"; id: number }
  | { kind: "patches"; id: number; summary: string; patches: ProposedPatch[]; raw: RawPatch[]; provider: string; applied: "pending" | "applied" | "rejected" }
  | { kind: "spec"; id: number; spec: SpecData; notes: string[] }
  | { kind: "skills"; id: number; skills: string[] }
  | { kind: "error"; id: number; message: string };

/* ------------------------------ аккаунты -------------------------------- */

export type PublicUser = {
  id: number;
  email: string;
  name: string;
  provider: string;
  plan: string;
  planName: string;
  planUntil: string | null;
  projectLimit: number;
  chatPerDay: number;
};

export type UsageInfo = {
  projects: number;
  projectLimit: number;
  chatUsedToday: number;
  chatLimit: number;
  plan: string;
};

export type PlanCard = {
  id: string;
  name: string;
  priceLabel: string;
  projectLimit: number;
  chatPerDay: number;
  features: string[];
  highlight?: boolean;
};

export const AGENTS = ["ARCHITECT", "SCOUT", "FLY", "FORGE", "ENGINEER", "CRITIC", "INTEGRATOR"] as const;

export const AGENT_META: Record<string, { label: string; hint: string }> = {
  ARCHITECT: { label: "АРХИТЕКТОР", hint: "Разбирает бриф, строит спецификацию" },
  SCOUT: { label: "РАЗВЕДЧИК", hint: "Ищет готовые решения и модели в сети" },
  FLY: { label: "МОЗГ МУХИ", hint: "LSH-память роя: помнит прошлые решения" },
  FORGE: { label: "КУЗНЕЦ", hint: "Кузнецу недостающие модули с нуля" },
  ENGINEER: { label: "ИНЖЕНЕР", hint: "Генерирует код проекта" },
  CRITIC: { label: "КРИТИК", hint: "QA-проверка и ремонт" },
  INTEGRATOR: { label: "ИНТЕГРАТОР", hint: "Собирает финальный проект" },
};

export const STARTERS = [
  "CLI, который читает CSV с продажами, чистит дубли и пишет JSON-отчёт",
  "Веб-сервис очереди задач с REST API, воркером и дашбордом",
  "Telegram-бот учёта расходов с недельным бюджетом",
  "Парсер цен с ротацией прокси, CSV-экспортом и алертами",
  "REST API библиотеки книг с поиском, рейтингом и отзывами",
  "Микросервис сокращения ссылок со статистикой кликов",
];
