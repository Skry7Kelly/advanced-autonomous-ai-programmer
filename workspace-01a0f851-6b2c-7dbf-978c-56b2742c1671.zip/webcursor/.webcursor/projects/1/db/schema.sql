-- Схема для продакшн-перехода с JSONL на PostgreSQL

CREATE TABLE IF NOT EXISTS users (
  id BIGSERIAL PRIMARY KEY,
  email text,
  password_hash text,
  role text,
  created_at timestamptz default now()
);

CREATE TABLE IF NOT EXISTS sessions (
  id BIGSERIAL PRIMARY KEY,
  user_id bigint,
  token text,
  expires_at timestamptz,
  ip text
);

CREATE TABLE IF NOT EXISTS documents (
  id BIGSERIAL PRIMARY KEY,
  title text,
  source_url text,
  content jsonb,
  hash text
);

CREATE TABLE IF NOT EXISTS events_log (
  id BIGSERIAL PRIMARY KEY,
  actor text,
  action text,
  payload jsonb,
  created_at timestamptz default now()
);
