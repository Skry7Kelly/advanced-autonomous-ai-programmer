import { ProxyAgent, fetch as undiciFetch } from 'undici';

export interface ProxyState { url: string; latencyMs: number; failCount: number; okCount: number; quarantinedUntil: number }

export class RotatingProxyPool {
  private states: ProxyState[] = [];
  private cursor = 0;
  private agents = new Map<string, ProxyAgent>();

  constructor(urls: string[], private readonly quarantineMs = 60000) {
    this.states = urls.map((url) => ({ url, latencyMs: 0, failCount: 0, okCount: 0, quarantinedUntil: 0 }));
  }

  get size(): number { return this.states.length; }

  private agent(url: string): ProxyAgent {
    const cached = this.agents.get(url);
    if (cached) return cached;
    const agent = new ProxyAgent({ uri: url, requestTls: { rejectUnauthorized: false } });
    this.agents.set(url, agent);
    return agent;
  }

  next(): ProxyState | null {
    const now = Date.now();
    const alive = this.states.filter((s) => s.quarantinedUntil < now);
    if (alive.length === 0) return null;
    alive.sort((a, b) => a.failCount - b.failCount || a.latencyMs - b.latencyMs);
    const pick = alive[this.cursor % alive.length];
    this.cursor += 1;
    return pick;
  }

  async fetch(url: string, init: Parameters<typeof undiciFetch>[1] = {}, timeoutMs = 12000): Promise<{ status: number; text: string; via: string }> {
    const attempts = this.states.length + 1;
    let lastError: unknown;
    for (let i = 0; i < attempts; i++) {
      const proxy = this.next();
      const started = Date.now();
      try {
        const res = await undiciFetch(url, {
          ...init,
          signal: AbortSignal.timeout(timeoutMs),
          dispatcher: proxy ? this.agent(proxy.url) : undefined,
        } as Parameters<typeof undiciFetch>[1]);
        const text = await res.text();
        if (proxy) {
          proxy.okCount += 1;
          proxy.latencyMs = Date.now() - started;
        }
        return { status: res.status, text, via: proxy ? proxy.url : 'direct' };
      } catch (error) {
        lastError = error;
        if (proxy) {
          proxy.failCount += 1;
          if (proxy.failCount % 3 === 0) proxy.quarantinedUntil = Date.now() + this.quarantineMs;
        }
      }
    }
    throw lastError instanceof Error ? lastError : new Error('proxy pool exhausted');
  }

  report(): ProxyState[] {
    return [...this.states].sort((a, b) => b.okCount - a.okCount);
  }
}