"use client";

import { useEffect, useRef } from "react";

/**
 * Общие футуристичные фоновые эффекты Svarma:
 * звёздное поле (canvas), аврора-блобы, перспективная сетка «пола»,
 * парящие гексы и виньетка. Используется на лендинге и экране проектов.
 */

export function Starfield() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let w = 0;
    let h = 0;
    type P = { x: number; y: number; r: number; v: number; hue: number; tw: number; ph: number };
    let dots: P[] = [];

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const n = Math.min(130, Math.floor((w * h) / 16000));
      dots = Array.from({ length: n }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: Math.random() * 1.4 + 0.4,
        v: Math.random() * 0.22 + 0.05,
        hue: [166, 199, 258][Math.floor(Math.random() * 3)],
        tw: Math.random() * 2 + 1.2,
        ph: Math.random() * Math.PI * 2,
      }));
    };
    resize();
    window.addEventListener("resize", resize);

    let t = 0;
    const frame = () => {
      t += 0.016;
      ctx.clearRect(0, 0, w, h);
      for (const d of dots) {
        d.y -= d.v;
        if (d.y < -4) {
          d.y = h + 4;
          d.x = Math.random() * w;
        }
        const a = 0.25 + 0.55 * (0.5 + 0.5 * Math.sin(t * d.tw + d.ph));
        ctx.beginPath();
        ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${d.hue}, 85%, 74%, ${a})`;
        ctx.fill();
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);
  return <canvas ref={ref} className="pointer-events-none absolute inset-0 h-full w-full opacity-70" />;
}

function FloatingHex({ className, delay, size }: { className: string; delay: string; size: number }) {
  const id = `hx-${delay}-${size}`.replace(/[^a-z0-9-]/gi, "");
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      className={`animate-float pointer-events-none absolute opacity-[0.13] ${className}`}
      style={{ animationDelay: delay }}
    >
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#5eead4" />
          <stop offset="100%" stopColor="#a78bfa" />
        </linearGradient>
      </defs>
      <path d="M12 2.4 20.4 7.2v9.6L12 21.6 3.6 16.8V7.2z" fill="none" stroke={`url(#${id})`} strokeWidth="0.6" />
      <path d="M12 7 16 9.3v4.4L12 16l-4-2.3V9.3z" fill="none" stroke={`url(#${id})`} strokeWidth="0.4" />
    </svg>
  );
}

export function BackgroundFX() {
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden">
      <div className="animate-aurora-a absolute -left-48 -top-48 h-[34rem] w-[34rem] rounded-full bg-accent/12 blur-[140px]" />
      <div className="animate-aurora-b absolute -right-40 top-1/4 h-[30rem] w-[30rem] rounded-full bg-accent3/12 blur-[140px]" />
      <div
        className="animate-aurora-a absolute bottom-[-10rem] left-1/3 h-[26rem] w-[26rem] rounded-full bg-accent2/8 blur-[120px]"
        style={{ animationDelay: "-6s" }}
      />
      <Starfield />
      <div className="hero-grid-floor animate-grid absolute -bottom-24 left-1/2 h-[46vh] w-[140%] -translate-x-1/2" />
      <FloatingHex className="left-[6%] top-[18%]" delay="-1s" size={120} />
      <FloatingHex className="right-[8%] top-[58%]" delay="-3s" size={90} />
      <FloatingHex className="left-[16%] bottom-[12%]" delay="-2s" size={64} />
      <FloatingHex className="right-[18%] top-[10%]" delay="-4.5s" size={52} />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_35%,#080a10_92%)]" />
    </div>
  );
}
