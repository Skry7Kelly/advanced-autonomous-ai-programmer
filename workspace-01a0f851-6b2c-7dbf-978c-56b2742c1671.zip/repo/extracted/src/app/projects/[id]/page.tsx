import ProjectClient from "@/components/ProjectClient";

export const dynamic = "force-dynamic";

export default async function ProjectPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <ProjectClient projectId={Number(id)} />;
}
