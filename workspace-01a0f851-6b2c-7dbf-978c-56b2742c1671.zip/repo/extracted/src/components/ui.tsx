import type { ReactNode } from "react";

export function Panel({
  title,
  subtitle,
  right,
  children,
  className = "",
}: {
  title?: string;
  subtitle?: string;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`rounded-xl border border-[#1b2531] bg-[#0b1017]/80 backdrop-blur-sm ${className}`}>
      {(title || right) && (
        <header className="flex items-start justify-between gap-3 border-b border-[#1b2531] px-4 py-3">
          <div>
            {title && <h2 className="text-sm font-semibold tracking-wide text-[#a9c3da] uppercase">{title}</h2>}
            {subtitle && <p className="mt-1 text-[11px] leading-relaxed text-[#5f738a]">{subtitle}</p>}
          </div>
          {right}
        </header>
      )}
      <div className="p-4">{children}</div>
    </section>
  );
}

export function Badge({ tone = "slate", children }: { tone?: "slate" | "lime" | "cyan" | "amber" | "red"; children: ReactNode }) {
  const tones: Record<string, string> = {
    slate: "border-[#26344a] bg-[#111a26] text-[#8ba3bb]",
    lime: "border-lime-500/40 bg-lime-500/10 text-lime-300",
    cyan: "border-sky-500/40 bg-sky-500/10 text-sky-300",
    amber: "border-amber-500/40 bg-amber-500/10 text-amber-300",
    red: "border-red-500/40 bg-red-500/10 text-red-300",
  };
  return <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[10px] tracking-wide uppercase ${tones[tone]}`}>{children}</span>;
}

export function Stat({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
      <div className="text-[10px] tracking-wider text-[#5f738a] uppercase">{label}</div>
      <div className="mt-1 text-lg font-semibold text-[#dbe4ee]">{value}</div>
      {hint && <div className="mt-0.5 text-[10px] text-[#4d5f74]">{hint}</div>}
    </div>
  );
}

export function statusTone(status: string): "lime" | "cyan" | "amber" | "red" | "slate" {
  if (status === "done" || status === "ready" || status === "alive" || status === "ok") return "lime";
  if (status === "running" || status === "queued") return "cyan";
  if (status === "warn" || status === "flaky" || status === "no-key" || status === "offline" || status === "empty" || status === "unknown") return "amber";
  if (status === "failed" || status === "dead" || status === "error" || status === "key-error" || status === "unreachable") return "red";
  return "slate";
}
