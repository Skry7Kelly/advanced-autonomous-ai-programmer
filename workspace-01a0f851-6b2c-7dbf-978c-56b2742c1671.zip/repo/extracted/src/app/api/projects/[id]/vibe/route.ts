import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { chats, projects } from "@/db/schema";
import { vibeTurn } from "@/lib/vibe";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(_request: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) return Response.json({ error: "плохой id" }, { status: 400 });
  const rows = await db.select().from(chats).where(eq(chats.projectId, projectId)).orderBy(asc(chats.id));
  return Response.json({ messages: rows });
}

export async function POST(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) return Response.json({ error: "плохой id" }, { status: 400 });
  const [project] = await db.select({ id: projects.id }).from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project) return Response.json({ error: "проект не найден" }, { status: 404 });
  const body = (await request.json().catch(() => ({}))) as { message?: string };
  try {
    const result = await vibeTurn(projectId, body.message ?? "");
    return Response.json(result);
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : String(error) }, { status: 400 });
  }
}
