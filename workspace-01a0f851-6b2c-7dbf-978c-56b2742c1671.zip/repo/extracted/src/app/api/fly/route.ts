import { desc } from "drizzle-orm";
import { db } from "@/db";
import { flyBrains, memories } from "@/db/schema";
import { breedGeneration, ensureFlyBrains, flyTag, genomeOf, getActiveBrain, hashText, tagSimilarity } from "@/lib/fly";
import { evaluateGenome } from "@/lib/fly";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request) {
  await ensureFlyBrains();
  const url = new URL(request.url);
  const query = url.searchParams.get("q") ?? "";
  const brains = await db.select().from(flyBrains).orderBy(desc(flyBrains.fitness)).limit(12);
  const active = await getActiveBrain();
  const memCount = await db.select({ id: memories.id }).from(memories).limit(5000);
  const [best] = brains;

  const demo =
    query.length > 2
      ? (() => {
          const genome = genomeOf(active);
          const a = flyTag(genome, hashText(query, active.inputDim));
          const corpus = [
            "ротация прокси пула при сборе данных",
            "локальная GGUF модель и инференс на CPU",
            "магнет-ссылки и раздача весов моделей",
            "миграции схемы и индексы в Postgres",
            "параллельный пул воркеров с лимитом",
          ];
          const scored = corpus
            .map((text) => ({ text, score: tagSimilarity(a, flyTag(genome, hashText(text, active.inputDim))) }))
            .sort((x, y) => y.score - x.score);
          return { query, top: scored.slice(0, 3), tagSize: a.length };
        })()
      : null;

  return Response.json({
    active: { name: active.name, generation: active.generation, fitness: active.fitness, note: active.note, outputDim: active.outputDim, conn: active.conn, k: active.k },
    population: brains.map((b) => ({ id: b.id, name: b.name, generation: b.generation, fitness: b.fitness, active: b.active, note: b.note })),
    memories: memCount.length,
    bestFitness: best?.fitness ?? 0,
    algorithm: {
      paper: "Dasgupta, Sheehan, Stevens, Navlakha — A neural algorithm for a fundamental computing problem (Science, 2017)",
      idea: "разреженная случайная проекция N→M (≈8x) + winner-take-all → бинарный тег; похожеcть по пересечению тегов",
      genetics: "геном = сиды блоков проекции; скрещивание равномерным кроссовером + мутации; отбор по recall@8 против косинуса на калибровочном корпусе",
    },
    demo,
  });
}

export async function POST(request: Request) {
  let body: { action?: string; generations?: number } = {};
  try {
    body = (await request.json()) as { action?: string; generations?: number };
  } catch {
    body = {};
  }
  await ensureFlyBrains();
  if (body.action !== "breed") {
    return Response.json({ error: "неизвестное действие (доступно: breed)" }, { status: 400 });
  }
  const rounds = Math.min(5, Math.max(1, body.generations ?? 1));
  const history: { generation: number; fitness: number; recall: number; contrast: number; improved: boolean; name: string }[] = [];
  for (let i = 0; i < rounds; i++) {
    const result = await breedGeneration();
    const ev = evaluateGenome(genomeOf(result.child));
    history.push({
      generation: result.child.generation,
      fitness: Number(result.child.fitness.toFixed(4)),
      recall: Number(ev.recall.toFixed(4)),
      contrast: Number(ev.contrast.toFixed(4)),
      improved: result.improved,
      name: result.child.name,
    });
  }
  const brains = await db.select().from(flyBrains).orderBy(desc(flyBrains.fitness)).limit(12);
  return Response.json({ bred: rounds, history, population: brains.map((b) => ({ id: b.id, name: b.name, generation: b.generation, fitness: b.fitness, active: b.active, note: b.note })) });
}
