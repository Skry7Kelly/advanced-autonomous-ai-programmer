import test from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../src/modules/config.js';

test('валидирует и подставляет дефолты', () => {
  const { config, issues } = loadConfig<{ PORT: number; MODE: string }>([
    { key: 'PORT', number: true, def: '8080' },
    { key: 'MODE', enum: ['fast', 'safe'], def: 'safe' },
  ], { PORT: 'abc' });
  assert.equal(config.PORT, 8080); // невалидное значение -> безопасный дефолт
  assert.equal(config.MODE, 'safe');
  assert.equal(issues.length, 1);
});