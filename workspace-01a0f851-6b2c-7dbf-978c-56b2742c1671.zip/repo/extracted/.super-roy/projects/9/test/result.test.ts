import test from 'node:test';
import assert from 'node:assert/strict';
import { attempt, ok, err, partition } from '../src/modules/result.js';

test('attempt ловит исключение', async () => {
  const res = await attempt(async () => { throw new Error('boom'); });
  assert.equal(res.ok, false);
  const good = await attempt(async () => 7);
  assert.equal(good.ok ? good.value : -1, 7);
});

test('partition разделяет результаты', () => {
  const { values, errors } = partition([ok(1), err(new Error('x')), ok(3)]);
  assert.deepEqual(values, [1, 3]);
  assert.equal(errors.length, 1);
});