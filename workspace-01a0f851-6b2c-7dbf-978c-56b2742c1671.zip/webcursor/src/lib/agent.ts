/**
 * Агентный слой Svarma — «мозг» чат-панели IDE.
 *
 * Три режима:
 *  - agent     — Cursor-стиль: модель предлагает патчи (write/delete) с диффами,
 *                пользователь ревьюит и применяет; при пустом проекте запускает полный конвейер роя.
 *  - architect — обсуждение архитектуры: строит спецификацию локально (plan.ts) + уточнения LLM.
 *  - ask       — вопросы о проекте с контекстом файлов.
 *
 * Всё стримится наружу через события (NDJSON по fetch-стриму).
 */
import fs from "node:fs";
import path from "node:path";
import { eq } from "@/db/orm";
import { db } from "@/db";
import { artifacts, chats, events, projects } from "@/db/schema";
import { chat, extractJson } from "@/lib/providers";
import { skillsContextFor } from "@/lib/skills";
import { sha256 } from "@/lib/qa";
import { runPipeline } from "@/lib/pipeline";
import { parseBrief } from "@/lib/brief";
import { buildSpec } from "@/lib/plan";
import type { Spec } from "@/lib/types";

export type PatchAction = "write" | "delete";
export type Patch = { action: PatchAction; path: string; content?: string };

export type DiffLine = { kind: "add" | "del" | "ctx"; text: string };

export type ProposedPatch = {
  action: PatchAction;
  path: string;
  isNew: boolean;
  additions: number;
  deletions: number;
  diff: DiffLine[];
};

export type AgentEvent =
  | { type: "status"; text: string; icon?: string }
  | { type: "provider"; provider: string; model: string }
  | { type: "skills"; skills: string[] }
  | { type: "build-started" }
  | { type: "answer"; text: string }
  | { type: "patches"; summary: string; patches: ProposedPatch[]; raw: Patch[]; provider: string }
  | { type: "spec"; spec: Spec; notes: string[] }
  | { type: "error"; message: string }
  | { type: "done"; result: { mode: string; changed: string[]; provider: string } };

/* ------------------------------- утилиты ------------------------------- */

function langOf(filePath: string): string {
  if (/\.tsx?$/.test(filePath)) return "typescript";
  if (/\.m?[jc]sx?$/.test(filePath)) return "javascript";
  if (filePath.endsWith(".json")) return "json";
  if (filePath.endsWith(".md")) return "markdown";
  if (filePath.endsWith(".css")) return "css";
  if (filePath.endsWith(".html")) return "html";
  if (filePath.endsWith(".py")) return "python";
  if (filePath.endsWith(".sql")) return "sql";
  return "text";
}

function slugPart(text: string): string {
  return (
    text
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 32) || "change"
  );
}

/** Простой построчный LCS-дифф. */
function lineDiff(before: string, after: string): DiffLine[] {
  const a = before.length ? before.split("\n") : [];
  const b = after.length ? after.split("\n") : [];
  const n = a.length;
  const m = b.length;
  // ограничиваем размер, чтобы не взорвать память на больших файлах
  if (n * m > 4_000_000) {
    return [...a.map((text) => ({ kind: "del" as const, text })), ...b.map((text) => ({ kind: "add" as const, text }))];
  }
  const dp: number[][] = Array.from({ length: n + 1 }, () => new Array<number>(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const out: DiffLine[] = [];
  let i = 0;
  let j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) {
      out.push({ kind: "ctx", text: a[i] });
      i += 1;
      j += 1;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      out.push({ kind: "del", text: a[i] });
      i += 1;
    } else {
      out.push({ kind: "add", text: b[j] });
      j += 1;
    }
  }
  while (i < n) {
    out.push({ kind: "del", text: a[i] });
    i += 1;
  }
  while (j < m) {
    out.push({ kind: "add", text: b[j] });
    j += 1;
  }
  return out;
}

function normalizePatchPath(p: string): string | null {
  const clean = p.replace(/^\/+/, "").replace(/\\/g, "/");
  if (!clean || clean.includes("..")) return null;
  return clean;
}

function helperModule(message: string): { path: string; content: string } {
  const name = slugPart(message);
  const pascal = name
    .split("-")
    .filter(Boolean)
    .map((w) => w[0].toUpperCase() + w.slice(1))
    .join("");
  return {
    path: `src/modules/vibe-${name}.ts`,
    content: `/** Сгенерировано vibe-агентом по запросу: ${message.replace(/\*\//g, "").slice(0, 180)} */
export interface ${pascal}Input {
  text: string;
}

export function run${pascal}(input: ${pascal}Input): { ok: true; echo: string; tokens: string[] } {
  const text = String(input?.text ?? "").trim();
  const tokens = text.split(/\\s+/).filter(Boolean);
  return { ok: true, echo: text, tokens };
}

export default { run${pascal} };
`,
  };
}

function builtinPatches(files: Map<string, string>, message: string): { summary: string; patches: Patch[] } {
  const helper = helperModule(message);
  const stamp = new Date().toISOString();
  const logPrev = files.get("VIBELOG.md") ?? "# VIBELOG\n\nИстория правок vibe-агента.\n";
  const patches: Patch[] = [
    { action: "write", path: helper.path, content: helper.content },
    { action: "write", path: "VIBELOG.md", content: `${logPrev.trim()}\n\n## ${stamp}\n\n${message}\n\n- модуль: \`${helper.path}\`\n` },
  ];
  const readme = files.get("README.md");
  if (readme && !readme.includes(helper.path)) {
    patches.push({
      action: "write",
      path: "README.md",
      content: `${readme.trim()}\n\n## Vibe: ${stamp.slice(0, 19)}\n\n${message}\n\nДобавлен модуль \`${helper.path}\`.\n`,
    });
  }
  return {
    summary: `Встроенный движок предлагает добавить рабочий модуль ${helper.path} и запись в VIBELOG.md. Подключите LLM-провайдера (Настройки → Модели), чтобы агент редактировал существующие файлы целиком.`,
    patches,
  };
}

async function persistFiles(projectId: number, files: Map<string, string>) {
  await db.delete(artifacts).where(eq(artifacts.projectId, projectId));
  const rows = [...files.entries()].map(([filePath, content]) => ({
    projectId,
    path: filePath,
    language: langOf(filePath),
    content,
    bytes: Buffer.byteLength(content, "utf8"),
    sha256: sha256(content),
    origin: "generated" as const,
    agent: "ENGINEER" as const,
  }));
  if (rows.length) await db.insert(artifacts).values(rows);
  const workspace = path.join(process.cwd(), ".svarma", "projects", String(projectId));
  fs.rmSync(workspace, { recursive: true, force: true });
  for (const [filePath, content] of files) {
    const target = path.join(workspace, filePath);
    if (!target.startsWith(workspace)) continue;
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, content, "utf8");
  }
}

async function loadProject(projectId: number) {
  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  return project ?? null;
}

/* ------------------------------ режим: agent ----------------------------- */

export async function agentPropose(
  projectId: number,
  message: string,
  onEvent: (e: AgentEvent) => void,
): Promise<void> {
  const text = message.trim();
  if (text.length < 2) throw new Error("пустое сообщение");
  const project = await loadProject(projectId);
  if (!project) throw new Error("проект не найден");

  await db.insert(chats).values({ projectId, role: "user", content: text });

  const artifactRows = await db.select().from(artifacts).where(eq(artifacts.projectId, projectId));

  /* Нет файлов — запускаем полный конвейер роя */
  if (artifactRows.length === 0 && project.status !== "running") {
    await db.insert(chats).values({
      projectId,
      role: "assistant",
      content: "Запускаю полный конвейер роя: АРХИТЕКТОР → РАЗВЕДЧИК → КУЗНЕЦ → ИНЖЕНЕР → КРИТИК → ИНТЕГРАТОР. Файлы начнут появляться в дереве по мере генерации.",
      provider: "swarm",
    });
    await db
      .update(projects)
      .set({ brief: `${project.brief}\n\nVibe: ${text}`, status: "queued", stage: "queued", progress: 0, error: null })
      .where(eq(projects.id, projectId));
    onEvent({ type: "build-started" });
    void runPipeline(projectId);
    onEvent({ type: "done", result: { mode: "build", changed: [], provider: "swarm" } });
    return;
  }

  onEvent({ type: "status", text: "Изучаю файлы проекта…", icon: "scan" });

  const files = new Map(artifactRows.map((r) => [r.path, r.content]));
  const list = [...files.keys()].slice(0, 80).join("\n");
  const relevant = [...files.entries()]
    .map(([p, c]) => ({
      p,
      c,
      score: text.toLowerCase().split(/\s+/).filter((w) => w.length > 3 && p.toLowerCase().includes(w)).length,
    }))
    .sort((a, b) => b.score - a.score || a.p.localeCompare(b.p))
    .slice(0, 6);

  onEvent({ type: "status", text: "Думаю над правками…", icon: "brain" });

  const skillCtx = await skillsContextFor(text);
  if (skillCtx) onEvent({ type: "skills", skills: skillCtx.names });

  const llm = await chat(
    [
      {
        role: "system",
        content:
          'Ты агент веб-IDE Svarma (как Cursor Agent). Верни СТРОГО JSON без пояснений: {"summary":"что сделал по-русски","patches":[{"action":"write"|"delete","path":"относительный путь","content":"полный файл"}]}. Пиши целые рабочие файлы, без TODO и заглушек. Меняй только нужные файлы (обычно 1–4).' +
          (skillCtx?.prompt ?? ""),
      },
      {
        role: "user",
        content: `Проект: ${project.name}\nБриф: ${project.brief.slice(0, 800)}\n\nФайлы:\n${list}\n\nСодержимое ключевых файлов:\n${relevant
          .map((item) => `--- ${item.p} ---\n${item.c.slice(0, 4000)}`)
          .join("\n\n")}\n\nЗапрос пользователя:\n${text}`,
      },
    ],
    { maxTokens: 3500, temperature: 0.2 },
  );

  let summary: string;
  let patches: Patch[];
  let provider = "builtin-engine";

  if (llm) {
    onEvent({ type: "provider", provider: llm.provider, model: llm.model });
    const parsed = extractJson<{ summary?: string; patches?: Patch[] }>(llm.text);
    if (parsed?.patches?.length) {
      summary = parsed.summary ?? `Правки от ${llm.provider}`;
      patches = parsed.patches;
      provider = `${llm.provider}:${llm.model}`;
    } else {
      const built = builtinPatches(files, text);
      summary = `${built.summary}\n\n(Модель ${llm.provider} ответила без JSON-патчей.)`;
      patches = built.patches;
      provider = `${llm.provider}+builtin`;
    }
  } else {
    const built = builtinPatches(files, text);
    summary = built.summary;
    patches = built.patches;
  }

  /* Готовим диффы для ревью */
  const proposed: ProposedPatch[] = [];
  for (const patch of patches) {
    const p = normalizePatchPath(patch.path);
    if (!p) continue;
    if (patch.action === "delete") {
      if (!files.has(p)) continue;
      const diff = files.get(p)!.split("\n").map((l) => ({ kind: "del" as const, text: l }));
      proposed.push({ action: "delete", path: p, isNew: false, additions: 0, deletions: diff.length, diff });
      continue;
    }
    if (typeof patch.content !== "string") continue;
    const before = files.get(p) ?? "";
    const diff = lineDiff(before, patch.content);
    if (diff.every((d) => d.kind === "ctx")) continue; // ничего не изменилось
    proposed.push({
      action: "write",
      path: p,
      isNew: !files.has(p),
      additions: diff.filter((d) => d.kind === "add").length,
      deletions: diff.filter((d) => d.kind === "del").length,
      diff,
    });
  }

  if (proposed.length === 0) {
    const answer = `${summary}\n\nПравок не требуется — файлы уже в нужном состоянии.`;
    await db.insert(chats).values({ projectId, role: "assistant", content: answer, provider });
    onEvent({ type: "answer", text: answer });
    onEvent({ type: "done", result: { mode: "noop", changed: [], provider } });
    return;
  }

  onEvent({ type: "patches", summary, patches: proposed, raw: patches, provider });
  onEvent({ type: "done", result: { mode: "propose", changed: [], provider } });
}

/** Применение отревьюенных патчей (после кнопки «Применить»). */
export async function applyAgentPatches(projectId: number, patches: Patch[], summary: string, provider: string) {
  const project = await loadProject(projectId);
  if (!project) throw new Error("проект не найден");
  const artifactRows = await db.select().from(artifacts).where(eq(artifacts.projectId, projectId));
  const files = new Map(artifactRows.map((r) => [r.path, r.content]));
  const changed: string[] = [];

  for (const patch of patches) {
    const p = normalizePatchPath(patch.path);
    if (!p) continue;
    if (patch.action === "delete") {
      if (files.delete(p)) changed.push(p);
      continue;
    }
    if (typeof patch.content !== "string") continue;
    files.set(p, patch.content);
    changed.push(p);
  }

  await persistFiles(projectId, files);
  await db.insert(chats).values({
    projectId,
    role: "assistant",
    content: `${summary}\n\nИзменены: ${changed.join(", ") || "—"}`,
    provider,
  });
  await db.insert(events).values({
    projectId,
    level: "success",
    agent: "ENGINEER",
    stage: "vibe",
    message: `Vibe: ${changed.length} файл(ов). ${summary.slice(0, 240)}`,
    data: { changed, provider },
  });
  await db
    .update(projects)
    .set({ updatedAt: new Date(), status: "done", stage: "vibe" })
    .where(eq(projects.id, projectId));
  return { changed };
}

/* --------------------------- режим: architect --------------------------- */

export async function architectTurn(
  projectId: number,
  message: string,
  onEvent: (e: AgentEvent) => void,
): Promise<void> {
  const text = message.trim();
  if (!text.length) throw new Error("пустое сообщение");
  const project = await loadProject(projectId);
  if (!project) throw new Error("проект не найден");
  await db.insert(chats).values({ projectId, role: "user", content: text });

  onEvent({ type: "status", text: "АРХИТЕКТОР разбирает задачу…", icon: "architect" });

  const settings = project.settings ?? { targetLanguage: "typescript" };
  const brief = parseBrief(`${project.brief}\n\nОбсуждение: ${text}`, settings.targetLanguage);
  const spec = buildSpec({
    brief,
    sources: [],
    models: [],
    forges: [],
    fly: { brains: 0, generation: 0, fitness: 0 },
    settings: { targetLanguage: settings.targetLanguage, maxAdopt: 0 },
  });

  onEvent({ type: "status", text: "Уточняю детали у LLM (если доступен)…", icon: "brain" });

  const notes: string[] = [];
  const skillCtx = await skillsContextFor(text);
  if (skillCtx) onEvent({ type: "skills", skills: skillCtx.names });
  const llm = await chat(
    [
      {
        role: "system",
        content:
          'Ты архитектор ПО. Верни СТРОГО JSON: {"clarifications":["…"],"extraFeatures":[{"key":"…","title":"…","detail":"…"}],"risks":[{"risk":"…","impact":"low|medium|high","mitigation":"…"}]}. Максимум 4 пункта в массиве. По-русски, кратко.' +
          (skillCtx?.prompt ?? ""),
      },
      { role: "user", content: `Задача: ${project.brief}\nЗапрос: ${text}` },
    ],
    { maxTokens: 900, temperature: 0.3 },
  );

  if (llm) {
    onEvent({ type: "provider", provider: llm.provider, model: llm.model });
    const parsed = extractJson<{ clarifications?: string[] }>(llm.text);
    if (parsed?.clarifications?.length) notes.push(...parsed.clarifications.slice(0, 4));
  } else {
    notes.push("LLM недоступен — спецификация построена встроенным движком (полностью рабочая).");
  }

  await db.insert(chats).values({
    projectId,
    role: "assistant",
    content: `Спецификация обновлена: ${spec.modules.length} модулей, ${spec.endpoints.length} эндпоинтов, ${spec.milestones.length} вех. ${notes.join(" ")}`,
    provider: "architect",
  });

  onEvent({ type: "spec", spec, notes });
  onEvent({ type: "done", result: { mode: "architect", changed: [], provider: llm ? `${llm.provider}:${llm.model}` : "builtin-engine" } });
}

/* ------------------------------ режим: ask ------------------------------ */

export async function askTurn(projectId: number, message: string, onEvent: (e: AgentEvent) => void): Promise<void> {
  const text = message.trim();
  if (!text.length) throw new Error("пустое сообщение");
  const project = await loadProject(projectId);
  if (!project) throw new Error("проект не найден");
  await db.insert(chats).values({ projectId, role: "user", content: text });

  onEvent({ type: "status", text: "Собираю контекст проекта…", icon: "scan" });

  const artifactRows = await db.select().from(artifacts).where(eq(artifacts.projectId, projectId));
  const spec = project.spec;
  const tree = artifactRows.map((r) => `- ${r.path} (${(r.bytes / 1024).toFixed(1)} КБ, ${r.language})`).join("\n");

  const skillCtx = await skillsContextFor(text);
  if (skillCtx) onEvent({ type: "skills", skills: skillCtx.names });

  const answer = await chat(
    [
      {
        role: "system",
        content:
          "Ты ассистент внутри веб-IDE Svarma. Отвечай по-русски, кратко и по делу, с примерами кода где уместно. Ты видишь спецификацию и дерево файлов проекта." +
          (skillCtx?.prompt ?? ""),
      },
      {
        role: "user",
        content: `Проект: ${project.name}\nБриф: ${project.brief.slice(0, 600)}\n${
          spec ? `Спека: ${spec.title} — ${spec.summary}\nМодули: ${spec.modules.map((m) => m.name).join(", ")}\n` : ""
        }Файлы:\n${tree || "(пока пусто)"}\n\nВопрос: ${text}`,
      },
    ],
    { maxTokens: 1200, temperature: 0.3 },
  );

  let content: string;
  let provider = "builtin-engine";
  if (answer) {
    onEvent({ type: "provider", provider: answer.provider, model: answer.model });
    content = answer.text;
    provider = `${answer.provider}:${answer.model}`;
  } else {
    content = [
      "**Встроенный ответ (LLM недоступен):**",
      "",
      `Проект «${project.name}»: ${artifactRows.length} файлов, статус ${project.status}.`,
      spec ? `Архитектура: ${spec.modules.map((m) => `\`${m.name}\``).join(", ")}.` : "Спецификация ещё не построена.",
      "",
      "Структура:",
      "```",
      tree || "(файлов пока нет — запустите сборку)",
      "```",
      "",
      "Подключите модель в Настройках → Модели, чтобы получать подробные ответы.",
    ].join("\n");
  }

  await db.insert(chats).values({ projectId, role: "assistant", content, provider });
  onEvent({ type: "answer", text: content });
  onEvent({ type: "done", result: { mode: "ask", changed: [], provider } });
}

export type ChatMode = "agent" | "architect" | "ask";

export async function runChatTurn(projectId: number, message: string, mode: ChatMode, onEvent: (e: AgentEvent) => void) {
  switch (mode) {
    case "architect":
      return architectTurn(projectId, message, onEvent);
    case "ask":
      return askTurn(projectId, message, onEvent);
    default:
      return agentPropose(projectId, message, onEvent);
  }
}
