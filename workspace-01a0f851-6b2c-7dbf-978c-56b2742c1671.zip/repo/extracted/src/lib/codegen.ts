import type { Spec } from "@/lib/types";
import type { ForgedModule } from "@/lib/forge";

export interface GeneratedFile {
  path: string;
  language: string;
  content: string;
  origin: "generated" | "forged";
}

function j(...lines: string[]): string {
  return lines.join("\n");
}

function pascal(input: string): string {
  return input
    .split(/[^a-zA-Z0-9]+/)
    .filter(Boolean)
    .map((w) => w[0].toUpperCase() + w.slice(1))
    .join("");
}

function snake(name: string): string {
  return name.replace(/([a-z0-9])([A-Z])/g, "$1_$2").replace(/[^a-zA-Z0-9]+/g, "_").toLowerCase();
}

function safeEntityName(name: string): string {
  const sing = name.endsWith("ies") ? name.slice(0, -3) + "y" : name.endsWith("s") ? name.slice(0, -1) : name;
  return pascal(sing);
}

/* --------------------------------- package.json ---------------------------- */
function pkgJson(spec: Spec): string {
  const deps: Record<string, string> = {};
  if (spec.modules.some((m) => m.deps.includes("undici"))) deps.undici = "^7.12.0";
  const dev: Record<string, string> = { typescript: "^5.9.3", tsx: "^4.20.6", "@types/node": "^22.19.15" };
  return JSON.stringify(
    {
      name: spec.slug,
      version: "0.1.0",
      private: true,
      type: "module",
      description: spec.summary.slice(0, 180),
      scripts: {
        start: "tsx src/server.ts",
        dev: "tsx watch src/server.ts",
        cli: "tsx src/cli.ts",
        build: "tsc -p tsconfig.json",
        test: "node --import tsx --test test/*.test.ts",
        doctor: "tsx src/cli.ts doctor",
      },
      dependencies: deps,
      devDependencies: dev,
    },
    null,
    2,
  );
}

/* --------------------------------- core sources ---------------------------- */
function configTs(): string {
  return j(
    "import { loadConfig } from './modules/config.js';",
    "",
    "export interface AppConfig {",
    "  PORT: number;",
    "  LOG_LEVEL: string;",
    "  DATA_DIR: string;",
    "  PROXY_LIST: string;",
    "  RATE_LIMIT_PER_MIN: number;",
    "  LLM_BASE_URL: string;",
    "  LLM_MODEL: string;",
    "}",
    "",
    "const { config, issues } = loadConfig<AppConfig>([",
    "  { key: 'PORT', number: true, def: '8787' },",
    "  { key: 'LOG_LEVEL', enum: ['debug', 'info', 'warn', 'error'], def: 'info' },",
    "  { key: 'DATA_DIR', def: './data' },",
    "  { key: 'PROXY_LIST', def: '' },",
    "  { key: 'RATE_LIMIT_PER_MIN', number: true, def: '120' },",
    "  { key: 'LLM_BASE_URL', def: 'http://127.0.0.1:11434' },",
    "  { key: 'LLM_MODEL', def: '' },",
    "]);",
    "",
    "if (issues.length > 0) {",
    "  console.error('[config] проблемы конфигурации:', issues);",
    "}",
    "",
    "export const appConfig: AppConfig = config;",
  );
}

function loggerTs(): string {
  return j(
    "import { createLogger } from './modules/logger.js';",
    "import { appConfig } from './config.js';",
    "",
    "export const logger = createLogger(appConfig.LOG_LEVEL as 'debug' | 'info' | 'warn' | 'error');",
  );
}

function routerTs(): string {
  return j(
    "import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';",
    "",
    "export interface RouteContext {",
    "  req: IncomingMessage;",
    "  res: ServerResponse;",
    "  method: string;",
    "  path: string;",
    "  params: Record<string, string>;",
    "  query: URLSearchParams;",
    "  body: unknown;",
    "  json: (data: unknown, status?: number) => void;",
    "}",
    "",
    "export type RouteHandler = (ctx: RouteContext) => unknown | Promise<unknown>;",
    "",
    "interface Route { method: string; segments: string[]; handler: RouteHandler }",
    "",
    "export interface Router {",
    "  get: (path: string, handler: RouteHandler) => void;",
    "  post: (path: string, handler: RouteHandler) => void;",
    "  put: (path: string, handler: RouteHandler) => void;",
    "  delete: (path: string, handler: RouteHandler) => void;",
    "  handle: (req: IncomingMessage, res: ServerResponse) => Promise<boolean>;",
    "  listen: (port: number) => Promise<void>;",
    "  routes: () => { method: string; path: string }[];",
    "}",
    "",
    "export function createRouter(options: { onError?: (error: unknown, ctx: RouteContext) => void } = {}): Router {",
    "  const routes: Route[] = [];",
    "",
    "  const add = (method: string) => (path: string, handler: RouteHandler) => {",
    "    routes.push({ method, segments: path.split('/').filter(Boolean), handler });",
    "  };",
    "",
    "  const readBody = async (req: IncomingMessage): Promise<unknown> => {",
    "    const chunks: Buffer[] = [];",
    "    for await (const chunk of req) chunks.push(chunk as Buffer);",
    "    if (chunks.length === 0) return null;",
    "    const raw = Buffer.concat(chunks).toString('utf8');",
    "    try {",
    "      return JSON.parse(raw);",
    "    } catch {",
    "      return raw;",
    "    }",
    "  };",
    "",
    "  const match = (method: string, pathname: string): { route: Route; params: Record<string, string> } | null => {",
    "    const parts = pathname.split('/').filter(Boolean);",
    "    for (const route of routes) {",
    "      if (route.method !== method) continue;",
    "      if (route.segments.length !== parts.length) continue;",
    "      const params: Record<string, string> = {};",
    "      let matched = true;",
    "      for (let i = 0; i < parts.length; i++) {",
    "        const seg = route.segments[i];",
    "        if (seg.startsWith(':')) params[seg.slice(1)] = decodeURIComponent(parts[i]);",
    "        else if (seg !== parts[i]) { matched = false; break; }",
    "      }",
    "      if (matched) return { route, params };",
    "    }",
    "    return null;",
    "  };",
    "",
    "  return {",
    "    get: add('GET'),",
    "    post: add('POST'),",
    "    put: add('PUT'),",
    "    delete: add('DELETE'),",
    "    routes: () => routes.map((r) => ({ method: r.method, path: '/' + r.segments.join('/') })),",
    "    async handle(req, res) {",
    "      const url = new URL(req.url ?? '/', 'http://localhost');",
    "      const found = match(req.method ?? 'GET', url.pathname);",
    "      if (!found) {",
    "        res.writeHead(404, { 'content-type': 'application/json; charset=utf-8' });",
    "        res.end(JSON.stringify({ error: 'not_found', path: url.pathname }));",
    "        return false;",
    "      }",
    "      const ctx: RouteContext = {",
    "        req,",
    "        res,",
    "        method: req.method ?? 'GET',",
    "        path: url.pathname,",
    "        params: found.params,",
    "        query: url.searchParams,",
    "        body: null,",
    "        json: (data, status = 200) => {",
    "          res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });",
    "          res.end(JSON.stringify(data, null, 2));",
    "        },",
    "      };",
    "      try {",
    "        if (ctx.method !== 'GET') ctx.body = await readBody(req);",
    "        const result = await found.route.handler(ctx);",
    "        if (!res.writableEnded) ctx.json(result);",
    "      } catch (error) {",
    "        options.onError?.(error, ctx);",
    "        const message = error instanceof Error ? error.message : String(error);",
    "        const status = /not found|нет записи/.test(message) ? 404 : /валид|обязатель|invalid/.test(message) ? 422 : 500;",
    "        if (!res.writableEnded) ctx.json({ error: message }, status);",
    "      }",
    "      return true;",
    "    },",
    "    listen(port) {",
    "      return new Promise((resolve) => {",
    "        createServer((req, res) => {",
    "          void this.handle(req, res);",
    "        }).listen(port, () => resolve());",
    "      });",
    "    },",
    "  };",
    "}",
  );
}

function storeTs(): string {
  return j(
    "import { join } from 'node:path';",
    "import { JsonlStore } from './modules/json-store.js';",
    "import { appConfig } from './config.js';",
    "",
    "export interface StoredRecord {",
    "  id: string;",
    "  createdAt: string;",
    "  updatedAt: string;",
    "  [key: string]: unknown;",
    "}",
    "",
    "export interface Repository<T extends StoredRecord> {",
    "  create: (input: Omit<T, 'id' | 'createdAt' | 'updatedAt'>) => Promise<T>;",
    "  list: (opts?: { limit?: number; offset?: number; where?: (item: T) => boolean }) => Promise<{ items: T[]; total: number }>;",
    "  get: (id: string) => Promise<T | null>;",
    "  update: (id: string, patch: Partial<T>) => Promise<T | null>;",
    "  remove: (id: string) => Promise<boolean>;",
    "  count: () => Promise<number>;",
    "  file: string;",
    "}",
    "",
    "export function createRepository<T extends StoredRecord>(name: string): Repository<T> {",
    "  const file = join(appConfig.DATA_DIR, name + '.jsonl');",
    "  const store = new JsonlStore<T>(file);",
    "  const newId = (): string => name.slice(0, 3) + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);",
    "",
    "  return {",
    "    file,",
    "    async create(input) {",
    "      const now = new Date().toISOString();",
    "      const record = { ...input, id: newId(), createdAt: now, updatedAt: now } as T;",
    "      await store.append(record);",
    "      return record;",
    "    },",
    "    async list(opts = {}) {",
    "      const all = await store.readAll();",
    "      const filtered = opts.where ? all.filter(opts.where) : all;",
    "      const start = opts.offset ?? 0;",
    "      const items = filtered.slice(start, start + (opts.limit ?? 50));",
    "      return { items, total: filtered.length };",
    "    },",
    "    async get(id) {",
    "      const all = await store.readAll();",
    "      return all.find((item) => item.id === id) ?? null;",
    "    },",
    "    async update(id, patch) {",
    "      const all = await store.readAll();",
    "      let updated: T | null = null;",
    "      const next = all.map((item) => {",
    "        if (item.id !== id) return item;",
    "        updated = { ...item, ...patch, id, updatedAt: new Date().toISOString() } as T;",
    "        return updated;",
    "      });",
    "      if (!updated) return null;",
    "      await store.rewrite(next);",
      "      return updated;",
    "    },",
    "    async remove(id) {",
    "      const all = await store.readAll();",
    "      const next = all.filter((item) => item.id !== id);",
    "      if (next.length === all.length) return false;",
    "      await store.rewrite(next);",
    "      return true;",
    "    },",
    "    async count() {",
    "      return (await store.readAll()).length;",
    "    },",
    "  };",
    "}",
    "",
    "export type AnyRepo = Repository<StoredRecord>;",
  );
}

function entitiesTs(spec: Spec): string {
  const lines: string[] = [
    "import { createRepository, type Repository, type StoredRecord } from './store.js';",
    "",
    "// Сущности выведены из брифа архитектором роя.",
  ];
  const repos: string[] = [];
  for (const table of spec.tables) {
    const entity = safeEntityName(table.name);
    lines.push(`export interface ${entity} extends StoredRecord {`);
    for (const col of table.columns) {
      if (["id", "createdAt", "updatedAt"].includes(col.name)) continue;
      const type = /_at$|date/.test(col.name)
        ? "string"
        : /^is_|^has_|verified|active/.test(col.name)
          ? "boolean"
          : /_id$|count$|size|score|stars|seeds|priority|latency|bytes|total/.test(col.name)
            ? "number"
            : "string";
      lines.push(`  ${col.name}: ${type};`);
    }
    lines.push("}");
    repos.push(`  ${table.name}: createRepository<${entity}>('${table.name}'),`);
  }
  lines.push("", "export const repositories = {", ...repos, "} satisfies Record<string, Repository<StoredRecord>>;", "");
  lines.push("export type RepositoryMap = typeof repositories;");
  return lines.join("\n");
}

function appTs(spec: Spec): string {
  const firstEntity = spec.tables[0]?.name ?? "items";
  const entityVar = safeEntityName(firstEntity);
  const lines: string[] = [
    "import { createRouter, type Router } from './router.js';",
    "import { logger } from './logger.js';",
    "import { appConfig } from './config.js';",
    "import { repositories } from './entities.js';",
    "import { TokenBucketRateLimiter } from './modules/rate-limit.js';",
    "import { retryWithBackoff } from './modules/retry.js';",
    "import { validate } from './modules/validate.js';",
    "import { FlyIndex } from './modules/fly-index.js';",
    "",
    "export interface AppState {",
    "  startedAt: number;",
    "  limiter: TokenBucketRateLimiter;",
    "  memory: FlyIndex;",
    "  jobs: { id: string; kind: string; state: string; startedAt: string }[];",
    "}",
    "",
    "export const state: AppState = {",
    "  startedAt: Date.now(),",
    "  limiter: new TokenBucketRateLimiter(appConfig.RATE_LIMIT_PER_MIN, appConfig.RATE_LIMIT_PER_MIN / 60),",
    "  memory: new FlyIndex({ outputDim: 4096, k: 48 }),",
    "  jobs: [],",
    "};",
    "",
    "const memorySchema = { type: 'object', fields: { q: { type: 'string', min: 1, max: 500 } } } as const;",
    "",
    "function requireObject(body: unknown): Record<string, unknown> {",
    "  if (!body || typeof body !== 'object' || Array.isArray(body)) {",
    "    throw new Error('валидация: ожидается JSON-объект');",
    "  }",
    "  return body as Record<string, unknown>;",
    "}",
    "",
    "export function buildApp(): Router {",
    "  const router = createRouter({ onError: (error, ctx) => logger.error('request failed', { path: ctx.path, error: String(error) }) });",
    "",
    "  router.get('/health', () => ({",
    "    status: 'ok',",
    "    uptimeMs: Date.now() - state.startedAt,",
    "    storage: Object.fromEntries(Object.entries(repositories).map(([name]) => [name, name])),",
    "  }));",
    "",
    "  router.get('/api/tasks', () => ({ items: state.jobs }));",
    "",
    "  router.get('/api/search', async (ctx) => {",
    "    const q = ctx.query.get('q') ?? '';",
    "    if (q.length < 1) throw new Error('валидация: параметр q обязателен');",
    "    const hits = state.memory.search(q, Number(ctx.query.get('limit') ?? 10));",
    "    return { results: hits, query: q };",
    "  });",
    "",
    "  router.get('/api/memory', async (ctx) => {",
    "    const issues = validate({ q: ctx.query.get('q') ?? '' }, memorySchema);",
    "    if (issues.length > 0) throw new Error('валидация: ' + issues.map((i) => i.path + ' ' + i.message).join('; '));",
    "    return { items: state.memory.search(ctx.query.get('q') ?? '', 8) };",
    "  });",
    "",
    "  router.post('/api/memory', async (ctx) => {",
    "    const body = requireObject(ctx.body);",
    "    const text = String(body.text ?? '');",
    "    if (text.length < 3) throw new Error('валидация: text обязателен');",
    "    state.memory.add(String(body.id ?? 'm_' + Date.now().toString(36)), text, body.meta ?? null);",
    "    return { ok: true, size: state.memory.size };",
    "  });",
    "",
    "  router.post('/api/ask', async (ctx) => {",
    "    const body = requireObject(ctx.body);",
    "    const question = String(body.question ?? '');",
    "    if (question.length < 3) throw new Error('валидация: question обязателен');",
    "    const context = state.memory.search(question, 4).map((h) => h.text).join('\\n');",
    "    const answer = await retryWithBackoff(async () => {",
    "      const res = await fetch(appConfig.LLM_BASE_URL.replace(/\\/$/, '') + '/api/generate', {",
    "        method: 'POST',",
    "        headers: { 'content-type': 'application/json' },",
    "        body: JSON.stringify({ model: appConfig.LLM_MODEL || 'qwen2.5-coder:7b', prompt: 'Контекст:\\n' + context + '\\n\\nВопрос: ' + question, stream: false }),",
    "      });",
    "      if (!res.ok) throw new Error(String(res.status) + ' llm unavailable');",
    "      const data = (await res.json()) as { response?: string };",
    "      return data.response ?? '';",
    "    }, { retries: 2, timeoutMs: 60000 });",
    "    return { answer, provider: appConfig.LLM_BASE_URL };",
    "  });",
    "",
    "  // --- CRUD по каждой сущности из спецификации ---",
  ];

  for (const table of spec.tables) {
    const path = snake(table.name).replace(/_log$/, "");
    const repo = `repositories.${snake(table.name)}`;
    lines.push(`  router.get('/api/${path}', async (ctx) => {`);
    lines.push("    const limit = Math.min(200, Number(ctx.query.get('limit') ?? 50));");
    lines.push("    const offset = Math.max(0, Number(ctx.query.get('offset') ?? 0));");
    lines.push(`    return ${repo}.list({ limit, offset });`);
    lines.push("  });");
    lines.push("");
    lines.push(`  router.post('/api/${path}', async (ctx) => {`);
    lines.push("    if (!state.limiter.tryTake('write')) throw new Error('rate limit: слишком много запросов');");
    lines.push("    const body = requireObject(ctx.body);");
    lines.push(`    const created = await ${repo}.create(body as never);`);
    lines.push(`    state.memory.add(created.id, JSON.stringify(created).slice(0, 1500), { kind: '${path}' });`);
    lines.push("    return { item: created };");
    lines.push("  });");
    lines.push("");
    lines.push(`  router.get('/api/${path}/:id', async (ctx) => {`);
    lines.push(`    const item = await ${repo}.get(ctx.params.id);`);
    lines.push("    if (!item) throw new Error('not found');");
    lines.push("    return { item };");
    lines.push("  });");
    lines.push("");
    lines.push(`  router.delete('/api/${path}/:id', async (ctx) => {`);
    lines.push(`    const ok = await ${repo}.remove(ctx.params.id);`);
    lines.push("    if (!ok) throw new Error('not found');");
    lines.push("    return { ok: true };");
    lines.push("  });");
    lines.push("");
  }

  // --- фичевые эндпоинты: реальная логика, а не болванки ---
  if (spec.brief.features.some((f) => f.key === "analytics")) {
    lines.push("  router.get('/api/stats', async () => {");
    lines.push("    const totals: Record<string, number> = {};");
    lines.push("    for (const [name, repo] of Object.entries(repositories)) {");
    lines.push("      totals[name] = await repo.count();");
    lines.push("    }");
    lines.push("    return { totals, uptimeMs: Date.now() - state.startedAt, memorySize: state.memory.size, jobs: state.jobs.length };");
    lines.push("  });");
  }

  if (spec.brief.features.some((f) => f.key === "proxy")) {
    lines.push("  router.get('/api/proxies', () => ({");
    lines.push("    items: (appConfig.PROXY_LIST ? appConfig.PROXY_LIST.split(',').map((u) => u.trim()).filter(Boolean) : []).map((url) => ({ url, protocol: url.split(':')[0] })),");
    lines.push("    hint: 'проверьте пул командой: npm run cli -- check-proxies',");
    lines.push("  }));");
  }

  if (spec.brief.features.some((f) => f.key === "scraper")) {
    lines.push("  router.post('/api/crawl', async (ctx) => {");
    lines.push("    const body = requireObject(ctx.body);");
    lines.push("    const seeds = Array.isArray(body.seeds) ? body.seeds.map(String).slice(0, 50) : [];");
    lines.push("    if (seeds.length === 0) throw new Error('валидация: seeds обязателен');");
    lines.push("    const job = { id: 'job_' + Date.now().toString(36), kind: 'crawl', state: 'running', startedAt: new Date().toISOString() };");
    lines.push("    state.jobs.unshift(job);");
    lines.push("    const { results, errors } = await mapPool(seeds, 3, async (seed) => {");
    lines.push("      const res = await retryWithBackoff(async () => fetch(seed, { signal: AbortSignal.timeout(15000) }), { retries: 2, baseMs: 200 });");
    lines.push("      const text = await res.text();");
    lines.push("      return { seed, status: res.status, bytes: text.length, title: ((text.match(/<title>([^<]{0,140})/i) ?? [])[1] ?? '').trim() };");
    lines.push("    });");
    lines.push("    job.state = errors.length === 0 ? 'done' : 'partial';");
    lines.push("    return { job, results, failed: errors.length };");
    lines.push("  });");
  }

  if (spec.brief.features.some((f) => f.key === "models") || spec.brief.integrations.includes("pirateface")) {
    lines.push("  router.get('/api/models', async () => {");
    lines.push("    const repoMap = repositories as unknown as Record<string, { list: (o: { limit: number }) => Promise<{ items: unknown[] }> }>;");
    lines.push("    const repo = repoMap['models'];");
    lines.push("    if (repo) return { source: 'storage', items: (await repo.list({ limit: 100 })).items };");
    lines.push("    return { source: 'config', items: [{ name: appConfig.LLM_MODEL || 'не настроено', endpoint: appConfig.LLM_BASE_URL }] };");
    lines.push("  });");
  }

  lines.push(
    "",
    "  router.get('/api/routes', () => ({ routes: router.routes() }));",
    "  return router;",
    "}",
  );
  return lines.join("\n");
}

function cliTs(spec: Spec): string {
  return j(
    "import { createLogger } from './modules/logger.js';",
    "import { parseArgs, helpText } from './modules/cli-args.js';",
    "import { attempt } from './modules/result.js';",
    "import { appConfig } from './config.js';",
    "import { repositories } from './entities.js';",
    "import { buildApp, state } from './app.js';",
    "",
    "const log = createLogger(appConfig.LOG_LEVEL as 'debug' | 'info' | 'warn' | 'error', { component: 'cli' });",
    "",
    "const COMMANDS = [",
    "  { command: 'start', description: 'поднять HTTP-сервис', flags: ['--port 8787'] },",
    "  { command: 'doctor', description: 'проверить конфигурацию и хранилище' },",
    "  { command: 'import <файл>', description: 'импорт JSONL в хранилище' },",
    "  { command: 'export <файл>', description: 'экспорт хранилища в JSONL' },",
    ...(spec.models.length > 0
      ? ["  { command: 'pull-models', description: 'показать команды скачивания локальных моделей' },"]
      : []),
    "];",
    "",
    "async function doctor(): Promise<void> {",
    "  log.info('конфигурация', { port: appConfig.PORT, dataDir: appConfig.DATA_DIR, proxy: appConfig.PROXY_LIST ? 'задан' : 'не задан' });",
    "  for (const [name, repo] of Object.entries(repositories)) {",
    "    const res = await attempt(async () => repo.count());",
    "    log.info('хранилище ' + name, res.ok ? { file: repo.file, records: res.value } : { error: res.error.message });",
    "  }",
    "  const memory = state.memory.search('проверка памяти', 1);",
    "  log.info('память роя отвечает', { size: state.memory.size, probe: memory.length });",
    "}",
    "",
    "async function importFile(path: string): Promise<void> {",
    "  const { readFile } = await import('node:fs/promises');",
    "  const raw = await readFile(path, 'utf8');",
    "  const name = Object.keys(repositories)[0];",
    "  const repo = repositories[name as keyof typeof repositories];",
    "  let count = 0;",
    "  for (const line of raw.split('\\n').filter(Boolean)) {",
    "    try {",
    "      await repo.create(JSON.parse(line));",
    "      count += 1;",
    "    } catch (error) {",
    "      log.warn('строка пропущена', { error: String(error) });",
    "    }",
    "  }",
    "  log.info('импорт завершён', { file: path, imported: count, target: name });",
    "}",
    "",
    "async function exportFile(path: string): Promise<void> {",
    "  const { writeFile } = await import('node:fs/promises');",
    "  const name = Object.keys(repositories)[0];",
    "  const repo = repositories[name as keyof typeof repositories];",
    "  const { items } = await repo.list({ limit: 10000 });",
    "  await writeFile(path, items.map((i) => JSON.stringify(i)).join('\\n'), 'utf8');",
    "  log.info('экспорт завершён', { file: path, records: items.length });",
    "}",
    "",
    "export async function main(argv: string[]): Promise<void> {",
    "  const parsed = parseArgs(argv);",
    "  switch (parsed.command) {",
    "    case 'start': {",
    "      const port = Number(parsed.flags.port ?? appConfig.PORT);",
    "      const app = buildApp();",
    "      await app.listen(port);",
    "      log.info('сервис запущен', { port, routes: app.routes().length });",
    "      break;",
    "    }",
    "    case 'doctor':",
    "      await doctor();",
    "      break;",
    "    case 'import':",
    "      await importFile(parsed.positionals[0] ?? 'data/import.jsonl');",
    "      break;",
    "    case 'export':",
    "      await exportFile(parsed.positionals[0] ?? 'data/export.jsonl');",
    "      break;",
    ...(spec.models.length
      ? [
          "    case 'pull-models':",
          ...spec.models.slice(0, 3).map((m) => `      console.log('${m.cmd.replace(/"/g, "\\\"")}');`),
          "      break;",
        ]
      : []),
    "    default:",
    "      console.log(helpText('" + spec.title.replace(/'/g, "") + "', COMMANDS));",
    "      break;",
    "  }",
    "}",
    "",
    "if (process.argv[1] && process.argv[1].endsWith('cli.ts')) {",
    "  await main(process.argv.slice(2));",
    "}",
  );
}

function serverTs(): string {
  return j(
    "import { main } from './cli.js';",
    "",
    "const argv = process.argv.slice(2);",
    "await main(argv.length > 0 ? argv : ['start']);",
  );
}

function schemaSql(spec: Spec): string {
  const lines = ["-- Схема для продакшн-перехода с JSONL на PostgreSQL", ""];
  for (const table of spec.tables) {
    lines.push(`CREATE TABLE IF NOT EXISTS ${table.name} (`);
    lines.push(
      table.columns
        .map((c) => `  ${c.name} ${c.type.toUpperCase().includes("PRIMARY") ? "BIGSERIAL PRIMARY KEY" : c.type}`)
        .join(",\n"),
    );
    lines.push(");", "");
  }
  return lines.join("\n");
}

function readme(spec: Spec, forges: ForgedModule[]): string {
  const lines: string[] = [
    `# ${spec.title}`,
    "",
    spec.summary,
    "",
    "> Проект спроектирован и собран роем ИИ-агентов SUPER ROY. Архитектура продумана до файлов, модули написаны, тесты приложены.",
    "",
    "## Быстрый старт",
    "",
    "```bash",
    "npm install",
    "cp .env.example .env",
    "npm run start          # HTTP-сервис на http://localhost:8787",
    "npm run cli -- doctor  # проверка конфигурации и хранилища",
    "npm test               # тесты на критические пути",
    "```",
    "",
    "## Что уже работает",
    "",
  ];
  spec.modules.forEach((m) => lines.push(`- **${m.name}** (${m.path}) — ${m.purpose}`));
  lines.push("", "## Эндпоинты", "", "| Метод | Путь | Назначение |", "| --- | --- | --- |");
  spec.endpoints.forEach((e) => lines.push(`| ${e.method} | \`${e.path}\` | ${e.purpose} |`));
  lines.push("", "## Хранилище", "");
  spec.tables.forEach((t) => lines.push(`### ${t.name}\n\n${t.reason}\n\n${t.columns.map((c) => `- \`${c.name}\` ${c.type}${c.note ? " — " + c.note : ""}`).join("\n")}\n`));
  lines.push("## CLI", "");
  spec.cli.forEach((c) => lines.push(`- \`${c.command}\` — ${c.purpose}`));
  if (spec.models.length) {
    lines.push("", "## Локальные модели (PirateFace.co)", "", "Веса берём из суверенного индекса: checksums + магниты, качаем и гоняем локально без облака.", "");
    spec.models.forEach((m) => lines.push(`### ${m.name}\n\n- размер: ${m.sizeGB} GB, сидов: ${m.seeds}\n- роль: ${m.role}\n- команда: \`${m.cmd}\`\n`));
    lines.push("Либо одной командой: `bash scripts/pull-models.sh` (нужен `aria2c`).");
  }
  if (spec.integrations.length) {
    lines.push("", "## Внедрённые репозитории", "", "| Репозиторий | ⭐ | Зачем |", "| --- | --- | --- |");
    spec.integrations.forEach((i) => lines.push(`| [${i.name}](${i.url}) | ${i.stars} | ${i.why} |`));
  }
  lines.push("", "## Выкованные модули (не существовали в открытом виде)", "");
  forges.forEach((f) => lines.push(`### ${f.capability} → \`${f.name}\`\n\n${f.rationale}\n\n\`\`\`ts\n${f.code.split("\n").slice(0, 14).join("\n")}\n…\n\`\`\`\n`));
  lines.push(
    "",
    "## Ускорение мышления: мозг мухи",
    "",
    spec.fly.note,
    "",
    `- мозгов в популяции: ${spec.fly.brains}, поколение: ${spec.fly.generation}, fitness: ${spec.fly.fitness}`,
    ...spec.fly.accelerations.map((a) => `- ${a}`),
    "",
    "## Риски и как они закрыты",
    "",
    "| Риск | Влияние | Митигация |",
    "| --- | --- | --- |",
  );
  spec.risks.forEach((r) => lines.push(`| ${r.risk} | ${r.impact} | ${r.mitigation} |`));
  lines.push("", "## Окружение", "", "Смотрите `.env.example`. Все секреты — только через переменные окружения.", "", "## Лицензия", "", "MIT");
  return lines.join("\n");
}

function architectureDoc(spec: Spec): string {
  return j(
    `# Архитектура: ${spec.title}`,
    "",
    "## Слои",
    "",
    "1. **Вход** — HTTP-роутер (`src/router.ts`) и CLI (`src/cli.ts`).",
    "2. **Приложение** — `src/app.ts`: маршруты, валидация, лимиты, память.",
    "3. **Домен** — `src/entities.ts`: типы и репозитории сущностей.",
    "4. **Хранилище** — `src/store.ts` + `src/modules/json-store.ts` (JSONL, можно заменить на Postgres по `db/schema.sql`).",
    "5. **Модули роя** — `src/modules/*`: кузница собирает недостающие блоки.",
    "",
    "## Поток данных",
    "",
    "```",
    "клиент → роутер → валидатор → лимитер → обработчик → репозиторий → JSONL",
    "                          ↘ память (FlyIndex) → поиск/рекомендации",
    "```",
    "",
    "## Модули",
    "",
    ...spec.modules.map((m) => `- \`${m.path}\` — ${m.purpose}. API: ${m.publicApi.join(", ")}`),
    "",
    "## Этапы",
    "",
    ...spec.milestones.map((m) => `${m.index}. **${m.title}** — ${m.tasks.join("; ")}. Готово, когда: ${m.doneWhen}`),
    "",
    "## Цели",
    "",
    ...spec.goals.map((g) => `- ${g}`),
    "",
    "## Не делаем",
    "",
    ...spec.nonGoals.map((g) => `- ${g}`),
    "",
    "## Ненаписанные (выкованные) части",
    "",
    ...spec.modules.filter((m) => m.origin === "forged").map((m) => `- ${m.name}: ${m.purpose}`),
  );
}

function researchDoc(spec: Spec, sources: { title: string; url: string; subtitle: string; metric: number; provider: string; score: number }[]): string {
  return j(
    `# Исследование источников для «${spec.title}»`,
    "",
    "Разведчик роя обошёл PirateFace.co (индекс суверенных моделей), GitHub, npm, Hacker News и StackOverflow.",
    "",
    "## Найденные репозитории и материалы",
    "",
    "| Источник | Название | Метрика | Смысл |",
    "| --- | --- | --- | --- |",
    ...sources.slice(0, 40).map((s) => `| ${s.provider} | [${s.title}](${s.url}) | ${s.metric} | ${s.subtitle.slice(0, 120)} |`),
    "",
    "## Локальные модели",
    "",
    ...(spec.models.length
      ? spec.models.map((m) => `- **${m.name}** — ${m.sizeGB} GB, ${m.seeds} сидов. \`${m.cmd}\``)
      : ["- Модели не найдены: используем встроенный движок и облачные бесплатные модели."]),
    "",
    "## Что внедряем",
    "",
    ...(spec.integrations.length
      ? spec.integrations.map((i) => `- [${i.name}](${i.url}) — ${i.why}. Подключение: \`${i.install}\``)
      : ["- Готовых репозиториев под задачу не нашлось подходящих — всё нужное выковано в `src/modules/`."]),
  );
}

function envExample(spec: Spec): string {
  return j(
    "# Конфигурация проекта " + spec.title,
    "PORT=8787",
    "LOG_LEVEL=info",
    "DATA_DIR=./data",
    "RATE_LIMIT_PER_MIN=120",
    "",
    "# Локальная LLM (Ollama / llama.cpp server)",
    "LLM_BASE_URL=http://127.0.0.1:11434",
    "LLM_MODEL=qwen2.5-coder:7b",
    "",
    "# Прокси (через запятую) — для обхода блокировок при сборе данных",
    "PROXY_LIST=",
    ...(spec.models.length ? ["", "# Качаем веса локально: bash scripts/pull-models.sh"] : []),
  );
}

function pullModelsScript(spec: Spec): string {
  return j(
    "#!/usr/bin/env bash",
    "# Скачивание локальных моделей из индекса PirateFace.co",
    "set -euo pipefail",
    "mkdir -p models",
    ...spec.models.map((m) => `echo "== ${m.name} (${m.sizeGB} GB, ${m.seeds} сидов)"; aria2c --dir=models --seed-ratio=1.0 --select-file=1-99 "${m.magnet}" || echo "не удалось скачать ${m.name}"`),
    'echo "Готово. Запуск: llama-server -m models/<файл>.gguf --port 8080  (или ollama create)"',
  );
}

function proxyCheckScript(): string {
  return j(
    "#!/usr/bin/env node",
    "// Проверка пула прокси: печатает живые с латентностью",
    "const list = (process.env.PROXY_LIST ?? '').split(',').map((s) => s.trim()).filter(Boolean);",
    "if (list.length === 0) {",
    "  console.log('PROXY_LIST пуст — работаем напрямую');",
    "  process.exit(0);",
    "}",
    "for (const proxy of list) {",
    "  const started = Date.now();",
    "  try {",
    "    const { ProxyAgent, fetch } = await import('undici');",
    "    const res = await fetch('https://api.github.com/zen', { dispatcher: new ProxyAgent(proxy), signal: AbortSignal.timeout(8000) });",
    "    console.log(proxy, res.ok ? 'OK' : 'FAIL ' + res.status, (Date.now() - started) + 'ms');",
    "  } catch (error) {",
    "    console.log(proxy, 'DEAD', String(error).slice(0, 60));",
    "  }",
    "}",
  );
}

function dockerfile(): string {
  return j(
    "FROM node:22-alpine",
    "WORKDIR /app",
    "COPY package.json tsconfig.json ./",
    "COPY src ./src",
    "RUN npm install --no-audit --no-fund",
    "ENV PORT=8787",
    "EXPOSE 8787",
    "HEALTHCHECK --interval=30s --timeout=5s CMD wget -qO- http://localhost:8787/health || exit 1",
    'CMD ["npm", "run", "start"]',
  );
}

function compose(spec: Spec): string {
  return j(
    "services:",
    `  ${spec.slug.replace(/-/g, "_")}:`,
    "    build: .",
    "    ports:",
    '      - "8787:8787"',
    "    environment:",
    "      LOG_LEVEL: info",
    "      DATA_DIR: /app/data",
    "    volumes:",
    "      - ./data:/app/data",
  );
}

function makefile(): string {
  return j(
    ".PHONY: start dev test build doctor",
    "start:",
    "\tnpm run start",
    "dev:",
    "\tnpm run dev",
    "test:",
    "\tnpm test",
    "build:",
    "\tnpm run build",
    "doctor:",
    "\tnpm run cli -- doctor",
  );
}

function apiTest(spec: Spec): string {
  const first = snake(spec.tables[0]?.name ?? "items");
  return j(
    "import test from 'node:test';",
    "import assert from 'node:assert/strict';",
    "import { buildApp, state } from '../src/app.js';",
    "",
    "function makeReq(method: string, path: string, body?: unknown) {",
    "  const headers: Record<string, string> = { host: 'localhost' };",
    "  if (body !== undefined) headers['content-length'] = String(JSON.stringify(body).length);",
    "  return { method, url: path, headers, async *[Symbol.asyncIterator]() { if (body !== undefined) yield Buffer.from(JSON.stringify(body)); } };",
    "}",
    "",
    "function makeRes() {",
    "  const chunks: string[] = [];",
    "  return {",
    "    chunks,",
    "    statusCode: 200,",
    "    writableEnded: false,",
    "    writeHead(code: number) { this.statusCode = code; },",
    "    end(text?: string) { if (text) chunks.push(text); this.writableEnded = true; },",
    "    text() { return chunks.join(''); },",
    "  };",
    "}",
    "",
    "test('GET /health отвечает ok', async () => {",
    "  const app = buildApp();",
    "  const res = makeRes();",
    "  await app.handle(makeReq('GET', '/health') as never, res as never);",
    "  const parsed = JSON.parse(res.text());",
    "  assert.equal(parsed.status, 'ok');",
    "});",
    "",
    "test('создание и чтение записи', async () => {",
    "  const app = buildApp();",
    "  const created = makeRes();",
    `  await app.handle(makeReq('POST', '/api/${first}', { title: 'проверка' }) as never, created as never);`,
    "  const item = JSON.parse(created.text()).item;",
    "  assert.ok(item.id);",
    "  const read = makeRes();",
    `  await app.handle(makeReq('GET', '/api/${first}/' + item.id) as never, read as never);`,
    "  assert.equal(JSON.parse(read.text()).item.id, item.id);",
    "});",
    "",
    "test('валидация отклоняет мусор', async () => {",
    "  const app = buildApp();",
    "  const res = makeRes();",
    "  await app.handle(makeReq('GET', '/api/memory?q=') as never, res as never);",
    "  assert.equal(res.statusCode, 422);",
    "});",
    "",
    "test('память роя находит по смыслу', async () => {",
    "  state.memory.add('note1', 'ротация прокси пула для парсинга');",
    "  const hits = state.memory.search('прокси ротация при парсинге', 2);",
    "  assert.ok(hits.length >= 1);",
    "});",
  );
}

function storeTest(): string {
  return j(
    "import test from 'node:test';",
    "import assert from 'node:assert/strict';",
    "import { mkdtemp } from 'node:fs/promises';",
    "import { tmpdir } from 'node:os';",
    "import { join } from 'node:path';",
    "import { createRepository, type StoredRecord } from '../src/store.js';",
    "",
    "test('JSONL-хранилище пишет и читает', async () => {",
    "  process.env.DATA_DIR = await mkdtemp(join(tmpdir(), 'store-'));",
    "  const repo = createRepository<StoredRecord & { title: string }>('tasks');",
    "  const created = await repo.create({ title: 'первая' });",
    "  const read = await repo.get(created.id);",
    "  assert.equal(read?.title, 'первая');",
    "  const removed = await repo.remove(created.id);",
    "  assert.equal(removed, true);",
    "});",
  );
}

/* --------------------------------- сборка ---------------------------------- */

export function generateProject(spec: Spec, forges: ForgedModule[], sources: { title: string; url: string; subtitle: string; metric: number; provider: string; score: number }[]): GeneratedFile[] {
  const files: GeneratedFile[] = [
    { path: "package.json", language: "json", content: pkgJson(spec), origin: "generated" },
    { path: "tsconfig.json", language: "json", content: JSON.stringify({ compilerOptions: { target: "ES2022", module: "NodeNext", moduleResolution: "NodeNext", strict: true, esModuleInterop: true, skipLibCheck: true, outDir: "dist", types: ["node"] }, include: ["src/**/*.ts", "test/**/*.ts"] }, null, 2), origin: "generated" },
    { path: "src/config.ts", language: "typescript", content: configTs(), origin: "generated" },
    { path: "src/logger.ts", language: "typescript", content: loggerTs(), origin: "generated" },
    { path: "src/router.ts", language: "typescript", content: routerTs(), origin: "generated" },
    { path: "src/store.ts", language: "typescript", content: storeTs(), origin: "generated" },
    { path: "src/entities.ts", language: "typescript", content: entitiesTs(spec), origin: "generated" },
    { path: "src/app.ts", language: "typescript", content: appTs(spec), origin: "generated" },
    { path: "src/cli.ts", language: "typescript", content: cliTs(spec), origin: "generated" },
    { path: "src/server.ts", language: "typescript", content: serverTs(), origin: "generated" },
    { path: "db/schema.sql", language: "sql", content: schemaSql(spec), origin: "generated" },
    { path: "test/api.test.ts", language: "typescript", content: apiTest(spec), origin: "generated" },
    { path: "test/store.test.ts", language: "typescript", content: storeTest(), origin: "generated" },
    { path: "README.md", language: "markdown", content: readme(spec, forges), origin: "generated" },
    { path: "docs/ARCHITECTURE.md", language: "markdown", content: architectureDoc(spec), origin: "generated" },
    { path: "docs/RESEARCH.md", language: "markdown", content: researchDoc(spec, sources), origin: "generated" },
    { path: "docs/ROADMAP.md", language: "markdown", content: spec.milestones.map((m) => `# Этап ${m.index}: ${m.title}\n\n${m.tasks.map((t) => `- [ ] ${t}`).join("\n")}\n\n**Готово, когда:** ${m.doneWhen}\n`).join("\n"), origin: "generated" },
    { path: ".env.example", language: "ini", content: envExample(spec), origin: "generated" },
    { path: ".gitignore", language: "text", content: j("node_modules/", "dist/", "data/", "models/", ".env"), origin: "generated" },
    { path: "Makefile", language: "makefile", content: makefile(), origin: "generated" },
    { path: "Dockerfile", language: "dockerfile", content: dockerfile(), origin: "generated" },
  ];
  if (spec.models.length > 0) {
    files.push({ path: "scripts/pull-models.sh", language: "bash", content: pullModelsScript(spec), origin: "generated" });
  }
  if (spec.brief.features.some((f) => f.key === "proxy")) {
    files.push({ path: "scripts/check-proxies.mjs", language: "javascript", content: proxyCheckScript(), origin: "generated" });
  }
  if (spec.brief.integrations.includes("postgres")) {
    files.push({ path: "docker-compose.yml", language: "yaml", content: compose(spec), origin: "generated" });
  }
  for (const forge of forges) {
    files.push({ path: `src/modules/${forge.capability}.ts`, language: "typescript", content: forge.code, origin: "forged" });
    // тесты кузницы пишутся относительно src/modules/, исправляем пути импортов
    files.push({
      path: `test/${forge.capability}.test.ts`,
      language: "typescript",
      content: forge.testCode.replace(/'\.\.\/src\/([a-z0-9-]+)\.js'/g, (_m, name: string) => `'../src/modules/${name}.js'`),
      origin: "forged",
    });
    files.push({ path: `docs/modules/${forge.capability}.md`, language: "markdown", content: `${forge.doc}\n\n> ${forge.rationale}\n`, origin: "forged" });
  }
  return files;
}
