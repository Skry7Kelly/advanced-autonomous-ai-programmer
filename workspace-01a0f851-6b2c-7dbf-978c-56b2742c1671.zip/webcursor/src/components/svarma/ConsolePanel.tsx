"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Icon } from "./icons";
import { fmtTime } from "./api";
import { AGENTS, AGENT_META, type EventRow, type QaData, type TaskRow } from "./types";

const LEVEL_COLORS: Record<string, string> = {
  info: "text-ink-300",
  warn: "text-warn",
  error: "text-danger",
  success: "text-ok",
};

export default function ConsolePanel({
  events,
  tasks,
  qa,
  tab,
  setTab,
  agentFilter,
  setAgentFilter,
  onClose,
  onOpenFile,
}: {
  events: EventRow[];
  tasks: TaskRow[];
  qa: QaData | null;
  tab: "console" | "tasks";
  setTab: (t: "console" | "tasks") => void;
  agentFilter: string | null;
  setAgentFilter: (a: string | null) => void;
  onClose: () => void;
  onOpenFile: (path: string) => void;
}) {
  const [autoScroll, setAutoScroll] = useState(true);
  const listRef = useRef<HTMLDivElement>(null);

  const filtered = useMemo(() => (agentFilter ? events.filter((e) => e.agent === agentFilter) : events), [events, agentFilter]);

  useEffect(() => {
    if (autoScroll && tab === "console" && listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [filtered.length, autoScroll, tab]);

  const doneTasks = tasks.filter((t) => t.status === "done").length;

  return (
    <div className="flex h-56 shrink-0 flex-col border-t border-ink-800 bg-ink-950">
      {/* заголовок */}
      <div className="flex h-8 shrink-0 items-center gap-1 border-b border-ink-800 px-2">
        {(
          [
            ["console", "Консоль роя", "terminal"],
            ["tasks", `Задачи${tasks.length ? ` · ${doneTasks}/${tasks.length}` : ""}`, "check"],
          ] as const
        ).map(([id, label, icon]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-[11px] font-medium transition-colors ${
              tab === id ? "bg-ink-800 text-ink-50" : "text-ink-400 hover:bg-ink-880 hover:text-ink-200"
            }`}
          >
            <Icon name={icon} size={12} />
            {label}
          </button>
        ))}

        {qa ? (
          <span className={`chip ml-2 ${qa.score >= 80 ? "!border-ok/40 !text-ok" : "!border-warn/40 !text-warn"}`} title={qa.checks.join(" · ")}>
            QA {qa.score}/100
          </span>
        ) : null}

        <div className="ml-auto flex items-center gap-1.5">
          {agentFilter ? (
            <button onClick={() => setAgentFilter(null)} className="chip !border-accent2/40 !text-accent2 hover:bg-ink-800">
              фильтр: {AGENT_META[agentFilter]?.label ?? agentFilter} ✕
            </button>
          ) : null}
          {tab === "console" ? (
            <button
              onClick={() => setAutoScroll((v) => !v)}
              className={`rounded-md p-1 transition-colors ${autoScroll ? "text-accent2" : "text-ink-500 hover:text-ink-200"}`}
              title={autoScroll ? "Автопрокрутка включена" : "Автопрокрутка выключена"}
            >
              <Icon name="chevronDown" size={13} />
            </button>
          ) : null}
          <button onClick={onClose} className="rounded-md p-1 text-ink-500 transition-colors hover:bg-ink-800 hover:text-ink-100" title="Скрыть консоль (Ctrl+J)">
            <Icon name="chevronDown" size={13} />
          </button>
        </div>
      </div>

      {/* содержимое */}
      {tab === "console" ? (
        <div
          ref={listRef}
          className="scroll-y flex-1 font-mono text-[11.5px] leading-relaxed"
          onMouseEnter={() => setAutoScroll(false)}
          onMouseLeave={() => setAutoScroll(true)}
        >
          {events.length === 0 ? (
            <div className="flex h-full items-center justify-center text-ink-600">
              Журнал пуст — запустите сборку, и здесь появится жизнь роя
            </div>
          ) : (
            filtered.map((e) => (
              <div key={e.id} className={`group flex animate-fade-in gap-2.5 px-3 py-[3px] hover:bg-ink-900 agent-${AGENTS.includes(e.agent as (typeof AGENTS)[number]) ? e.agent : "SWARM"}`}>
                <span className="shrink-0 text-ink-600">{fmtTime(e.createdAt)}</span>
                <span className="w-[104px] shrink-0 truncate font-semibold" style={{ color: "var(--ag)" }} title={e.agent}>
                  {AGENT_META[e.agent]?.label ?? e.agent}
                </span>
                <span className={`min-w-0 flex-1 whitespace-pre-wrap break-words ${LEVEL_COLORS[e.level] ?? "text-ink-300"}`}>{e.message}</span>
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="scroll-y flex-1 p-2.5">
          {tasks.length === 0 ? (
            <div className="flex h-full items-center justify-center text-ink-600">Задачи появятся после построения плана</div>
          ) : (
            <div className="grid grid-cols-1 gap-1.5 lg:grid-cols-2">
              {tasks.map((t) => (
                <button
                  key={t.id}
                  onClick={() => t.artifactPath && onOpenFile(t.artifactPath)}
                  className={`flex items-start gap-2.5 rounded-lg border px-3 py-2 text-left transition-all hover:border-ink-600 ${
                    t.status === "done" ? "border-ok/25 bg-ok/5" : t.status === "running" ? "border-accent2/30 bg-accent2/5" : "border-ink-750 bg-ink-900"
                  } ${t.artifactPath ? "cursor-pointer" : "cursor-default"}`}
                >
                  <span className={`mt-0.5 shrink-0 ${t.status === "done" ? "text-ok" : t.status === "running" ? "text-accent2" : "text-ink-600"}`}>
                    <Icon name={t.status === "done" ? "check" : t.status === "running" ? "zap" : "dot"} size={12} className={t.status === "running" ? "animate-glow" : ""} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className={`block text-[12px] leading-snug ${t.status === "done" ? "text-ink-300 line-through decoration-ink-600" : "text-ink-100"}`}>
                      {t.title}
                    </span>
                    {t.detail ? <span className="mt-0.5 block line-clamp-2 text-[10.5px] leading-snug text-ink-500">{t.detail}</span> : null}
                    {t.artifactPath ? <span className="mt-1 block truncate font-mono text-[10px] text-accent2/70">{t.artifactPath}</span> : null}
                  </span>
                  <span className="shrink-0 font-mono text-[9.5px] uppercase tracking-wide text-ink-600">#{t.ordinal + 1}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
