import { main } from './cli.js';

const argv = process.argv.slice(2);
await main(argv.length > 0 ? argv : ['start']);