import { and, asc, eq } from "drizzle-orm";
import { createHash } from "node:crypto";
import { db } from "@/db";
import { artifacts } from "@/db/schema";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const projectId = Number(id);
  const path = new URL(request.url).searchParams.get("path");
  if (!Number.isFinite(projectId) || !path) return Response.json({ error: "нужны id и path" }, { status: 400 });
  const rows = await db.select().from(artifacts).where(eq(artifacts.projectId, projectId)).orderBy(asc(artifacts.path));
  const file = rows.find((r) => r.path === path);
  if (!file) return Response.json({ error: "файл не найден" }, { status: 404 });
  return Response.json({
    path: file.path,
    language: file.language,
    content: file.content,
    bytes: file.bytes,
    sha256: file.sha256,
    origin: file.origin,
  });
}

export async function PUT(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const projectId = Number(id);
  const body = (await request.json().catch(() => ({}))) as { path?: string; content?: string };
  if (!Number.isFinite(projectId) || !body.path || typeof body.content !== "string") {
    return Response.json({ error: "нужны path и content" }, { status: 400 });
  }
  const filePath = body.path.replace(/^\/+/, "").replace(/\\/g, "/");
  if (!filePath || filePath.includes("..")) return Response.json({ error: "плохой путь" }, { status: 400 });
  const sha = createHash("sha256").update(body.content).digest("hex").slice(0, 32);
  const bytes = Buffer.byteLength(body.content, "utf8");
  const [hit] = await db
    .select({ id: artifacts.id })
    .from(artifacts)
    .where(and(eq(artifacts.projectId, projectId), eq(artifacts.path, filePath)))
    .limit(1);
  if (hit) {
    await db.update(artifacts).set({ content: body.content, bytes, sha256: sha }).where(eq(artifacts.id, hit.id));
  } else {
    await db.insert(artifacts).values({
      projectId,
      path: filePath,
      language: filePath.endsWith(".ts") || filePath.endsWith(".tsx") ? "typescript" : "text",
      content: body.content,
      bytes,
      sha256: sha,
      origin: "generated",
      agent: "ENGINEER",
    });
  }
  return Response.json({ ok: true, path: filePath, bytes });
}
