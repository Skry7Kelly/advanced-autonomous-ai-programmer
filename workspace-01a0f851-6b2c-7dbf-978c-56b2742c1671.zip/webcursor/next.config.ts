import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  serverExternalPackages: ["undici"],
  // Превью-прокси (например, *.e2b.app) должен иметь доступ к dev-ресурсам
  // (/_next/*, HMR) — иначе клиентский бандл не загрузится и приложение
  // застрянет на экране загрузки.
  allowedDevOrigins: ["*.e2b.app", "e2b.app", "localhost", "127.0.0.1"],
  // жёсткое «не кэшировать» для HTML — чтобы превью всегда отдавало свежую страницу
  async headers() {
    return [
      {
        source: "/",
        headers: [{ key: "Cache-Control", value: "no-store, max-age=0, must-revalidate" }],
      },
    ];
  },
};

export default nextConfig;
