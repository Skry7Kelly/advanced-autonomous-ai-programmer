/** Token-bucket + скользящее окно. Без зависимостей. */
export interface Bucket { tokens: number; updated: number }

export class TokenBucketRateLimiter {
  private buckets = new Map<string, Bucket>();
  private taken = 0;
  private rejected = 0;

  constructor(public readonly capacity: number, public readonly refillPerSecond: number) {}

  private refill(bucket: Bucket, now: number): void {
    const elapsed = (now - bucket.updated) / 1000;
    if (elapsed <= 0) return;
    bucket.tokens = Math.min(this.capacity, bucket.tokens + elapsed * this.refillPerSecond);
    bucket.updated = now;
  }

  tryTake(key = 'default', cost = 1): boolean {
    const now = Date.now();
    const bucket = this.buckets.get(key) ?? { tokens: this.capacity, updated: now };
    this.refill(bucket, now);
    this.buckets.set(key, bucket);
    if (bucket.tokens >= cost) {
      bucket.tokens -= cost;
      this.taken += cost;
      return true;
    }
    this.rejected += 1;
    return false;
  }

  async acquire(key = 'default', cost = 1, timeoutMs = 30000): Promise<void> {
    const deadline = Date.now() + timeoutMs;
    while (!this.tryTake(key, cost)) {
      if (Date.now() > deadline) throw new Error('rate-limit:timeout:' + key);
      const bucket = this.buckets.get(key);
      const missing = bucket ? cost - bucket.tokens : cost;
      const waitMs = Math.max(15, Math.ceil((missing / this.refillPerSecond) * 1000));
      await new Promise((resolve) => setTimeout(resolve, Math.min(waitMs, 250)));
    }
  }

  sweep(maxIdleMs = 60000): number {
    const now = Date.now();
    let removed = 0;
    for (const [key, bucket] of this.buckets) {
      if (now - bucket.updated > maxIdleMs) {
        this.buckets.delete(key);
        removed += 1;
      }
    }
    return removed;
  }

  stats() {
    return { keys: this.buckets.size, taken: this.taken, rejected: this.rejected };
  }
}