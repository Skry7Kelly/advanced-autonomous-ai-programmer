import { eq } from "@/db/orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, ensureSeed, publicUser, sessionCookieHeader, usageOf, verifyPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { email?: string; password?: string };
  const email = (body.email ?? "").trim().toLowerCase();
  const password = body.password ?? "";
  if (!email || !password) return Response.json({ error: "Введите e-mail и пароль" }, { status: 400 });
  await ensureSeed();
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user || !user.passwordHash || !verifyPassword(password, user.passwordHash)) {
    return Response.json({ error: "Неверный e-mail или пароль" }, { status: 401 });
  }
  const { token } = await createSession(user.id);
  return Response.json(
    { user: publicUser(user), usage: await usageOf(user) },
    { headers: { "set-cookie": sessionCookieHeader(token) } },
  );
}
