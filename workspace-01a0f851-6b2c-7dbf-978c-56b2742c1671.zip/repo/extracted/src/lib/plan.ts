import type { Brief, Spec, SpecEndpoint, SpecTable } from "@/lib/types";
import type { ForgedModule } from "@/lib/forge";
import type { PirateModel, ScoutResult } from "@/lib/scout";

export interface PlanInput {
  brief: Brief;
  sources: ScoutResult["items"];
  models: PirateModel[];
  forges: ForgedModule[];
  fly: { brains: number; generation: number; fitness: number };
  settings: { targetLanguage: string; maxAdopt: number };
}

const COLUMN_TYPES: Record<string, string> = {
  id: "bigserial primary key",
  created_at: "timestamptz default now()",
  updated_at: "timestamptz default now()",
};

function sqlType(field: string): string {
  if (COLUMN_TYPES[field]) return COLUMN_TYPES[field];
  if (/_at$|_date$/.test(field)) return "timestamptz";
  if (/^is_|^has_|^verified$|^active$/.test(field)) return "boolean default false";
  if (/count$|_id$|size|score|stars|seeds|priority|latency|bytes|total/.test(field)) return "bigint";
  if (/payload|meta|log|content|fields|body|magnet|notes/.test(field)) return "jsonb";
  return "text";
}

function snake(name: string): string {
  return name
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
    .replace(/[^a-zA-Z0-9]+/g, "_")
    .toLowerCase();
}

function slugify(title: string): string {
  const map: Record<string, string> = { а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "e", ж: "zh", з: "z", и: "i", й: "y", к: "k", л: "l", м: "m", н: "n", о: "o", п: "p", р: "r", с: "s", т: "t", у: "u", ф: "f", х: "h", ц: "c", ч: "ch", ш: "sh", щ: "sch", ъ: "", ы: "y", ь: "", э: "e", ю: "yu", я: "ya" };
  return (
    title
      .toLowerCase()
      .split("")
      .map((ch) => map[ch] ?? ch)
      .join("")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 42) || "super-roy-project"
  );
}

function featureEndpoints(brief: Brief): SpecEndpoint[] {
  const endpoints: SpecEndpoint[] = [];
  if (brief.features.some((f) => f.key === "search")) {
    endpoints.push({ method: "GET", path: "/api/search", purpose: "Полнотекстовый поиск по хранилищу с ранжированием", handler: "searchHandler", request: "?q=строка&limit=20", response: "{ results: [{ id, score, snippet }] }" });
  }
  if (brief.features.some((f) => f.key === "ai")) {
    endpoints.push({ method: "POST", path: "/api/ask", purpose: "Запрос к LLM (локальной или бесплатной облачной) с контекстом из памяти", handler: "askHandler", request: "{ question: string }", response: "{ answer: string, provider: string }" });
    endpoints.push({ method: "GET", path: "/api/memory", purpose: "Семантическая память: ближайшие записи по тегам мозга мухи", handler: "memoryHandler", request: "?q=строка", response: "{ items: [{ id, text, score }] }" });
  }
  if (brief.features.some((f) => f.key === "proxy")) {
    endpoints.push({ method: "GET", path: "/api/proxies", purpose: "Состояние пула прокси", handler: "proxiesHandler", response: "{ items: [{ url, latencyMs, failCount }] }" });
  }
  if (brief.features.some((f) => f.key === "scraper")) {
    endpoints.push({ method: "POST", path: "/api/crawl", purpose: "Запуск обхода источников с ротацией прокси", handler: "crawlHandler", request: "{ seeds: string[] }", response: "{ jobId: string }" });
  }
  if (brief.features.some((f) => f.key === "models") || brief.integrations.includes("pirateface")) {
    endpoints.push({ method: "GET", path: "/api/models", purpose: "Доступные локальные модели и их источники", handler: "modelsHandler", response: "{ items: [{ name, sizeGB, seeds, magnet }] }" });
  }
  if (brief.features.some((f) => f.key === "analytics")) {
    endpoints.push({ method: "GET", path: "/api/stats", purpose: "Агрегированные метрики продукта", handler: "statsHandler", response: "{ totals: object, series: object[] }" });
  }
  return endpoints;
}

export function buildSpec(input: PlanInput): Spec {
  const { brief, sources, models, forges, fly, settings } = input;
  const slug = slugify(brief.title);

  const tables: SpecTable[] = brief.entities.map((entity) => ({
    name: snake(entity.name),
    reason: `Хранит сущность «${entity.name}» из брифа: ${brief.features.slice(0, 2).map((f) => f.title).join(", ") || "основной сценарий"}`,
    columns: entity.fields.map((field) => ({ name: snake(field), type: sqlType(field), note: field === "id" ? "первичный ключ" : "" })),
  }));

  const crudEndpoints: SpecEndpoint[] = [];
  for (const entity of brief.entities) {
    const base = `/api/${snake(entity.name).replace(/_log$/, "")}`;
    crudEndpoints.push({ method: "GET", path: base, purpose: `Список «${entity.name}» с пагинацией`, handler: `list${pascal(entity.name)}`, request: "?limit=50&offset=0", response: `{ items: ${entity.name}[], total: number }` });
    crudEndpoints.push({ method: "POST", path: base, purpose: `Создание записи «${entity.name}»`, handler: `create${pascal(entity.name)}`, request: JSON.stringify(Object.fromEntries(entity.fields.filter((f) => f !== "id").slice(0, 3).map((f) => [f, "…"]))), response: `{ item: ${entity.name} }` });
    crudEndpoints.push({ method: "GET", path: `${base}/:id`, purpose: `Получить «${entity.name}» по идентификатору`, handler: `get${pascal(entity.name)}`, response: `{ item: ${entity.name} }` });
    crudEndpoints.push({ method: "DELETE", path: `${base}/:id`, purpose: `Удалить «${entity.name}»`, handler: `delete${pascal(entity.name)}`, response: "{ ok: true }" });
  }

  const systemEndpoints: SpecEndpoint[] = [
    { method: "GET", path: "/health", purpose: "Живость сервиса: uptime, число записей, состояние провайдеров", handler: "healthHandler", response: "{ status: 'ok', uptimeMs, storage }" },
    { method: "GET", path: "/api/tasks", purpose: "Журнал фоновых задач роя", handler: "tasksHandler", response: "{ items: [{ id, state, startedAt }] }" },
  ];

  const coreModules = [
    { name: "config", path: "src/config.ts", purpose: "Строгая загрузка конфигурации из env с валидацией при старте", publicApi: ["loadConfig"], deps: [], origin: "generated" as const },
    { name: "logger", path: "src/logger.ts", purpose: "Структурные JSON-логи с маскировкой секретов", publicApi: ["createLogger"], deps: [], origin: "generated" as const },
    { name: "router", path: "src/router.ts", purpose: "Минимальный HTTP-роутер с параметрами пути и middleware", publicApi: ["createRouter", "serve"], deps: ["node:http"], origin: "generated" as const },
    { name: "store", path: "src/store.ts", purpose: "Репозитории на JSONL-хранилище: CRUD, фильтры, счётчики", publicApi: ["createStore"], deps: ["node:fs/promises"], origin: "generated" as const },
    { name: "app", path: "src/app.ts", purpose: "Сборка эндпоинтов, обработчиков и фоновых задач в приложение", publicApi: ["buildApp"], deps: ["./router", "./store"], origin: "generated" as const },
    { name: "cli", path: "src/cli.ts", purpose: "CLI-команды: запуск сервера, импорт, проверка прокси, доктор", publicApi: ["main"], deps: ["./app"], origin: "generated" as const },
  ];

  const forgedModules = forges.map((m) => ({
    name: m.capability,
    path: `src/modules/${m.capability}.ts`,
    purpose: m.rationale,
    publicApi: [m.name],
    deps: m.capability === "proxy-pool" ? ["undici"] : m.capability === "model-downloader" ? ["node:fs", "node:stream"] : [],
    origin: "forged" as const,
  }));

  const adopted = sources
    .filter((s) => s.provider === "github" && s.metric >= 50)
    .slice(0, settings.maxAdopt);

  const integrations = adopted.map((s) => ({
    name: s.title,
    url: s.url,
    provider: s.provider,
    stars: s.metric,
    score: s.score,
    why: s.subtitle.slice(0, 240) || "Совпадение по смыслу с брифом",
    install: `git clone ${s.url}.git vendor/${s.title.split("/")[1] ?? s.title}`,
    usage: `Изучить README (${s.title}) и переиспользовать подход в ${slug}: не тащим зависимость целиком, а переносим проверенное решение.`,
  }));

  const modelPicks = models.slice(0, 4).map((m, i) => ({
    name: m.name,
    sizeGB: m.sizeGB,
    seeds: m.seeds,
    magnet: m.magnet,
    webSeed: m.webSeed,
    url: `https://pirateface.co/s/${encodeURIComponent(m.name.split("/")[0])}`,
    role: i === 0 ? "основная модель для генерации кода и планирования" : i === 1 ? "резервная модель (другая квантизация)" : "эмбеддинги/классификация для векторной памяти",
    cmd: `aria2c --seed-ratio=1.0 --select-file=1-99 "${m.magnet}"`,
  }));

  const risks = [
    { risk: "Локальные модели могут не влезть в память машины", impact: "high" as const, mitigation: modelPicks.length ? "Брать GGUF подходящего размера (см. раздел «Локальные модели»), начинать с 7B-кванта" : "Начинать с облачных бесплатных моделей и держать встроенный движок как fallback" },
    { risk: "Внешние API ограничивают частоту запросов", impact: "medium" as const, mitigation: "Token-bucket + экспоненциальный бэкофф + кэш ответов (модули из кузницы)" },
    ...(brief.features.some((f) => f.key === "proxy") ? [{ risk: "IP блокируют при обходе источников", impact: "high" as const, mitigation: "Ротация прокси, карантин сбойных, уважение к robots.txt и задержки между запросами" }] : []),
    ...(brief.features.some((f) => f.key === "security") ? [{ risk: "Утечка секретов в логи", impact: "high" as const, mitigation: "Маскировка секретов в логгере, секреты только в env, аудит доступа" }] : []),
    { risk: "Качество данных источников нестабильно", impact: "medium" as const, mitigation: "Схемная валидация входа + отдельный слой нормализации + метрики отбраковки" },
  ];

  const milestones = [
    { index: 1, title: "Каркас и конфигурация", tasks: ["инициализация репозитория и tsconfig", "config/logger/retry из кузницы", "health-check и структурные логи"], doneWhen: "Сервер стартует одной командой и отвечает на /health" },
    { index: 2, title: "Данные и хранилище", tasks: tables.slice(0, 4).map((t) => `таблица ${t.name}: ${t.columns.length} полей`), doneWhen: "CRUD по каждой сущности работает и покрыт тестами" },
    { index: 3, title: "Ключевые сценарии", tasks: brief.features.slice(0, 5).map((f) => `реализовать: ${f.title}`), doneWhen: "Основной пользовательский сценарий проходит end-to-end" },
    { index: 4, title: "Устойчивость и сеть", tasks: ["прокси-пул и ретраи", "лимиты запросов", "фоновые задачи и scheduler"], doneWhen: "Сбои внешних сервисов не роняют процесс" },
    { index: 5, title: "ИИ-слой и упаковка", tasks: ["подключение локальной GGUF-модели", "векторная память на FlyIndex", "Dockerfile и README"], doneWhen: "Проект работает без платных API и собирается в контейнер" },
  ];

  const goals = [
    `Реализовать: ${brief.summary.slice(0, 180)}`,
    ...brief.features.slice(0, 6).map((f) => `${f.title} — ${f.detail}`),
    `Целевые пользователи: ${brief.personas.join(", ")}`,
  ];

  const nonGoals = [
    "Не делаем платных обязательных зависимостей: всё работает на бесплатных и локальных моделях",
    ...(brief.kind === "web" ? ["Не делаем SSR-фреймворк: статический фронтенд без сборщика"] : ["Не делаем веб-интерфейс на реакте: минимум зависимостей"]),
    "Не храним секреты в репозитории",
  ];

  return {
    title: brief.title,
    slug,
    summary: brief.summary,
    brief,
    goals,
    nonGoals,
    modules: [...coreModules, ...forgedModules],
    tables,
    endpoints: [...systemEndpoints, ...crudEndpoints, ...featureEndpoints(brief)],
    cli: [
      { command: "npm run start", purpose: "Поднять HTTP-сервис" },
      { command: "npm run cli -- doctor", purpose: "Проверить конфигурацию, хранилище и сеть" },
      { command: "npm run cli -- import <файл>", purpose: "Импорт данных из JSONL/CSV" },
      { command: "npm run cli -- export <файл>", purpose: "Экспорт хранилища" },
      ...(brief.features.some((f) => f.key === "proxy") ? [{ command: "npm run cli -- check-proxies", purpose: "Проверить пул прокси и выкинуть мёртвые" }] : []),
      ...(modelPicks.length ? [{ command: "bash scripts/pull-models.sh", purpose: "Скачать локальные модели по магнет-ссылкам PirateFace" }] : []),
    ],
    tests: [
      ...forges.map((m) => ({ name: `модуль ${m.capability}`, path: `test/${m.capability}.test.ts`, asserts: ["успешный сценарий", "обработка ошибки"] })),
      { name: "HTTP API", path: "test/api.test.ts", asserts: ["GET /health возвращает ok", `CRUD /api/${snake(brief.entities[0].name)} работает`, "валидация входа отклоняет мусор"] },
      { name: "Хранилище", path: "test/store.test.ts", asserts: ["запись и чтение JSONL", "фильтрация и лимиты"] },
    ],
    milestones,
    risks,
    integrations,
    models: modelPicks,
    fly: {
      brains: fly.brains,
      generation: fly.generation,
      fitness: Number(fly.fitness.toFixed(4)),
      note: "Поиск и ранжирование ускорены LSH по принципу обонятельной системы мухи; поколение мозгов выведено генетическим отбором.",
      accelerations: [
        "переранжирование находок разведчика за O(k) без векторной БД",
        "дедупликация задач и источников по тегам",
        "семантическая память решений между проектами",
      ],
    },
    localFirst: brief.features.some((f) => f.key === "local-first") || brief.features.some((f) => f.key === "ai"),
    notes: [
      `Тип проекта: ${brief.kind} · рантайм: ${brief.runtime} · язык: ${brief.language}`,
      `Обнаружено функций: ${brief.features.length}, сущностей: ${brief.entities.length}, интеграций: ${brief.integrations.length}`,
      `Найдено источников: ${sources.length}, из них принято к внедрению: ${integrations.length}`,
      `Выковано модулей, которых не существовало: ${forges.length}`,
    ],
  };
}

function pascal(input: string): string {
  return input
    .split(/[^a-zA-Z0-9]+/)
    .filter(Boolean)
    .map((w) => w[0].toUpperCase() + w.slice(1))
    .join("");
}
