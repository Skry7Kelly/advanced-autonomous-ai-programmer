import { eq } from "@/db/orm";
import { db } from "@/db";
import { artifacts, events, forgedModules, projects, runs, sources, tasks } from "@/db/schema";
import { parseBrief } from "@/lib/brief";
import { githubReadme, persistSources, runScout, searchModels } from "@/lib/scout";
import { buildSpec } from "@/lib/plan";
import { generateProject } from "@/lib/codegen";
import { forgeAll, pickCapabilities } from "@/lib/forge";
import { repairProject, runQa, sha256 } from "@/lib/qa";
import { ensureFlyBrains, getActiveBrain, recall, remember } from "@/lib/fly";
import { chat, extractJson } from "@/lib/providers";
import type { AgentId, ProjectSettings } from "@/lib/types";
import fs from "node:fs";
import path from "node:path";

export const DEFAULT_SETTINGS: ProjectSettings = {
  targetLanguage: "typescript",
  searchDepth: 2,
  maxAdopt: 4,
  useProxy: false,
  flyBoost: true,
  allowForge: true,
  cloudLlm: true,
  localLlm: true,
};

const inflight = new Set<number>();

async function emit(
  projectId: number,
  runId: number | null,
  agent: AgentId,
  stage: string,
  message: string,
  data?: unknown,
  level: "info" | "warn" | "error" | "success" = "info",
) {
  await db.insert(events).values({ projectId, runId, agent, stage, message, data: data ?? null, level });
}

async function setStage(projectId: number, stage: string, progress: number) {
  await db.update(projects).set({ stage, progress, updatedAt: new Date() }).where(eq(projects.id, projectId));
}

export async function runPipeline(projectId: number): Promise<void> {
  if (inflight.has(projectId)) return;
  inflight.add(projectId);
  const startedAt = Date.now();
  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project) {
    inflight.delete(projectId);
    return;
  }
  const settings: ProjectSettings = { ...DEFAULT_SETTINGS, ...(project.settings ?? {}) };
  const [run] = await db.insert(runs).values({ projectId, status: "running" }).returning();
  let runId: number | null = run?.id ?? null;

  try {
    await db
      .update(projects)
      .set({ status: "running", error: null, progress: 2, stage: "bootstrap" })
      .where(eq(projects.id, projectId));
    await emit(projectId, runId, "ARCHITECT", "bootstrap", `Рой проснулся. Бриф: ${project.brief.slice(0, 160)}…`, undefined, "success");

    /* ---------------------------- 1. Мозг мухи ---------------------------- */
    await setStage(projectId, "fly", 6);
    await ensureFlyBrains();
    const brain = await getActiveBrain();
    await emit(
      projectId,
      runId,
      "FLY",
      "fly",
      `Активен мозг «${brain.name}» (поколение ${brain.generation}, fitness ${brain.fitness.toFixed(4)}, ${brain.outputDim} нейронов, k=${brain.k}). LSH-поиск вместо векторной БД.`,
      { brain: brain.name, generation: brain.generation, fitness: brain.fitness },
      "success",
    );
    const prior = await recall(project.brief, { limit: 5 });
    if (prior.length > 0) {
      await emit(projectId, runId, "FLY", "memory", `Найдено ${prior.length} похожих решений в памяти роя — переиспользуем выводы.`, {
        items: prior.map((p) => ({ kind: p.kind, score: Number(p.score.toFixed(3)), text: p.text.slice(0, 160) })),
      });
    }

    /* ------------------------------ 2. Разбор ----------------------------- */
    await setStage(projectId, "brief", 12);
    const brief = parseBrief(project.brief, settings.targetLanguage);
    await db.update(projects).set({ briefParsed: brief, kind: brief.kind, language: brief.language }).where(eq(projects.id, projectId));
    await emit(
      projectId,
      runId,
      "ARCHITECT",
      "brief",
      `Разобрал бриф: тип «${brief.kind}», домен «${brief.domain}», функций ${brief.features.length}, сущностей ${brief.entities.length}, ключевые слова: ${brief.keywords.slice(0, 8).join(", ")}`,
      { features: brief.features.map((f) => f.key), entities: brief.entities.map((e) => e.name) },
      "success",
    );

    /* ------------------- 3. Опциональное усиление LLM -------------------- */
    let llmProvider = "builtin-engine";
    if (settings.cloudLlm || settings.localLlm) {
      await setStage(projectId, "llm", 18);
      const answer = await chat(
        [
          {
            role: "system",
            content:
              "Ты главный архитектор ПО. Верни СТРОГО JSON без пояснений: {\"clarifications\":[\"…\"],\"extraFeatures\":[{\"key\":\"…\",\"title\":\"…\",\"detail\":\"…\"}],\"risks\":[{\"risk\":\"…\",\"impact\":\"low|medium|high\",\"mitigation\":\"…\"}]}. Максимум 5 пунктов в каждом массиве. Пиши по-русски, кратко и по делу.",
          },
          { role: "user", content: `Задача: ${project.brief}\nТип: ${brief.kind}. Домен: ${brief.domain}. Уже найдено: ${brief.features.map((f) => f.title).join(", ")}.` },
        ],
        {
          allowed: settings.localLlm && settings.cloudLlm
            ? [
                "pollinations",
                "pollinations-mistral",
                "ollama",
                "llamacpp",
                "lmstudio",
                "openrouter",
                "groq",
                "gemini",
                "cerebras",
                "huggingface",
                "mistral",
                "openai",
                "deepseek",
                "together",
                "fireworks",
                "nvidia",
                "anthropic",
              ]
            : settings.localLlm
              ? ["ollama", "llamacpp", "lmstudio"]
              : [
                  "pollinations",
                  "pollinations-mistral",
                  "openrouter",
                  "groq",
                  "gemini",
                  "cerebras",
                  "huggingface",
                  "mistral",
                  "openai",
                  "deepseek",
                  "together",
                  "fireworks",
                  "nvidia",
                  "anthropic",
                ],
          maxTokens: 900,
          temperature: 0.2,
        },
      );
      if (answer) {
        llmProvider = `${answer.provider}:${answer.model}`;
        const parsed = extractJson<{
          clarifications?: string[];
          extraFeatures?: { key: string; title: string; detail: string }[];
          risks?: { risk: string; impact: "low" | "medium" | "high"; mitigation: string }[];
        }>(answer.text);
        if (parsed) {
          for (const feature of parsed.extraFeatures ?? []) {
            if (!brief.features.some((f) => f.key === feature.key)) brief.features.push(feature);
          }
          brief.nonFunctional.push(...(parsed.clarifications ?? []).slice(0, 4));
          await emit(
            projectId,
            runId,
            "ARCHITECT",
            "llm",
            `Мозг дополнен внешней моделью ${llmProvider}: +${(parsed.extraFeatures ?? []).length} функций, +${(parsed.clarifications ?? []).length} уточнений.`,
            { provider: answer.provider, model: answer.model, ms: answer.ms },
            "success",
          );
        } else {
          await emit(projectId, runId, "ARCHITECT", "llm", `Модель ${llmProvider} ответила без JSON — беру только свободный текст как заметку.`, undefined, "warn");
          brief.notes?.push?.(answer.text.slice(0, 400));
        }
      } else {
        await emit(
          projectId,
          runId,
          "ARCHITECT",
          "llm",
          "Внешние модели недоступны (нет ключей/локальных серверов) — рой работает на встроенном детерминированном движке. Это не заглушка: планирование и кодогенерация полностью локальные.",
          undefined,
          "warn",
        );
      }
    }

    /* ------------------------------ 4. Разведка --------------------------- */
    await setStage(projectId, "scout", 26);
    await emit(projectId, runId, "SCOUT", "scout", "Иду в интернет: PirateFace.co (индекс моделей), GitHub, npm, Hacker News, StackOverflow.", undefined);
    const scout = await runScout(brief, settings);
    if (scout.failures.length > 0) {
      await emit(projectId, runId, "SCOUT", "scout", `Часть источников недоступна: ${scout.failures.join(", ")} — компенсирую остальными и кузницей.`, undefined, "warn");
    }
    const decisions = new Map<string, { decision: string; reason: string }>();
    const adoptable = scout.items.filter((i) => i.provider === "github" && i.metric >= 30 && i.score >= 1).slice(0, settings.maxAdopt);
    for (const item of adoptable) {
      decisions.set(item.url, { decision: "adopted", reason: `высокое совпадение (score ${item.score}), ${item.metric} ⭐` });
    }
    if (settings.flyBoost) {
      for (const item of scout.items.slice(0, 12)) {
        if (!decisions.has(item.url) && item.flyScore > 0.25) {
          decisions.set(item.url, { decision: "reference", reason: `мозг мухи подтвердил смысловую близость (${item.flyScore.toFixed(2)})` });
        }
      }
    }
    await persistSources(projectId, scout.items, decisions);
    await emit(
      projectId,
      runId,
      "SCOUT",
      "scout",
      `Собрал ${scout.items.length} источников по ${scout.queries.length} запросам; к внедрению принято ${adoptable.length}.`,
      { queries: scout.queries, adopted: adoptable.map((a) => a.title) },
      "success",
    );

    // README принятых репозиториев — чтобы внедрение было осмысленным
    let readmeNotes = 0;
    for (const item of adoptable.slice(0, 3)) {
      const md = await githubReadme(item.title, settings.useProxy);
      if (md.length > 100) {
        readmeNotes += 1;
        await remember({
          projectId,
          kind: "source",
          text: `${item.title}: ${md.slice(0, 1200)}`,
          meta: { url: item.url, stars: item.metric },
        });
      }
    }
    if (readmeNotes > 0) {
      await emit(projectId, runId, "INTEGRATOR", "scout", `Прочитал README ${readmeNotes} репозиториев и положил выжимки в память роя.`, undefined);
    }

    /* -------------------- 5. Модели с PirateFace.co ---------------------- */
    await setStage(projectId, "models", 40);
    const models = await searchModels(brief, settings);
    if (models.length > 0) {
      await db.insert(sources).values(
        models.slice(0, 6).map((m) => ({
          projectId,
          provider: "pirateface",
          query: m.query,
          title: m.name,
          url: `https://pirateface.co/s/${encodeURIComponent(m.name.split("/")[0])}`,
          subtitle: `${m.sizeGB} GB · ${m.seeds} сидов · магнет-ссылка`,
          metric: m.seeds,
          metricLabel: "seeds",
          score: 3 + Math.log10(1 + m.seeds),
          decision: "model",
          reason: "локальные веса для автономного режима",
          payload: { magnet: m.magnet, sizeGB: m.sizeGB, webSeed: m.webSeed ?? null },
        })),
      );
      await emit(
        projectId,
        runId,
        "SCOUT",
        "models",
        `PirateFace.co: нашёл ${models.length} подходящих весов, лучшие — ${models.slice(0, 3).map((m) => `${m.name} (${m.sizeGB} GB, ${m.seeds} сидов)`).join("; ")}. Качаем по магнет-ссылке и гоняем локально.`,
        { top: models.slice(0, 3).map((m) => m.name) },
        "success",
      );
    } else {
      await emit(projectId, runId, "SCOUT", "models", "PirateFace.co не отдал результатов по этим запросам — план считаем облачно-независимым (встроенный движок).", undefined, "warn");
    }

    /* ------------------------------- 6. Кузница -------------------------- */
    await setStage(projectId, "forge", 50);
    const capabilities = settings.allowForge ? pickCapabilities(brief, scout.items.slice(0, 10).map((s) => `${s.title} ${s.subtitle}`)) : [];
    const forges = forgeAll(capabilities, brief);
    if (forges.length > 0) {
      await db.delete(forgedModules).where(eq(forgedModules.projectId, projectId));
      await db.insert(forgedModules).values(
        forges.map((f) => ({
          projectId,
          capability: f.capability,
          name: f.name,
          rationale: f.rationale,
          code: f.code,
          testCode: f.testCode,
          doc: f.doc,
          bytes: Buffer.byteLength(f.code, "utf8"),
        })),
      );
      await emit(
        projectId,
        runId,
        "FORGE",
        "forge",
        `Выковал ${forges.length} модулей, которых не было в открытом виде: ${forges.map((f) => f.capability).join(", ")}. Каждый с тестами.`,
        { modules: forges.map((f) => ({ capability: f.capability, class: f.name, bytes: Buffer.byteLength(f.code, "utf8") })) },
        "success",
      );
      for (const f of forges) {
        await remember({ projectId, kind: "module", text: `${f.capability}: ${f.rationale}`, meta: { class: f.name } });
      }
    }

    /* ------------------------------ 7. План ------------------------------ */
    await setStage(projectId, "plan", 60);
    const spec = buildSpec({
      brief,
      sources: scout.items,
      models,
      forges,
      fly: { brains: 3, generation: brain.generation, fitness: brain.fitness },
      settings: { targetLanguage: settings.targetLanguage, maxAdopt: settings.maxAdopt },
    });
    spec.fly.brains = 3;
    await db.update(projects).set({ spec, stage: "codegen", progress: 66, updatedAt: new Date() }).where(eq(projects.id, projectId));
    await emit(
      projectId,
      runId,
      "ARCHITECT",
      "plan",
      `Спецификация готова: ${spec.modules.length} модулей, ${spec.tables.length} таблиц, ${spec.endpoints.length} эндпоинтов, ${spec.milestones.length} этапов, ${spec.risks.length} рисков с митигацией.`,
      { modules: spec.modules.map((m) => m.name), endpoints: spec.endpoints.length },
      "success",
    );
    await remember({ projectId, kind: "decision", text: `${spec.title}: ${spec.summary.slice(0, 500)}`, meta: { slug: spec.slug } });

    await db.delete(tasks).where(eq(tasks.projectId, projectId));
    const taskRows = [
      ...spec.milestones.flatMap((m) =>
        m.tasks.map((t) => ({ projectId, ordinal: 0, title: t, detail: `Этап ${m.index}: ${m.title}. Готово, когда: ${m.doneWhen}`, agent: "ENGINEER" as AgentId, status: "done", dependsOn: [] as string[] })),
      ),
      ...spec.modules.map((m) => ({ projectId, ordinal: 0, title: `Модуль ${m.name} → ${m.path}`, detail: m.purpose, agent: "FORGE" as AgentId, status: "done", dependsOn: [] as string[] })),
    ].map((row, index) => ({ ...row, ordinal: index + 1 }));
    if (taskRows.length > 0) await db.insert(tasks).values(taskRows);

    /* ---------------------------- 8. Кодогенерация ----------------------- */
    await setStage(projectId, "codegen", 72);
    await db.delete(artifacts).where(eq(artifacts.projectId, projectId));
    let files = generateProject(spec, forges, scout.items.map((s) => ({ title: s.title, url: s.url, subtitle: s.subtitle, metric: s.metric, provider: s.provider, score: s.score })));
    await emit(projectId, runId, "ENGINEER", "codegen", `Собрал ${files.length} файлов проекта (запускается командой npm install && npm run start).`, undefined, "success");

    /* -------------------------------- 9. QA ----------------------------- */
    await setStage(projectId, "qa", 84);
    let qa = runQa(files, spec);
    await emit(
      projectId,
      runId,
      "CRITIC",
      "qa",
      `Проверка качества: ${qa.checks.length} групп проверок, оценка ${qa.score}/100, блокеров ${qa.findings.filter((f) => f.severity === "blocker").length}.`,
      { findings: qa.findings.slice(0, 12) },
      qa.score >= 80 ? "success" : "warn",
    );
    if (qa.findings.some((f) => f.severity === "blocker" || f.severity === "warn")) {
      const repair = repairProject(files, spec);
      files = repair.files;
      if (repair.fixed.length > 0) {
        await emit(projectId, runId, "CRITIC", "repair", `Ремонт: ${repair.fixed.join("; ")}`, undefined, "success");
      }
      qa = runQa(files, spec);
      await emit(projectId, runId, "CRITIC", "qa", `Повторная проверка после ремонта: ${qa.score}/100, файлов ${qa.files}.`, { findings: qa.findings.slice(0, 10) }, qa.score >= 80 ? "success" : "warn");
    }

    await db.insert(artifacts).values(
      files.map((f) => ({
        projectId,
        path: f.path,
        language: f.language,
        content: f.content,
        bytes: Buffer.byteLength(f.content, "utf8"),
        sha256: sha256(f.content),
        origin: f.origin,
        agent: f.origin === "forged" ? ("FORGE" as AgentId) : ("ENGINEER" as AgentId),
      })),
    );
    const workspace = path.join(process.cwd(), ".svarma", "projects", String(projectId));
    fs.rmSync(workspace, { recursive: true, force: true });
    for (const file of files) {
      const target = path.join(workspace, file.path);
      if (!target.startsWith(workspace)) continue;
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(target, file.content, "utf8");
    }

    /* ------------------------------ 10. Финал ---------------------------- */
    const bytes = files.reduce((acc, f) => acc + Buffer.byteLength(f.content, "utf8"), 0);
    const stats = {
      files: files.length,
      bytes,
      sources: scout.items.length,
      adopted: adoptable.length,
      models: models.length,
      forged: forges.length,
      endpoints: spec.endpoints.length,
      tables: spec.tables.length,
      qaScore: qa.score,
      durationMs: Date.now() - startedAt,
    };
    await db
      .update(projects)
      .set({ status: "done", stage: "done", progress: 100, qa, stats, updatedAt: new Date() })
      .where(eq(projects.id, projectId));
    if (runId) {
      await db.update(runs).set({ status: "done", summary: stats, finishedAt: new Date() }).where(eq(runs.id, runId));
    }
    await emit(
      projectId,
      runId,
      "INTEGRATOR",
      "done",
      `Готово за ${(stats.durationMs / 1000).toFixed(1)} c: ${stats.files} файлов (${(bytes / 1024).toFixed(1)} КБ), ${stats.forged} выкованных модулей, ${stats.sources} источников, QA ${stats.qaScore}/100. Проект можно скачать архивом и запустить.`,
      stats,
      "success",
    );
    await remember({ projectId, kind: "lesson", text: `Проект «${spec.title}» собран: ${stats.files} файлов, QA ${stats.qaScore}/100, модулей выковано ${stats.forged}.`, meta: stats });
  } catch (error) {
    const message = error instanceof Error ? `${error.message}\n${error.stack ?? ""}` : String(error);
    await db.update(projects).set({ status: "failed", error: message.slice(0, 4000), stage: "failed", updatedAt: new Date() }).where(eq(projects.id, projectId));
    if (runId) await db.update(runs).set({ status: "failed", finishedAt: new Date() }).where(eq(runs.id, runId));
    await emit(projectId, runId, "CRITIC", "error", `Прогон упал: ${message.slice(0, 400)}`, undefined, "error");
  } finally {
    inflight.delete(projectId);
  }
}
