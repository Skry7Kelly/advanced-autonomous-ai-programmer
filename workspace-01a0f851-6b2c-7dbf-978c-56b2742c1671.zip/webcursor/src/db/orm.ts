/**
 * Мини-ORM для Svarma: drop-in замена используемого API drizzle-orm
 * поверх in-memory хранилища с персистентностью в JSON.
 *
 * Поддерживает ровно тот синтаксис, который использует движок роя:
 *   db.select().from(t).where(eq(t.x, 1)).orderBy(desc(t.id)).limit(n)
 *   db.select({ id: t.id }).from(t)
 *   db.insert(t).values({...}) / .values([...]).returning()
 *   db.update(t).set({...}).where(eq(t.id, 1))
 *   db.delete(t).where(eq(t.id, 1))
 *   eq / ne / gt / lt / and / or / asc / desc / sql`...`
 */
import fs from "node:fs";
import path from "node:path";

export type Column = { readonly __column: true; table: string; name: string };

export type Cond = { readonly __cond: true; test: (row: Record<string, any>) => boolean };

export type Order = { readonly __order: true; col: Column; dir: "asc" | "desc" };

export type SqlExpr = {
  readonly __sql: true;
  strings: string[];
  values: unknown[];
};

export type ColDef = {
  readonly __coldef: true;
  kind: "serial" | "text" | "integer" | "integerNull" | "jsonb" | "boolean" | "real" | "timestamp" | "timestampNull";
  def?: unknown;
};

export function serial(): ColDef {
  return { __coldef: true, kind: "serial" };
}
export function text(def?: string): ColDef {
  return { __coldef: true, kind: "text", def };
}
export function integer(def?: number): ColDef {
  return { __coldef: true, kind: "integer", def };
}
export function real(def?: number): ColDef {
  return { __coldef: true, kind: "real", def };
}
export function boolean(def?: boolean): ColDef {
  return { __coldef: true, kind: "boolean", def };
}
export function jsonb(def?: unknown): ColDef {
  return { __coldef: true, kind: "jsonb", def };
}
export function timestamp(): ColDef {
  return { __coldef: true, kind: "timestamp" };
}
export function nullableInteger(): ColDef {
  return { __coldef: true, kind: "integerNull" };
}
export function timestampNull(): ColDef {
  return { __coldef: true, kind: "timestampNull" };
}

/* ------------------------------- операторы ------------------------------- */

function colName(col: Column | string): string {
  return typeof col === "string" ? col : col.name;
}

export function eq(col: Column | string, value: unknown): Cond {
  const name = colName(col);
  return { __cond: true, test: (row) => row[name] === value };
}

export function ne(col: Column | string, value: unknown): Cond {
  const name = colName(col);
  return { __cond: true, test: (row) => row[name] !== value };
}

export function gt(col: Column | string, value: unknown): Cond {
  const name = colName(col);
  return { __cond: true, test: (row) => row[name] > (value as never) };
}

export function lt(col: Column | string, value: unknown): Cond {
  const name = colName(col);
  return { __cond: true, test: (row) => row[name] < (value as never) };
}

export function and(...conds: Cond[]): Cond {
  return { __cond: true, test: (row) => conds.every((c) => c.test(row)) };
}

export function or(...conds: Cond[]): Cond {
  return { __cond: true, test: (row) => conds.some((c) => c.test(row)) };
}

export function asc(col: Column): Order {
  return { __order: true, col, dir: "asc" };
}

export function desc(col: Column): Order {
  return { __order: true, col, dir: "desc" };
}

/** sql`...` — разбор паттернов движка: `${col} <> 'x'` (условие) и `${col} + 1` (инкремент). */
export function sql(strings: TemplateStringsArray, ...values: unknown[]): SqlExpr {
  return { __sql: true, strings: [...strings], values };
}

function isColumn(v: unknown): v is Column {
  return typeof v === "object" && v !== null && (v as { __column?: boolean }).__column === true;
}

function isCond(v: unknown): v is Cond {
  return typeof v === "object" && v !== null && (v as { __cond?: boolean }).__cond === true;
}

function isSql(v: unknown): v is SqlExpr {
  return typeof v === "object" && v !== null && (v as { __sql?: boolean }).__sql === true;
}

function sqlToCond(expr: SqlExpr): Cond {
  const [first] = expr.values;
  const name = isColumn(first) ? first.name : typeof first === "string" ? first : null;
  const tail = expr.strings.slice(1).join(" ? ");
  if (name !== null) {
    const m = tail.match(/^\s*(<>|!=|>=|<=|=|>|<)\s*'?"?([^'"]*?)"?'?\s*$/);
    if (m) {
      const op = m[1];
      const raw = m[2].trim();
      const lit: unknown =
        raw === "true" ? true : raw === "false" ? false : raw !== "" && Number.isFinite(Number(raw)) ? Number(raw) : raw;
      return {
        __cond: true,
        test: (row) => {
          const v = row[name];
          switch (op) {
            case "<>":
            case "!=":
              return v !== lit;
            case "=":
              return v === lit;
            case ">":
              return v > (lit as never);
            case "<":
              return v < (lit as never);
            case ">=":
              return v >= (lit as never);
            case "<=":
              return v <= (lit as never);
            default:
              return true;
          }
        },
      };
    }
  }
  return { __cond: true, test: () => true };
}

function sqlSet(expr: SqlExpr, row: Record<string, any>): unknown {
  const [first] = expr.values;
  const name = isColumn(first) ? first.name : null;
  const tail = expr.strings.slice(1).join(" ").trim();
  const m = tail.match(/^\s*([+\-*/])\s*(\d+(?:\.\d+)?)\s*$/);
  if (name !== null && m) {
    const base = Number(row[name]) || 0;
    const num = Number(m[2]);
    switch (m[1]) {
      case "+":
        return base + num;
      case "-":
        return base - num;
      case "*":
        return base * num;
      case "/":
        return num === 0 ? base : base / num;
    }
  }
  return null;
}

/* -------------------------------- таблицы -------------------------------- */

const TABLE_META = Symbol("svarma-table-meta");

interface TableMeta {
  name: string;
  defs: Record<string, ColDef>;
  columns: Record<string, Column>;
}

export type TableDef<TSelect = Record<string, any>> = {
  readonly __table: true;
  readonly $inferSelect: TSelect;
  readonly $inferInsert: Partial<TSelect>;
} & { [K in keyof TSelect & string]: Column };

/** Непрозрачный тип «любая таблица» для параметров методов БД. */
export type AnyTable = {
  readonly __table: true;
  readonly $inferSelect?: unknown;
  readonly $inferInsert?: unknown;
};

function meta(table: AnyTable): TableMeta {
  return (table as unknown as Record<symbol, TableMeta>)[TABLE_META];
}

export function memTable<TSelect>(tableName: string, defs: Record<string, ColDef>): TableDef<TSelect> {
  const columns: Record<string, Column> = {};
  for (const key of Object.keys(defs)) columns[key] = { __column: true, table: tableName, name: key };
  const tableMeta: TableMeta = { name: tableName, defs, columns };
  const target: Record<string | symbol, unknown> = { __table: true };
  target[TABLE_META] = tableMeta;
  return new Proxy(target as unknown as TableDef<TSelect>, {
    get(t, prop) {
      if (prop === TABLE_META) return tableMeta;
      if (typeof prop === "string" && Object.prototype.hasOwnProperty.call(columns, prop)) return columns[prop];
      return Reflect.get(t, prop, t);
    },
  });
}

/* ------------------------------- хранилище ------------------------------- */

type StoreTable = { rows: Record<string, any>[]; nextId: number };

function cmp(a: unknown, b: unknown): number {
  if (a instanceof Date && b instanceof Date) return a.getTime() - b.getTime();
  if (typeof a === "number" && typeof b === "number") return a - b;
  return String(a ?? "").localeCompare(String(b ?? ""));
}

export class MemDB {
  private tables = new Map<string, StoreTable>();
  private saveTimer: ReturnType<typeof setTimeout> | null = null;
  private dirty = false;

  constructor(private readonly persistPath: string | null) {
    this.load();
    // подтягиваем флаг dirty при завершении процесса
    process.once("exit", () => {
      if (this.dirty) this.saveNow();
    });
  }

  private store(table: AnyTable): StoreTable {
    const name = meta(table).name;
    let t = this.tables.get(name);
    if (!t) {
      t = { rows: [], nextId: 1 };
      this.tables.set(name, t);
    }
    return t;
  }

  private load() {
    if (!this.persistPath) return;
    try {
      if (!fs.existsSync(this.persistPath)) return;
      const raw = JSON.parse(fs.readFileSync(this.persistPath, "utf8")) as { tables?: Record<string, Record<string, any>[]> };
      for (const [name, rows] of Object.entries(raw.tables ?? {})) {
        const revived = rows.map((row) => this.reviveDates(row));
        const maxId = Math.max(0, ...revived.map((r) => Number(r.id) || 0));
        this.tables.set(name, { rows: revived, nextId: maxId + 1 });
      }
    } catch {
      // битый/отсутствующий файл — стартуем с чистого хранилища
    }
  }

  private reviveDates(row: Record<string, any>): Record<string, any> {
    const out: Record<string, any> = { ...row };
    for (const key of ["createdAt", "updatedAt", "startedAt", "finishedAt", "lastCheckedAt", "planUntil", "expiresAt"]) {
      const v = out[key];
      if (typeof v === "string" && /^\d{4}-\d{2}-\d{2}T/.test(v)) out[key] = new Date(v);
    }
    return out;
  }

  private scheduleSave() {
    this.dirty = true;
    if (!this.persistPath || this.saveTimer) return;
    this.saveTimer = setTimeout(() => {
      this.saveTimer = null;
      this.saveNow();
    }, 350);
    if (typeof this.saveTimer.unref === "function") this.saveTimer.unref();
  }

  saveNow() {
    if (!this.persistPath) return;
    try {
      const tables: Record<string, Record<string, any>[]> = {};
      for (const [name, t] of this.tables.entries()) tables[name] = t.rows;
      fs.mkdirSync(path.dirname(this.persistPath), { recursive: true });
      const tmp = `${this.persistPath}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify({ version: 1, tables }), "utf8");
      fs.renameSync(tmp, this.persistPath);
      this.dirty = false;
    } catch {
      // запись не критична — работает как in-memory
    }
  }

  /* -------------------------------- select ------------------------------- */

  select(fields?: Record<string, Column>) {
    return new SelectStart(this, fields ?? null);
  }

  insert<T extends object>(table: TableDef<T>): InsertBuilder<T> {
    return new InsertBuilder<T>(this, table);
  }

  update(table: AnyTable): UpdateBuilder {
    return new UpdateBuilder(this, table);
  }

  delete(table: AnyTable): DeleteBuilder {
    return new DeleteBuilder(this, table);
  }

  count(table: AnyTable): number {
    return this.store(table).rows.length;
  }

  /** Пометить «зависшие» после рестарта прогоны как упавшие. */
  recoverStale() {
    for (const t of this.tables.values()) {
      for (const row of t.rows) {
        if (row.status === "running" || row.status === "queued") {
          row.status = "failed";
          row.error = "Процесс сервера был перезапущен во время прогона. Запустите сборку заново.";
        }
      }
    }
    this.scheduleSave();
  }

  /* ------------------------------ внутреннее ----------------------------- */

  _runSelect<R>(table: AnyTable, fields: Record<string, Column> | null, cond: Cond | SqlExpr | null, orders: Order[], limit: number | null): R[] {
    const s = this.store(table);
    let rows = s.rows.slice();
    if (cond) rows = rows.filter((isSql(cond) ? sqlToCond(cond) : cond).test);
    if (orders.length > 0) {
      rows = rows.slice().sort((a, b) => {
        for (const o of orders) {
          const r = cmp(a[o.col.name], b[o.col.name]);
          if (r !== 0) return o.dir === "asc" ? r : -r;
        }
        return 0;
      });
    }
    if (limit !== null) rows = rows.slice(0, limit);
    if (!fields) return rows as R[];
    return rows.map((row) => {
      const out: Record<string, any> = {};
      for (const [key, col] of Object.entries(fields)) out[key] = row[col.name];
      return out as R;
    });
  }

  _runInsert<T extends object>(table: AnyTable, values: Partial<T>[]): T[] {
    const s = this.store(table);
    const { defs } = meta(table);
    const inserted: T[] = [];
    for (const value of values) {
      const row: Record<string, any> = {};
      for (const [key, def] of Object.entries(defs)) {
        if (Object.prototype.hasOwnProperty.call(value as object, key)) {
          row[key] = (value as Record<string, any>)[key];
        } else if (def.kind === "serial") {
          row[key] = s.nextId++;
        } else if (def.kind === "timestamp") {
          row[key] = new Date();
        } else if (def.kind === "timestampNull" || def.kind === "integerNull") {
          row[key] = null;
        } else if (def.def !== undefined) {
          row[key] = def.def;
        } else {
          row[key] = def.kind === "integer" || def.kind === "real" ? 0 : def.kind === "boolean" ? false : def.kind === "text" ? "" : null;
        }
      }
      s.rows.push(row);
      inserted.push(row as T);
    }
    this.scheduleSave();
    return inserted;
  }

  _runUpdate(table: AnyTable, set: Record<string, any>, cond: Cond | SqlExpr | null): number {
    const s = this.store(table);
    const predicate = cond ? (isSql(cond) ? sqlToCond(cond) : cond) : null;
    let touched = 0;
    for (const row of s.rows) {
      if (predicate && !predicate.test(row)) continue;
      for (const [key, value] of Object.entries(set)) {
        row[key] = isSql(value) ? sqlSet(value, row) : value;
      }
      touched += 1;
    }
    if (touched > 0) this.scheduleSave();
    return touched;
  }

  _runDelete(table: AnyTable, cond: Cond | SqlExpr | null): number {
    const s = this.store(table);
    const predicate = cond ? (isSql(cond) ? sqlToCond(cond) : cond) : null;
    const before = s.rows.length;
    s.rows = predicate ? s.rows.filter((row) => !predicate.test(row)) : [];
    const removed = before - s.rows.length;
    if (removed > 0) this.scheduleSave();
    return removed;
  }
}

/* ------------------------------- строители ------------------------------- */

function toCond(where: Cond | SqlExpr | null | undefined): Cond | SqlExpr | null {
  if (!where) return null;
  if (isCond(where) || isSql(where)) return where;
  return null;
}

class SelectStart {
  constructor(
    private readonly db: MemDB,
    private readonly fields: Record<string, Column> | null,
  ) {}
  from<T>(table: TableDef<T>): SelectBuilder<T> {
    return new SelectBuilder<T>(this.db, this.fields, table);
  }
}

class SelectBuilder<R> implements PromiseLike<R[]> {
  private cond: Cond | SqlExpr | null = null;
  private orders: Order[] = [];
  private limitCount: number | null = null;

  constructor(
    private readonly db: MemDB,
    private readonly fields: Record<string, Column> | null,
    private readonly table: AnyTable,
  ) {}

  where(cond: Cond | SqlExpr | undefined | null): this {
    this.cond = toCond(cond);
    return this;
  }

  orderBy(...orders: (Order | Column)[]): this {
    this.orders = orders.map((o) => ((o as Order).__order ? (o as Order) : { __order: true as const, col: o as Column, dir: "asc" as const }));
    return this;
  }

  limit(n: number): this {
    this.limitCount = n;
    return this;
  }

  then<T1 = R[], T2 = never>(
    onfulfilled?: ((value: R[]) => T1 | PromiseLike<T1>) | null,
    onrejected?: ((reason: unknown) => T2 | PromiseLike<T2>) | null,
  ): PromiseLike<T1> {
    return Promise.resolve(
      this.db._runSelect<R>(this.table, this.fields, this.cond, this.orders, this.limitCount),
    ).then(onfulfilled, onrejected) as PromiseLike<T1>;
  }
}

class InsertBuilder<T extends object> implements PromiseLike<T[]> {
  private rowsArg: Partial<T>[] = [];
  private wantsReturning = false;

  constructor(
    private readonly db: MemDB,
    private readonly table: AnyTable,
  ) {}

  values(value: Partial<T> | Partial<T>[]): this {
    this.rowsArg = Array.isArray(value) ? value : [value];
    return this;
  }

  returning(): this {
    this.wantsReturning = true;
    return this;
  }

  then<T1 = T[], T2 = never>(
    onfulfilled?: ((value: T[]) => T1 | PromiseLike<T1>) | null,
    onrejected?: ((reason: unknown) => T2 | PromiseLike<T2>) | null,
  ): PromiseLike<T1> {
    try {
      const rows = this.db._runInsert<T>(this.table, this.rowsArg);
      return Promise.resolve(this.wantsReturning ? rows : ([] as unknown as T[])).then(onfulfilled, onrejected) as PromiseLike<T1>;
    } catch (error) {
      return Promise.reject(error).then(onfulfilled, onrejected) as PromiseLike<T1>;
    }
  }
}

class UpdateBuilder implements PromiseLike<void> {
  private setValues: Record<string, any> = {};
  private cond: Cond | SqlExpr | null = null;

  constructor(
    private readonly db: MemDB,
    private readonly table: AnyTable,
  ) {}

  set(values: Record<string, any>): this {
    this.setValues = values;
    return this;
  }

  where(cond: Cond | SqlExpr | undefined | null): this {
    this.cond = toCond(cond);
    return this;
  }

  then<T1 = void, T2 = never>(
    onfulfilled?: ((value: void) => T1 | PromiseLike<T1>) | null,
    onrejected?: ((reason: unknown) => T2 | PromiseLike<T2>) | null,
  ): PromiseLike<T1> {
    try {
      this.db._runUpdate(this.table, this.setValues, this.cond);
      return Promise.resolve().then(onfulfilled, onrejected) as PromiseLike<T1>;
    } catch (error) {
      return Promise.reject(error).then(onfulfilled, onrejected) as PromiseLike<T1>;
    }
  }
}

class DeleteBuilder implements PromiseLike<void> {
  private cond: Cond | SqlExpr | null = null;

  constructor(
    private readonly db: MemDB,
    private readonly table: AnyTable,
  ) {}

  where(cond: Cond | SqlExpr | undefined | null): this {
    this.cond = toCond(cond);
    return this;
  }

  then<T1 = void, T2 = never>(
    onfulfilled?: ((value: void) => T1 | PromiseLike<T1>) | null,
    onrejected?: ((reason: unknown) => T2 | PromiseLike<T2>) | null,
  ): PromiseLike<T1> {
    try {
      this.db._runDelete(this.table, this.cond);
      return Promise.resolve().then(onfulfilled, onrejected) as PromiseLike<T1>;
    } catch (error) {
      return Promise.reject(error).then(onfulfilled, onrejected) as PromiseLike<T1>;
    }
  }
}
