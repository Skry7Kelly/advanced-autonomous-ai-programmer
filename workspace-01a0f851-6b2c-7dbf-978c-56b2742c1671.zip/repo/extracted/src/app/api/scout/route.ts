import { parseBrief } from "@/lib/brief";
import { pirateFaceSearch, runScout, searchModels } from "@/lib/scout";
import { DEFAULT_SETTINGS } from "@/lib/pipeline";
import type { ProjectSettings } from "@/lib/types";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: { query?: string; depth?: number; useProxy?: boolean; models?: boolean; provider?: string } = {};
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "некорректный JSON" }, { status: 400 });
  }
  const query = (body.query ?? "").trim();
  if (query.length < 3) return Response.json({ error: "напишите, что искать" }, { status: 400 });

  const settings: ProjectSettings = {
    ...DEFAULT_SETTINGS,
    useProxy: body.useProxy ?? false,
    searchDepth: Math.min(3, Math.max(1, body.depth ?? 2)),
  };

  if (body.provider === "pirateface") {
    const models = await pirateFaceSearch(query, settings.useProxy);
    return Response.json({
      query,
      provider: "pirateface",
      models: models.slice(0, 20).map((m) => ({ ...m, aria2: `aria2c --seed-ratio=1.0 "${m.magnet}"` })),
    });
  }

  const brief = parseBrief(query);
  const started = Date.now();
  const [scout, models] = await Promise.all([
    runScout(brief, settings),
    body.models === false ? Promise.resolve([]) : searchModels(brief, settings),
  ]);
  return Response.json({
    query,
    brief: { kind: brief.kind, domain: brief.domain, keywords: brief.keywords },
    queries: scout.queries,
    failures: scout.failures,
    models,
    ms: Date.now() - started,
    items: scout.items.slice(0, 40).map((i) => ({
      provider: i.provider,
      title: i.title,
      url: i.url,
      subtitle: i.subtitle,
      metric: i.metric,
      metricLabel: i.metricLabel,
      score: i.score,
      flyScore: Number(i.flyScore.toFixed(3)),
    })),
  });
}
