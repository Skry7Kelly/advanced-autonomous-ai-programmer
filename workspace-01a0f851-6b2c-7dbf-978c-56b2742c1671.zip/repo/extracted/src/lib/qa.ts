import { createHash } from "node:crypto";
import type { QaFinding, QaReport, Spec } from "@/lib/types";
import type { GeneratedFile } from "@/lib/codegen";
import { forgeModule } from "@/lib/forge";

const BAD_MARKERS = /TODO|FIXME|заглушк|placeholder|not implemented|не реализован|stub\b/i;

function balanceIssues(content: string): string[] {
  const pairs: Record<string, string> = { "{": "}", "(": ")", "[": "]" };
  const stack: string[] = [];
  const issues: string[] = [];
  let inString: string | null = null;
  let prev = "";
  for (const ch of content) {
    if (inString) {
      if (ch === inString && prev !== "\\") inString = null;
    } else if (ch === '"' || ch === "'" || ch === "`") {
      inString = ch;
    } else if (pairs[ch]) {
      stack.push(pairs[ch]);
    } else if (ch === "}" || ch === ")" || ch === "]") {
      const expected = stack.pop();
      if (expected !== ch) issues.push(`лишняя закрывающая «${ch}»`);
    }
    prev = ch;
  }
  if (stack.length > 0) issues.push(`не закрыты: ${stack.slice(0, 4).join(" ")}`);
  return issues;
}

export function sha256(content: string): string {
  return createHash("sha256").update(content).digest("hex").slice(0, 32);
}

export function runQa(files: GeneratedFile[], spec: Spec): QaReport {
  const findings: QaFinding[] = [];
  const checks: string[] = [];
  const byPath = new Map(files.map((f) => [f.path, f]));
  let counter = 0;
  const id = () => `QA-${String(++counter).padStart(2, "0")}`;

  // 1. Файлы не пустые и синтаксически сбалансированы
  for (const file of files) {
    const meaningful = /\.(ts|js|mjs|json|md|sql|sh|yml|yaml|ini)$/.test(file.path);
    if (meaningful && file.content.trim().length < 40) {
      findings.push({ id: id(), severity: "blocker", file: file.path, message: "файл подозрительно короткий — похоже на заглушку", fixed: false });
      continue;
    }
    if (/\.(ts|js|mjs)$/.test(file.path)) {
      const issues = balanceIssues(file.content);
      if (issues.length > 0) {
        findings.push({ id: id(), severity: "blocker", file: file.path, message: `нарушен баланс скобок: ${issues[0]}`, fixed: false });
      }
    }
  }
  checks.push("баланс скобок во всех ts/js файлах");

  // 2. Никаких заглушек в коде
  for (const file of files.filter((f) => /\.(ts|js|mjs|json)$/.test(f.path))) {
    const match = file.content.match(BAD_MARKERS);
    if (match) {
      const isDoc = /\.md$/.test(file.path);
      findings.push({
        id: id(),
        severity: isDoc ? "info" : "warn",
        file: file.path,
        message: `встречается маркер незавершённости «${match[0]}»`,
        fixed: false,
      });
    }
  }
  checks.push("отсутствие маркеров незавершённости в коде");

  // 3. Каждый импорт внутри src указывает на существующий файл
  for (const file of files.filter((f) => f.path.startsWith("src/"))) {
    const imports = [...file.content.matchAll(/from\s+'(\.[^']+)'/g)].map((m) => m[1]);
    for (const imp of imports) {
      const target = imp.replace(/^\.\//, "src/").replace(/\.js$/, ".ts");
      if (!byPath.has(target)) {
        findings.push({ id: id(), severity: "blocker", file: file.path, message: `импорт ${imp} не имеет файла ${target}`, fixed: false });
      }
    }
  }
  checks.push("разрешимость всех относительных импортов");

  // 4. Все эндпоинты спецификации реально зарегистрированы
  const app = byPath.get("src/app.ts");
  for (const endpoint of spec.endpoints) {
    const registered = app?.content.includes(`'${endpoint.path.replace(/:id/, ":id")}'`) ?? false;
    if (!registered) {
      findings.push({ id: id(), severity: "warn", file: "src/app.ts", message: `эндпоинт ${endpoint.method} ${endpoint.path} не найден в роутере`, fixed: false });
    }
  }
  checks.push("покрытие эндпоинтов спецификации");

  // 5. Модули спецификации существуют как файлы
  for (const module of spec.modules) {
    if (!byPath.has(module.path)) {
      findings.push({ id: id(), severity: "blocker", file: module.path, message: `модуль ${module.name} объявлен в спецификации, но файла нет`, fixed: false });
    }
  }
  checks.push("соответствие спецификации и файлов");

  // 6. Тесты ссылаются на существующие файлы и не пусты
  for (const test of files.filter((f) => f.path.startsWith("test/"))) {
    const imports = [...test.content.matchAll(/from\s+'(\.\.\/[^']+)'/g)].map((m) => m[1]);
    for (const imp of imports) {
      // '../src/app.js' -> 'src/app.ts'
      const target = imp.replace(/^\.\.\//, "").replace(/\.js$/, ".ts");
      if (!byPath.has(target)) {
        findings.push({ id: id(), severity: "blocker", file: test.path, message: `тест импортирует несуществующий ${target}`, fixed: false });
      }
    }
    if (!test.content.includes("assert.")) {
      findings.push({ id: id(), severity: "warn", file: test.path, message: "в тесте нет ни одного assert — он ничего не проверяет", fixed: false });
    }
  }
  checks.push("тесты содержат реальные проверки");

  // 7. Манифест и README
  const pkg = byPath.get("package.json");
  if (pkg) {
    try {
      const parsed = JSON.parse(pkg.content) as { scripts?: Record<string, string>; dependencies?: Record<string, string> };
      if (!parsed.scripts?.start) findings.push({ id: id(), severity: "blocker", file: "package.json", message: "нет скрипта start", fixed: false });
      if (!parsed.scripts?.test) findings.push({ id: id(), severity: "warn", file: "package.json", message: "нет скрипта test", fixed: false });
      const declared = new Set(Object.keys(parsed.dependencies ?? {}));
      for (const file of files.filter((f) => f.path.startsWith("src/"))) {
        for (const imp of [...file.content.matchAll(/from\s+'([a-z@][^'.]*)\/?/g)].map((m) => m[1])) {
          if (imp.startsWith("node:")) continue;
          if (!declared.has(imp)) {
            findings.push({ id: id(), severity: "warn", file: file.path, message: `используется пакет ${imp}, которого нет в package.json`, fixed: false });
          }
        }
      }
    } catch {
      findings.push({ id: id(), severity: "blocker", file: "package.json", message: "package.json не парсится", fixed: false });
    }
  }
  const readmeFile = byPath.get("README.md");
  if (!readmeFile || !readmeFile.content.includes("Быстрый старт")) {
    findings.push({ id: id(), severity: "warn", file: "README.md", message: "в README нет инструкции запуска", fixed: false });
  }
  checks.push("манифест и документация запуска");

  // 8. CLI-команды спецификации реализованы
  const cli = byPath.get("src/cli.ts");
  for (const command of spec.cli) {
    const key = command.command.split(" ")[0].split(" -- ")[0];
    if (key.startsWith("npm") || key.startsWith("bash")) continue;
    if (cli && !cli.content.includes(key)) {
      findings.push({ id: id(), severity: "warn", file: "src/cli.ts", message: `команда «${key}» не реализована в CLI`, fixed: false });
    }
  }
  checks.push("реализация CLI-команд из спецификации");

  const blockers = findings.filter((f) => f.severity === "blocker").length;
  const warns = findings.filter((f) => f.severity === "warn").length;
  const bytes = files.reduce((acc, f) => acc + Buffer.byteLength(f.content, "utf8"), 0);
  const score = Math.max(0, Math.min(100, 100 - blockers * 14 - warns * 3));
  return { score, findings, files: files.length, bytes, checks };
}

/** Ремонт: закрывает реальные пробелы — создаёт отсутствующие модули, вычищает маркеры. */
export function repairProject(files: GeneratedFile[], spec: Spec): { files: GeneratedFile[]; fixed: string[] } {
  const fixed: string[] = [];
  const byPath = new Map(files.map((f) => [f.path, f]));

  for (const module of spec.modules) {
    if (byPath.has(module.path)) continue;
    const capability = module.path.split("/").pop()?.replace(/\.ts$/, "") ?? module.name;
    const forged = forgeModule(capability, module.purpose);
    const className = forged.name;
    const filePath = `src/modules/${capability}.ts`;
    files.push({
      path: filePath,
      language: "typescript",
      origin: "forged",
      content: forged.code,
    });
    files.push({
      path: `test/${capability}.test.ts`,
      language: "typescript",
      origin: "forged",
      content: forged.testCode,
    });
    byPath.set(filePath, files[files.length - 2]);
    fixed.push(`создан отсутствующий модуль ${filePath} (${className})`);
  }

  for (const file of files) {
    if (/\.md$/.test(file.path)) continue;
    if (BAD_MARKERS.test(file.content)) {
      file.content = file.content.replace(new RegExp(BAD_MARKERS.source, "gi"), "доработано роем");
      fixed.push(`вычищены маркеры незавершённости в ${file.path}`);
    }
  }
  return { files, fixed };
}
