import type { Metadata, Viewport } from "next";
import "./globals.css";

const description =
  "Svarma — рой ИИ-агентов, выковывающий приложения. Опишите идею словами: агенты АРХИТЕКТОР, РАЗВЕДЧИК, МОЗГ МУХИ, КУЗНЕЦ, ИНЖЕНЕР, КРИТИК и ИНТЕГРАТОР спроектируют, сгенерируют и проверят код — готовый проект скачивается ZIP-архивом прямо из браузерной IDE.";

export const metadata: Metadata = {
  metadataBase: new URL("https://svarma.app"),
  title: {
    default: "Svarma — рой ИИ-агентов, выковывающий приложения",
    template: "%s · Svarma",
  },
  description,
  applicationName: "Svarma",
  keywords: [
    "Svarma",
    "Svarma IDE",
    "Svarma AI",
    "ИИ-IDE",
    "AI IDE",
    "веб-Cursor",
    "Cursor аналог",
    "рой агентов",
    "AI агент разработчик",
    "генерация приложений ИИ",
    "автономная разработка",
    "генератор кода",
    "AI software engineer",
    "swarm agents",
    "vibe coding",
  ],
  authors: [{ name: "Svarma" }],
  creator: "Svarma",
  category: "technology",
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    siteName: "Svarma",
    locale: "ru_RU",
    title: "Svarma — рой ИИ-агентов, выковывающий приложения",
    description,
    images: [{ url: "/logo.png", width: 1024, height: 1024, alt: "Svarma — hexagon swarm & spark" }],
  },
  twitter: {
    card: "summary",
    title: "Svarma — рой ИИ-агентов, выковывающий приложения",
    description,
    images: ["/logo.png"],
  },
  icons: { icon: "/logo.png", apple: "/logo.png", shortcut: "/logo.png" },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#0a0c12",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <body className="h-full antialiased">{children}</body>
    </html>
  );
}
