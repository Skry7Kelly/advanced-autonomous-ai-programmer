import test from 'node:test';
import assert from 'node:assert/strict';
import { AsyncEventBus } from '../src/modules/event-bus.js';

test('доставка и отписка', async () => {
  const bus = new AsyncEventBus<{ tick: { n: number } }>();
  let seen = 0;
  const off = bus.on('tick', (p) => { seen += p.n; });
  await bus.emit('tick', { n: 2 });
  off();
  await bus.emit('tick', { n: 5 });
  assert.equal(seen, 2);
  assert.equal(bus.tail('tick').length, 2);
});