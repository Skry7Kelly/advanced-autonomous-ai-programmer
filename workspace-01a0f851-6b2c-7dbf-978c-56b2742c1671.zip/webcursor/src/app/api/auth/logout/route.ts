import { destroySession, getAuthUser, clearSessionCookieHeader, parseCookies, SESSION_COOKIE } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(request: Request) {
  const token = parseCookies(request)[SESSION_COOKIE];
  if (token) await destroySession(token).catch(() => undefined);
  void getAuthUser;
  return Response.json({ ok: true }, { headers: { "set-cookie": clearSessionCookieHeader() } });
}
