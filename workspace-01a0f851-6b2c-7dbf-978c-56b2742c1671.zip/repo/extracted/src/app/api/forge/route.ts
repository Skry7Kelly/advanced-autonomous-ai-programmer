import { desc } from "drizzle-orm";
import { db } from "@/db";
import { forgedModules } from "@/db/schema";
import { FORGE_CATALOG, forgeModule } from "@/lib/forge";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  const recent = await db.select().from(forgedModules).orderBy(desc(forgedModules.id)).limit(20);
  return Response.json({
    catalog: FORGE_CATALOG,
    recent: recent.map((r) => ({ id: r.id, capability: r.capability, name: r.name, bytes: r.bytes, rationale: r.rationale })),
    note: "Если нужной возможности нет в каталоге — опишите её, и кузница соберёт модуль с нуля (реестр обработчиков + журнал + метрики).",
  });
}

export async function POST(request: Request) {
  let body: { capability?: string; description?: string; projectId?: number } = {};
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "некорректный JSON" }, { status: 400 });
  }
  const capability = (body.capability ?? "").trim() || "custom-module";
  const description = (body.description ?? "").trim();
  if (description.length < 5) return Response.json({ error: "опишите, что модуль должен делать" }, { status: 400 });

  const forged = forgeModule(capability, description);
  const [row] = await db
    .insert(forgedModules)
    .values({
      projectId: body.projectId ?? null,
      capability: forged.capability,
      name: forged.name,
      rationale: forged.rationale,
      code: forged.code,
      testCode: forged.testCode,
      doc: forged.doc,
      bytes: Buffer.byteLength(forged.code, "utf8"),
    })
    .returning();
  return Response.json(
    {
      module: { id: row.id, capability: row.capability, name: row.name, bytes: row.bytes, rationale: row.rationale },
      code: forged.code,
      test: forged.testCode,
      doc: forged.doc,
    },
    { status: 201 },
  );
}
