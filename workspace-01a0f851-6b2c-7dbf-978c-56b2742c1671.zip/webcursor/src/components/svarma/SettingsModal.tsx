"use client";

import { useEffect, useMemo, useState } from "react";
import { Icon } from "./icons";
import { api, skillsApi } from "./api";
import type { SkillInfo } from "./types";

type ProviderRow = {
  key: string;
  label: string;
  kind: string;
  model: string;
  status: string;
  latencyMs: number | null;
  detail: string;
  keyless: boolean;
  envKey: string;
};

type KeySlot = {
  provider: string;
  label: string;
  envKey: string;
  model: string;
  note: string;
  hasValue: boolean;
  masked: string;
  fromEnv: boolean;
};

const SKILL_EXAMPLES = [
  "vercel-labs/agent-skills",
  "anthropics/skills",
  "vercel-labs/skills",
];

function groupOf(p: ProviderRow): string {
  if (p.key === "builtin") return "Встроенный движок";
  if (p.kind === "model-index") return "Индексы моделей";
  if (p.keyless && p.kind === "local") return "Локальные (без ключей)";
  if (p.keyless) return "Без ключей (работают сразу)";
  return "Облачные (нужен API-ключ)";
}

export default function SettingsModal({
  open,
  onClose,
  onToast,
  onProvidersChanged,
}: {
  open: boolean;
  onClose: () => void;
  onToast: (kind: "ok" | "error" | "info", text: string) => void;
  onProvidersChanged: () => Promise<void> | void;
}) {
  const [tab, setTab] = useState<"providers" | "keys" | "skills" | "about">("providers");
  const [providers, setProviders] = useState<ProviderRow[]>([]);
  const [slots, setSlots] = useState<KeySlot[]>([]);
  const [probing, setProbing] = useState(false);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [savingKey, setSavingKey] = useState<string | null>(null);
  const [providerQuery, setProviderQuery] = useState("");
  const [keyQuery, setKeyQuery] = useState("");

  /* скиллы */
  const [skills, setSkills] = useState<SkillInfo[]>([]);
  const [skillSource, setSkillSource] = useState("");
  const [installing, setInstalling] = useState(false);
  const [skillBusy, setSkillBusy] = useState<string | null>(null);

  const loadSkills = () => {
    skillsApi
      .list()
      .then(setSkills)
      .catch(() => undefined);
  };

  useEffect(() => {
    if (!open) return;
    api
      .providers()
      .then((d) => setProviders(d.providers))
      .catch(() => undefined);
    api
      .keys()
      .then((d) => setSlots(d.slots))
      .catch(() => undefined);
    loadSkills();
  }, [open]);

  const filteredProviders = useMemo(() => {
    const q = providerQuery.trim().toLowerCase();
    const list = q
      ? providers.filter((p) => p.label.toLowerCase().includes(q) || p.key.includes(q) || p.envKey.toLowerCase().includes(q))
      : providers;
    const groups = new Map<string, ProviderRow[]>();
    for (const p of list) {
      const g = groupOf(p);
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g)!.push(p);
    }
    return [...groups.entries()];
  }, [providers, providerQuery]);

  const filteredSlots = useMemo(() => {
    const q = keyQuery.trim().toLowerCase();
    if (!q) return slots;
    return slots.filter((s) => s.label.toLowerCase().includes(q) || s.envKey.toLowerCase().includes(q));
  }, [slots, keyQuery]);

  if (!open) return null;

  const probe = async () => {
    setProbing(true);
    try {
      const d = await api.probeProviders();
      setProviders(d.providers);
      onToast("ok", `Проверка завершена: готово ${d.ready.length}`);
      await onProvidersChanged();
    } catch (e) {
      onToast("error", e instanceof Error ? e.message : String(e));
    } finally {
      setProbing(false);
    }
  };

  const saveKey = async (envKey: string) => {
    const value = drafts[envKey]?.trim();
    if (!value) return;
    setSavingKey(envKey);
    try {
      await api.saveKey(envKey, value);
      setDrafts((d) => ({ ...d, [envKey]: "" }));
      const d = await api.keys();
      setSlots(d.slots);
      onToast("ok", `${envKey} сохранён`);
      await onProvidersChanged();
    } catch (e) {
      onToast("error", e instanceof Error ? e.message : String(e));
    } finally {
      setSavingKey(null);
    }
  };

  const removeKey = async (envKey: string) => {
    try {
      await api.deleteKey(envKey);
      const d = await api.keys();
      setSlots(d.slots);
      onToast("ok", `${envKey} удалён`);
    } catch (e) {
      onToast("error", e instanceof Error ? e.message : String(e));
    }
  };

  const installSkills = async () => {
    const src = skillSource.trim();
    if (!src || installing) return;
    setInstalling(true);
    try {
      const result = await skillsApi.install(src);
      onToast("ok", result.message);
      setSkillSource("");
      loadSkills();
    } catch (e) {
      onToast("error", e instanceof Error ? e.message : String(e));
    } finally {
      setInstalling(false);
    }
  };

  const toggleSkill = async (skill: SkillInfo) => {
    setSkillBusy(skill.name);
    try {
      await skillsApi.toggle(skill.name, !skill.enabled);
      loadSkills();
    } catch (e) {
      onToast("error", e instanceof Error ? e.message : String(e));
    } finally {
      setSkillBusy(null);
    }
  };

  const deleteSkill = async (skill: SkillInfo) => {
    setSkillBusy(skill.name);
    try {
      await skillsApi.remove(skill.name);
      onToast("ok", `Скилл «${skill.name}» удалён`);
      loadSkills();
    } catch (e) {
      onToast("error", e instanceof Error ? e.message : String(e));
    } finally {
      setSkillBusy(null);
    }
  };

  const readyCount = providers.filter((p) => p.status === "ready").length;
  const enabledSkills = skills.filter((s) => s.enabled).length;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4" onMouseDown={onClose}>
      <div className="absolute inset-0 bg-ink-950/75 backdrop-blur-sm" />
      <div
        className="relative flex max-h-[86vh] w-[720px] max-w-full animate-pop flex-col overflow-hidden rounded-2xl border border-ink-650 bg-ink-850 shadow-2xl"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 border-b border-ink-700 px-5 py-4">
          <Icon name="settings" size={17} className="text-accent2" />
          <span className="text-[15px] font-semibold text-ink-50">Настройки</span>
          <span className="chip ml-1 !py-0.5 !text-[9.5px]">
            {providers.length} моделей · {readyCount} готово · {enabledSkills}/{skills.length} скиллов
          </span>
          <button onClick={onClose} className="ml-auto rounded-lg p-1.5 text-ink-400 transition-colors hover:bg-ink-800 hover:text-ink-100">
            <Icon name="close" size={15} />
          </button>
        </div>

        <div className="flex gap-1 border-b border-ink-700 px-3 py-2">
          {(
            [
              ["providers", "Модели", "cpu"],
              ["keys", "Ключи API", "key"],
              ["skills", "Скиллы", "sparkles"],
              ["about", "О движке", "info"],
            ] as const
          ).map(([id, label, icon]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12px] font-medium transition-colors ${
                tab === id ? "bg-ink-750 text-ink-50" : "text-ink-400 hover:bg-ink-800 hover:text-ink-200"
              }`}
            >
              <Icon name={icon} size={12} />
              {label}
            </button>
          ))}
        </div>

        <div className="scroll-y flex-1 p-4">
          {tab === "providers" && (
            <div className="space-y-2">
              <div className="mb-3 flex items-center gap-2.5">
                <p className="text-[11.5px] leading-relaxed text-ink-400">
                  Роутер сам выбирает первый живой провайдер и <b className="text-ink-200">пропускает неподключённые</b>.
                </p>
                <div className="relative ml-auto shrink-0">
                  <Icon name="search" size={12} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-500" />
                  <input
                    value={providerQuery}
                    onChange={(e) => setProviderQuery(e.target.value)}
                    placeholder="поиск модели…"
                    className="input !w-44 !py-1.5 !pl-7 !text-[11.5px]"
                  />
                </div>
                <button className="btn shrink-0" onClick={() => void probe()} disabled={probing}>
                  {probing ? <span className="h-3 w-3 animate-spin-slow rounded-full border-2 border-accent2/30 border-t-accent2" /> : <Icon name="refresh" size={12} />}
                  Проверить
                </button>
              </div>
              {filteredProviders.map(([group, list]) => (
                <div key={group}>
                  <div className="mb-1 mt-2.5 text-[10px] font-bold uppercase tracking-[0.14em] text-ink-500">
                    {group} <span className="text-ink-600">· {list.length}</span>
                  </div>
                  {list.map((p) => (
                    <div key={p.key} className="mb-1.5 flex items-center gap-3 rounded-xl border border-ink-750 bg-ink-900 px-3.5 py-2.5">
                      <span
                        className={`h-2 w-2 shrink-0 rounded-full ${
                          p.status === "ready" ? "bg-ok shadow-[0_0_8px_rgba(110,231,168,0.6)]" : p.status === "error" ? "bg-danger" : "bg-ink-500"
                        }`}
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="truncate text-[12.5px] font-medium text-ink-100">{p.label}</span>
                          {p.keyless ? <span className="chip !border-ok/30 !text-ok !text-[9px]">без ключа</span> : null}
                          {p.kind === "local" ? <span className="chip !text-[9px]">локально</span> : null}
                        </div>
                        <div className="mt-0.5 truncate font-mono text-[10px] text-ink-500">
                          {p.model || "—"} {p.latencyMs ? `· ${p.latencyMs} мс` : ""} {p.detail ? `· ${p.detail.slice(0, 60)}` : ""}
                        </div>
                      </div>
                      <span className={`shrink-0 text-[10.5px] font-semibold uppercase tracking-wide ${p.status === "ready" ? "text-ok" : p.status === "error" ? "text-danger" : "text-ink-500"}`}>
                        {p.status === "ready" ? "готов" : p.status === "error" ? "ошибка" : p.status}
                      </span>
                    </div>
                  ))}
                </div>
              ))}
              {providers.length === 0 ? <div className="py-8 text-center text-ink-500">Загрузка…</div> : null}
            </div>
          )}

          {tab === "keys" && (
            <div className="space-y-2.5">
              <div className="mb-3 flex items-center gap-2.5">
                <p className="text-[11.5px] leading-relaxed text-ink-400">
                  Ключи хранятся локально (в .data). Провайдеры без ключей просто пропускаются.
                </p>
                <div className="relative ml-auto shrink-0">
                  <Icon name="search" size={12} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-500" />
                  <input
                    value={keyQuery}
                    onChange={(e) => setKeyQuery(e.target.value)}
                    placeholder="поиск ключа…"
                    className="input !w-44 !py-1.5 !pl-7 !text-[11.5px]"
                  />
                </div>
              </div>
              {filteredSlots.map((s) => (
                <div key={s.envKey} className="rounded-xl border border-ink-750 bg-ink-900 p-3.5">
                  <div className="flex items-center gap-2">
                    <Icon name="key" size={13} className="text-warn" />
                    <span className="text-[12.5px] font-medium text-ink-100">{s.label}</span>
                    <span className="font-mono text-[10px] text-ink-500">{s.envKey}</span>
                    {s.hasValue ? (
                      <span className="chip ml-auto !border-ok/40 !text-ok">{s.fromEnv ? "из env" : s.masked}</span>
                    ) : (
                      <span className="chip ml-auto">не задан</span>
                    )}
                  </div>
                  <p className="mt-1 text-[10.5px] leading-snug text-ink-500">{s.note}</p>
                  <div className="mt-2.5 flex gap-2">
                    <input
                      type="password"
                      value={drafts[s.envKey] ?? ""}
                      onChange={(e) => setDrafts((d) => ({ ...d, [s.envKey]: e.target.value }))}
                      placeholder={s.hasValue ? "новый ключ…" : "вставьте ключ…"}
                      className="input !py-2 !text-[12px]"
                    />
                    <button className="btn shrink-0" disabled={!drafts[s.envKey]?.trim() || savingKey === s.envKey} onClick={() => void saveKey(s.envKey)}>
                      {savingKey === s.envKey ? <span className="h-3 w-3 animate-spin-slow rounded-full border-2 border-accent2/30 border-t-accent2" /> : <Icon name="check" size={12} />}
                      Сохранить
                    </button>
                    {s.hasValue && !s.fromEnv ? (
                      <button className="btn btn-danger shrink-0" onClick={() => void removeKey(s.envKey)} title="Удалить ключ">
                        <Icon name="trash" size={12} />
                      </button>
                    ) : null}
                  </div>
                </div>
              ))}
              {filteredSlots.length === 0 ? <div className="py-8 text-center text-ink-500">Ничего не найдено</div> : null}
            </div>
          )}

          {tab === "skills" && (
            <div className="space-y-3">
              <div className="rounded-xl border border-accent3/25 bg-accent3/5 p-3.5">
                <div className="flex items-start gap-2.5">
                  <Icon name="sparkles" size={15} className="mt-0.5 shrink-0 text-accent3" />
                  <div>
                    <p className="text-[12.5px] font-semibold text-ink-50">Агентные скиллы — открытый формат vercel-labs/skills</p>
                    <p className="mt-1 text-[11.5px] leading-relaxed text-ink-300">
                      Скилл — папка со <span className="font-mono text-[10.5px]">SKILL.md</span> (описание + инструкции). Рой
                      автоматически подключает релевантные скиллы к запросу — работает с Claude и любым другим провайдером.
                      Устанавливайте скиллы из любого GitHub-репозитория.
                    </p>
                  </div>
                </div>
                <div className="mt-3 flex gap-2">
                  <input
                    value={skillSource}
                    onChange={(e) => setSkillSource(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && void installSkills()}
                    placeholder="owner/repo или ссылка github.com/…"
                    className="input !py-2 !text-[12px]"
                  />
                  <button className="btn btn-accent shrink-0 !text-[12px]" disabled={!skillSource.trim() || installing} onClick={() => void installSkills()}>
                    {installing ? <span className="h-3 w-3 animate-spin-slow rounded-full border-2 border-accent2/30 border-t-accent2" /> : <Icon name="download" size={12} />}
                    Установить
                  </button>
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <span className="text-[10.5px] text-ink-500">примеры:</span>
                  {SKILL_EXAMPLES.map((ex) => (
                    <button
                      key={ex}
                      onClick={() => setSkillSource(ex)}
                      className="chip !py-0.5 !text-[10px] font-mono transition-colors hover:!border-accent3/40 hover:!text-accent3"
                    >
                      {ex}
                    </button>
                  ))}
                  <a
                    href="https://skills.sh"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="ml-auto flex items-center gap-1 text-[10.5px] text-ink-400 transition-colors hover:text-accent2"
                  >
                    каталог skills.sh <Icon name="external" size={10} />
                  </a>
                </div>
              </div>

              {skills.map((s) => (
                <div
                  key={s.name}
                  className={`flex items-start gap-3 rounded-xl border p-3.5 transition-colors ${
                    s.enabled ? "border-ink-750 bg-ink-900" : "border-ink-800 bg-ink-900/50 opacity-70"
                  }`}
                >
                  <button
                    onClick={() => void toggleSkill(s)}
                    disabled={skillBusy === s.name}
                    title={s.enabled ? "Выключить скилл" : "Включить скилл"}
                    className={`ring-focus relative mt-0.5 h-5 w-9 shrink-0 rounded-full transition-colors ${s.enabled ? "bg-accent2/70" : "bg-ink-700"}`}
                  >
                    <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-ink-950 transition-all ${s.enabled ? "left-[18px]" : "left-0.5"}`} />
                  </button>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[12.5px] font-semibold text-ink-50">{s.name}</span>
                      <span className={`chip !py-0.5 !text-[9px] ${s.source === "github" ? "!border-accent3/40 !text-accent3" : ""}`}>
                        {s.source === "github" ? "из GitHub" : "встроенный"}
                      </span>
                      <span className="font-mono text-[9.5px] text-ink-600">
                        {s.files} файл(ов) · {(s.bytes / 1024).toFixed(1)} КБ
                      </span>
                    </div>
                    <p className="mt-1 text-[11px] leading-snug text-ink-400">{s.description}</p>
                  </div>
                  <button
                    onClick={() => void deleteSkill(s)}
                    disabled={skillBusy === s.name}
                    title="Удалить скилл"
                    className="shrink-0 rounded-lg p-1.5 text-ink-600 transition-colors hover:bg-danger/10 hover:text-danger"
                  >
                    <Icon name="trash" size={13} />
                  </button>
                </div>
              ))}
              {skills.length === 0 ? (
                <div className="py-6 text-center text-[12px] text-ink-500">
                  Скиллов пока нет — установите из примеров выше, и рой начнёт их применять.
                </div>
              ) : null}
            </div>
          )}

          {tab === "about" && (
            <div className="space-y-4 text-[12.5px] leading-relaxed text-ink-300">
              <p>
                <b className="text-ink-50">Svarma</b> — веб-IDE для разработки приложений силами автономного роя.
                Построен на движке <span className="text-accent2">advanced-autonomous-ai-programmer</span> (SUPER ROY).
              </p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  ["АРХИТЕКТОР", "разбирает бриф и строит спецификацию", "ARCHITECT"],
                  ["РАЗВЕДЧИК", "ищет готовые решения на GitHub/HN/PyPI и торренты моделей", "SCOUT"],
                  ["МОЗГ МУХИ", "эволюционирующая LSH-память вместо векторной БД", "FLY"],
                  ["КУЗНЕЦ", "куёт недостающие модули с тестами и доками", "FORGE"],
                  ["ИНЖЕНЕР", "генерирует весь код проекта по спецификации", "ENGINEER"],
                  ["КРИТИК", "статический анализ, 12 проверок, авторемонт", "CRITIC"],
                  ["ИНТЕГРАТОР", "собирает итоговый проект и ZIP-архив", "INTEGRATOR"],
                ].map(([label, hint, agent]) => (
                  <div key={agent} className={`rounded-xl border border-ink-750 bg-ink-900 p-3 agent-${agent}`}>
                    <div className="text-[11.5px] font-bold" style={{ color: "var(--ag)" }}>
                      {label}
                    </div>
                    <div className="mt-1 text-[10.5px] leading-snug text-ink-400">{hint}</div>
                  </div>
                ))}
              </div>
              <div className="rounded-xl border border-ink-750 bg-ink-900 p-3.5 font-mono text-[11px] text-ink-400">
                <div>хранилище — in-memory + автосейв в .data/svarma-db.json</div>
                <div>LLM — {providers.length} провайдеров: ключевые и безключевые, облако и локально</div>
                <div>скиллы — открытый формат vercel-labs/skills, установка из GitHub</div>
                <div>архитектура движка — Next.js API + порт lib/{"{brief,plan,forge,codegen,qa,fly,scout,skills}"}</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
