import { crc32, deflateRawSync } from "node:zlib";

/**
 * Свой ZIP-писатель (PKZIP). Без JSZip: в iframe-превью сторонний пакет
 * иногда отдаёт битый архив или HTML вместо файла.
 */

function dosDate(date: Date) {
  const time =
    ((date.getHours() & 31) << 11) |
    ((date.getMinutes() & 63) << 5) |
    (Math.floor(date.getSeconds() / 2) & 31);
  const day =
    (((date.getFullYear() - 1980) & 127) << 9) |
    (((date.getMonth() + 1) & 15) << 5) |
    (date.getDate() & 31);
  return { time, day };
}

function u16(value: number) {
  const buf = Buffer.alloc(2);
  buf.writeUInt16LE(value >>> 0, 0);
  return buf;
}

function u32(value: number) {
  const buf = Buffer.alloc(4);
  buf.writeUInt32LE(value >>> 0, 0);
  return buf;
}

export type ZipEntry = { path: string; content: string | Buffer };

export function makeZip(files: ZipEntry[]): Buffer {
  const now = dosDate(new Date());
  const locals: Buffer[] = [];
  const centrals: Buffer[] = [];
  let offset = 0;

  for (const file of files) {
    const name = file.path.replace(/\\/g, "/").replace(/^\/+/, "").slice(0, 240) || "file.txt";
    const nameBuf = Buffer.from(name, "utf8");
    const data = Buffer.isBuffer(file.content) ? file.content : Buffer.from(file.content, "utf8");
    const compressed = deflateRawSync(data);
    const crc = crc32(data) >>> 0;

    const local = Buffer.concat([
      u32(0x04034b50),
      u16(20),
      u16(0x0800), // UTF-8
      u16(8), // deflate
      u16(now.time),
      u16(now.day),
      u32(crc),
      u32(compressed.length),
      u32(data.length),
      u16(nameBuf.length),
      u16(0),
      nameBuf,
      compressed,
    ]);
    locals.push(local);

    const central = Buffer.concat([
      u32(0x02014b50),
      u16(20),
      u16(20),
      u16(0x0800),
      u16(8),
      u16(now.time),
      u16(now.day),
      u32(crc),
      u32(compressed.length),
      u32(data.length),
      u16(nameBuf.length),
      u16(0),
      u16(0),
      u16(0),
      u16(0),
      u32(0),
      u32(offset),
      nameBuf,
    ]);
    centrals.push(central);
    offset += local.length;
  }

  const centralDir = Buffer.concat(centrals);
  const eocd = Buffer.concat([
    u32(0x06054b50),
    u16(0),
    u16(0),
    u16(files.length),
    u16(files.length),
    u32(centralDir.length),
    u32(offset),
    u16(0),
  ]);
  return Buffer.concat([...locals, centralDir, eocd]);
}

export function safeZipName(raw: string, fallback = "project"): string {
  const ascii = raw
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 48);
  return ascii || fallback;
}
