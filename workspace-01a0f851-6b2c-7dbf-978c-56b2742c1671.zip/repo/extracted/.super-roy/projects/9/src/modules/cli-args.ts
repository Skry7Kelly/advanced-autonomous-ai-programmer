export interface ParsedArgs {
  command: string;
  flags: Record<string, string | boolean | string[]>;
  positionals: string[];
}

export function parseArgs(argv: string[]): ParsedArgs {
  const [command = 'main', ...rest] = argv;
  const flags: Record<string, string | boolean | string[]> = {};
  const positionals: string[] = [];
  for (let i = 0; i < rest.length; i++) {
    const token = rest[i];
    if (!token.startsWith('-')) {
      positionals.push(token);
      continue;
    }
    const key = token.replace(/^-+/, '');
    const eqIndex = key.indexOf('=');
    if (eqIndex > 0) {
      flags[key.slice(0, eqIndex)] = key.slice(eqIndex + 1);
      continue;
    }
    const next = rest[i + 1];
    if (next !== undefined && !next.startsWith('-')) {
      const existing = flags[key];
      if (Array.isArray(existing)) existing.push(next);
      else if (existing !== undefined) flags[key] = [String(existing), next];
      else flags[key] = next;
      i += 1;
    } else {
      flags[key] = true;
    }
  }
  return { command, flags, positionals };
}

export function helpText(name: string, commands: { command: string; description: string; flags?: string[] }[]): string {
  const lines = [name, '', 'Команды:'];
  for (const c of commands) {
    lines.push('  ' + c.command.padEnd(18) + c.description);
    (c.flags ?? []).forEach((f) => lines.push('      ' + f));
  }
  return lines.join('\n');
}