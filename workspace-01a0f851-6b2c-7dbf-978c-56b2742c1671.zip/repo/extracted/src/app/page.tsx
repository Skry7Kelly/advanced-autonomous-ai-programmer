import VibeIde from "@/components/VibeIde";

export const dynamic = "force-dynamic";

export default function Home() {
  return <VibeIde />;
}
