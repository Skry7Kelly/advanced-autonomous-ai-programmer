import test from 'node:test';
import assert from 'node:assert/strict';
import { createLogger } from '../src/modules/logger.js';

test('маскирует секреты и уважает уровень', () => {
  const lines: string[] = [];
  const log = createLogger('info', { agent: 'test' }, (l) => lines.push(l));
  log.info('hello', { apiKey: 'abc', plain: 'ok' });
  log.debug('скрыто');
  const parsed = JSON.parse(lines[0]);
  assert.equal(parsed.data.apiKey, '[redacted]');
  assert.equal(parsed.data.plain, 'ok');
  assert.equal(lines.length, 1);
});