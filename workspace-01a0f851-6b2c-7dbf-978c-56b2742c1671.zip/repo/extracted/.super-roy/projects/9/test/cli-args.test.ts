import test from 'node:test';
import assert from 'node:assert/strict';
import { parseArgs } from '../src/modules/cli-args.js';

test('читает флаги и позиционные аргументы', () => {
  const parsed = parseArgs(['run', '--depth', '3', '--proxy', 'http://a', '--proxy', 'http://b', 'extra', '--dry']);
  assert.equal(parsed.command, 'run');
  assert.equal(parsed.flags.depth, '3');
  assert.deepEqual(parsed.flags.proxy, ['http://a', 'http://b']);
  assert.deepEqual(parsed.positionals, ['extra']);
  assert.equal(parsed.flags.dry, true);
});