export interface FieldSpec {
  key: string;
  required?: boolean;
  def?: string;
  number?: boolean;
  boolean?: boolean;
  enum?: string[];
}

export interface ConfigIssue { key: string; message: string }

export function loadConfig<T extends object>(spec: FieldSpec[], source: Record<string, string | undefined> = process.env): { config: T; issues: ConfigIssue[] } {
  const config: Record<string, unknown> = {};
  const issues: ConfigIssue[] = [];
  for (const field of spec) {
    let raw = source[field.key];
    if (raw === undefined || raw === '') {
      if (field.required) {
        issues.push({ key: field.key, message: 'обязательная переменная не задана' });
        continue;
      }
      config[field.key] = field.def ?? (field.number ? 0 : field.boolean ? false : '');
      continue;
    }
    if (field.number) {
      const num = Number(raw);
      if (Number.isNaN(num)) {
        issues.push({ key: field.key, message: 'ожидается число, получено: ' + raw });
        config[field.key] = field.def !== undefined && !Number.isNaN(Number(field.def)) ? Number(field.def) : 0;
        continue;
      }
      config[field.key] = num;
      continue;
    }
    if (field.boolean) {
      config[field.key] = /^(1|true|yes|on)$/i.test(raw);
      continue;
    }
    if (field.enum && !field.enum.includes(raw)) {
      issues.push({ key: field.key, message: 'ожидается одно из: ' + field.enum.join(', ') });
      config[field.key] = field.def ?? field.enum[0];
      continue;
    }
    config[field.key] = raw;
  }
  return { config: config as unknown as T, issues };
}