import { createRepository, type Repository, type StoredRecord } from './store.js';

// Сущности выведены из брифа архитектором роя.
export interface Item extends StoredRecord {
  title: string;
  status: string;
  payload: string;
  created_at: string;
}
export interface Run extends StoredRecord {
  target_id: number;
  state: string;
  log: string;
  started_at: string;
  finished_at: string;
}
export interface EventsLog extends StoredRecord {
  actor: string;
  action: string;
  payload: string;
  created_at: string;
}

export const repositories = {
  items: createRepository<Item>('items'),
  runs: createRepository<Run>('runs'),
  events_log: createRepository<EventsLog>('events_log'),
} satisfies Record<string, Repository<StoredRecord>>;

export type RepositoryMap = typeof repositories;