export type Schema =
  | { type: 'string'; min?: number; max?: number; pattern?: string; optional?: boolean }
  | { type: 'number'; min?: number; max?: number; integer?: boolean; optional?: boolean }
  | { type: 'boolean'; optional?: boolean }
  | { type: 'enum'; values: string[]; optional?: boolean }
  | { type: 'array'; items: Schema; max?: number; optional?: boolean }
  | { type: 'object'; fields: Record<string, Schema>; optional?: boolean };

export interface Issue { path: string; message: string }

export function validate(value: unknown, schema: Schema, path = '$'): Issue[] {
  if (value === undefined || value === null) {
    return schema.optional ? [] : [{ path, message: 'обязательное поле' }];
  }
  switch (schema.type) {
    case 'string': {
      if (typeof value !== 'string') return [{ path, message: 'ожидается строка' }];
      const issues: Issue[] = [];
      if (schema.min !== undefined && value.length < schema.min) issues.push({ path, message: 'короче ' + schema.min });
      if (schema.max !== undefined && value.length > schema.max) issues.push({ path, message: 'длиннее ' + schema.max });
      if (schema.pattern && !new RegExp(schema.pattern).test(value)) issues.push({ path, message: 'не совпадает с шаблоном' });
      return issues;
    }
    case 'number': {
      if (typeof value !== 'number' || Number.isNaN(value)) return [{ path, message: 'ожидается число' }];
      const issues: Issue[] = [];
      if (schema.integer && !Number.isInteger(value)) issues.push({ path, message: 'ожидается целое' });
      if (schema.min !== undefined && value < schema.min) issues.push({ path, message: 'меньше ' + schema.min });
      if (schema.max !== undefined && value > schema.max) issues.push({ path, message: 'больше ' + schema.max });
      return issues;
    }
    case 'boolean':
      return typeof value === 'boolean' ? [] : [{ path, message: 'ожидается boolean' }];
    case 'enum':
      return schema.values.includes(String(value)) ? [] : [{ path, message: 'ожидается одно из: ' + schema.values.join(', ') }];
    case 'array': {
      if (!Array.isArray(value)) return [{ path, message: 'ожидается массив' }];
      const issues: Issue[] = [];
      if (schema.max && value.length > schema.max) issues.push({ path, message: 'больше ' + schema.max + ' элементов' });
      value.forEach((item, i) => issues.push(...validate(item, schema.items, path + '[' + i + ']')));
      return issues;
    }
    case 'object': {
      if (typeof value !== 'object' || Array.isArray(value)) return [{ path, message: 'ожидается объект' }];
      const issues: Issue[] = [];
      const record = value as Record<string, unknown>;
      for (const [key, child] of Object.entries(schema.fields)) {
        issues.push(...validate(record[key], child, path + '.' + key));
      }
      return issues;
    }
  }
}