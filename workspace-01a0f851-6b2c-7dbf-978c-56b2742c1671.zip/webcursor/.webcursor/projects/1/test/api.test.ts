import test from 'node:test';
import assert from 'node:assert/strict';
import { buildApp, state } from '../src/app.js';

function makeReq(method: string, path: string, body?: unknown) {
  const headers: Record<string, string> = { host: 'localhost' };
  if (body !== undefined) headers['content-length'] = String(JSON.stringify(body).length);
  return { method, url: path, headers, async *[Symbol.asyncIterator]() { if (body !== undefined) yield Buffer.from(JSON.stringify(body)); } };
}

function makeRes() {
  const chunks: string[] = [];
  return {
    chunks,
    statusCode: 200,
    writableEnded: false,
    writeHead(code: number) { this.statusCode = code; },
    end(text?: string) { if (text) chunks.push(text); this.writableEnded = true; },
    text() { return chunks.join(''); },
  };
}

test('GET /health отвечает ok', async () => {
  const app = buildApp();
  const res = makeRes();
  await app.handle(makeReq('GET', '/health') as never, res as never);
  const parsed = JSON.parse(res.text());
  assert.equal(parsed.status, 'ok');
});

test('создание и чтение записи', async () => {
  const app = buildApp();
  const created = makeRes();
  await app.handle(makeReq('POST', '/api/users', { title: 'проверка' }) as never, created as never);
  const item = JSON.parse(created.text()).item;
  assert.ok(item.id);
  const read = makeRes();
  await app.handle(makeReq('GET', '/api/users/' + item.id) as never, read as never);
  assert.equal(JSON.parse(read.text()).item.id, item.id);
});

test('валидация отклоняет мусор', async () => {
  const app = buildApp();
  const res = makeRes();
  await app.handle(makeReq('GET', '/api/memory?q=') as never, res as never);
  assert.equal(res.statusCode, 422);
});

test('память роя находит по смыслу', async () => {
  state.memory.add('note1', 'ротация прокси пула для парсинга');
  const hits = state.memory.search('прокси ротация при парсинге', 2);
  assert.ok(hits.length >= 1);
});