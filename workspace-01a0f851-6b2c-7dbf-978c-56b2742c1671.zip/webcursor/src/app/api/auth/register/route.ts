import { eq } from "@/db/orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, ensureSeed, hashPassword, publicUser, sessionCookieHeader, usageOf } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { email?: string; password?: string; name?: string };
  const email = (body.email ?? "").trim().toLowerCase();
  const password = body.password ?? "";
  const name = (body.name ?? "").trim() || email.split("@")[0];
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return Response.json({ error: "Некорректный e-mail" }, { status: 400 });
  if (password.length < 6) return Response.json({ error: "Пароль — минимум 6 символов" }, { status: 400 });
  if (name.length < 2) return Response.json({ error: "Укажите имя (минимум 2 символа)" }, { status: 400 });
  await ensureSeed();
  const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing) return Response.json({ error: "Такой e-mail уже зарегистрирован" }, { status: 409 });
  const [user] = await db
    .insert(users)
    .values({ email, name, passwordHash: hashPassword(password), provider: "email", providerId: "" })
    .returning();
  const { token } = await createSession(user.id);
  return Response.json(
    { user: publicUser(user), usage: await usageOf(user) },
    { status: 201, headers: { "set-cookie": sessionCookieHeader(token) } },
  );
}
