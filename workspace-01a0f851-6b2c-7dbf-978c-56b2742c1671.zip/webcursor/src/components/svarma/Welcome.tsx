"use client";

import { useEffect, useState } from "react";
import { Icon } from "./icons";
import { BackgroundFX } from "./BackgroundFX";
import { STARTERS, type ProjectRow, type UsageInfo } from "./types";

const LANGS = ["typescript", "javascript", "python"];

const STATS = [
  { value: "7", label: "агентов в рое" },
  { value: "61 файл", label: "за 17 секунд*" },
  { value: "100/100", label: "QA-score прогона" },
  { value: "33", label: "скилла установлено" },
];

const PIPELINE = ["АРХИТЕКТОР", "РАЗВЕДЧИК", "МОЗГ МУХИ", "КУЗНЕЦ", "ИНЖЕНЕР", "КРИТИК", "ИНТЕГРАТОР"];

const IDEAS = [
  "REST API трекера привычек с JWT…",
  "дашборд аналитики на React…",
  "телеграм-бот для команды…",
  "сайт-портфолио с блогом…",
  "CLI-инструмент для деплоя…",
  "игру-кликер на TypeScript…",
];

function fmtDate(iso: string): string {
  return new Date(iso).toLocaleString("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

function useTypewriter(words: string[]): { text: string; full: string } {
  const [idx, setIdx] = useState(0);
  const [len, setLen] = useState(0);
  const word = words[idx % words.length];
  useEffect(() => {
    if (len < word.length) {
      const t = setTimeout(() => setLen(len + 1), 46);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => {
      setLen(0);
      setIdx((i) => (i + 1) % words.length);
    }, 2100);
    return () => clearTimeout(t);
  }, [len, word, words]);
  return { text: word.slice(0, len), full: word };
}

export default function Welcome({
  projects,
  busy,
  usage,
  onOpenPlans,
  onCreate,
  onOpen,
  onDelete,
}: {
  projects: ProjectRow[];
  busy: boolean;
  usage: UsageInfo | null;
  onOpenPlans: () => void;
  onCreate: (brief: string, settings: Record<string, unknown>) => Promise<void>;
  onOpen: (id: number) => void;
  onDelete: (id: number) => Promise<void>;
}) {
  const [brief, setBrief] = useState("");
  const [advanced, setAdvanced] = useState(false);
  const [settings, setSettings] = useState<Record<string, unknown>>({
    targetLanguage: "typescript",
    searchDepth: 2,
    maxAdopt: 4,
    flyBoost: true,
    allowForge: true,
    cloudLlm: true,
    localLlm: true,
  });
  const typed = useTypewriter(IDEAS);

  const set = <K extends string>(key: K, value: unknown) => setSettings((s) => ({ ...s, [key]: value }));
  const canCreate = brief.trim().length >= 12 && !busy;

  return (
    <div className="scroll-y relative h-screen overflow-y-auto bg-ink-950">
      <BackgroundFX />

      <div className="relative mx-auto flex min-h-screen w-full max-w-6xl flex-col px-5 pb-10 pt-8 sm:px-8">
        {/* ------------------------------ шапка ------------------------------ */}
        <header className="animate-rise flex flex-col items-center text-center">
          <div className="relative">
            <span className="animate-pulse-ring absolute inset-0 rounded-3xl border border-accent2/40" />
            <Icon name="logo" size={56} className="animate-float relative animate-glow" />
            <span className="absolute -right-9 -top-1 rounded-full border border-accent2/40 bg-ink-850 px-1.5 py-px font-mono text-[9px] text-accent2">v1.2</span>
          </div>
          <h1 className="mt-4 text-[26px] font-bold tracking-[0.26em] text-ink-50">
            SVAR<span className="text-gradient">MA</span>
          </h1>
          <p className="mt-1.5 text-[10.5px] uppercase tracking-[0.22em] text-ink-500">рой ИИ-агентов, выковывающий приложения</p>

          {/* квоты тарифа */}
          {usage ? (
            <div className="mt-5 inline-flex flex-wrap items-center justify-center gap-x-4 gap-y-2 rounded-2xl border border-ink-750 bg-ink-900/70 px-4 py-2.5 text-[11.5px] text-ink-300 backdrop-blur">
              <span className="flex items-center gap-1.5">
                <Icon name="sparkles" size={12} className={usage.plan === "free" ? "text-ink-400" : "text-accent3"} />
                Тариф <b className={usage.plan === "free" ? "text-ink-100" : "text-accent3"}>{usage.plan === "free" ? "Free" : usage.plan === "pro" ? "Pro" : "Team"}</b>
              </span>
              <span className="text-ink-600">·</span>
              <span className="font-mono">
                проекты {usage.projects}/{usage.projectLimit >= 100000 ? "∞" : usage.projectLimit}
              </span>
              <span className="text-ink-600">·</span>
              <span className="font-mono">
                запросы сегодня {usage.chatUsedToday}/{usage.chatLimit >= 5000 ? "∞" : usage.chatLimit}
              </span>
              {usage.plan === "free" ? (
                <button onClick={onOpenPlans} className="btn btn-accent !px-3 !py-1 !text-[11px] !font-semibold">
                  <Icon name="zap" size={11} /> Улучшить тариф
                </button>
              ) : null}
            </div>
          ) : null}
        </header>

        {/* ------------------------------- hero ------------------------------- */}
        <div className="mt-10 grid flex-1 items-start gap-10 lg:grid-cols-[1.05fr_0.95fr]">
          {/* левая колонка */}
          <div className="animate-rise min-w-0" style={{ animationDelay: "0.1s" }}>
            <h2 className="text-balance text-[2rem] font-extrabold leading-[1.1] tracking-tight text-ink-50 sm:text-[2.5rem]">
              Что <span className="animate-pan text-gradient">выкует рой</span> сегодня?
            </h2>
            <p className="mt-4 max-w-lg text-[14px] leading-relaxed text-ink-300">
              Один абзац текста — и семь агентов спроектируют архитектуру, найдут готовые решения,
              сгенерируют код с тестами, проверят качество и соберут ZIP. Правки принимаются
              построчными диффами, как в Cursor.
            </p>

            {/* терминальная строка с идеями */}
            <button
              onClick={() => setBrief(typed.full.replace(/…$/, ""))}
              title="Вставить эту идею в бриф"
              className="mt-5 flex w-full max-w-lg items-center gap-2.5 rounded-xl border border-ink-750 bg-ink-950/70 px-3.5 py-2.5 text-left font-mono text-[12.5px] text-ink-300 backdrop-blur transition-colors hover:border-accent2/35"
            >
              <span className="text-accent3">❯</span>
              <span className="text-ink-500">бриф:</span>
              <span className="min-w-0 flex-1 truncate text-ink-100">{typed.text}</span>
              <span className="animate-caret -mb-0.5 inline-block h-[1.15em] w-[2px] shrink-0 bg-accent2" />
              <Icon name="download" size={12} className="shrink-0 text-ink-500" />
            </button>

            {/* статистика */}
            <div className="mt-6 grid max-w-lg grid-cols-2 gap-px overflow-hidden rounded-2xl border border-ink-750 bg-ink-750 sm:grid-cols-4">
              {STATS.map((s) => (
                <div key={s.label} className="bg-ink-900/85 px-3.5 py-3">
                  <div className="text-[16px] font-bold leading-none text-ink-50">{s.value}</div>
                  <div className="mt-1.5 text-[10px] leading-snug text-ink-400">{s.label}</div>
                </div>
              ))}
            </div>

            {/* конвейер агентов */}
            <div className="marquee-track animate-rise relative mt-6 overflow-hidden py-1" style={{ animationDelay: "0.2s" }}>
              <div className="animate-marquee flex w-max items-center gap-3">
                {[...PIPELINE, ...PIPELINE].map((a, i) => (
                  <span key={`${a}-${i}`} className="flex items-center gap-3">
                    <span className="chip !border-ink-650 !bg-ink-900/70 !py-1.5 font-mono !text-[10.5px] tracking-wider text-ink-200">{a}</span>
                    <Icon name="chevronRight" size={12} className="text-ink-600" />
                  </span>
                ))}
              </div>
            </div>

            <p className="mt-5 text-[11px] leading-relaxed text-ink-500">
              48 LLM-провайдеров · 33 скилла (Claude + Vercel) · ZIP-экспорт · превью в браузере.
              <span className="text-ink-600"> * реальный прогон роя в демо.</span>
            </p>
          </div>

          {/* правая колонка — форма */}
          <div className="animate-rise w-full justify-self-end" style={{ animationDelay: "0.2s" }}>
            <div className="relative rounded-2xl p-px">
              <div className="absolute -inset-px overflow-hidden rounded-2xl">
                <div
                  className="animate-rotate-slow absolute left-1/2 top-1/2 aspect-square w-[280%] -translate-x-1/2 -translate-y-1/2"
                  style={{ background: "conic-gradient(from 0deg, transparent 0 42%, rgba(94,234,212,0.5) 47%, rgba(125,211,252,0.7) 50%, rgba(167,139,250,0.5) 53%, transparent 58% 100%)" }}
                />
              </div>

              <div className="glass relative rounded-2xl p-5 shadow-[0_30px_80px_-30px_rgba(0,0,0,0.9)]">
                <label className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-400">
                  <Icon name="sparkles" size={12} className="text-accent3" />
                  Что будем разрабатывать?
                </label>
                <textarea
                  value={brief}
                  onChange={(e) => setBrief(e.target.value)}
                  rows={4}
                  maxLength={2000}
                  placeholder="Например: REST API трекера привычек с пользователями, сериями дней, статистикой и JWT-авторизацией…"
                  className="input !bg-ink-950/80 !text-[14px] !leading-relaxed"
                />

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {STARTERS.map((s) => (
                    <button
                      key={s}
                      onClick={() => setBrief(s)}
                      className="chip max-w-full !py-1.5 transition-all hover:!border-accent2/50 hover:!text-accent2"
                      title={s}
                    >
                      <Icon name="sparkles" size={11} />
                      <span className="max-w-72 truncate">{s}</span>
                    </button>
                  ))}
                </div>

                {/* расширенные настройки */}
                <button
                  onClick={() => setAdvanced((v) => !v)}
                  className="mt-4 flex items-center gap-1.5 text-[11.5px] text-ink-400 transition-colors hover:text-ink-200"
                >
                  <Icon name={advanced ? "chevronDown" : "chevronRight"} size={12} />
                  Настройки роя
                </button>

                {advanced ? (
                  <div className="mt-3 grid animate-slide-up grid-cols-1 gap-3 rounded-xl border border-ink-750 bg-ink-950/60 p-4 sm:grid-cols-2">
                    <div>
                      <label className="mb-1.5 block text-[11px] text-ink-400">Язык проекта</label>
                      <div className="flex gap-1.5">
                        {LANGS.map((l) => (
                          <button
                            key={l}
                            onClick={() => set("targetLanguage", l)}
                            className={`btn !py-1.5 ${settings.targetLanguage === l ? "!border-accent2/50 !text-accent2" : ""}`}
                          >
                            {l === "typescript" ? "TS" : l === "javascript" ? "JS" : "PY"}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="mb-1.5 block text-[11px] text-ink-400">
                        Глубина разведки: <b className="text-ink-200">{String(settings.searchDepth)}</b> из 3
                      </label>
                      <input
                        type="range"
                        min={1}
                        max={3}
                        value={Number(settings.searchDepth)}
                        onChange={(e) => set("searchDepth", Number(e.target.value))}
                        className="w-full accent-accent2"
                      />
                    </div>
                    {(
                      [
                        ["allowForge", "Кузнец", "выковывать недостающие модули с нуля"],
                        ["flyBoost", "Мозг мухи", "переиспользовать память похожих решений"],
                        ["cloudLlm", "Облачные LLM", "все 48 провайдеров с ключами"],
                        ["localLlm", "Локальные LLM", "Ollama / vLLM / llama.cpp / LM Studio"],
                      ] as const
                    ).map(([key, label, hint]) => (
                      <button
                        key={key}
                        onClick={() => set(key, !settings[key])}
                        className="flex items-center gap-3 rounded-lg border border-ink-750 bg-ink-880 px-3 py-2.5 text-left transition-all hover:border-ink-600"
                      >
                        <span
                          className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${settings[key] ? "bg-accent2/70" : "bg-ink-700"}`}
                        >
                          <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-ink-950 transition-all ${settings[key] ? "left-[18px]" : "left-0.5"}`} />
                        </span>
                        <span>
                          <span className="block text-[12px] font-medium text-ink-100">{label}</span>
                          <span className="block text-[10.5px] text-ink-500">{hint}</span>
                        </span>
                      </button>
                    ))}
                  </div>
                ) : null}

                <div className="mt-5 flex items-center gap-3">
                  <button
                    disabled={!canCreate}
                    onClick={() => void onCreate(brief.trim(), settings)}
                    className="btn btn-accent !px-6 !py-2.5 !text-[13.5px] !font-semibold disabled:opacity-40"
                  >
                    {busy ? (
                      <>
                        <span className="h-3.5 w-3.5 animate-spin-slow rounded-full border-2 border-accent2/30 border-t-accent2" />
                        Рой собирается…
                      </>
                    ) : (
                      <>
                        <Icon name="zap" size={15} />
                        Создать и собрать
                      </>
                    )}
                  </button>
                  <span className="text-[11.5px] text-ink-500">
                    {brief.trim().length < 12 ? "Опишите задачу хотя бы в 12 символах" : "Конвейер запустится автоматически"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* --------------------------- недавние проекты --------------------------- */}
        {projects.length > 0 ? (
          <section className="animate-rise mt-12" style={{ animationDelay: "0.3s" }}>
            <h2 className="mb-4 flex items-baseline gap-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-500">
              Недавние проекты
              <span className="font-mono text-[10px] normal-case text-ink-600">{projects.length}</span>
            </h2>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {projects.map((p) => (
                <div key={p.id} className="glass group relative overflow-hidden rounded-xl p-4 transition-all duration-300 hover:-translate-y-1 hover:border-accent2/35 hover:shadow-[0_10px_40px_-15px_rgba(125,211,252,0.3)]">
                  <div className="pointer-events-none absolute -right-8 -top-8 h-20 w-20 rounded-full bg-accent2/0 blur-2xl transition-all duration-500 group-hover:bg-accent2/12" />
                  <button onClick={() => onOpen(p.id)} className="block w-full text-left">
                    <div className="flex items-start justify-between gap-2">
                      <span className="line-clamp-2 text-[13.5px] font-semibold leading-snug text-ink-50">{p.name}</span>
                      <span
                        className={`chip shrink-0 !py-0.5 !text-[9.5px] ${
                          p.status === "done"
                            ? "!border-ok/40 !text-ok"
                            : p.status === "failed"
                              ? "!border-danger/40 !text-danger"
                              : "!border-accent2/40 !text-accent2"
                        }`}
                      >
                        {p.status === "running" || p.status === "queued" ? "в работе" : p.status === "done" ? "готов" : p.status === "failed" ? "ошибка" : p.status}
                      </span>
                    </div>
                    <p className="mt-2 line-clamp-2 text-[11.5px] leading-snug text-ink-400">{p.brief}</p>
                    <div className="mt-3 flex items-center gap-2 text-[10.5px] text-ink-500">
                      <span className="rounded bg-ink-800 px-1.5 py-0.5 font-mono">{p.kind}</span>
                      {p.stats?.files ? <span>{p.stats.files} файлов</span> : null}
                      {p.stats?.qaScore ? <span className={p.stats.qaScore >= 80 ? "text-ok" : "text-warn"}>QA {p.stats.qaScore}</span> : null}
                      <span className="ml-auto">{fmtDate(p.createdAt)}</span>
                    </div>
                  </button>
                  <button
                    onClick={() => void onDelete(p.id)}
                    className="absolute right-2.5 top-2.5 rounded-lg p-1.5 text-ink-600 opacity-0 transition-all hover:bg-danger/10 hover:text-danger group-hover:opacity-100"
                    title="Удалить проект"
                  >
                    <Icon name="trash" size={13} />
                  </button>
                </div>
              ))}
            </div>
          </section>
        ) : null}

        {/* ------------------------------- футер ------------------------------- */}
        <footer className="mt-14 flex flex-col items-center gap-2 border-t border-ink-850 pt-6 text-center">
          <p className="text-[11px] leading-relaxed text-ink-500">
            Svarma работает без ключей и баз данных: встроенный движок + бесплатные LLM-шлюзы.
            <br className="hidden sm:block" /> Подключите любой из 48 провайдеров в настройках — рой станет умнее.
          </p>
          <a
            href="https://github.com/Skry7Kelly/advanced-autonomous-ai-programmer"
            target="_blank"
            rel="noreferrer noopener"
            className="flex items-center gap-1.5 text-[11px] text-ink-400 transition-colors hover:text-accent2"
          >
            <Icon name="github" size={13} /> движок: advanced-autonomous-ai-programmer
          </a>
        </footer>
      </div>
    </div>
  );
}
