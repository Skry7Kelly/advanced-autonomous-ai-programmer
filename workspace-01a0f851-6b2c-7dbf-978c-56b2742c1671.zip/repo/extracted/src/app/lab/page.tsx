import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { flyBrains, projects, sources } from "@/db/schema";
import SwarmConsole from "@/components/SwarmConsole";

export const dynamic = "force-dynamic";

export default async function LabPage() {
  let projectCount = 0;
  let brainCount = 0;
  let sourceCount = 0;
  try {
    projectCount = (await db.select({ id: projects.id }).from(projects).orderBy(desc(projects.id)).limit(200)).length;
    brainCount = (await db.select({ id: flyBrains.id }).from(flyBrains).limit(50)).length;
    sourceCount = (await db.select({ id: sources.id }).from(sources).limit(5000)).length;
  } catch {
    projectCount = 0;
  }

  return (
    <main className="mx-auto max-w-[1400px] px-4 py-6 sm:px-6">
      <header className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <Link href="/" className="text-[11px] text-[#5f738a] hover:text-sky-300">
              ← vibe ide
            </Link>
            <h1 className="text-2xl font-bold tracking-tight text-[#e8f1fa]">Лаборатория роя</h1>
          </div>
          <p className="mt-2 max-w-3xl text-[12px] leading-relaxed text-[#7d93ab]">
            Разведка PirateFace/GitHub, мозг мухи, кузница модулей и пул прокси. Сборка программ — в основном окне IDE.
          </p>
        </div>
        <div className="flex gap-2 text-[11px] text-[#8ba3bb]">
          <span>проектов {projectCount}</span>
          <span>источников {sourceCount}</span>
          <span>мозгов {brainCount}</span>
        </div>
      </header>
      <SwarmConsole />
    </main>
  );
}
