import { loadConfig } from './modules/config.js';

export interface AppConfig {
  PORT: number;
  LOG_LEVEL: string;
  DATA_DIR: string;
  PROXY_LIST: string;
  RATE_LIMIT_PER_MIN: number;
  LLM_BASE_URL: string;
  LLM_MODEL: string;
}

const { config, issues } = loadConfig<AppConfig>([
  { key: 'PORT', number: true, def: '8787' },
  { key: 'LOG_LEVEL', enum: ['debug', 'info', 'warn', 'error'], def: 'info' },
  { key: 'DATA_DIR', def: './data' },
  { key: 'PROXY_LIST', def: '' },
  { key: 'RATE_LIMIT_PER_MIN', number: true, def: '120' },
  { key: 'LLM_BASE_URL', def: 'http://127.0.0.1:11434' },
  { key: 'LLM_MODEL', def: '' },
]);

if (issues.length > 0) {
  console.error('[config] проблемы конфигурации:', issues);
}

export const appConfig: AppConfig = config;