import { parseISO } from 'node:util';

/**
 * Строка даты в формате ISO 8601, например "2024-10-01T12:34:56Z".
 */
export type ISODateString = string;

/**
 * Запись статистики за неделю.
 */
export interface WeeklyStatsEntry {
  /**
   * Начало недели (понедельник) в формате ISO 8601 без времени.
   */
  weekStart: string;
  /**
   * Количество событий за эту неделю.
   */
  count: number;
}

/**
 * Вычисляет статистику по событиям, сгруппированную по неделям.
 *
 * @param events Массив объектов, содержащих поле `date` в ISO формате.
 * @returns Массив записей статистики, отсортированный по возрастанию недели.
 */
export function computeWeeklyStats(events: Array<{ date: ISODateString }>): WeeklyStatsEntry[] {
  const weekMap = new Map<string, number>();

  for (const ev of events) {
    const d = new Date(ev.date);
    if (Number.isNaN(d.getTime())) {
      continue; // игнорируем некорректные даты
    }
    const weekStart = getWeekStart(d);
    const key = weekStart.toISOString().split('T')[0]; // YYYY-MM-DD
    weekMap.set(key, (weekMap.get(key) ?? 0) + 1);
  }

  const result: WeeklyStatsEntry[] = [];
  for (const [key, count] of weekMap.entries()) {
    result.push({ weekStart: key, count });
  }

  result.sort((a, b) => (a.weekStart < b.weekStart ? -1 : a.weekStart > b.weekStart ? 1 : 0));
  return result;
}

/**
 * Возвращает объект Date, представляющий понедельник недели, к которой принадлежит дата.
 * Время обнуляется до 00:00 UTC.
 */
function getWeekStart(date: Date): Date {
  const utcDay = date.getUTCDay(); // 0 (Sun) - 6 (Sat)
  const diff = (utcDay + 6) % 7; // 0 (Mon) - 6 (Sun)
  const monday = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  monday.setUTCDate(monday.getUTCDate() - diff);
  monday.setUTCHours(0, 0, 0, 0);
  return monday;
}
