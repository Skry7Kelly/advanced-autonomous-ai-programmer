import { createWriteStream } from 'node:fs';
import { stat, unlink } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import { Readable } from 'node:stream';

export interface DownloadProgress { url: string; bytes: number; totalBytes: number | null; done: boolean }

export class ResumableDownloader {
  constructor(private readonly headers: Record<string, string> = {}) {}

  async size(url: string): Promise<number | null> {
    const res = await fetch(url, { method: 'HEAD', headers: this.headers });
    const len = res.headers.get('content-length');
    return res.ok && len ? Number(len) : null;
  }

  async download(url: string, destPath: string, onProgress?: (p: DownloadProgress) => void): Promise<{ bytes: number; resumed: boolean }> {
    let bytes = 0;
    let resumed = false;
    try {
      const existing = await stat(destPath);
      if (existing.size > 0) {
        bytes = existing.size;
        resumed = true;
      }
    } catch {
      // файла ещё нет
    }
    const total = await this.size(url);
    const headers: Record<string, string> = { ...this.headers };
    if (resumed) headers.range = 'bytes=' + bytes + '-';
    const res = await fetch(url, { headers });
    if (!res.ok && res.status !== 206) {
      await unlink(destPath).catch(() => {});
      throw new Error('download failed: ' + res.status);
    }
    if (!res.body) throw new Error('пустой ответ');
    let counter = bytes;
    const reporter = new Readable({
      read() {},
    });
    void reporter.push(Buffer.alloc(0));
    const source = Readable.fromWeb(res.body as Parameters<typeof Readable.fromWeb>[0]);
    source.on('data', (chunk: Buffer) => {
      counter += chunk.length;
      onProgress?.({ url, bytes: counter, totalBytes: total, done: false });
    });
    await pipeline(source, createWriteStream(destPath, { flags: resumed ? 'a' : 'w' }));
    reporter.destroy();
    onProgress?.({ url, bytes: counter, totalBytes: total, done: true });
    return { bytes: counter, resumed };
  }
}