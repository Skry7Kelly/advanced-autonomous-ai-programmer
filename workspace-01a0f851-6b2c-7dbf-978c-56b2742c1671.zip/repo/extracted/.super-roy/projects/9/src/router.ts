import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';

export interface RouteContext {
  req: IncomingMessage;
  res: ServerResponse;
  method: string;
  path: string;
  params: Record<string, string>;
  query: URLSearchParams;
  body: unknown;
  json: (data: unknown, status?: number) => void;
}

export type RouteHandler = (ctx: RouteContext) => unknown | Promise<unknown>;

interface Route { method: string; segments: string[]; handler: RouteHandler }

export interface Router {
  get: (path: string, handler: RouteHandler) => void;
  post: (path: string, handler: RouteHandler) => void;
  put: (path: string, handler: RouteHandler) => void;
  delete: (path: string, handler: RouteHandler) => void;
  handle: (req: IncomingMessage, res: ServerResponse) => Promise<boolean>;
  listen: (port: number) => Promise<void>;
  routes: () => { method: string; path: string }[];
}

export function createRouter(options: { onError?: (error: unknown, ctx: RouteContext) => void } = {}): Router {
  const routes: Route[] = [];

  const add = (method: string) => (path: string, handler: RouteHandler) => {
    routes.push({ method, segments: path.split('/').filter(Boolean), handler });
  };

  const readBody = async (req: IncomingMessage): Promise<unknown> => {
    const chunks: Buffer[] = [];
    for await (const chunk of req) chunks.push(chunk as Buffer);
    if (chunks.length === 0) return null;
    const raw = Buffer.concat(chunks).toString('utf8');
    try {
      return JSON.parse(raw);
    } catch {
      return raw;
    }
  };

  const match = (method: string, pathname: string): { route: Route; params: Record<string, string> } | null => {
    const parts = pathname.split('/').filter(Boolean);
    for (const route of routes) {
      if (route.method !== method) continue;
      if (route.segments.length !== parts.length) continue;
      const params: Record<string, string> = {};
      let matched = true;
      for (let i = 0; i < parts.length; i++) {
        const seg = route.segments[i];
        if (seg.startsWith(':')) params[seg.slice(1)] = decodeURIComponent(parts[i]);
        else if (seg !== parts[i]) { matched = false; break; }
      }
      if (matched) return { route, params };
    }
    return null;
  };

  return {
    get: add('GET'),
    post: add('POST'),
    put: add('PUT'),
    delete: add('DELETE'),
    routes: () => routes.map((r) => ({ method: r.method, path: '/' + r.segments.join('/') })),
    async handle(req, res) {
      const url = new URL(req.url ?? '/', 'http://localhost');
      const found = match(req.method ?? 'GET', url.pathname);
      if (!found) {
        res.writeHead(404, { 'content-type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ error: 'not_found', path: url.pathname }));
        return false;
      }
      const ctx: RouteContext = {
        req,
        res,
        method: req.method ?? 'GET',
        path: url.pathname,
        params: found.params,
        query: url.searchParams,
        body: null,
        json: (data, status = 200) => {
          res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify(data, null, 2));
        },
      };
      try {
        if (ctx.method !== 'GET') ctx.body = await readBody(req);
        const result = await found.route.handler(ctx);
        if (!res.writableEnded) ctx.json(result);
      } catch (error) {
        options.onError?.(error, ctx);
        const message = error instanceof Error ? error.message : String(error);
        const status = /not found|нет записи/.test(message) ? 404 : /валид|обязатель|invalid/.test(message) ? 422 : 500;
        if (!res.writableEnded) ctx.json({ error: message }, status);
      }
      return true;
    },
    listen(port) {
      return new Promise((resolve) => {
        createServer((req, res) => {
          void this.handle(req, res);
        }).listen(port, () => resolve());
      });
    },
  };
}