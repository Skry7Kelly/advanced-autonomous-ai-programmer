export interface Chunk { index: number; text: string; tokensApprox: number }

export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 3.6);
}

export function chunkText(
  text: string,
  opts: { maxTokens?: number; overlapTokens?: number } = {},
): Chunk[] {
  const maxTokens = opts.maxTokens ?? 700;
  const overlapTokens = Math.min(opts.overlapTokens ?? 80, Math.floor(maxTokens / 3));
  const sentences = text
    .replace(/\s+/g, ' ')
    .split(/(?<=[.!?。])\s+/)
    .filter(Boolean);
  const chunks: Chunk[] = [];
  let buffer: string[] = [];
  let bufferTokens = 0;
  const flush = (): void => {
    if (buffer.length === 0) return;
    const body = buffer.join(' ');
    chunks.push({ index: chunks.length, text: body, tokensApprox: estimateTokens(body) });
    const tail: string[] = [];
    let tailTokens = 0;
    for (let i = buffer.length - 1; i >= 0 && tailTokens < overlapTokens; i--) {
      tail.unshift(buffer[i]);
      tailTokens += estimateTokens(buffer[i]);
    }
    buffer = tail;
    bufferTokens = tailTokens;
  };
  for (const sentence of sentences) {
    const cost = estimateTokens(sentence);
    if (bufferTokens + cost > maxTokens && buffer.length > 0) flush();
    buffer.push(sentence);
    bufferTokens += cost;
  }
  flush();
  return chunks;
}