# REST API трекера привычек: пользователи

REST API трекера привычек: пользователи, серии дней, статистика прогресса, JWT-авторизация

> Проект спроектирован и собран роем ИИ-агентов SUPER ROY. Архитектура продумана до файлов, модули написаны, тесты приложены.

## Быстрый старт

```bash
npm install
cp .env.example .env
npm run start          # HTTP-сервис на http://localhost:8787
npm run cli -- doctor  # проверка конфигурации и хранилища
npm test               # тесты на критические пути
```

## Что уже работает

- **config** (src/config.ts) — Строгая загрузка конфигурации из env с валидацией при старте
- **logger** (src/logger.ts) — Структурные JSON-логи с маскировкой секретов
- **router** (src/router.ts) — Минимальный HTTP-роутер с параметрами пути и middleware
- **store** (src/store.ts) — Репозитории на JSONL-хранилище: CRUD, фильтры, счётчики
- **app** (src/app.ts) — Сборка эндпоинтов, обработчиков и фоновых задач в приложение
- **cli** (src/cli.ts) — CLI-команды: запуск сервера, импорт, проверка прокси, доктор
- **config** (src/modules/config.ts) — Конфигурация только через env со строгой валидацией и понятными ошибками запуска.
- **logger** (src/modules/logger.ts) — Структурные логи с уровнями, контекстом запроса и маскировкой секретов — обязательны для отладки роя.
- **retry** (src/modules/retry.ts) — Сеть и LLM шумные: нужны ретраи с джиттером, уважением к Retry-After и таймаутом на попытку.
- **result** (src/modules/result.ts) — Ошибки как значения: без исключений в бизнес-логике, с аккуратной агрегацией частичных сбоев роя.
- **validate** (src/modules/validate.ts) — Валидация входа API без тяжёлых зависимостей: типы, строки, числа, enum, вложенность, кастомные проверки.
- **rate-limit** (src/modules/rate-limit.ts) — Нужен контроль нагрузки на внешние API и локальные модели; в открытых репозиториях либо тяжёлые зависимости, либо нет ожидания и метрик.
- **json-store** (src/modules/json-store.ts) — Локальное хранилище журнала/артефактов: append-only JSONL + скан с фильтром, чтобы проект работал и без Postgres.
- **cli-args** (src/modules/cli-args.ts) — Парсер аргументов CLI: флаги, значения, массивы, подкоманды, автогенерация справки.
- **fly-index** (src/modules/fly-index.ts) — Ускорение мышления роя: LSH по принципу обонятельной системы мухи — без векторных БД и без обучения.
- **worker-pool** (src/modules/worker-pool.ts) — Параллельный обход источников и моделей с ограничением concurrency и сохранением порядка результатов.
- **proxy-pool** (src/modules/proxy-pool.ts) — Пользователю нужен допуск в интернет с прокси: ротация, health-check, карантин после сбоев — готовых лёгких решений нет.
- **text-chunker** (src/modules/text-chunker.ts) — Подготовка контекста для LLM: резка текста по границам предложений с перекрытием и токен-бюджетом.
- **model-downloader** (src/modules/model-downloader.ts) — Докачка весов модели по web-seed из PirateFace: докачка с Range-запросами и контрольной суммой размера.

## Эндпоинты

| Метод | Путь | Назначение |
| --- | --- | --- |
| GET | `/health` | Живость сервиса: uptime, число записей, состояние провайдеров |
| GET | `/api/tasks` | Журнал фоновых задач роя |
| GET | `/api/users` | Список «users» с пагинацией |
| POST | `/api/users` | Создание записи «users» |
| GET | `/api/users/:id` | Получить «users» по идентификатору |
| DELETE | `/api/users/:id` | Удалить «users» |
| GET | `/api/sessions` | Список «sessions» с пагинацией |
| POST | `/api/sessions` | Создание записи «sessions» |
| GET | `/api/sessions/:id` | Получить «sessions» по идентификатору |
| DELETE | `/api/sessions/:id` | Удалить «sessions» |
| GET | `/api/documents` | Список «documents» с пагинацией |
| POST | `/api/documents` | Создание записи «documents» |
| GET | `/api/documents/:id` | Получить «documents» по идентификатору |
| DELETE | `/api/documents/:id` | Удалить «documents» |
| GET | `/api/events` | Список «events_log» с пагинацией |
| POST | `/api/events` | Создание записи «events_log» |
| GET | `/api/events/:id` | Получить «events_log» по идентификатору |
| DELETE | `/api/events/:id` | Удалить «events_log» |
| POST | `/api/ask` | Запрос к LLM (локальной или бесплатной облачной) с контекстом из памяти |
| GET | `/api/memory` | Семантическая память: ближайшие записи по тегам мозга мухи |
| GET | `/api/stats` | Агрегированные метрики продукта |

## Хранилище

### users

Хранит сущность «users» из брифа: Аутентификация и роли, HTTP API

- `id` bigserial primary key — первичный ключ
- `email` text
- `password_hash` text
- `role` text
- `created_at` timestamptz default now()

### sessions

Хранит сущность «sessions» из брифа: Аутентификация и роли, HTTP API

- `id` bigserial primary key — первичный ключ
- `user_id` bigint
- `token` text
- `expires_at` timestamptz
- `ip` text

### documents

Хранит сущность «documents» из брифа: Аутентификация и роли, HTTP API

- `id` bigserial primary key — первичный ключ
- `title` text
- `source_url` text
- `content` jsonb
- `hash` text

### events_log

Хранит сущность «events_log» из брифа: Аутентификация и роли, HTTP API

- `id` bigserial primary key — первичный ключ
- `actor` text
- `action` text
- `payload` jsonb
- `created_at` timestamptz default now()

## CLI

- `npm run start` — Поднять HTTP-сервис
- `npm run cli -- doctor` — Проверить конфигурацию, хранилище и сеть
- `npm run cli -- import <файл>` — Импорт данных из JSONL/CSV
- `npm run cli -- export <файл>` — Экспорт хранилища
- `bash scripts/pull-models.sh` — Скачать локальные модели по магнет-ссылкам PirateFace

## Локальные модели (PirateFace.co)

Веса берём из суверенного индекса: checksums + магниты, качаем и гоняем локально без облака.

### ISTA-DASLab/Qwen3.8-Flash-Next-GSQ-RCO-Coder-GGUF

- размер: 30 GB, сидов: 3
- роль: основная модель для генерации кода и планирования
- команда: `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:d91faad0a0a8fcb9eece9441d49b011e423f418d&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FISTA-DASLab%2FQwen3.8-Flash-Next-GSQ-RCO-Coder-GGUF%2F04d8b36b50cc0479fda9214a378336f89b356d67%2F"`

### Qwen/Qwen2.5-Coder-7B-Instruct-GGUF

- размер: 15 GB, сидов: 2
- роль: резервная модель (другая квантизация)
- команда: `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:556995f1e8b9265253ca819f8f6b5133ba427848&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FQwen%2FQwen2.5-Coder-7B-Instruct-GGUF%2F13fb94bfda8c8cf22497dc57b78f391a9acb426a%2F"`

### Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF

- размер: 1.9 GB, сидов: 2
- роль: эмбеддинги/классификация для векторной памяти
- команда: `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:0b7c54e97fef910575c92974f8cd88d713401962&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FQwen%2FQwen2.5-Coder-1.5B-Instruct-GGUF%2Ff86cb2c1fa58255f8052cc32aeede1b7482d4361%2F"`

### unsloth/Qwen3-Coder-30B-A3B-Instruct-GGUF

- размер: 50 GB, сидов: 1
- роль: эмбеддинги/классификация для векторной памяти
- команда: `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:f29eca18c9bb3794241fab70b359c1316a9b2510&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2Funsloth%2FQwen3-Coder-30B-A3B-Instruct-GGUF%2Fb17cb02dd882d5b6ab62fc777ad2995f19668350%2F"`

Либо одной командой: `bash scripts/pull-models.sh` (нужен `aria2c`).

## Внедрённые репозитории

| Репозиторий | ⭐ | Зачем |
| --- | --- | --- |
| [firecrawl/firecrawl](https://github.com/firecrawl/firecrawl) | 187424 | 🔥 Supercharge your AI agents with data from the web and beyond. A web data API to search, scrape, and access more sources. · TypeScript · AGPL-3.0 · обновлён 2026-10-01 · ai,ai-agents,ai-crawler,ai-scraping |
| [open-webui/open-webui](https://github.com/open-webui/open-webui) | 153714 | User-friendly AI Interface (Supports Ollama, OpenAI API, ...) · Python · обновлён 2026-10-01 · ai,llm,llm-ui,llm-webui |
| [Comfy-Org/ComfyUI](https://github.com/Comfy-Org/ComfyUI) | 135734 | The most powerful and modular diffusion model GUI, api and backend with a graph/nodes interface. The fastest local inference engine in the world. · Python · GPL-3.0 · обновлён 2026-10-01 · ai,comfy,comfyui,python |
| [earendil-works/pi](https://github.com/earendil-works/pi) | 110974 | AI agent toolkit: unified LLM API, agent loop, TUI, coding agent CLI · TypeScript · MIT · обновлён 2026-10-01 |

## Выкованные модули (не существовали в открытом виде)

### config → `loadConfig`

Конфигурация только через env со строгой валидацией и понятными ошибками запуска.

```ts
export interface FieldSpec {
  key: string;
  required?: boolean;
  def?: string;
  number?: boolean;
  boolean?: boolean;
  enum?: string[];
}

export interface ConfigIssue { key: string; message: string }

export function loadConfig<T extends object>(spec: FieldSpec[], source: Record<string, string | undefined> = process.env): { config: T; issues: ConfigIssue[] } {
  const config: Record<string, unknown> = {};
  const issues: ConfigIssue[] = [];
…
```

### logger → `createLogger`

Структурные логи с уровнями, контекстом запроса и маскировкой секретов — обязательны для отладки роя.

```ts
export type Level = 'debug' | 'info' | 'warn' | 'error';

const ORDER: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };

const SECRET_RE = /(api[_-]?key|token|secret|password|authorization|cookie|magnet\?xt)/i;

function redact(value: unknown, depth = 0): unknown {
  if (depth > 4) return '[depth]';
  if (typeof value === 'string') return SECRET_RE.test(value) ? '[redacted]' : value;
  if (Array.isArray(value)) return value.map((v) => redact(v, depth + 1));
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = SECRET_RE.test(k) ? '[redacted]' : redact(v, depth + 1);
…
```

### retry → `retryWithBackoff`

Сеть и LLM шумные: нужны ретраи с джиттером, уважением к Retry-After и таймаутом на попытку.

```ts
export interface RetryOptions {
  retries?: number;
  baseMs?: number;
  maxMs?: number;
  timeoutMs?: number;
  jitter?: boolean;
  isRetryable?: (error: unknown) => boolean;
  onRetry?: (info: { attempt: number; delayMs: number; error: unknown }) => void;
}

const defaultRetryable = (error: unknown): boolean => {
  const msg = error instanceof Error ? error.message : String(error);
  return /timeout|econn|socket|429|5\d\d|rate|temporarily/i.test(msg);
};
…
```

### result → `Result`

Ошибки как значения: без исключений в бизнес-логике, с аккуратной агрегацией частичных сбоев роя.

```ts
export type Result<T, E = Error> = { ok: true; value: T } | { ok: false; error: E };

export const ok = <T>(value: T): Result<T, never> => ({ ok: true, value });
export const err = <E>(error: E): Result<never, E> => ({ ok: false, error });

export async function attempt<T>(fn: () => Promise<T>): Promise<Result<T, Error>> {
  try {
    return ok(await fn());
  } catch (error) {
    return err(error instanceof Error ? error : new Error(String(error)));
  }
}

export function unwrap<T>(result: Result<T, Error>): T {
…
```

### validate → `validate`

Валидация входа API без тяжёлых зависимостей: типы, строки, числа, enum, вложенность, кастомные проверки.

```ts
export type Schema =
  | { type: 'string'; min?: number; max?: number; pattern?: string; optional?: boolean }
  | { type: 'number'; min?: number; max?: number; integer?: boolean; optional?: boolean }
  | { type: 'boolean'; optional?: boolean }
  | { type: 'enum'; values: string[]; optional?: boolean }
  | { type: 'array'; items: Schema; max?: number; optional?: boolean }
  | { type: 'object'; fields: Record<string, Schema>; optional?: boolean };

export interface Issue { path: string; message: string }

export function validate(value: unknown, schema: Schema, path = '$'): Issue[] {
  if (value === undefined || value === null) {
    return schema.optional ? [] : [{ path, message: 'обязательное поле' }];
  }
…
```

### rate-limit → `TokenBucketRateLimiter`

Нужен контроль нагрузки на внешние API и локальные модели; в открытых репозиториях либо тяжёлые зависимости, либо нет ожидания и метрик.

```ts
/** Token-bucket + скользящее окно. Без зависимостей. */
export interface Bucket { tokens: number; updated: number }

export class TokenBucketRateLimiter {
  private buckets = new Map<string, Bucket>();
  private taken = 0;
  private rejected = 0;

  constructor(public readonly capacity: number, public readonly refillPerSecond: number) {}

  private refill(bucket: Bucket, now: number): void {
    const elapsed = (now - bucket.updated) / 1000;
    if (elapsed <= 0) return;
    bucket.tokens = Math.min(this.capacity, bucket.tokens + elapsed * this.refillPerSecond);
…
```

### json-store → `JsonlStore`

Локальное хранилище журнала/артефактов: append-only JSONL + скан с фильтром, чтобы проект работал и без Postgres.

```ts
import { createReadStream } from 'node:fs';
import { appendFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import { createInterface } from 'node:readline';
import { dirname, resolve } from 'node:path';

export interface JsonlQuery { where?: (record: Record<string, unknown>) => boolean; limit?: number; reverse?: boolean }

export class JsonlStore<T extends Record<string, unknown>> {
  constructor(public readonly filePath: string) {}

  async append(record: T): Promise<T> {
    await mkdir(dirname(resolve(this.filePath)), { recursive: true });
    await appendFile(this.filePath, JSON.stringify(record) + '\n', 'utf8');
    return record;
…
```

### cli-args → `parseArgs`

Парсер аргументов CLI: флаги, значения, массивы, подкоманды, автогенерация справки.

```ts
export interface ParsedArgs {
  command: string;
  flags: Record<string, string | boolean | string[]>;
  positionals: string[];
}

export function parseArgs(argv: string[]): ParsedArgs {
  const [command = 'main', ...rest] = argv;
  const flags: Record<string, string | boolean | string[]> = {};
  const positionals: string[] = [];
  for (let i = 0; i < rest.length; i++) {
    const token = rest[i];
    if (!token.startsWith('-')) {
      positionals.push(token);
…
```

### fly-index → `FlyIndex`

Ускорение мышления роя: LSH по принципу обонятельной системы мухи — без векторных БД и без обучения.

```ts
type Vec = Map<number, number>;

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function fnv1a(str: string): number {
…
```

### worker-pool → `mapPool`

Параллельный обход источников и моделей с ограничением concurrency и сохранением порядка результатов.

```ts
export interface PoolStats { items: number; done: number; failed: number; concurrency: number }

export async function mapPool<T, R>(
  items: T[],
  concurrency: number,
  worker: (item: T, index: number) => Promise<R>,
  onProgress?: (stats: PoolStats) => void,
): Promise<{ results: R[]; errors: { index: number; error: unknown }[] }> {
  const results = new Array<R>(items.length);
  const errors: { index: number; error: unknown }[] = [];
  let cursor = 0;
  let done = 0;
  let failed = 0;
  const lanes = Array.from({ length: Math.max(1, Math.min(concurrency, items.length || 1)) }, async () => {
…
```

### proxy-pool → `RotatingProxyPool`

Пользователю нужен допуск в интернет с прокси: ротация, health-check, карантин после сбоев — готовых лёгких решений нет.

```ts
import { ProxyAgent, fetch as undiciFetch } from 'undici';

export interface ProxyState { url: string; latencyMs: number; failCount: number; okCount: number; quarantinedUntil: number }

export class RotatingProxyPool {
  private states: ProxyState[] = [];
  private cursor = 0;
  private agents = new Map<string, ProxyAgent>();

  constructor(urls: string[], private readonly quarantineMs = 60000) {
    this.states = urls.map((url) => ({ url, latencyMs: 0, failCount: 0, okCount: 0, quarantinedUntil: 0 }));
  }

  get size(): number { return this.states.length; }
…
```

### text-chunker → `chunkText`

Подготовка контекста для LLM: резка текста по границам предложений с перекрытием и токен-бюджетом.

```ts
export interface Chunk { index: number; text: string; tokensApprox: number }

export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 3.6);
}

export function chunkText(
  text: string,
  opts: { maxTokens?: number; overlapTokens?: number } = {},
): Chunk[] {
  const maxTokens = opts.maxTokens ?? 700;
  const overlapTokens = Math.min(opts.overlapTokens ?? 80, Math.floor(maxTokens / 3));
  const sentences = text
    .replace(/\s+/g, ' ')
…
```

### model-downloader → `ResumableDownloader`

Докачка весов модели по web-seed из PirateFace: докачка с Range-запросами и контрольной суммой размера.

```ts
import { createWriteStream } from 'node:fs';
import { stat, unlink } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import { Readable } from 'node:stream';

export interface DownloadProgress { url: string; bytes: number; totalBytes: number | null; done: boolean }

export class ResumableDownloader {
  constructor(private readonly headers: Record<string, string> = {}) {}

  async size(url: string): Promise<number | null> {
    const res = await fetch(url, { method: 'HEAD', headers: this.headers });
    const len = res.headers.get('content-length');
    return res.ok && len ? Number(len) : null;
…
```


## Ускорение мышления: мозг мухи

Поиск и ранжирование ускорены LSH по принципу обонятельной системы мухи; поколение мозгов выведено генетическим отбором.

- мозгов в популяции: 3, поколение: 0, fitness: 1.0102
- переранжирование находок разведчика за O(k) без векторной БД
- дедупликация задач и источников по тегам
- семантическая память решений между проектами

## Риски и как они закрыты

| Риск | Влияние | Митигация |
| --- | --- | --- |
| Локальные модели могут не влезть в память машины | high | Брать GGUF подходящего размера (см. раздел «Локальные модели»), начинать с 7B-кванта |
| Внешние API ограничивают частоту запросов | medium | Token-bucket + экспоненциальный бэкофф + кэш ответов (модули из кузницы) |
| Качество данных источников нестабильно | medium | Схемная валидация входа + отдельный слой нормализации + метрики отбраковки |

## Окружение

Смотрите `.env.example`. Все секреты — только через переменные окружения.

## Лицензия

MIT