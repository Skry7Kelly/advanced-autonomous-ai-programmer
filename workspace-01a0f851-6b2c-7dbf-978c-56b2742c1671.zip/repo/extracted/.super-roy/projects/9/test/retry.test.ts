import test from 'node:test';
import assert from 'node:assert/strict';
import { retryWithBackoff, withTimeout } from '../src/modules/retry.js';

test('повторяет до успеха', async () => {
  let calls = 0;
  const value = await retryWithBackoff(async () => {
    calls += 1;
    if (calls < 3) throw new Error('503 temporarily');
    return 'ok';
  }, { baseMs: 1, retries: 5 });
  assert.equal(value, 'ok');
  assert.equal(calls, 3);
});

test('таймаут обрывает висяк', async () => {
  await assert.rejects(() => withTimeout(new Promise(() => {}), 20), /timeout/);
});