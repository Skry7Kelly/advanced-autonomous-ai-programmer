import type { AgentEvent, ChatMode, ProjectDetail, ProjectRow, PublicUser, RawPatch, SkillInfo, UsageInfo } from "./types";

async function json<T>(res: Response): Promise<T> {
  const data = (await res.json().catch(() => ({}))) as T & { error?: string; upgrade?: boolean; auth?: boolean };
  if (!res.ok) {
    const err = new Error(data.error ?? `HTTP ${res.status}`) as Error & { upgrade?: boolean; auth?: boolean };
    err.upgrade = data.upgrade === true;
    err.auth = data.auth === true;
    throw err;
  }
  return data;
}

/* ------------------------------ аутентификация ---------------------------- */

export const authApi = {
  async me(): Promise<{ user: PublicUser | null; usage: UsageInfo | null }> {
    return json(await fetch("/api/auth/me", { cache: "no-store" }));
  },
  async register(input: { email: string; password: string; name: string }): Promise<{ user: PublicUser; usage: UsageInfo }> {
    return json(
      await fetch("/api/auth/register", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(input),
      }),
    );
  },
  async login(input: { email: string; password: string }): Promise<{ user: PublicUser; usage: UsageInfo }> {
    return json(
      await fetch("/api/auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(input),
      }),
    );
  },
  async guest(): Promise<{ user: PublicUser; usage: UsageInfo }> {
    return json(await fetch("/api/auth/guest", { method: "POST" }));
  },
  async logout(): Promise<void> {
    await json(await fetch("/api/auth/logout", { method: "POST" }));
  },
  async subscribe(plan: string): Promise<{ user: PublicUser; usage: UsageInfo; demo: boolean }> {
    return json(
      await fetch("/api/billing/subscribe", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ plan }),
      }),
    );
  },
  /** Ссылка на OAuth-вход (Google/Apple/GitHub/Яндекс). */
  oauthUrl(provider: string): string {
    return `/api/auth/oauth/${provider}`;
  },
};

/* ------------------------------- скиллы ---------------------------------- */

export const skillsApi = {
  async list(): Promise<SkillInfo[]> {
    const data = await json<{ skills: SkillInfo[] }>(await fetch("/api/skills", { cache: "no-store" }));
    return data.skills;
  },
  async install(source: string): Promise<{ installed: string[]; message: string }> {
    return json(
      await fetch("/api/skills", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "install", source }),
      }),
    );
  },
  async toggle(name: string, enabled: boolean): Promise<void> {
    await json(
      await fetch("/api/skills", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "toggle", name, enabled }),
      }),
    );
  },
  async remove(name: string): Promise<void> {
    await json(
      await fetch("/api/skills", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "delete", name }),
      }),
    );
  },
};

/* -------------------------------- проекты -------------------------------- */

export const api = {
  async listProjects(): Promise<ProjectRow[]> {
    const data = await json<{ projects: ProjectRow[] }>(await fetch("/api/projects", { cache: "no-store" }));
    return data.projects;
  },
  async createProject(brief: string, settings: Record<string, unknown>): Promise<ProjectRow> {
    const data = await json<{ project: ProjectRow }>(
      await fetch("/api/projects", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ brief, settings, autostart: true }),
      }),
    );
    return data.project;
  },
  async deleteProject(id: number): Promise<void> {
    await json<{ ok: boolean }>(await fetch(`/api/projects/${id}`, { method: "DELETE" }));
  },
  async getProject(id: number): Promise<ProjectDetail> {
    return json<ProjectDetail>(await fetch(`/api/projects/${id}`, { cache: "no-store" }));
  },
  async build(id: number): Promise<void> {
    await json<unknown>(await fetch(`/api/projects/${id}/build`, { method: "POST" }));
  },
  async getFile(id: number, path: string): Promise<string> {
    const data = await json<{ content: string }>(
      await fetch(`/api/projects/${id}/file?path=${encodeURIComponent(path)}`, { cache: "no-store" }),
    );
    return data.content;
  },
  async saveFile(id: number, path: string, content: string): Promise<void> {
    await json<unknown>(
      await fetch(`/api/projects/${id}/file`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ path, content }),
      }),
    );
  },
  /** Стриминговый ход агента. onEvent вызывается по мере NDJSON-стриминга. */
  async chatTurn(id: number, message: string, mode: ChatMode, onEvent: (e: AgentEvent) => void): Promise<void> {
    const res = await fetch(`/api/projects/${id}/chat`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ message, mode }),
    });
    if (!res.ok || !res.body) {
      const data = (await res.json().catch(() => ({}))) as { error?: string; upgrade?: boolean };
      const err = new Error(data.error ?? `HTTP ${res.status}`) as Error & { upgrade?: boolean };
      err.upgrade = data.upgrade === true;
      throw err;
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        try {
          onEvent(JSON.parse(trimmed) as AgentEvent);
        } catch {
          /* игнорируем битые строки */
        }
      }
    }
    if (buffer.trim()) {
      try {
        onEvent(JSON.parse(buffer.trim()) as AgentEvent);
      } catch {
        /* остаток не JSON */
      }
    }
  },
  async applyPatches(id: number, patches: RawPatch[], summary: string, provider: string): Promise<string[]> {
    const res = await fetch(`/api/projects/${id}/chat`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ apply: { patches, summary, provider } }),
    });
    const reader = res.body?.getReader();
    const decoder = new TextDecoder();
    let changed: string[] = [];
    if (!reader) return changed;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      const lines = decoder.decode(value, { stream: true }).split("\n").filter(Boolean);
      for (const line of lines) {
        try {
          const evt = JSON.parse(line) as AgentEvent;
          if (evt.type === "changed") changed = evt.changed;
        } catch {
          /* пропускаем */
        }
      }
    }
    return changed;
  },
  async providers(): Promise<{ providers: ProviderLike[]; ready: string[]; llmAvailable: boolean }> {
    return json(await fetch("/api/providers", { cache: "no-store" }));
  },
  async probeProviders(): Promise<{ providers: ProviderLike[]; ready: string[] }> {
    return json(
      await fetch("/api/providers", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({}),
      }),
    );
  },
  async keys(): Promise<{ slots: KeySlotLike[] }> {
    return json(await fetch("/api/keys", { cache: "no-store" }));
  },
  async saveKey(envKey: string, value: string): Promise<void> {
    await json(
      await fetch("/api/keys", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ envKey, value }),
      }),
    );
  },
  async deleteKey(envKey: string): Promise<void> {
    await json(await fetch(`/api/keys?envKey=${encodeURIComponent(envKey)}`, { method: "DELETE" }));
  },
};

type ProviderLike = { key: string; label: string; kind: string; model: string; status: string; latencyMs: number | null; detail: string; keyless: boolean; envKey: string };
type KeySlotLike = { provider: string; label: string; envKey: string; model: string; note: string; hasValue: boolean; masked: string; fromEnv: boolean };

/* ------------------------------ утилиты ------------------------------ */

export function fmtBytes(n: number): string {
  if (n < 1024) return `${n} Б`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} КБ`;
  return `${(n / 1024 / 1024).toFixed(1)} МБ`;
}

export function fmtTime(iso: string | null): string {
  if (!iso) return "--:--";
  const d = new Date(iso);
  return d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export function fileExt(path: string): string {
  const m = path.match(/\.([a-z0-9]+)$/i);
  return m ? m[1].toLowerCase() : "";
}

const EXT_COLORS: Record<string, string> = {
  ts: "#60a5fa",
  tsx: "#60a5fa",
  js: "#fbbf24",
  mjs: "#fbbf24",
  json: "#fbbf24",
  md: "#8b95ad",
  css: "#38bdf8",
  html: "#fb923c",
  py: "#6ee7a8",
  sql: "#a78bfa",
  sh: "#64748b",
  yml: "#94a3b8",
  yaml: "#94a3b8",
  env: "#6ee7a8",
  txt: "#8b95ad",
};

export function extColor(path: string): string {
  return EXT_COLORS[fileExt(path)] ?? "#8b95ad";
}
