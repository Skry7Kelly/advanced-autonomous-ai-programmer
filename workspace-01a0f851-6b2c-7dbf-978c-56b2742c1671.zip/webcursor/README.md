# Svarma — рой ИИ-агентов, выковывающий приложения

**Svarma** — веб-аналог Cursor на движке автономного роя
[advanced-autonomous-ai-programmer](https://github.com/Skry7Kelly/advanced-autonomous-ai-programmer) (SUPER ROY).
Опишите приложение словами — рой из семи агентов его спроектирует, выкует недостающие модули,
сгенерирует код, проверит качество и отдаст ZIP-архивом. Аккаунты, OAuth-вход и тарифные планы включены.

```
АРХИТЕКТОР → РАЗВЕДЧИК → МОЗГ МУХИ → КУЗНЕЦ → ИНЖЕНЕР → КРИТИК → ИНТЕГРАТОР
```

> *Svarma* — от «сварм» (swarm, рой) и «варить/кузнечить»: имя свободно как бренд,
> слоган — «The swarm that forges software».

## Возможности

| | |
|---|---|
| 🔐 **Аккаунты** | Регистрация и вход по e-mail/паролю, гостевой вход, сессии в HttpOnly-cookie (30 дней) |
| 🌐 **OAuth-вход** | Google · Apple · GitHub · Яндекс — с ключами работает по-настоящему, без ключей входит в демо-аккаунт провайдера |
| 💳 **Тарифы** | Free / Pro / Team с честными квотами (проекты, чат-запросы в день) и демо-оплатой |
| 🗂 **IDE в браузере** | Файловое дерево, вкладки, редактор кода с подсветкой (CodeMirror 6), Ctrl+S |
| 🤖 **Агент как в Cursor** | Режим «Агент» предлагает патчи с диффами (+/− по строкам) — применяйте или отклоняйте |
| 🏗 **Архитектор** | Обсуждение архитектуры: интерактивная карточка спецификации (модули, API, вехи, риски) |
| 💬 **Спросить** | Вопросы о проекте с контекстом файлов |
| 🖥 **Консоль роя** | Живой терминал событий всех агентов (SSE), задачи, фильтр по агенту |
| 👁 **Превью** | Вкладка превью с дашбордом спецификации (или index.html проекта) |
| ⌨️ **Палитра команд** | Ctrl+K: команды + нечёткий поиск по файлам |
| 📦 **ZIP в один клик** | Скачать сгенерированный проект с манифестом `SVARMA-MANIFEST.json` |
| 🔑 **46 LLM-провайдеров** | OpenAI, Anthropic Claude, xAI Grok, Gemini, Grok, DeepSeek, Qwen, GLM, Kimi, Mistral, Cohere, Perplexity, OpenRouter, GitHub Models, Azure, Vercel AI Gateway, Doubao, ERNIE… + локальные Ollama/vLLM/llama.cpp/LM Studio/Jan. Неподключённые просто пропускаются |
| 🧩 **Скиллы агента** | Открытый формат [vercel-labs/skills](https://github.com/vercel-labs/skills): SKILL.md-навыки, совместимые с Claude Code и anthropics/skills. Установка из любого GitHub-репозитория, авто-подключение релевантных скиллов к запросу |
| 🧠 **Память роя** | «Мозг мухи» — эволюционирующая LSH-память, переиспользует выводы прошлых проектов |
| 🔍 **Разведка** | SCOUT ищет готовые решения на GitHub / npm / HN / StackOverflow и веса моделей |

## Быстрый старт

```bash
npm install
npm run dev          # http://localhost:3000
```

**Ничего больше не нужно**: ни Postgres, ни ключей, ни .env.
Данные хранятся в памяти и автоматически сохраняются в `.data/svarma-db.json`
(при первом запуске старый `.data/webcursor-db.json` мигрируется автоматически).
LLM по умолчанию — бесплатный шлюз Pollinations + встроенный детерминированный движок роя.

### Демо-аккаунт

```
e-mail:  demo@svarma.app
пароль:  demo1234        # тариф Pro, 365 дней
```

Также можно войти одной кнопкой **«Продолжить как гость»** — создастся временный аккаунт Free.

## Тарифы и квоты

| План | Цена | Проекты | Запросов агенту/день |
|---|---|---|---|
| **Free** | 0 ₽ | 3 | 20 |
| **Pro** | 19 $/мес | 100 | 500 |
| **Team** | 49 $/мес | без лимита | 5000 |

Превышение квоты → HTTP 402 с флагом `upgrade: true` → UI открывает модал тарифов.
Оплата — **демо-режим**: подписка активируется мгновенно и бесплатно (провайдер не подключён).
Для боевых платежей подключите Stripe/ЮKassa в `src/app/api/billing/subscribe/route.ts`.

Применение патчей из чата, просмотр файлов и превью квотами не тарифицируются —
считаются только ходы «Агент»/«Спросить».

## OAuth-вход (Google · Apple · GitHub · Яндекс)

Кнопки соц-входа работают в двух режимах:

1. **Демо-режим** (без ключей): вход в автоматически создаваемый аккаунт
   `demo.<provider>@svarma.app` — удобно для превью и локальной разработки.
2. **Боевой режим** — задайте переменные окружения:

```bash
GOOGLE_CLIENT_ID=...        GOOGLE_CLIENT_SECRET=...
APPLE_CLIENT_ID=...         APPLE_TEAM_ID=...  APPLE_KEY_ID=...  APPLE_PRIVATE_KEY=...
GITHUB_CLIENT_ID=...        GITHUB_CLIENT_SECRET=...
YANDEX_CLIENT_ID=...        YANDEX_CLIENT_SECRET=...
```

Redirect URI для консолей провайдеров: `https://ваш-домен/api/auth/oauth/<provider>/callback`
(Apple использует `form_post` и обрабатывает и GET, и POST).

### Все LLM-провайдеры (46)

Роутер перебирает провайдеров по приоритету и **пропускает те, у которых нет ключа** —
достаточно вставить ключ любого провайдера в **Настройки → Ключи API**:

OpenAI · Anthropic Claude · xAI Grok · Google Gemini · Groq · DeepSeek · Mistral · Cohere ·
Perplexity · OpenRouter · Cerebras · Hugging Face · Together · Fireworks · NVIDIA NIM ·
xAI · Moonshot Kimi · Z.AI GLM · Zhipu GLM · Alibaba Qwen · DeepInfra · Novita · Hyperbolic ·
SambaNova · Lambda · AI21 · 01.AI Yi · Baidu ERNIE · StepFun · SiliconFlow · ModelScope ·
ByteDance Doubao · MiniMax · iFlytek Spark · Nebius · Chutes · Kluster · GitHub Models ·
Azure OpenAI · Vercel AI Gateway — и локальные: Ollama · vLLM · llama.cpp · LM Studio · Jan.

Плюс безключевые каналы: Pollinations и встроенный детерминированный движок роя.

### Скиллы агента (agent skills)

Скилл — папка со `SKILL.md` (frontmatter `name`/`description` + инструкции) в открытом формате
[vercel-labs/skills](https://github.com/vercel-labs/skills). Совместимы с каталогами
[Claude Code](https://github.com/anthropics/skills) и [skills.sh](https://skills.sh).

```bash
# в UI: Настройки → Скиллы → owner/repo
vercel-labs/agent-skills   # официальный набор Vercel
anthropics/skills          # официальный набор Anthropic (Claude)
```

Рой сам подбирает релевантные скиллы по запросу и подключает их инструкции к системному
промпту — с Claude и любым другим провайдером. Встроены 5 стартовых скиллов:
web-design-guidelines, typescript-strict, api-rest-design, react-performance, sql-schema-design.

### Хотите умнее рой?

Добавьте ключи LLM в UI (**Настройки → Ключи**) или через переменные окружения:

```bash
GROQ_API_KEY=...        # очень быстрый free tier
GEMINI_API_KEY=...      # Google AI Studio
OPENROUTER_API_KEY=...  # модели с суффиксом :free
```

Локальные модели:

```bash
OLLAMA_BASE_URL=http://127.0.0.1:11434
OLLAMA_MODEL=qwen2.5-coder:7b
ollama serve
```

## Как это работает

```
Бриф ──► parseBrief ──► buildSpec ──► forge (кузница модулей) ──► codegen ──► QA/ремонт ──► артефакты
              ▲                    ▲                                              │
              └── LLM-уточнения ───┘                                     ZIP + превью + IDE
```

1. **АРХИТЕКТОР** разбирает бриф в структуру (тип, домен, фичи, сущности), LLM добавляет уточнения.
2. **МОЗГ МУХИ** вспоминает похожие решения из LSH-памяти прошлых прогонов.
3. **РАЗВЕДЧИК** ищет в интернете готовые библиотеки и веса моделей (PirateFace, GitHub, npm, HN, SO).
4. **КУЗНЕЦ** выковывает недостающие модули с тестами и доками.
5. **ИНЖЕНЕР** генерирует весь проект по спецификации.
6. **КРИТИК** гоняет статический анализ (12 проверок) и авторемонт.
7. **ИНТЕГРАТОР** собирает итог, пишет манифест и отдаёт ZIP.

## Стек

- **Next.js 16** (App Router) + React 19 + Tailwind CSS 4
- **CodeMirror 6** — редактор с подсветкой TS/JS/JSON/MD/CSS/HTML/Python/SQL
- **Мини-ORM** (`src/db/orm.ts`) — drop-in замена API drizzle поверх in-memory хранилища
  с персистентностью в JSON; таблицы `users`/`sessions` добавлены для аккаунтов
- **scrypt** (node:crypto) для паролей, HttpOnly-cookie `svarma_session` для сессий
- **SSE** для живых событий конвейера, **NDJSON** для стриминга чат-агента

## Структура

```
src/
├── app/
│   ├── api/
│   │   ├── auth/                # register, login, logout, me, guest, oauth/[provider](/callback)
│   │   ├── billing/             # plans, subscribe (демо-оплата)
│   │   ├── projects/            # CRUD + /build + /stream (SSE) + /file + /chat + /bundle + /preview
│   │   ├── providers/           # статус LLM-провайдеров
│   │   └── keys/                # ключи API
│   ├── robots.ts / sitemap.ts   # SEO
│   └── page.tsx                 # IDE + экран входа
├── components/svarma/           # UI: AuthScreen, PlansModal, TitleBar, Sidebar, EditorPane, ChatPanel, ...
├── db/                          # мини-ORM + схема (порт схемы SUPER ROY + users/sessions)
└── lib/
    ├── auth.ts                  # тарифы, пароли, сессии, квоты
    ├── oauth.ts                 # Google/Apple/GitHub/Яндекс
    └── (движок роя: brief, plan, forge, codegen, qa, fly, scout, providers, pipeline, agent)
```

## Горячие клавиши

| | |
|---|---|
| `Ctrl+K` | палитра команд / быстрый поиск файлов |
| `Ctrl+S` | сохранить активный файл |
| `Ctrl+B` | боковая панель |
| `Ctrl+J` | консоль роя |
| `Ctrl+I` | чат с агентом |

## Кредиты

Движок роя — [Skry7Kelly/advanced-autonomous-ai-programmer](https://github.com/Skry7Kelly/advanced-autonomous-ai-programmer).
Svarma — интерфейсная оболочка, агентный слой и система аккаунтов поверх него.
