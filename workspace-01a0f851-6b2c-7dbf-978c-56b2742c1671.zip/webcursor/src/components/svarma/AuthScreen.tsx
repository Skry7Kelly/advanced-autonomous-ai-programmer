"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Icon } from "./icons";
import { authApi } from "./api";
import { BackgroundFX } from "./BackgroundFX";
import type { PublicUser, UsageInfo } from "./types";

/* --------------------------- печатающаяся строка -------------------------- */

function useTypewriter(words: string[]): { text: string; wordIndex: number } {
  const [idx, setIdx] = useState(0);
  const [len, setLen] = useState(0);
  const word = words[idx % words.length];
  useEffect(() => {
    if (len < word.length) {
      const t = setTimeout(() => setLen(len + 1), 46);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => {
      setLen(0);
      setIdx((i) => (i + 1) % words.length);
    }, 2100);
    return () => clearTimeout(t);
  }, [len, word, words]);
  return { text: word.slice(0, len), wordIndex: idx };
}

/* -------------------------------- данные --------------------------------- */

const SOCIALS: { id: string; label: string; icon: "google" | "apple" | "github" | "yandex" }[] = [
  { id: "google", label: "Google", icon: "google" },
  { id: "apple", label: "Apple", icon: "apple" },
  { id: "github", label: "GitHub", icon: "github" },
  { id: "yandex", label: "Яндекс", icon: "yandex" },
];

const PIPELINE = [
  "АРХИТЕКТОР",
  "РАЗВЕДЧИК",
  "МОЗГ МУХИ",
  "КУЗНЕЦ",
  "ИНЖЕНЕР",
  "КРИТИК",
  "ИНТЕГРАТОР",
];

const STATS = [
  { value: "7", label: "агентов в рое" },
  { value: "61 файл", label: "за 17 секунд*" },
  { value: "100/100", label: "QA-score прогона" },
  { value: "0 ₽", label: "старт без карты" },
];

const FEATURES = [
  { icon: "swarm" as const, title: "Рой из 7 агентов", text: "АРХИТЕКТОР → РАЗВЕДЧИК → КУЗНЕЦ → ИНЖЕНЕР → КРИТИК: полный конвейер, а не один чат-бот" },
  { icon: "zap" as const, title: "Диффы как в Cursor", text: "Агент предлагает правки построчным диффом — применяйте или отклоняйте одним кликом" },
  { icon: "brain" as const, title: "Память роя", text: "LSH-мозг запоминает решения и с каждым проектом куёт быстрее и точнее" },
  { icon: "download" as const, title: "ZIP за один клик", text: "Код, тесты, манифест и QA-отчёт — скачивайте готовый проект целиком" },
];

const PLANS = [
  { id: "free", name: "Free", price: "0 ₽", per: "навсегда", top: "3 проекта · 20 запросов/день", cta: "Начать бесплатно" },
  { id: "pro", name: "Pro", price: "19 $", per: "в месяц", top: "100 проектов · 500 запросов/день", cta: "Выбрать Pro", hot: true },
  { id: "team", name: "Team", price: "49 $", per: "в месяц", top: "проекты без лимита · 5000 запросов/день", cta: "Выбрать Team" },
];

const IDEAS = [
  "REST API трекера привычек с JWT…",
  "дашборд аналитики на React…",
  "телеграм-бот для команды…",
  "сайт-портфолио с блогом…",
  "CLI-инструмент для деплоя…",
  "игру-кликер на TypeScript…",
];

/* ------------------------------- компонент -------------------------------- */

export default function AuthScreen({ onAuthed }: { onAuthed: (user: PublicUser, usage: UsageInfo) => void }) {
  const [mode, setMode] = useState<"login" | "register">("register");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState<null | "form" | "guest">(null);
  const [error, setError] = useState<string | null>(null);
  const [oauthError, setOauthError] = useState<string | null>(null);
  const [planHint, setPlanHint] = useState<string | null>(null);
  const emailRef = useRef<HTMLInputElement>(null);
  const typed = useTypewriter(IDEAS);
  const pipelineDoubled = useMemo(() => [...PIPELINE, ...PIPELINE], []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const err = params.get("oauthError");
    if (err) {
      setOauthError(
        err === "cancelled"
          ? "Вход через соцсеть отменён"
          : err === "state"
            ? "Истекла сессия входа — попробуйте ещё раз"
            : "Не удалось войти через соцсеть. Проверьте настройки OAuth-ключей.",
      );
      window.history.replaceState(null, "", "/");
    }
  }, []);

  const submit = async () => {
    if (busy) return;
    setError(null);
    setBusy("form");
    try {
      const result =
        mode === "register"
          ? await authApi.register({ email, password, name: name || email.split("@")[0] })
          : await authApi.login({ email, password });
      onAuthed(result.user, result.usage);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  };

  const guest = async () => {
    if (busy) return;
    setBusy("guest");
    try {
      const result = await authApi.guest();
      onAuthed(result.user, result.usage);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  };

  const pickPlan = (plan: string) => {
    setMode("register");
    setError(null);
    emailRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    setTimeout(() => emailRef.current?.focus(), 350);
    if (plan !== "free") {
      setError(null);
      setPlanHint(`Создайте аккаунт — тариф ${plan === "pro" ? "Pro" : "Team"} можно активировать в демо-режиме после входа`);
    }
  };

  return (
    <div className="scroll-y relative h-screen overflow-y-auto bg-ink-950">
      <BackgroundFX />

      <div className="relative mx-auto flex min-h-screen w-full max-w-7xl flex-col px-5 pb-10 pt-6 sm:px-8">
        {/* ------------------------------ навбар ------------------------------ */}
        <nav className="animate-rise flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Icon name="logo" size={26} />
            <span className="text-[15px] font-bold tracking-[0.24em] text-ink-50">
              SVAR<span className="text-gradient">MA</span>
            </span>
            <span className="chip !border-accent2/30 !py-0.5 !text-[9px] !text-accent2">v1.2</span>
          </div>
          <div className="flex items-center gap-4 text-[12.5px]">
            <span className="hidden items-center gap-1.5 text-ink-400 sm:flex">
              <span className="h-1.5 w-1.5 animate-blink rounded-full bg-ok" />
              рой на связи
            </span>
            <button
              onClick={() => {
                setMode(mode === "login" ? "register" : "login");
                setError(null);
                setPlanHint(null);
              }}
              className="rounded-lg px-3 py-1.5 font-medium text-ink-300 transition-colors hover:bg-ink-850 hover:text-ink-50"
            >
              {mode === "login" ? "Создать аккаунт" : "Уже есть аккаунт?"}
            </button>
          </div>
        </nav>

        {/* ------------------------------- hero ------------------------------- */}
        <div className="mt-10 grid flex-1 items-center gap-12 lg:mt-14 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16">
          {/* левая колонка */}
          <div className="min-w-0">
            <div className="animate-rise inline-flex items-center gap-2 rounded-full border border-accent2/25 bg-accent2/5 px-3.5 py-1.5 text-[11.5px] font-medium text-accent2" style={{ animationDelay: "0.05s" }}>
              <span className="relative flex h-2 w-2">
                <span className="animate-pulse-ring absolute inset-0 rounded-full bg-accent2" />
                <span className="relative h-2 w-2 rounded-full bg-accent2" />
              </span>
              v1.0 — рой уже куёт приложения без единого ключа
            </div>

            <h1
              className="animate-rise mt-6 text-balance text-[2.6rem] font-extrabold leading-[1.06] tracking-tight text-ink-50 sm:text-5xl xl:text-[3.6rem]"
              style={{ animationDelay: "0.12s" }}
            >
              Опишите идею —<br />
              <span className="animate-pan text-gradient">рой выкует</span> приложение
            </h1>

            <div className="animate-rise mt-5 flex items-center gap-2.5 font-mono text-[13px] text-ink-300 sm:text-sm" style={{ animationDelay: "0.2s" }}>
              <span className="text-accent3">❯</span>
              <span className="text-ink-500">создать:</span>
              <span className="text-ink-100">{typed.text}</span>
              <span className="animate-caret -mb-0.5 inline-block h-[1.15em] w-[2px] bg-accent2" />
            </div>

            <p className="animate-rise mt-5 max-w-xl text-[15px] leading-relaxed text-ink-300" style={{ animationDelay: "0.28s" }}>
              <b className="text-ink-100">Svarma</b> — браузерная ИИ-IDE: семь автономных агентов проектируют архитектуру,
              ищут готовые решения, генерируют код и проверяют качество. Вы формулируете задачу —
              скачиваете ZIP с готовым проектом.
            </p>

            {/* статистика */}
            <div className="animate-rise mt-7 grid max-w-xl grid-cols-2 gap-px overflow-hidden rounded-2xl border border-ink-750 bg-ink-750 sm:grid-cols-4" style={{ animationDelay: "0.36s" }}>
              {STATS.map((s) => (
                <div key={s.label} className="bg-ink-900/85 px-4 py-3">
                  <div className="text-[17px] font-bold leading-none text-ink-50">{s.value}</div>
                  <div className="mt-1.5 text-[10.5px] leading-snug text-ink-400">{s.label}</div>
                </div>
              ))}
            </div>

            {/* конвейер агентов */}
            <div className="animate-rise marquee-track relative mt-7 overflow-hidden py-1" style={{ animationDelay: "0.44s" }}>
              <div className="animate-marquee flex w-max items-center gap-3">
                {pipelineDoubled.map((a, i) => (
                  <span key={`${a}-${i}`} className="flex items-center gap-3">
                    <span className="chip !border-ink-650 !bg-ink-900/70 !py-1.5 font-mono !text-[10.5px] tracking-wider text-ink-200">{a}</span>
                    <Icon name="chevronRight" size={12} className="text-ink-600" />
                  </span>
                ))}
              </div>
            </div>

            {/* карточки возможностей */}
            <div className="animate-rise mt-7 grid max-w-xl grid-cols-1 gap-2.5 sm:grid-cols-2" style={{ animationDelay: "0.52s" }}>
              {FEATURES.map((f) => (
                <div key={f.title} className="group glass relative overflow-hidden rounded-xl p-3.5 transition-all duration-300 hover:-translate-y-0.5 hover:border-accent2/35">
                  <div className="absolute -right-6 -top-6 h-16 w-16 rounded-full bg-accent2/0 blur-2xl transition-all duration-500 group-hover:bg-accent2/15" />
                  <div className="flex items-center gap-2 text-accent2">
                    <Icon name={f.icon} size={15} />
                    <span className="text-[12.5px] font-semibold text-ink-50">{f.title}</span>
                  </div>
                  <p className="mt-1.5 text-[11.5px] leading-snug text-ink-400">{f.text}</p>
                </div>
              ))}
            </div>

            <p className="animate-rise mt-6 text-[11px] text-ink-500" style={{ animationDelay: "0.6s" }}>
              LLM-провайдеры: <span className="text-ink-300">Pollinations · Groq · Gemini · OpenRouter · Ollama</span> — работает из коробки, ключи опциональны.
              <span className="text-ink-600"> * реальный прогон роя в демо.</span>
            </p>
          </div>

          {/* правая колонка — карта входа */}
          <div className="animate-rise w-full justify-self-end lg:max-w-md" style={{ animationDelay: "0.25s" }}>
            <div className="relative rounded-2xl p-px">
              {/* вращающееся свечение по контуру */}
              <div className="absolute -inset-px overflow-hidden rounded-2xl">
                <div
                  className="animate-rotate-slow absolute left-1/2 top-1/2 aspect-square w-[280%] -translate-x-1/2 -translate-y-1/2"
                  style={{ background: "conic-gradient(from 0deg, transparent 0 42%, rgba(94,234,212,0.55) 47%, rgba(125,211,252,0.75) 50%, rgba(167,139,250,0.55) 53%, transparent 58% 100%)" }}
                />
              </div>

              <div className="glass relative overflow-hidden rounded-2xl p-6 shadow-[0_30px_80px_-30px_rgba(0,0,0,0.9)]">
                {/* логотип с пульсацией */}
                <div className="mb-5 flex flex-col items-center">
                  <div className="relative">
                    <span className="animate-pulse-ring absolute inset-0 rounded-3xl border border-accent2/40" />
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src="/logo.png" alt="Svarma" className="animate-float relative h-16 w-16 rounded-2xl object-cover shadow-[0_0_45px_-8px_rgba(125,211,252,0.55)]" />
                  </div>
                  <div className="mt-3.5 text-[13px] font-bold tracking-[0.3em] text-ink-100">SVARMA</div>
                  <div className="mt-1 text-[10px] uppercase tracking-[0.2em] text-ink-500">the swarm that forges software</div>
                </div>

                {oauthError ? (
                  <div className="animate-slide-up mb-3 flex items-center gap-2 rounded-xl border border-danger/30 bg-danger/5 px-3.5 py-2.5 text-[12px] text-danger">
                    <Icon name="alert" size={13} className="shrink-0" />
                    {oauthError}
                  </div>
                ) : null}

                {/* табы */}
                <div className="mb-4 flex gap-1 rounded-xl bg-ink-950/80 p-1">
                  {(["register", "login"] as const).map((m) => (
                    <button
                      key={m}
                      onClick={() => {
                        setMode(m);
                        setError(null);
                        setPlanHint(null);
                      }}
                      className={`flex-1 rounded-lg py-2 text-[12.5px] font-semibold transition-all duration-300 ${
                        mode === m ? "bg-ink-750 text-ink-50 shadow-sm" : "text-ink-500 hover:text-ink-300"
                      }`}
                    >
                      {m === "register" ? "Регистрация" : "Вход"}
                    </button>
                  ))}
                </div>

                <div className="space-y-2.5">
                  {mode === "register" ? (
                    <div className="animate-slide-up">
                      <label className="mb-1 block text-[10.5px] font-semibold uppercase tracking-wider text-ink-500">Имя</label>
                      <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Сварог Кузнецов" maxLength={60} />
                    </div>
                  ) : null}
                  <div>
                    <label className="mb-1 block text-[10.5px] font-semibold uppercase tracking-wider text-ink-500">E-mail</label>
                    <input
                      ref={emailRef}
                      className="input"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      onKeyDown={(e) => e.key === "Enter" && void submit()}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[10.5px] font-semibold uppercase tracking-wider text-ink-500">Пароль</label>
                    <input
                      className="input"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Минимум 6 символов"
                      onKeyDown={(e) => e.key === "Enter" && void submit()}
                    />
                  </div>

                  {error ? (
                    <div className="animate-slide-up flex items-start gap-2 rounded-lg border border-danger/30 bg-danger/5 px-3 py-2 text-[12px] text-danger">
                      <Icon name="alert" size={13} className="mt-0.5 shrink-0" />
                      {error}
                    </div>
                  ) : null}
                  {planHint ? (
                    <div className="animate-slide-up flex items-start gap-2 rounded-lg border border-accent3/30 bg-accent3/5 px-3 py-2 text-[12px] text-accent3">
                      <Icon name="sparkles" size={13} className="mt-0.5 shrink-0" />
                      {planHint}
                    </div>
                  ) : null}

                  <button className="btn btn-accent w-full justify-center !py-2.5 !text-[13px] !font-semibold" disabled={busy !== null} onClick={() => void submit()}>
                    {busy === "form" ? (
                      <span className="h-3.5 w-3.5 animate-spin-slow rounded-full border-2 border-accent2/30 border-t-accent2" />
                    ) : (
                      <Icon name={mode === "register" ? "sparkles" : "key"} size={14} />
                    )}
                    {mode === "register" ? "Создать аккаунт — бесплатно" : "Войти в IDE"}
                  </button>
                  <p className="text-center text-[10.5px] text-ink-600">Без карты. Free-тариф навсегда.</p>
                </div>

                {/* соцсети */}
                <div className="my-4 flex items-center gap-3 text-[10px] uppercase tracking-[0.16em] text-ink-600">
                  <span className="h-px flex-1 bg-ink-750" />
                  или через
                  <span className="h-px flex-1 bg-ink-750" />
                </div>

                <div className="grid grid-cols-4 gap-2">
                  {SOCIALS.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => (window.location.href = authApi.oauthUrl(s.id))}
                      title={`Войти через ${s.label}`}
                      className="flex h-10 items-center justify-center rounded-xl border border-ink-700 bg-ink-950/70 text-ink-300 transition-all duration-300 hover:-translate-y-0.5 hover:border-accent2/40 hover:text-accent2"
                    >
                      <Icon name={s.icon} size={16} />
                    </button>
                  ))}
                </div>
                <p className="mt-2 text-center text-[10px] leading-snug text-ink-600">
                  Без OAuth-ключей — вход в демо-аккаунт провайдера
                </p>

                {/* гость */}
                <button className="btn mt-3.5 w-full justify-center !text-[12.5px]" disabled={busy !== null} onClick={() => void guest()}>
                  {busy === "guest" ? (
                    <span className="h-3.5 w-3.5 animate-spin-slow rounded-full border-2 border-accent2/30 border-t-accent2" />
                  ) : (
                    <Icon name="external" size={13} />
                  )}
                  Продолжить как гость
                </button>

                <p className="mt-3.5 border-t border-ink-750 pt-3 text-center text-[10.5px] text-ink-500">
                  Посмотреть вживую: <span className="font-mono text-ink-300">demo@svarma.app</span> /{" "}
                  <span className="font-mono text-ink-300">demo1234</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* --------------------------- тарифная полоса --------------------------- */}
        <section className="animate-rise mt-12 lg:mt-16" style={{ animationDelay: "0.3s" }}>
          <div className="mb-4 flex flex-wrap items-baseline justify-between gap-2">
            <h2 className="text-[15px] font-bold text-ink-100">Тарифы</h2>
            <p className="text-[11.5px] text-ink-500">Начните на Free — улучшьте, когда упрётесь в лимиты</p>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {PLANS.map((p) => (
              <div
                key={p.id}
                className={`group relative flex flex-col overflow-hidden rounded-2xl border p-5 transition-all duration-300 hover:-translate-y-1 ${
                  p.hot
                    ? "border-accent3/45 bg-gradient-to-b from-accent3/10 via-ink-900/90 to-ink-900/90 shadow-[0_0_50px_-18px_rgba(167,139,250,0.55)]"
                    : "border-ink-750 bg-ink-900/70 hover:border-ink-600"
                }`}
              >
                {p.hot ? (
                  <>
                    <span className="absolute -right-9 top-3 rotate-45 bg-gradient-to-r from-accent2 to-accent3 px-9 py-0.5 text-[9px] font-bold uppercase tracking-wider text-ink-950">
                      выбор роя
                    </span>
                    <div className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full bg-accent3/15 blur-2xl" />
                  </>
                ) : null}
                <div className="flex items-baseline justify-between">
                  <span className="text-[14px] font-bold text-ink-50">{p.name}</span>
                  <span className="text-[22px] font-extrabold text-gradient">{p.price}</span>
                </div>
                <p className="mt-1 text-[10.5px] uppercase tracking-wider text-ink-500">{p.per}</p>
                <p className="mt-2.5 flex-1 text-[12px] leading-snug text-ink-300">{p.top}</p>
                <button
                  onClick={() => pickPlan(p.id)}
                  className={`btn mt-4 w-full justify-center !text-[12px] ${p.hot ? "btn-accent !font-semibold" : ""}`}
                >
                  {p.cta}
                </button>
              </div>
            ))}
          </div>
          <p className="mt-3 text-center text-[10.5px] text-ink-600">
            Оплата в демо-режиме: подписка активируется мгновенно и бесплатно — платёжный провайдер не подключён.
          </p>
        </section>

        {/* ------------------------------- футер ------------------------------- */}
        <footer className="mt-10 flex flex-col items-center gap-1.5 border-t border-ink-850 pt-5 text-center">
          <p className="text-[11px] text-ink-500">
            © 2026 Svarma — рой ИИ-агентов, выковывающий приложения.
          </p>
          <a
            href="https://github.com/Skry7Kelly/advanced-autonomous-ai-programmer"
            target="_blank"
            rel="noreferrer noopener"
            className="flex items-center gap-1.5 text-[10.5px] text-ink-600 transition-colors hover:text-accent2"
          >
            <Icon name="github" size={12} /> движок роя: advanced-autonomous-ai-programmer
          </a>
        </footer>
      </div>
    </div>
  );
}
