import { eq } from "@/db/orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getAuthUser, PLANS, publicUser, usageOf } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * Демо-оформление подписки: активирует тариф на 30 дней без реального платежа.
 * Для боевых платежей подключите провайдера (Stripe/ЮKassa) и вызывайте его здесь.
 */
export async function POST(request: Request) {
  const user = await getAuthUser(request);
  if (!user) return Response.json({ error: "Требуется вход" }, { status: 401 });
  const body = (await request.json().catch(() => ({}))) as { plan?: string };
  const plan = body.plan as keyof typeof PLANS | undefined;
  if (!plan || !(plan in PLANS) || plan === "free") {
    return Response.json({ error: "Укажите тариф pro или team" }, { status: 400 });
  }
  const planUntil = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  await db.update(users).set({ plan, planUntil }).where(eq(users.id, user.id));
  const [fresh] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
  return Response.json({ user: publicUser(fresh), usage: await usageOf(fresh), demo: true });
}
