import { createRouter, type Router } from './router.js';
import { logger } from './logger.js';
import { appConfig } from './config.js';
import { repositories } from './entities.js';
import { TokenBucketRateLimiter } from './modules/rate-limit.js';
import { retryWithBackoff } from './modules/retry.js';
import { validate } from './modules/validate.js';
import { FlyIndex } from './modules/fly-index.js';

export interface AppState {
  startedAt: number;
  limiter: TokenBucketRateLimiter;
  memory: FlyIndex;
  jobs: { id: string; kind: string; state: string; startedAt: string }[];
}

export const state: AppState = {
  startedAt: Date.now(),
  limiter: new TokenBucketRateLimiter(appConfig.RATE_LIMIT_PER_MIN, appConfig.RATE_LIMIT_PER_MIN / 60),
  memory: new FlyIndex({ outputDim: 4096, k: 48 }),
  jobs: [],
};

const memorySchema = { type: 'object', fields: { q: { type: 'string', min: 1, max: 500 } } } as const;

function requireObject(body: unknown): Record<string, unknown> {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new Error('валидация: ожидается JSON-объект');
  }
  return body as Record<string, unknown>;
}

export function buildApp(): Router {
  const router = createRouter({ onError: (error, ctx) => logger.error('request failed', { path: ctx.path, error: String(error) }) });

  router.get('/health', () => ({
    status: 'ok',
    uptimeMs: Date.now() - state.startedAt,
    storage: Object.fromEntries(Object.entries(repositories).map(([name]) => [name, name])),
  }));

  router.get('/api/tasks', () => ({ items: state.jobs }));

  router.get('/api/search', async (ctx) => {
    const q = ctx.query.get('q') ?? '';
    if (q.length < 1) throw new Error('валидация: параметр q обязателен');
    const hits = state.memory.search(q, Number(ctx.query.get('limit') ?? 10));
    return { results: hits, query: q };
  });

  router.get('/api/memory', async (ctx) => {
    const issues = validate({ q: ctx.query.get('q') ?? '' }, memorySchema);
    if (issues.length > 0) throw new Error('валидация: ' + issues.map((i) => i.path + ' ' + i.message).join('; '));
    return { items: state.memory.search(ctx.query.get('q') ?? '', 8) };
  });

  router.post('/api/memory', async (ctx) => {
    const body = requireObject(ctx.body);
    const text = String(body.text ?? '');
    if (text.length < 3) throw new Error('валидация: text обязателен');
    state.memory.add(String(body.id ?? 'm_' + Date.now().toString(36)), text, body.meta ?? null);
    return { ok: true, size: state.memory.size };
  });

  router.post('/api/ask', async (ctx) => {
    const body = requireObject(ctx.body);
    const question = String(body.question ?? '');
    if (question.length < 3) throw new Error('валидация: question обязателен');
    const context = state.memory.search(question, 4).map((h) => h.text).join('\n');
    const answer = await retryWithBackoff(async () => {
      const res = await fetch(appConfig.LLM_BASE_URL.replace(/\/$/, '') + '/api/generate', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ model: appConfig.LLM_MODEL || 'qwen2.5-coder:7b', prompt: 'Контекст:\n' + context + '\n\nВопрос: ' + question, stream: false }),
      });
      if (!res.ok) throw new Error(String(res.status) + ' llm unavailable');
      const data = (await res.json()) as { response?: string };
      return data.response ?? '';
    }, { retries: 2, timeoutMs: 60000 });
    return { answer, provider: appConfig.LLM_BASE_URL };
  });

  // --- CRUD по каждой сущности из спецификации ---
  router.get('/api/items', async (ctx) => {
    const limit = Math.min(200, Number(ctx.query.get('limit') ?? 50));
    const offset = Math.max(0, Number(ctx.query.get('offset') ?? 0));
    return repositories.items.list({ limit, offset });
  });

  router.post('/api/items', async (ctx) => {
    if (!state.limiter.tryTake('write')) throw new Error('rate limit: слишком много запросов');
    const body = requireObject(ctx.body);
    const created = await repositories.items.create(body as never);
    state.memory.add(created.id, JSON.stringify(created).slice(0, 1500), { kind: 'items' });
    return { item: created };
  });

  router.get('/api/items/:id', async (ctx) => {
    const item = await repositories.items.get(ctx.params.id);
    if (!item) throw new Error('not found');
    return { item };
  });

  router.delete('/api/items/:id', async (ctx) => {
    const ok = await repositories.items.remove(ctx.params.id);
    if (!ok) throw new Error('not found');
    return { ok: true };
  });

  router.get('/api/runs', async (ctx) => {
    const limit = Math.min(200, Number(ctx.query.get('limit') ?? 50));
    const offset = Math.max(0, Number(ctx.query.get('offset') ?? 0));
    return repositories.runs.list({ limit, offset });
  });

  router.post('/api/runs', async (ctx) => {
    if (!state.limiter.tryTake('write')) throw new Error('rate limit: слишком много запросов');
    const body = requireObject(ctx.body);
    const created = await repositories.runs.create(body as never);
    state.memory.add(created.id, JSON.stringify(created).slice(0, 1500), { kind: 'runs' });
    return { item: created };
  });

  router.get('/api/runs/:id', async (ctx) => {
    const item = await repositories.runs.get(ctx.params.id);
    if (!item) throw new Error('not found');
    return { item };
  });

  router.delete('/api/runs/:id', async (ctx) => {
    const ok = await repositories.runs.remove(ctx.params.id);
    if (!ok) throw new Error('not found');
    return { ok: true };
  });

  router.get('/api/events', async (ctx) => {
    const limit = Math.min(200, Number(ctx.query.get('limit') ?? 50));
    const offset = Math.max(0, Number(ctx.query.get('offset') ?? 0));
    return repositories.events_log.list({ limit, offset });
  });

  router.post('/api/events', async (ctx) => {
    if (!state.limiter.tryTake('write')) throw new Error('rate limit: слишком много запросов');
    const body = requireObject(ctx.body);
    const created = await repositories.events_log.create(body as never);
    state.memory.add(created.id, JSON.stringify(created).slice(0, 1500), { kind: 'events' });
    return { item: created };
  });

  router.get('/api/events/:id', async (ctx) => {
    const item = await repositories.events_log.get(ctx.params.id);
    if (!item) throw new Error('not found');
    return { item };
  });

  router.delete('/api/events/:id', async (ctx) => {
    const ok = await repositories.events_log.remove(ctx.params.id);
    if (!ok) throw new Error('not found');
    return { ok: true };
  });


  router.get('/api/routes', () => ({ routes: router.routes() }));
  return router;
}