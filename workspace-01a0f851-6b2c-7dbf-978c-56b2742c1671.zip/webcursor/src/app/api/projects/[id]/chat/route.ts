import { asc, eq } from "@/db/orm";
import { db } from "@/db";
import { chats, projects } from "@/db/schema";
import { consumeChatQuota, getAuthUser } from "@/lib/auth";
import {
  applyAgentPatches,
  runChatTurn,
  type AgentEvent,
  type ChatMode,
  type Patch,
} from "@/lib/agent";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

async function authed(request: Request, projectId: number) {
  const user = await getAuthUser(request);
  if (!user) return { error: Response.json({ error: "Требуется вход", auth: true }, { status: 401 }), user: null };
  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project || project.userId !== user.id) {
    return { error: Response.json({ error: "проект не найден" }, { status: 404 }), user: null };
  }
  return { error: null, user };
}

export async function GET(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) return Response.json({ error: "плохой id" }, { status: 400 });
  const gate = await authed(request, projectId);
  if (gate.error) return gate.error;
  const rows = await db.select().from(chats).where(eq(chats.projectId, projectId)).orderBy(asc(chats.id));
  return Response.json({ messages: rows });
}

/**
 * POST — ход агента (NDJSON-стрим). body:
 *   { message, mode: "agent" | "architect" | "ask" }
 *   { apply: { patches, summary, provider } }
 */
export async function POST(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) return Response.json({ error: "плохой id" }, { status: 400 });
  const gate = await authed(request, projectId);
  if (gate.error) return gate.error;
  const user = gate.user!;
  const body = (await request.json().catch(() => ({}))) as {
    message?: string;
    mode?: ChatMode;
    apply?: { patches: Patch[]; summary?: string; provider?: string };
  };

  const encoder = new TextEncoder();

  /* Применение отревьюенных патчей — квотой не считается */
  if (body.apply?.patches) {
    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        const send = (payload: unknown) => {
          try {
            controller.enqueue(encoder.encode(`${JSON.stringify(payload)}\n`));
          } catch {
            /* закрыт */
          }
        };
        try {
          send({ type: "status", text: "Применяю правки…", icon: "apply" });
          const result = await applyAgentPatches(
            projectId,
            body.apply!.patches,
            body.apply!.summary ?? "Правки агента",
            body.apply!.provider ?? "agent",
          );
          send({ type: "changed", changed: result.changed });
          send({ type: "done", result: { mode: "apply", changed: result.changed, provider: "user-approved" } });
        } catch (error) {
          send({ type: "error", message: error instanceof Error ? error.message : String(error) });
        }
        controller.close();
      },
    });
    return new Response(stream, {
      headers: { "content-type": "application/x-ndjson; charset=utf-8", "cache-control": "no-store" },
    });
  }

  /* Обычный ход агента — списываем дневную квоту тарифа */
  const message = (body.message ?? "").trim();
  const mode: ChatMode = body.mode === "architect" || body.mode === "ask" ? body.mode : "agent";
  if (message.length < 2) return Response.json({ error: "пустое сообщение" }, { status: 400 });
  const quota = await consumeChatQuota(user);
  if (!quota.ok) {
    return Response.json(
      {
        error: `Дневной лимит тарифа исчерпан: ${quota.limit} запросов агенту. Оформите Pro (500/день) или Team (5000/день).`,
        upgrade: true,
      },
      { status: 402 },
    );
  }

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (event: AgentEvent | { type: string; [k: string]: unknown }) => {
        try {
          controller.enqueue(encoder.encode(`${JSON.stringify(event)}\n`));
        } catch {
          /* закрыт */
        }
      };
      try {
        await runChatTurn(projectId, message, mode, send as (e: AgentEvent) => void);
      } catch (error) {
        send({ type: "error", message: error instanceof Error ? error.message : String(error) });
        send({ type: "done", result: { mode, changed: [], provider: "error" } });
      }
      controller.close();
    },
  });

  return new Response(stream, {
    headers: { "content-type": "application/x-ndjson; charset=utf-8", "cache-control": "no-store" },
  });
}
