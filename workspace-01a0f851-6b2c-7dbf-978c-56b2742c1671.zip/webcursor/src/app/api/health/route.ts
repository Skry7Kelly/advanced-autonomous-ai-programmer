import { db } from "@/db";
import { projects } from "@/db/schema";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  return Response.json({
    ok: true,
    app: "Svarma",
    engine: "SUPER ROY swarm",
    projects: db.count(projects),
    at: new Date().toISOString(),
  });
}
