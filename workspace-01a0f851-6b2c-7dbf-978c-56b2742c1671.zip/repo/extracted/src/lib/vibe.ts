import fs from "node:fs";
import path from "node:path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { artifacts, chats, events, projects } from "@/db/schema";
import { chat, extractJson } from "@/lib/providers";
import { sha256 } from "@/lib/qa";
import { runPipeline } from "@/lib/pipeline";

export type Patch = { action: "write" | "delete"; path: string; content?: string };

function langOf(filePath: string): string {
  if (filePath.endsWith(".ts") || filePath.endsWith(".tsx")) return "typescript";
  if (filePath.endsWith(".js") || filePath.endsWith(".mjs")) return "javascript";
  if (filePath.endsWith(".json")) return "json";
  if (filePath.endsWith(".md")) return "markdown";
  if (filePath.endsWith(".css")) return "css";
  if (filePath.endsWith(".py")) return "python";
  if (filePath.endsWith(".sh")) return "bash";
  return "text";
}

function slugPart(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 32) || "change";
}

function helperModule(message: string): { path: string; content: string } {
  const name = slugPart(message);
  const pascal = name
    .split("-")
    .filter(Boolean)
    .map((w) => w[0].toUpperCase() + w.slice(1))
    .join("");
  return {
    path: `src/modules/vibe-${name}.ts`,
    content: `/** Сгенерировано vibe-агентом по запросу: ${message.replace(/\*\//g, "").slice(0, 180)} */
export interface ${pascal}Input {
  text: string;
}

export function run${pascal}(input: ${pascal}Input): { ok: true; echo: string; tokens: string[] } {
  const text = String(input?.text ?? "").trim();
  const tokens = text.split(/\\s+/).filter(Boolean);
  return { ok: true, echo: text, tokens };
}

export default { run${pascal} };
`,
  };
}

function applyPatches(files: Map<string, string>, patches: Patch[]): string[] {
  const changed: string[] = [];
  for (const patch of patches) {
    const p = patch.path.replace(/^\/+/, "").replace(/\\/g, "/");
    if (!p || p.includes("..")) continue;
    if (patch.action === "delete") {
      if (files.delete(p)) changed.push(p);
      continue;
    }
    if (typeof patch.content !== "string") continue;
    files.set(p, patch.content);
    changed.push(p);
  }
  return [...new Set(changed)];
}

function builtinPatches(files: Map<string, string>, message: string): { summary: string; patches: Patch[] } {
  const helper = helperModule(message);
  const stamp = new Date().toISOString();
  const logPrev = files.get("VIBELOG.md") ?? "# VIBELOG\n\nИстория правок vibe-агента.\n";
  const patches: Patch[] = [
    { action: "write", path: helper.path, content: helper.content },
    { action: "write", path: "VIBELOG.md", content: `${logPrev.trim()}\n\n## ${stamp}\n\n${message}\n\n- модуль: \`${helper.path}\`\n` },
  ];
  const readme = files.get("README.md");
  if (readme && !readme.includes(helper.path)) {
    patches.push({
      action: "write",
      path: "README.md",
      content: `${readme.trim()}\n\n## Vibe: ${stamp.slice(0, 19)}\n\n${message}\n\nДобавлен модуль \`${helper.path}\`.\n`,
    });
  }
  return {
    summary: `Встроенный движок добавил рабочий модуль ${helper.path} и записал правку в VIBELOG.md. Подключите ключ в панели «Ключи», чтобы агент правил существующие файлы целиком.`,
    patches,
  };
}

async function persistFiles(projectId: number, files: Map<string, string>) {
  await db.delete(artifacts).where(eq(artifacts.projectId, projectId));
  const rows = [...files.entries()].map(([filePath, content]) => ({
    projectId,
    path: filePath,
    language: langOf(filePath),
    content,
    bytes: Buffer.byteLength(content, "utf8"),
    sha256: sha256(content),
    origin: "generated" as const,
    agent: "ENGINEER" as const,
  }));
  if (rows.length) await db.insert(artifacts).values(rows);
  const workspace = path.join(process.cwd(), ".super-roy", "projects", String(projectId));
  fs.rmSync(workspace, { recursive: true, force: true });
  for (const [filePath, content] of files) {
    const target = path.join(workspace, filePath);
    if (!target.startsWith(workspace)) continue;
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, content, "utf8");
  }
}

export async function vibeTurn(projectId: number, message: string) {
  const text = message.trim();
  if (text.length < 2) throw new Error("пустое сообщение");
  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project) throw new Error("проект не найден");

  await db.insert(chats).values({ projectId, role: "user", content: text });

  const artifactRows = await db.select().from(artifacts).where(eq(artifacts.projectId, projectId));
  if (artifactRows.length === 0 && project.status !== "running") {
    await db.insert(chats).values({
      projectId,
      role: "assistant",
      content: "Рой собирает проект с нуля по этому запросу. Файлы появятся в дереве, когда конвейер закончит.",
      provider: "swarm",
    });
    await db
      .update(projects)
      .set({ brief: `${project.brief}\n\nVibe: ${text}`, status: "queued", stage: "queued", progress: 0, error: null })
      .where(eq(projects.id, projectId));
    void runPipeline(projectId);
    return { mode: "build" as const, summary: "запущен полный конвейер роя", changed: [] as string[], provider: "swarm" };
  }

  const files = new Map(artifactRows.map((r) => [r.path, r.content]));
  const list = [...files.keys()].slice(0, 80).join("\n");
  const relevant = [...files.entries()]
    .map(([p, c]) => ({ p, c, score: text.toLowerCase().split(/\s+/).filter((w) => w.length > 3 && p.toLowerCase().includes(w)).length }))
    .sort((a, b) => b.score - a.score || a.p.localeCompare(b.p))
    .slice(0, 8);

  const llm = await chat(
    [
      {
        role: "system",
        content:
          'Ты vibe-coding агент в браузерном IDE (как Cursor). Верни СТРОГО JSON без пояснений: {"summary":"что сделал","patches":[{"action":"write"|"delete","path":"относительный путь","content":"полный файл"}]}. Пиши целые рабочие файлы, без TODO и без заглушек. Меняй только нужные файлы. По-русски в summary.',
      },
      {
        role: "user",
        content: `Проект: ${project.name}\nБриф: ${project.brief.slice(0, 800)}\n\nФайлы:\n${list}\n\nСодержимое ключевых файлов:\n${relevant
          .map((item) => `--- ${item.p} ---\n${item.c.slice(0, 4000)}`)
          .join("\n\n")}\n\nЗапрос пользователя:\n${text}`,
      },
    ],
    { maxTokens: 3500, temperature: 0.2 },
  );

  let summary: string;
  let patches: Patch[];
  let provider = "builtin-engine";

  if (llm) {
    const parsed = extractJson<{ summary?: string; patches?: Patch[] }>(llm.text);
    if (parsed?.patches?.length) {
      summary = parsed.summary ?? `Правки от ${llm.provider}`;
      patches = parsed.patches;
      provider = `${llm.provider}:${llm.model}`;
    } else {
      const built = builtinPatches(files, text);
      summary = `${built.summary}\n\nМодель ${llm.provider} ответила без JSON-патчей.`;
      patches = built.patches;
      provider = `${llm.provider}+builtin`;
    }
  } else {
    const built = builtinPatches(files, text);
    summary = built.summary;
    patches = built.patches;
  }

  const changed = applyPatches(files, patches);
  await persistFiles(projectId, files);
  await db.insert(chats).values({ projectId, role: "assistant", content: `${summary}\n\nИзменены: ${changed.join(", ") || "—"}`, provider });
  await db.insert(events).values({
    projectId,
    level: "success",
    agent: "ENGINEER",
    stage: "vibe",
    message: `Vibe: ${changed.length} файл(ов). ${summary.slice(0, 240)}`,
    data: { changed, provider },
  });
  await db.update(projects).set({ updatedAt: new Date(), status: "done", stage: "vibe" }).where(eq(projects.id, projectId));

  return { mode: "edit" as const, summary, changed, provider };
}
