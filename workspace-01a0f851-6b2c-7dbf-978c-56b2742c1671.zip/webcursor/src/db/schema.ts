/**
 * Схема Svarma — порт схемы SUPER ROY на мини-ORM + аккаунты и подписки.
 */
import { boolean, integer, jsonb, memTable, nullableInteger, real, serial, text, timestamp, timestampNull } from "@/db/orm";
import type { Brief, ProjectSettings, QaReport, Spec } from "@/lib/types";

/* ------------------------------ аккаунты -------------------------------- */

export interface UserRow {
  id: number;
  email: string;
  name: string;
  passwordHash: string; // "salt:hash" (scrypt); "" — для соцсетей/гостей
  provider: string; // email | google | apple | github | yandex | guest
  providerId: string; // "google:12345"
  plan: string; // free | pro | team
  planUntil: Date | null;
  chatUsed: number;
  chatDay: string; // YYYY-MM-DD
  createdAt: Date;
}

export const users = memTable<UserRow>("users", {
  id: serial(),
  email: text(),
  name: text(),
  passwordHash: text(""),
  provider: text("email"),
  providerId: text(""),
  plan: text("free"),
  planUntil: timestampNull(),
  chatUsed: integer(0),
  chatDay: text(""),
  createdAt: timestamp(),
});

export interface SessionRow {
  id: number;
  token: string;
  userId: number;
  expiresAt: Date;
  createdAt: Date;
}

export const sessions = memTable<SessionRow>("sessions", {
  id: serial(),
  token: text(),
  userId: integer(),
  expiresAt: timestamp(),
  createdAt: timestamp(),
});

/* ------------------------------- проекты -------------------------------- */

export interface ProjectRow {
  id: number;
  userId: number | null;
  name: string;
  brief: string;
  kind: string;
  language: string;
  status: string;
  stage: string;
  progress: number;
  spec: Spec | null;
  briefParsed: Brief | null;
  qa: QaReport | null;
  settings: ProjectSettings | null;
  stats: Record<string, number> | null;
  error: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export const projects = memTable<ProjectRow>("projects", {
  id: serial(),
  userId: nullableInteger(),
  name: text(),
  brief: text(),
  kind: text("tool"),
  language: text("typescript"),
  status: text("queued"),
  stage: text("init"),
  progress: integer(0),
  spec: jsonb(),
  briefParsed: jsonb(),
  qa: jsonb(),
  settings: jsonb(),
  stats: jsonb(),
  error: text(),
  createdAt: timestamp(),
  updatedAt: timestamp(),
});

/* -------------------------------- рой ----------------------------------- */

export interface RunRow {
  id: number;
  projectId: number;
  status: string;
  summary: Record<string, number> | null;
  startedAt: Date;
  finishedAt: Date | null;
}

export const runs = memTable<RunRow>("runs", {
  id: serial(),
  projectId: integer(),
  status: text("running"),
  summary: jsonb(),
  startedAt: timestamp(),
  finishedAt: timestampNull(),
});

export interface EventRow {
  id: number;
  projectId: number;
  runId: number | null;
  level: string;
  agent: string;
  stage: string;
  message: string;
  data: unknown;
  createdAt: Date;
}

export const events = memTable<EventRow>("events", {
  id: serial(),
  projectId: integer(),
  runId: integer(),
  level: text("info"),
  agent: text("ARCHITECT"),
  stage: text("init"),
  message: text(),
  data: jsonb(),
  createdAt: timestamp(),
});

export interface TaskRow {
  id: number;
  projectId: number;
  ordinal: number;
  title: string;
  detail: string;
  agent: string;
  status: string;
  artifactPath: string | null;
  dependsOn: string[] | null;
  createdAt: Date;
}

export const tasks = memTable<TaskRow>("tasks", {
  id: serial(),
  projectId: integer(),
  ordinal: integer(0),
  title: text(),
  detail: text(""),
  agent: text("ENGINEER"),
  status: text("pending"),
  artifactPath: text(),
  dependsOn: jsonb(),
  createdAt: timestamp(),
});

export interface ArtifactRow {
  id: number;
  projectId: number;
  path: string;
  language: string;
  content: string;
  bytes: number;
  sha256: string;
  origin: string;
  agent: string;
  createdAt: Date;
}

export const artifacts = memTable<ArtifactRow>("artifacts", {
  id: serial(),
  projectId: integer(),
  path: text(),
  language: text("typescript"),
  content: text(),
  bytes: integer(0),
  sha256: text(""),
  origin: text("generated"),
  agent: text("ENGINEER"),
  createdAt: timestamp(),
});

export interface SourceRow {
  id: number;
  projectId: number;
  provider: string;
  query: string;
  title: string;
  url: string;
  subtitle: string;
  metric: number;
  metricLabel: string;
  score: number;
  flyScore: number;
  decision: string;
  reason: string;
  payload: unknown;
  createdAt: Date;
}

export const sources = memTable<SourceRow>("sources", {
  id: serial(),
  projectId: integer(),
  provider: text(),
  query: text(""),
  title: text(),
  url: text(),
  subtitle: text(""),
  metric: integer(0),
  metricLabel: text("stars"),
  score: real(0),
  flyScore: real(0),
  decision: text("reference"),
  reason: text(""),
  payload: jsonb(),
  createdAt: timestamp(),
});

export interface ForgedModuleRow {
  id: number;
  projectId: number | null;
  capability: string;
  name: string;
  rationale: string;
  code: string;
  testCode: string;
  doc: string;
  bytes: number;
  used: boolean;
  createdAt: Date;
}

export const forgedModules = memTable<ForgedModuleRow>("forged_modules", {
  id: serial(),
  projectId: integer(),
  capability: text(),
  name: text(),
  rationale: text(""),
  code: text(),
  testCode: text(""),
  doc: text(""),
  bytes: integer(0),
  used: boolean(true),
  createdAt: timestamp(),
});

export interface MemoryRow {
  id: number;
  projectId: number | null;
  brainId: number | null;
  kind: string;
  text: string;
  meta: unknown;
  tag: number[] | null;
  createdAt: Date;
}

export const memories = memTable<MemoryRow>("memories", {
  id: serial(),
  projectId: integer(),
  brainId: integer(),
  kind: text("note"),
  text: text(),
  meta: jsonb(),
  tag: jsonb(),
  createdAt: timestamp(),
});

export interface FlyBrainRow {
  id: number;
  name: string;
  generation: number;
  parents: number[] | null;
  inputDim: number;
  outputDim: number;
  conn: number;
  k: number;
  seed: number;
  weights: number[] | null;
  fitness: number;
  evals: number;
  active: boolean;
  note: string;
  createdAt: Date;
}

export const flyBrains = memTable<FlyBrainRow>("fly_brains", {
  id: serial(),
  name: text(),
  generation: integer(0),
  parents: jsonb(),
  inputDim: integer(4096),
  outputDim: integer(32768),
  conn: integer(32),
  k: integer(128),
  seed: integer(1),
  weights: jsonb(),
  fitness: real(0),
  evals: integer(0),
  active: boolean(false),
  note: text(""),
  createdAt: timestamp(),
});

export interface ProxyRow {
  id: number;
  url: string;
  protocol: string;
  status: string;
  latencyMs: number | null;
  failCount: number;
  okCount: number;
  note: string;
  lastCheckedAt: Date | null;
  createdAt: Date;
}

export const proxies = memTable<ProxyRow>("proxies", {
  id: serial(),
  url: text(),
  protocol: text("http"),
  status: text("unknown"),
  latencyMs: integer(),
  failCount: integer(0),
  okCount: integer(0),
  note: text(""),
  lastCheckedAt: timestampNull(),
  createdAt: timestamp(),
});

export interface SecretRow {
  id: number;
  envKey: string;
  label: string;
  value: string;
  hint: string;
  updatedAt: Date;
}

export const secrets = memTable<SecretRow>("secrets", {
  id: serial(),
  envKey: text(),
  label: text(""),
  value: text(""),
  hint: text(""),
  updatedAt: timestamp(),
});

export interface ChatRow {
  id: number;
  projectId: number;
  role: string;
  content: string;
  provider: string;
  createdAt: Date;
}

export const chats = memTable<ChatRow>("chats", {
  id: serial(),
  projectId: integer(),
  role: text("user"),
  content: text(),
  provider: text(""),
  createdAt: timestamp(),
});

export interface ProviderRow {
  id: number;
  key: string;
  label: string;
  kind: string;
  baseUrl: string;
  model: string;
  envKey: string;
  enabled: boolean;
  status: string;
  latencyMs: number | null;
  detail: string;
  priority: number;
  lastCheckedAt: Date | null;
}

export const providers = memTable<ProviderRow>("providers", {
  id: serial(),
  key: text(),
  label: text(),
  kind: text("chat"),
  baseUrl: text(""),
  model: text(""),
  envKey: text(""),
  enabled: boolean(true),
  status: text("unknown"),
  latencyMs: integer(),
  detail: text(""),
  priority: integer(100),
  lastCheckedAt: timestampNull(),
});
