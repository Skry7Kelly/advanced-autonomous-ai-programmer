import test from 'node:test';
import assert from 'node:assert/strict';
import { ResumableDownloader } from '../src/modules/model-downloader.js';

test('класс создаётся и не теряет заголовки', () => {
  const dl = new ResumableDownloader({ 'user-agent': 'super-roy' });
  assert.ok(dl);
});