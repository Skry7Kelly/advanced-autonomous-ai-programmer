import crypto from "node:crypto";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, ensureSeed, publicUser, sessionCookieHeader, usageOf } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST() {
  await ensureSeed();
  const suffix = crypto.randomBytes(5).toString("hex");
  const [user] = await db
    .insert(users)
    .values({
      email: `guest-${suffix}@svarma.app`,
      name: `Гость ${suffix.slice(0, 4)}`,
      passwordHash: "",
      provider: "guest",
      providerId: "",
    })
    .returning();
  const { token } = await createSession(user.id);
  return Response.json(
    { user: publicUser(user), usage: await usageOf(user) },
    { status: 201, headers: { "set-cookie": sessionCookieHeader(token) } },
  );
}
