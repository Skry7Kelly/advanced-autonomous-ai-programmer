"use client";

import { useMemo, useState } from "react";
import { Icon } from "./icons";
import { extColor, fmtBytes } from "./api";
import { AGENTS, AGENT_META, type EventRow, type FileRow, type ForgedRow, type SourceRow } from "./types";

/* ------------------------------ дерево файлов ----------------------------- */

type TreeNode = {
  name: string;
  path: string;
  isFile: boolean;
  children: Map<string, TreeNode>;
};

function buildTree(paths: string[]): TreeNode {
  const root: TreeNode = { name: "", path: "", isFile: false, children: new Map() };
  for (const p of paths) {
    const parts = p.split("/").filter(Boolean);
    let node = root;
    for (let i = 0; i < parts.length; i++) {
      const name = parts[i];
      const isFile = i === parts.length - 1;
      if (!node.children.has(name)) {
        node.children.set(name, { name, path: parts.slice(0, i + 1).join("/"), isFile, children: new Map() });
      }
      node = node.children.get(name)!;
    }
  }
  return root;
}

function TreeRow({
  node,
  depth,
  activePath,
  dirtyPaths,
  onOpenFile,
}: {
  node: TreeNode;
  depth: number;
  activePath: string | null;
  dirtyPaths: Set<string>;
  onOpenFile: (path: string) => void;
}) {
  const [open, setOpen] = useState(true);
  const children = [...node.children.values()].sort((a, b) => Number(a.isFile) - Number(b.isFile) || a.name.localeCompare(b.name));

  if (node.isFile) {
    const isActive = activePath === node.path;
    const isDirty = dirtyPaths.has(node.path);
    return (
      <button
        onClick={() => onOpenFile(node.path)}
        className={`group flex w-full items-center gap-1.5 rounded-md py-[3px] pr-2 text-left text-[12.5px] transition-colors ${
          isActive ? "bg-ink-750 text-ink-50" : "text-ink-200 hover:bg-ink-800"
        }`}
        style={{ paddingLeft: 8 + depth * 14 }}
      >
        <span className="h-1.5 w-1.5 shrink-0 rounded-[2px]" style={{ background: extColor(node.path) }} />
        <span className="truncate">{node.name}</span>
        {isDirty && <span className="ml-auto h-1.5 w-1.5 shrink-0 rounded-full bg-accent2" />}
      </button>
    );
  }

  return (
    <div>
      {node.name && (
        <button
          onClick={() => setOpen((v) => !v)}
          className="flex w-full items-center gap-1 rounded-md py-[3px] pr-2 text-left text-[12.5px] text-ink-300 transition-colors hover:bg-ink-800"
          style={{ paddingLeft: 4 + depth * 14 }}
        >
          <Icon name={open ? "chevronDown" : "chevronRight"} size={12} className="shrink-0 text-ink-500" />
          <Icon name={open ? "folderOpen" : "folder"} size={13} className="shrink-0 text-warn/80" />
          <span className="truncate font-medium">{node.name}</span>
        </button>
      )}
      {open && children.map((child) => <TreeRow key={child.path} node={child} depth={node.name ? depth + 1 : depth} activePath={activePath} dirtyPaths={dirtyPaths} onOpenFile={onOpenFile} />)}
    </div>
  );
}

/* -------------------------------- панель ---------------------------------- */

export default function Sidebar({
  tab,
  files,
  activePath,
  dirtyPaths,
  onOpenFile,
  events,
  sources,
  forged,
  onAgentClick,
}: {
  tab: "files" | "swarm" | "sources";
  files: FileRow[];
  activePath: string | null;
  dirtyPaths: Set<string>;
  onOpenFile: (path: string) => void;
  events: EventRow[];
  sources: SourceRow[];
  forged: ForgedRow[];
  onAgentClick: (agent: string) => void;
}) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    if (!query.trim()) return files;
    const q = query.toLowerCase();
    return files.filter((f) => f.path.toLowerCase().includes(q));
  }, [files, query]);

  const tree = useMemo(() => buildTree(filtered.map((f) => f.path)), [filtered]);

  const lastByAgent = useMemo(() => {
    const map = new Map<string, EventRow>();
    for (const e of events) {
      if (AGENTS.includes(e.agent as (typeof AGENTS)[number])) map.set(e.agent, e);
    }
    return map;
  }, [events]);

  return (
    <aside className="flex w-60 shrink-0 flex-col border-r border-ink-800 bg-ink-900">
      {/* заголовок панели */}
      <div className="flex h-9 shrink-0 items-center justify-between border-b border-ink-800 px-3">
        <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-ink-400">
          {tab === "files" ? "Проводник" : tab === "swarm" ? "Рой агентов" : "Источники"}
        </span>
        {tab === "files" && (
          <span className="font-mono text-[10px] text-ink-500">{files.length} файлов</span>
        )}
      </div>

      {tab === "files" && (
        <>
          <div className="shrink-0 px-2.5 pt-2">
            <div className="relative">
              <Icon name="search" size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-500" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Фильтр файлов…"
                className="input !py-1.5 !pl-8 !text-[12px]"
              />
            </div>
          </div>
          <div className="scroll-y flex-1 p-1.5 pt-2">
            {files.length === 0 ? (
              <div className="grid-bg m-1 rounded-xl border border-dashed border-ink-700 p-5 text-center">
                <Icon name="files" size={22} className="mx-auto mb-2 text-ink-500" />
                <p className="text-[11.5px] leading-relaxed text-ink-400">
                  Файлы появятся здесь, когда рой сгенерирует проект
                </p>
              </div>
            ) : (
              <TreeRow node={tree} depth={0} activePath={activePath} dirtyPaths={dirtyPaths} onOpenFile={onOpenFile} />
            )}
          </div>
        </>
      )}

      {tab === "swarm" && (
        <div className="scroll-y flex-1 space-y-1.5 p-2">
          {AGENTS.map((agent) => {
            const last = lastByAgent.get(agent);
            const meta = AGENT_META[agent];
            return (
              <button
                key={agent}
                onClick={() => onAgentClick(agent)}
                className={`group w-full rounded-xl border border-ink-750 bg-ink-880 p-2.5 text-left transition-all hover:border-ink-600 hover:bg-ink-850 agent-${agent}`}
              >
                <div className="flex items-center gap-2">
                  <span className="flex h-6 w-6 items-center justify-center rounded-lg border text-[9px] font-bold" style={{ color: "var(--ag)", borderColor: "color-mix(in srgb, var(--ag) 30%, transparent)", background: "color-mix(in srgb, var(--ag) 10%, transparent)" }}>
                    {agent.slice(0, 2)}
                  </span>
                  <span className="text-[11.5px] font-semibold text-ink-100">{meta.label}</span>
                  <span className={`ml-auto h-1.5 w-1.5 rounded-full ${last ? "bg-ok" : "bg-ink-600"}`} />
                </div>
                <p className="mt-1.5 text-[10.5px] leading-snug text-ink-400">{meta.hint}</p>
                {last ? (
                  <p className="mt-1.5 line-clamp-2 border-t border-ink-750 pt-1.5 text-[10.5px] leading-snug text-ink-300">
                    {last.message.slice(0, 120)}
                  </p>
                ) : (
                  <p className="mt-1.5 border-t border-ink-750 pt-1.5 text-[10.5px] text-ink-500">пока молчит…</p>
                )}
              </button>
            );
          })}

          {forged.length > 0 && (
            <div className="mt-2">
              <div className="mb-1.5 px-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-ink-500">
                Выковано КУЗНЕЦОМ · {forged.length}
              </div>
              <div className="space-y-1">
                {forged.slice(0, 12).map((m) => (
                  <div key={m.id} className="rounded-lg border border-warn/20 bg-warn/5 px-2.5 py-1.5">
                    <div className="truncate font-mono text-[11px] text-warn/90">{m.name}</div>
                    <div className="truncate text-[10px] text-ink-400">{m.capability} · {fmtBytes(m.bytes)}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {tab === "sources" && (
        <div className="scroll-y flex-1 p-2">
          {sources.length === 0 ? (
            <div className="grid-bg m-1 rounded-xl border border-dashed border-ink-700 p-5 text-center">
              <Icon name="sources" size={22} className="mx-auto mb-2 text-ink-500" />
              <p className="text-[11.5px] leading-relaxed text-ink-400">
                РАЗВЕДЧИК найдёт готовые решения и модели, когда запустится конвейер
              </p>
            </div>
          ) : (
            <div className="space-y-1.5">
              {sources.map((s) => (
                <a
                  key={s.id}
                  href={s.url}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="block rounded-xl border border-ink-750 bg-ink-880 p-2.5 transition-all hover:border-ink-600 hover:bg-ink-850"
                >
                  <div className="flex items-start gap-2">
                    <span
                      className={`chip shrink-0 ${
                        s.decision === "adopted"
                          ? "!border-ok/40 !text-ok"
                          : s.decision === "rejected"
                            ? "!border-danger/30 !text-danger"
                            : ""
                      }`}
                    >
                      {s.decision === "adopted" ? "принято" : s.decision === "rejected" ? "отклонено" : s.decision === "model" ? "модель" : "референс"}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-[12px] font-medium text-ink-100" title={s.title}>
                      {s.title}
                    </span>
                  </div>
                  <div className="mt-1 flex items-center gap-2 text-[10px] text-ink-400">
                    <span className="rounded bg-ink-800 px-1.5 py-0.5 font-mono">{s.provider}</span>
                    {s.metric > 0 ? <span>★ {s.metric.toLocaleString("ru-RU")} {s.metricLabel}</span> : null}
                    <span className="ml-auto truncate font-mono">score {s.score.toFixed(2)}</span>
                  </div>
                  {s.reason ? <p className="mt-1 line-clamp-2 text-[10.5px] leading-snug text-ink-400">{s.reason}</p> : null}
                </a>
              ))}
            </div>
          )}
        </div>
      )}
    </aside>
  );
}
