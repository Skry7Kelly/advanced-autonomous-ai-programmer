# Исследование источников для «Которое будет говорить какую USDT пару Сейчас лучше LONG или SHORT»

Разведчик роя обошёл PirateFace.co (индекс суверенных моделей), GitHub, npm, Hacker News и StackOverflow.

## Найденные репозитории и материалы

| Источник | Название | Метрика | Смысл |
| --- | --- | --- | --- |
| github | [HackkingMan/Hack](https://github.com/HackkingMan/Hack) | 20 | Для тех, кто не в теме, проведу краткий экскурс в историю. Ратники, они же Remote Access Trojan (трояны удаленного досту |
| github | [Kervalix/Kevoice](https://github.com/Kervalix/Kevoice) | 1 | TTS приложение которое выводит звук на VB Cable и позволяет говорить если нет такой возможности ·  · MIT · обновлён 2026 |
| github | [rupleide/NetFix](https://github.com/rupleide/NetFix) | 467 | ⚡️ NetFix - Лучшее GUI приложение для обходов. Оживляет Telegram и Discord за 2 секунды. Забудь про консоль и батники на |
| github | [FaradayApp/Faraday-android](https://github.com/FaradayApp/Faraday-android) | 40 | Мобильное приложение, которое сочетает в себе безопасность и конфиденциальность общения с эффективным управлением проект |
| github | [technology16/pgsqlblocks](https://github.com/technology16/pgsqlblocks) | 32 | pgSqlBlocks - это standalone приложение, написанное на языке программирования Java, которое позволяет легко ориентироват |
| github | [AlexDev505/AudioBookPlayer](https://github.com/AlexDev505/AudioBookPlayer) | 25 | AB Player - приложение для Windows, которое позволит вам бесплатно слушать и скачивать аудио книги. · Python · MIT · обн |
| github | [GeekBrainsTutorial/online-store-api](https://github.com/GeekBrainsTutorial/online-store-api) | 22 | В этом репозитории будет храниться API для интернет-магазина с заглушками. API будет возвращать тестовые данные. Данное  |
| github | [Severenit/The-Basics-Of-Angular-2](https://github.com/Severenit/The-Basics-Of-Angular-2) | 19 | Простое приложение по голосованию, которое напоминает чем-то знаминитый сайт reddit, но написанный на Angular 2 · JavaSc |
| github | [Shiyan7/kinomore](https://github.com/Shiyan7/kinomore) | 243 | Front-end приложение для поиска и просмотра фильмов · TypeScript · MIT · обновлён 2022-11-23 · cinema,jest,nextjs,redux- |
| github | [solntsevatv/CosmosApp](https://github.com/solntsevatv/CosmosApp) | 5 | 🌌 Андроид-приложение, в котором Вы сможете увидеть фотографию звездного неба любого знаменательного для Вас дня, послуш |
| github | [juvirez/yandex-music-app](https://github.com/juvirez/yandex-music-app) | 1429 | Неофициальное приложение Яндекс Музыка для MacOS · JavaScript · MIT · обновлён 2023-05-11 |
| github | [romanvht/ByeByeDPI](https://github.com/romanvht/ByeByeDPI) | 6744 | Приложение локально запускает ByeDPI и перенаправляет весь трафик через него · Kotlin · GPL-3.0 · обновлён 2026-09-29 ·  |
| github | [KaterynaZadorozhnia/JavaScript_1](https://github.com/KaterynaZadorozhnia/JavaScript_1) | 2 | 1. Запросить у пользователя его возраст и определить, кем он является: ребенком (0–2), подростком (12–18), взрослым (18_ |
| github | [SpoofDPIApp/SpoofDPI-App](https://github.com/SpoofDPIApp/SpoofDPI-App) | 612 | Простое в использовании приложение для Mac, благодаря которому YouTube снова заработает отлично! На основе библиотеки Sp |
| github | [MYSOREZ/vk-turn-proxy-android](https://github.com/MYSOREZ/vk-turn-proxy-android) | 447 | Android-приложение под ядро https://github.com/cacggghp/vk-turn-proxy · Kotlin · GPL-3.0 · обновлён 2026-08-28 |
| github | [ncanode-kz/NCANode](https://github.com/ncanode-kz/NCANode) | 322 | ⭐ Приложение-сервер для работы с Электронно Цифровой Подписью (ЭЦП) РК · Java · MIT · обновлён 2026-09-16 · api,crl,digi |
| github | [alvassin/backendschool2019](https://github.com/alvassin/backendschool2019) | 271 | Приложение для практического руководства по разработке бекенд-сервисов на Python (на основе вступительного испытания в Ш |
| github | [raulhaag/MiMangaNu](https://github.com/raulhaag/MiMangaNu) | 271 | *ES - Lector de Manga online / offline, gratuito y de código abierto.  *EN - Manga reader online / offline, free and ope |
| github | [1C-Company/v8-code-style](https://github.com/1C-Company/v8-code-style) | 240 | Расширение для 1C:EDT, которое помогает разрабатывать конфигурации/приложения по стандартам 1С для платформы "1С:Предпри |
| github | [garakh/kladrapi](https://github.com/garakh/kladrapi) | 185 | Проект переведен в прориетарный статус. Дальнейшее его развитие будет осуществляться компанией-разработчиком, исходные к |
| github | [fullstack-development/blockchain-wiki](https://github.com/fullstack-development/blockchain-wiki) | 119 | Исчерпывающее wiki от разработчиков смарт-контрактов для разработчиков смарт-контрактов и не только. Оно будет полезно р |
| github | [bot-probiv-tg/.github](https://github.com/bot-probiv-tg/.github) | 115 | Пробив бот тг — ТОП 10 сервисов 2026. Поможем пробить номер телефона, найти человека по юзу в ТГ или фото. Лучшие боты п |
| github | [pegakmop/neofit](https://github.com/pegakmop/neofit) | 94 | В общем старый неофит который на php списан в архивный, не будет поддержки и обновлений, перешел на новый формат с устан |
| github | [ciricc/kinopoisk-dualsubs](https://github.com/ciricc/kinopoisk-dualsubs) | 52 | Расширение для браузера, которое включает двойные субтитры на Кинопоиск HD · Svelte · обновлён 2025-05-02 · kinopoisk,su |
| github | [xKARASb/SferumBot](https://github.com/xKARASb/SferumBot) | 53 | Бот создан для учеников, школьные чаты которых находятся в "Сферум"! Бот будет пересылать все сообщения из Сферума в тел |
| github | [kovalevdmv/1CRestAPINextJSGenCode](https://github.com/kovalevdmv/1CRestAPINextJSGenCode) | 39 | Обработка которая может сильно ускорить процесс разработки web интерфейса с применением web технологий (React/NextJS) за |
| github | [1C-Company/dt-project-checks](https://github.com/1C-Company/dt-project-checks) | 29 | Расширение для 1C:EDT, которое проверяет структурную целостность проектов "1С:Предприятия 8". · Java · EPL-2.0 · обновлё |
| github | [kysect/Main](https://github.com/kysect/Main) | 23 | Место, где будет хранится основная информация связанная с жизнью kysect ·  · обновлён 2024-04-05 |
| github | [karabanov/gimp-id-photo](https://github.com/karabanov/gimp-id-photo) | 18 | Дополнение для GIMP которое позволяет легко и быстро изготавливать фотографии для документов · Python · GPL-3.0 · обновл |
| github | [Delinor-Hens/Vortex](https://github.com/Delinor-Hens/Vortex) | 14 | ИИ под названием Vortex для любых задач. Сейчас уже доступна рабочая версия проекта, которая ежедневно улучшается · C++  |
| github | [leobrn/edt-metadata-favorites](https://github.com/leobrn/edt-metadata-favorites) | 8 | Избранное для проектов и объектов метаданных в Навигаторе 1С:EDT. Позволяет добавлять нужные элементы в избранное, скрыв |
| github | [bewflast/VK-Music-Discord-RPC](https://github.com/bewflast/VK-Music-Discord-RPC) | 6 | Продержи в курсе своих друзей в том, какой трек ты сейчас слушаешь в ВК · C++ · MIT · обновлён 2023-09-26 |
| github | [metya/DataScienceStudy](https://github.com/metya/DataScienceStudy) | 5 | То что я сейчас прохожу, читаю, прочитал, посмотрел, сделал и вообще мой личный списочек всего с этим связанного ·  · об |
| github | [pavelvladimirovich258614-sys/Telegram-AI-Commenter](https://github.com/pavelvladimirovich258614-sys/Telegram-AI-Commenter) | 3 | CommentHulk — это умный бот для автоматического комментирования в Telegram-каналах. Он пишет комментарии от вашего имени |
| github | [qiyanaitsme/QIYANASMCRCON](https://github.com/qiyanaitsme/QIYANASMCRCON) | 3 | Программа берет данные (айпи, пароль RCON и порт RCON из data.txt), а затем позволяет мне отправлять любые команды на се |
| github | [A-Universum/Minimal-formal-core-of-ontological-operators-A-Universum](https://github.com/A-Universum/Minimal-formal-core-of-ontological-operators-A-Universum) | 2 | RFC-Λ (Request for Comments — Λ) — семейство спецификаций, формализующих онтологические операторы системы Λ-Универсум. Э |
| github | [WaterMemor/API-Tinkoff](https://github.com/WaterMemor/API-Tinkoff) | 2 | Узнайте какую комиссию вы заплатили брокеру, сколько денег всего заработали с Тинькофф банком · Python · обновлён 2021-1 |
| github | [abbos-khamidov/blackJackInC](https://github.com/abbos-khamidov/blackJackInC) | 2 | Это мини игра которая сможет считать карты и сказать какую именно карту вы выбрали, требует доработки... · C · Unlicense |
| github | [onesmilla/courserpru](https://github.com/onesmilla/courserpru) | 2 | Учебный геймифицированный курс о том, как руководителю проектов работать с командой данных: кому ставить какую задачу, к |
| github | [IvanZasukhin/SiteGuessr](https://github.com/IvanZasukhin/SiteGuessr) | 2 | Игра где пользователю предстоит угадывать на какую страницу его перекинуло. · Python · обновлён 2024-04-26 |

## Локальные модели

- **Qwen/Qwen2.5-Coder-7B-Instruct-GGUF** — 15 GB, 2 сидов. `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:556995f1e8b9265253ca819f8f6b5133ba427848&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FQwen%2FQwen2.5-Coder-7B-Instruct-GGUF%2F13fb94bfda8c8cf22497dc57b78f391a9acb426a%2F"`
- **ISTA-DASLab/Qwen3.8-Flash-Next-GSQ-RCO-Coder-GGUF** — 30 GB, 2 сидов. `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:d91faad0a0a8fcb9eece9441d49b011e423f418d&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FISTA-DASLab%2FQwen3.8-Flash-Next-GSQ-RCO-Coder-GGUF%2F04d8b36b50cc0479fda9214a378336f89b356d67%2F"`
- **unsloth/Qwen3-Coder-30B-A3B-Instruct-GGUF** — 50 GB, 1 сидов. `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:f29eca18c9bb3794241fab70b359c1316a9b2510&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2Funsloth%2FQwen3-Coder-30B-A3B-Instruct-GGUF%2Fb17cb02dd882d5b6ab62fc777ad2995f19668350%2F"`
- **Jackrong/Qwopus3.5-9B-Coder-MTP-GGUF** — 9.8 GB, 1 сидов. `aria2c --seed-ratio=1.0 --select-file=1-99 "magnet:?xt=urn:btih:3a2878ab7dc7b1b0a6a063dc8909087d4975bcc6&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FJackrong%2FQwopus3.5-9B-Coder-MTP-GGUF%2F58f9bfb45380b53ef0cbd693fce9b97b21f416ae%2F"`

## Что внедряем

- [rupleide/NetFix](https://github.com/rupleide/NetFix) — ⚡️ NetFix - Лучшее GUI приложение для обходов. Оживляет Telegram и Discord за 2 секунды. Забудь про консоль и батники навсегда! 🚀 · C# · GPL-3.0 · обновлён 2026-09-20 · gui,network,telegram,vpn. Подключение: `git clone https://github.com/rupleide/NetFix.git vendor/NetFix`
- [Shiyan7/kinomore](https://github.com/Shiyan7/kinomore) — Front-end приложение для поиска и просмотра фильмов · TypeScript · MIT · обновлён 2022-11-23 · cinema,jest,nextjs,redux-toolkit. Подключение: `git clone https://github.com/Shiyan7/kinomore.git vendor/kinomore`
- [juvirez/yandex-music-app](https://github.com/juvirez/yandex-music-app) — Неофициальное приложение Яндекс Музыка для MacOS · JavaScript · MIT · обновлён 2023-05-11. Подключение: `git clone https://github.com/juvirez/yandex-music-app.git vendor/yandex-music-app`
- [romanvht/ByeByeDPI](https://github.com/romanvht/ByeByeDPI) — Приложение локально запускает ByeDPI и перенаправляет весь трафик через него · Kotlin · GPL-3.0 · обновлён 2026-09-29 · android,byedpi. Подключение: `git clone https://github.com/romanvht/ByeByeDPI.git vendor/ByeByeDPI`