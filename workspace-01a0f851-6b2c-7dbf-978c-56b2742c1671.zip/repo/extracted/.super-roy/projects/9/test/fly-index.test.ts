import test from 'node:test';
import assert from 'node:assert/strict';
import { FlyIndex } from '../src/modules/fly-index.js';

test('похожие тексты находят друг друга', () => {
  const index = new FlyIndex({ outputDim: 4096, k: 48 });
  index.add('1', 'ротация прокси пула для парсинга сайтов');
  index.add('2', 'пул прокси ротация для обхода блокировок');
  index.add('3', 'рецепт борща со свёклой и сметаной');
  const hits = index.search('ротация прокси при парсинге', 2);
  assert.equal(hits[0].id === '1' || hits[0].id === '2', true);
  assert.notEqual(hits[1].id, '3');
});