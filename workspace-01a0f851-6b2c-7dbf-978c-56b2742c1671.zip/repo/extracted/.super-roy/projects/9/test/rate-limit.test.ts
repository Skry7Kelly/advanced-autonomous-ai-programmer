import test from 'node:test';
import assert from 'node:assert/strict';
import { TokenBucketRateLimiter } from '../src/modules/rate-limit.js';

test('не превышает вместимость ведра', () => {
  const limiter = new TokenBucketRateLimiter(2, 100);
  assert.equal(limiter.tryTake('k'), true);
  assert.equal(limiter.tryTake('k'), true);
  assert.equal(limiter.tryTake('k'), false);
});

test('восстанавливает токены со временем', async () => {
  const limiter = new TokenBucketRateLimiter(1, 50);
  limiter.tryTake('k');
  await new Promise((r) => setTimeout(r, 40));
  assert.equal(limiter.tryTake('k'), true);
});