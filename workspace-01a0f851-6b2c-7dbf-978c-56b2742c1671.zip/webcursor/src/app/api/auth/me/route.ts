import { getAuthUser, publicUser, usageOf } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request) {
  const user = await getAuthUser(request);
  if (!user) return Response.json({ user: null, usage: null });
  return Response.json({ user: publicUser(user), usage: await usageOf(user) });
}
