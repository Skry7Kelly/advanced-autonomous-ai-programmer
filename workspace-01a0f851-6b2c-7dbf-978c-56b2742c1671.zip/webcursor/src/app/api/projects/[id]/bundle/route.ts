import { asc, eq } from "@/db/orm";
import { db } from "@/db";
import { artifacts, projects } from "@/db/schema";
import { getAuthUser } from "@/lib/auth";
import { makeZip, safeZipName } from "@/lib/zip";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function zipResponse(filename: string, buffer: Buffer) {
  const ascii = safeZipName(filename, "project");
  return new Response(new Uint8Array(buffer), {
    headers: {
      "content-type": "application/zip",
      "content-disposition": `attachment; filename="${ascii}.zip"; filename*=UTF-8''${encodeURIComponent(ascii)}.zip`,
      "content-length": String(buffer.length),
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
    },
  });
}

async function buildBundle(request: Request, projectId: number) {
  const user = await getAuthUser(request);
  if (!user) return { error: Response.json({ error: "Требуется вход", auth: true }, { status: 401 }) };
  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project || project.userId !== user.id) return { error: Response.json({ error: "проект не найден" }, { status: 404 }) };
  const rows = await db
    .select()
    .from(artifacts)
    .where(eq(artifacts.projectId, projectId))
    .orderBy(asc(artifacts.path));

  const slug = safeZipName(project.spec?.slug ?? project.name ?? `svarma-${projectId}`, `project-${projectId}`);
  const files = rows.map((row) => ({
    path: `${slug}/${row.path.replace(/^\/+/, "")}`,
    content: row.content,
  }));

  files.push({
    path: `${slug}/SVARMA-MANIFEST.json`,
    content: JSON.stringify(
      {
        generatedBy: "Svarma (SUPER ROY swarm)",
        project: {
          id: project.id,
          name: project.name,
          kind: project.kind,
          language: project.language,
          status: project.status,
        },
        spec: project.spec
          ? { title: project.spec.title, slug: project.spec.slug, summary: project.spec.summary }
          : null,
        qa: project.qa,
        stats: project.stats,
        files: rows.map((r) => ({ path: r.path, bytes: r.bytes, language: r.language })),
        exportedAt: new Date().toISOString(),
      },
      null,
      2,
    ),
  });

  if (rows.length === 0) {
    files.push({
      path: `${slug}/README.md`,
      content: `# ${project.name}\n\nРой ещё не собрал файлы (статус: ${project.status}, этап: ${project.stage}).\nПерезапустите сборку и скачайте архив снова.\n\nБриф:\n\n${project.brief}\n`,
    });
  }

  const buffer = makeZip(files);
  return { buffer, slug, files: rows.length, bytes: buffer.length };
}

export async function GET(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) return new Response("bad id", { status: 400 });
  try {
    const result = await buildBundle(request, projectId);
    if ("error" in result) return result.error;
    return zipResponse(result.slug, result.buffer);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return new Response(`не удалось собрать zip: ${message}`, { status: 500 });
  }
}
