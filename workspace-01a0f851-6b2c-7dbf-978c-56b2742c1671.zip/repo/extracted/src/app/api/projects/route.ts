import { desc } from "drizzle-orm";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { DEFAULT_SETTINGS } from "@/lib/pipeline";
import type { ProjectSettings } from "@/lib/types";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  const rows = await db
    .select({
      id: projects.id,
      name: projects.name,
      brief: projects.brief,
      kind: projects.kind,
      language: projects.language,
      status: projects.status,
      stage: projects.stage,
      progress: projects.progress,
      stats: projects.stats,
      qa: projects.qa,
      createdAt: projects.createdAt,
    })
    .from(projects)
    .orderBy(desc(projects.id))
    .limit(40);
  return Response.json({ projects: rows });
}

export async function POST(request: Request) {
  let body: { brief?: string; settings?: Partial<ProjectSettings> } = {};
  try {
    body = (await request.json()) as { brief?: string; settings?: Partial<ProjectSettings> };
  } catch {
    return Response.json({ error: "некорректный JSON" }, { status: 400 });
  }
  const brief = (body.brief ?? "").trim();
  if (brief.length < 12) {
    return Response.json({ error: "Опишите задачу подробнее (минимум 12 символов)" }, { status: 400 });
  }
  const settings: ProjectSettings = { ...DEFAULT_SETTINGS, ...(body.settings ?? {}) };
  const name = brief.split("\n")[0].slice(0, 70).replace(/^\p{Ll}/u, (c) => c.toUpperCase());
  const [row] = await db
    .insert(projects)
    .values({ name, brief, settings, status: "queued", stage: "queued", progress: 0 })
    .returning();
  return Response.json({ project: row }, { status: 201 });
}
