"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Icon } from "./icons";
import { Markdown } from "./markdown";
import { extColor } from "./api";
import type { ChatMode, FileRow, ProposedPatch, RawPatch, UiMessage } from "./types";

const MODES: { id: ChatMode; label: string; icon: Parameters<typeof Icon>[0]["name"]; hint: string }[] = [
  { id: "agent", label: "Агент", icon: "zap", hint: "Меняет файлы проекта: предложит патчи с диффами — вы решаете, применять ли" },
  { id: "architect", label: "Архитектор", icon: "swarm", hint: "Обсуждение архитектуры: строит спецификацию — модули, эндпоинты, вехи" },
  { id: "ask", label: "Спросить", icon: "chat", hint: "Вопросы о проекте с контекстом файлов" },
];

/* ---------------------------- карточка патчей ---------------------------- */

function PatchCard({
  patch,
  onOpenFile,
}: {
  patch: ProposedPatch;
  onOpenFile: (path: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const isDelete = patch.action === "delete";
  return (
    <div className="overflow-hidden rounded-xl border border-ink-700 bg-ink-950">
      <button onClick={() => setOpen((v) => !v)} className="flex w-full items-center gap-2 px-3 py-2 text-left transition-colors hover:bg-ink-880">
        <Icon name={isDelete ? "trash" : "file"} size={13} style={{ color: isDelete ? "#fb7185" : extColor(patch.path) }} />
        <span className="min-w-0 flex-1 truncate font-mono text-[11.5px] text-ink-100">{patch.path}</span>
        {patch.isNew && !isDelete ? <span className="chip !border-ok/40 !text-ok">новый</span> : null}
        {isDelete ? <span className="chip !border-danger/40 !text-danger">удаление</span> : null}
        {!isDelete ? (
          <span className="shrink-0 font-mono text-[10.5px]">
            <span className="text-ok">+{patch.additions}</span> <span className="text-danger">−{patch.deletions}</span>
          </span>
        ) : null}
        <Icon name={open ? "chevronDown" : "chevronRight"} size={13} className="shrink-0 text-ink-500" />
      </button>
      {open ? (
        <div className="max-h-72 overflow-y-auto border-t border-ink-750 bg-ink-950 py-1">
          {patch.diff.slice(0, 400).map((line, i) => (
            <div key={i} className={`diff-line ${line.kind === "add" ? "diff-add" : line.kind === "del" ? "diff-del" : "diff-ctx"}`}>
              <span className="diff-sign">{line.kind === "add" ? "+" : line.kind === "del" ? "−" : " "}</span>
              <span className="truncate">{line.text || " "}</span>
            </div>
          ))}
          {patch.diff.length > 400 ? (
            <div className="px-3 py-1.5 text-center text-[10.5px] text-ink-500">… и ещё {patch.diff.length - 400} строк</div>
          ) : null}
          <button
            onClick={() => onOpenFile(patch.path)}
            className="mt-1 w-full border-t border-ink-750 py-1.5 text-[11px] text-accent2 transition-colors hover:bg-ink-880"
          >
            Открыть в редакторе →
          </button>
        </div>
      ) : null}
    </div>
  );
}

/* --------------------------- карточка спецификации ------------------------ */

function SpecCard({ spec, notes, onOpenFile }: { spec: UiMessage & { kind: "spec" }; notes: string[]; onOpenFile: (path: string) => void }) {
  const [tab, setTab] = useState<"modules" | "endpoints" | "milestones" | "risks">("modules");
  return (
    <div className="overflow-hidden rounded-xl border border-accent3/25 bg-ink-950">
      <div className="border-b border-ink-750 bg-gradient-to-r from-accent3/10 to-transparent px-3.5 py-2.5">
        <div className="flex items-center gap-2">
          <Icon name="sparkles" size={14} className="text-accent3" />
          <span className="text-[12.5px] font-semibold text-ink-50">Спецификация: {spec.spec.title}</span>
        </div>
        <p className="mt-1 text-[11.5px] leading-snug text-ink-300">{spec.spec.summary}</p>
      </div>

      <div className="flex gap-1 border-b border-ink-750 px-2 py-1.5">
        {(
          [
            ["modules", `Модули · ${spec.spec.modules.length}`],
            ["endpoints", `API · ${spec.spec.endpoints.length}`],
            ["milestones", `Вехи · ${spec.spec.milestones.length}`],
            ["risks", `Риски · ${spec.spec.risks.length}`],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`rounded-md px-2 py-1 text-[10.5px] font-medium transition-colors ${
              tab === id ? "bg-ink-750 text-ink-50" : "text-ink-400 hover:bg-ink-800 hover:text-ink-200"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="max-h-64 overflow-y-auto p-2">
        {tab === "modules" &&
          spec.spec.modules.map((m) => (
            <button
              key={m.name}
              onClick={() => onOpenFile(m.path)}
              className="mb-1 flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-ink-880"
            >
              <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: m.origin === "forged" ? "#fbbf24" : m.origin === "adopted" ? "#6ee7a8" : "#7dd3fc" }} />
              <span className="shrink-0 font-mono text-[11px] text-ink-100">{m.name}</span>
              <span className="ml-auto shrink-0 text-[10px] uppercase tracking-wide text-ink-500">{m.origin}</span>
            </button>
          ))}
        {tab === "endpoints" &&
          spec.spec.endpoints.map((e, i) => (
            <div key={i} className="mb-1 flex items-center gap-2 rounded-lg px-2 py-1 font-mono text-[11px]">
              <span className={`w-12 shrink-0 font-bold ${e.method === "GET" ? "text-ok" : e.method === "POST" ? "text-accent2" : e.method === "DELETE" ? "text-danger" : "text-warn"}`}>
                {e.method}
              </span>
              <span className="truncate text-ink-100">{e.path}</span>
            </div>
          ))}
        {tab === "milestones" &&
          spec.spec.milestones.map((m) => (
            <div key={m.index} className="mb-1.5 rounded-lg border-l-2 border-accent3/50 bg-accent3/5 px-2.5 py-1.5">
              <div className="text-[11.5px] font-semibold text-ink-100">M{m.index + 1}. {m.title}</div>
              <div className="mt-0.5 text-[10.5px] text-ink-400">{m.doneWhen}</div>
            </div>
          ))}
        {tab === "risks" &&
          spec.spec.risks.map((r, i) => (
            <div key={i} className="mb-1 rounded-lg border border-ink-750 px-2.5 py-1.5">
              <div className="flex items-center gap-2">
                <span className={`chip ${r.impact === "high" ? "!border-danger/40 !text-danger" : r.impact === "medium" ? "!border-warn/40 !text-warn" : ""}`}>{r.impact}</span>
                <span className="text-[11.5px] text-ink-100">{r.risk}</span>
              </div>
              <div className="mt-1 text-[10.5px] text-ink-400">↳ {r.mitigation}</div>
            </div>
          ))}
      </div>

      {notes.length > 0 ? (
        <div className="border-t border-ink-750 px-3 py-2">
          {notes.map((n, i) => (
            <p key={i} className="text-[11px] leading-snug text-ink-300">• {n}</p>
          ))}
        </div>
      ) : null}
    </div>
  );
}

/* -------------------------------- панель ---------------------------------- */

export default function ChatPanel({
  messages,
  busy,
  mode,
  setMode,
  onSend,
  onApply,
  onReject,
  onOpenFile,
  files,
  running,
  onMinimize,
}: {
  messages: UiMessage[];
  busy: boolean;
  mode: ChatMode;
  setMode: (m: ChatMode) => void;
  onSend: (text: string) => void;
  onApply: (id: number, patches: RawPatch[], summary: string, provider: string) => void;
  onReject: (id: number) => void;
  onOpenFile: (path: string) => void;
  files: FileRow[];
  running: boolean;
  onMinimize: () => void;
}) {
  const [draft, setDraft] = useState("");
  const [mentionOpen, setMentionOpen] = useState(false);
  const [mentionQuery, setMentionQuery] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, busy]);

  const mentionMatches = useMemo(() => {
    if (!mentionQuery) return files.slice(0, 8);
    const q = mentionQuery.toLowerCase();
    return files.filter((f) => f.path.toLowerCase().includes(q)).slice(0, 8);
  }, [files, mentionQuery]);

  const send = () => {
    const text = draft.trim();
    if (!text || busy || running) return;
    onSend(text);
    setDraft("");
    setMentionOpen(false);
  };

  const onDraftChange = (v: string) => {
    setDraft(v);
    const m = v.match(/@([\w./-]*)$/);
    if (m && files.length > 0) {
      setMentionOpen(true);
      setMentionQuery(m[1]);
    } else {
      setMentionOpen(false);
    }
  };

  const insertMention = (path: string) => {
    setDraft((d) => d.replace(/@([\w./-]*)$/, `@${path} `));
    setMentionOpen(false);
    inputRef.current?.focus();
  };

  const activeMode = MODES.find((m) => m.id === mode)!;

  return (
    <aside className="flex w-[400px] shrink-0 flex-col border-l border-ink-800 bg-ink-900">
      {/* заголовок */}
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-ink-800 px-3">
        <Icon name="swarm" size={14} className="text-accent2" />
        <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-ink-400">Чат с роем</span>
        <button onClick={onMinimize} className="ml-auto rounded p-1 text-ink-500 transition-colors hover:bg-ink-800 hover:text-ink-100" title="Скрыть (Ctrl+I)">
          <Icon name="close" size={13} />
        </button>
      </div>

      {/* режимы */}
      <div className="flex shrink-0 gap-1 border-b border-ink-800 p-2">
        {MODES.map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            title={m.hint}
            className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-1.5 text-[11.5px] font-medium transition-all ${
              mode === m.id
                ? "bg-gradient-to-b from-accent2/15 to-accent3/10 text-accent2 shadow-[inset_0_0_0_1px_rgba(125,211,252,0.25)]"
                : "text-ink-400 hover:bg-ink-800 hover:text-ink-200"
            }`}
          >
            <Icon name={m.icon} size={12} />
            {m.label}
          </button>
        ))}
      </div>

      {/* лента сообщений */}
      <div className="scroll-y flex-1 space-y-3 p-3">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 p-6 text-center">
            <Icon name="logo" size={40} className="opacity-70" />
            <p className="text-[12.5px] leading-relaxed text-ink-300">
              Опишите, что нужно сделать — <b className="text-ink-100">{activeMode.label.toLowerCase()}</b> приступит к работе.
            </p>
            <p className="text-[11px] leading-relaxed text-ink-500">{activeMode.hint}</p>
          </div>
        ) : null}

        {messages.map((msg) => {
          if (msg.kind === "row") {
            if (msg.row.role === "user") {
              return (
                <div key={msg.row.id} className="flex animate-slide-up justify-end">
                  <div className="max-w-[85%] rounded-2xl rounded-br-md border border-accent2/25 bg-gradient-to-br from-accent2/10 to-accent3/10 px-3.5 py-2 text-[12.5px] leading-relaxed text-ink-50">
                    <p className="whitespace-pre-wrap break-words">{msg.row.content}</p>
                  </div>
                </div>
              );
            }
            return (
              <div key={msg.row.id} className="flex animate-slide-up gap-2">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border border-ink-650 bg-ink-850">
                  <Icon name="logoMini" size={12} />
                </span>
                <div className="min-w-0 flex-1 rounded-2xl rounded-tl-md border border-ink-750 bg-ink-850 px-3.5 py-2.5">
                  <Markdown text={msg.row.content} />
                  {msg.row.provider ? (
                    <div className="mt-1.5 border-t border-ink-750 pt-1.5 font-mono text-[9.5px] text-ink-500">{msg.row.provider}</div>
                  ) : null}
                </div>
              </div>
            );
          }

          if (msg.kind === "status") {
            return (
              <div key={msg.id} className="flex animate-fade-in items-center gap-2.5 rounded-xl border border-ink-750 bg-ink-850 px-3.5 py-2.5">
                <span className="h-3.5 w-3.5 shrink-0 animate-spin-slow rounded-full border-[1.5px] border-accent2/30 border-t-accent2" />
                <span className="text-[12px] text-ink-200">{msg.text}</span>
                <span className="ml-auto flex gap-1">
                  <span className="h-1 w-1 animate-blink rounded-full bg-accent2" style={{ animationDelay: "0ms" }} />
                  <span className="h-1 w-1 animate-blink rounded-full bg-accent2" style={{ animationDelay: "200ms" }} />
                  <span className="h-1 w-1 animate-blink rounded-full bg-accent2" style={{ animationDelay: "400ms" }} />
                </span>
              </div>
            );
          }

          if (msg.kind === "skills") {
            return (
              <div key={msg.id} className="flex animate-slide-up flex-wrap items-center gap-1.5 rounded-xl border border-accent3/25 bg-accent3/5 px-3 py-2">
                <Icon name="sparkles" size={12} className="shrink-0 text-accent3" />
                <span className="text-[10.5px] font-semibold uppercase tracking-wider text-ink-400">скиллы:</span>
                {msg.skills.map((sk) => (
                  <span key={sk} className="chip !border-accent3/30 !py-0.5 !text-[10px] !text-accent3">
                    {sk}
                  </span>
                ))}
              </div>
            );
          }

          if (msg.kind === "build") {
            return (
              <div key={msg.id} className="animate-slide-up rounded-xl border border-accent2/30 bg-gradient-to-r from-accent2/10 via-accent3/10 to-transparent px-3.5 py-3">
                <div className="flex items-center gap-2">
                  <Icon name="zap" size={14} className="animate-glow text-accent2" />
                  <span className="text-[12.5px] font-semibold text-ink-50">Конвейер роя запущен</span>
                </div>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-ink-300">
                  АРХИТЕКТОР → РАЗВЕДЧИК → КУЗНЕЦ → ИНЖЕНЕР → КРИТИК → ИНТЕГРАТОР. Следите за консолью (Ctrl+J) — файлы появятся в дереве по готовности.
                </p>
              </div>
            );
          }

          if (msg.kind === "patches") {
            const applied = msg.applied;
            return (
              <div key={msg.id} className="animate-slide-up space-y-2">
                <div className="flex gap-2">
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border border-accent2/30 bg-accent2/10 text-accent2">
                    <Icon name="zap" size={12} />
                  </span>
                  <div className="min-w-0 flex-1 rounded-2xl rounded-tl-md border border-ink-750 bg-ink-850 px-3.5 py-2.5">
                    <Markdown text={msg.summary} />
                    {msg.provider ? <div className="mt-1.5 font-mono text-[9.5px] text-ink-500">{msg.provider}</div> : null}
                  </div>
                </div>

                <div className="space-y-1.5 pl-8">
                  {msg.patches.map((p, i) => (
                    <PatchCard key={i} patch={p} onOpenFile={onOpenFile} />
                  ))}
                </div>

                {applied === "pending" ? (
                  <div className="flex gap-2 pl-8">
                    <button className="btn btn-accent flex-1 justify-center !py-2" onClick={() => onApply(msg.id, msg.raw, msg.summary, msg.provider)}>
                      <Icon name="check" size={13} /> Применить {msg.patches.length > 1 ? `все (${msg.patches.length})` : ""}
                    </button>
                    <button className="btn btn-danger !py-2" onClick={() => onReject(msg.id)}>
                      <Icon name="close" size={13} /> Отклонить
                    </button>
                  </div>
                ) : (
                  <div className="pl-8">
                    <span className={`chip ${applied === "applied" ? "!border-ok/40 !text-ok" : "!border-ink-650 !text-ink-400"}`}>
                      {applied === "applied" ? "✓ применено" : "✕ отклонено"}
                    </span>
                  </div>
                )}
              </div>
            );
          }

          if (msg.kind === "spec") {
            return (
              <div key={msg.id} className="animate-slide-up">
                <SpecCard spec={msg} notes={msg.notes} onOpenFile={onOpenFile} />
              </div>
            );
          }

          if (msg.kind === "error") {
            return (
              <div key={msg.id} className="animate-slide-up rounded-xl border border-danger/30 bg-danger/5 px-3.5 py-2.5">
                <div className="flex items-center gap-2 text-[12px] font-medium text-danger">
                  <Icon name="alert" size={13} /> Ошибка
                </div>
                <p className="mt-1 break-words text-[11.5px] leading-relaxed text-ink-300">{msg.message}</p>
              </div>
            );
          }

          return null;
        })}

        {running && busy === false ? (
          <div className="flex items-center gap-2.5 rounded-xl border border-accent2/25 bg-accent2/5 px-3.5 py-2.5 text-[11.5px] text-ink-300">
            <span className="h-3 w-3 shrink-0 animate-spin-slow rounded-full border-[1.5px] border-accent2/30 border-t-accent2" />
            Рой сейчас собирает проект — чат подождёт окончания конвейера.
          </div>
        ) : null}

        <div ref={bottomRef} />
      </div>

      {/* ввод */}
      <div className="shrink-0 border-t border-ink-800 p-2.5">
        <div className="relative">
          {mentionOpen && mentionMatches.length > 0 ? (
            <div className="absolute bottom-full left-0 right-0 z-30 mb-2 max-h-52 animate-slide-up overflow-y-auto rounded-xl border border-ink-650 bg-ink-850 p-1.5 shadow-2xl">
              <div className="px-2 pb-1 pt-0.5 text-[10px] uppercase tracking-wider text-ink-500">Контекст: файлы проекта</div>
              {mentionMatches.map((f) => (
                <button
                  key={f.path}
                  onClick={() => insertMention(f.path)}
                  className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-ink-750"
                >
                  <span className="h-1.5 w-1.5 shrink-0 rounded-[2px]" style={{ background: extColor(f.path) }} />
                  <span className="truncate font-mono text-[11.5px] text-ink-100">{f.path}</span>
                </button>
              ))}
            </div>
          ) : null}

          <div className="rounded-xl border border-ink-700 bg-ink-950 transition-colors focus-within:border-accent2/50">
            <textarea
              ref={inputRef}
              value={draft}
              onChange={(e) => onDraftChange(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
              rows={2}
              maxLength={4000}
              placeholder={
                running
                  ? "Рой работает — дождитесь окончания сборки…"
                  : mode === "agent"
                    ? "Например: добавь endpoint /stats с метриками…  @файл для контекста"
                    : mode === "architect"
                      ? "Например: а если добавить авторизацию и роли?"
                      : "Спросите что угодно о проекте…"
              }
              disabled={running}
              className="max-h-36 w-full resize-none bg-transparent px-3.5 py-2.5 text-[12.5px] leading-relaxed text-ink-50 outline-none placeholder:text-ink-500 disabled:opacity-50"
            />
            <div className="flex items-center gap-2 border-t border-ink-800 px-3 py-1.5">
              <span className="text-[10px] text-ink-500">
                <kbd className="rounded border border-ink-700 bg-ink-800 px-1 py-px font-mono text-[9.5px]">⏎</kbd> отправить ·{" "}
                <kbd className="rounded border border-ink-700 bg-ink-800 px-1 py-px font-mono text-[9.5px]">⇧⏎</kbd> перенос
              </span>
              <button
                onClick={send}
                disabled={!draft.trim() || busy || running}
                className="ml-auto flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-accent2/80 to-accent3/80 text-ink-950 transition-all hover:from-accent2 hover:to-accent3 disabled:from-ink-700 disabled:to-ink-700 disabled:text-ink-500"
                title="Отправить"
              >
                {busy ? <span className="h-3 w-3 animate-spin-slow rounded-full border-[1.5px] border-ink-500 border-t-ink-200" /> : <Icon name="send" size={13} />}
              </button>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
