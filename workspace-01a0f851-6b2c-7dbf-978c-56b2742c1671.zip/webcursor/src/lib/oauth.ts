/**
 * OAuth-вход: Google, Apple, GitHub, Яндекс.
 * Если ключи провайдера не заданы в окружении — кнопка работает в демо-режиме:
 * создаётся/используется демо-аккаунт провайдера (честно помечен как «Гость · …»).
 */
import crypto from "node:crypto";
import { eq } from "@/db/orm";
import { db } from "@/db";
import { users, type UserRow } from "@/db/schema";

export type OAuthProvider = "google" | "apple" | "github" | "yandex";

interface Tokens {
  accessToken?: string;
  idToken?: string;
}

interface SocialProfile {
  id: string;
  email: string;
  name: string;
}

interface ProviderDef {
  label: string;
  configured: () => boolean;
  authorizeUrl: (state: string, redirectUri: string) => string;
  exchange: (code: string, redirectUri: string) => Promise<Tokens>;
  profile: (tokens: Tokens) => Promise<SocialProfile>;
}

function formPost(url: string, params: Record<string, string>, headers: Record<string, string> = {}) {
  return fetch(url, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded", accept: "application/json", ...headers },
    body: new URLSearchParams(params).toString(),
  });
}

function decodeJwtPayload(jwt: string): Record<string, unknown> {
  try {
    const payload = jwt.split(".")[1];
    const json = Buffer.from(payload.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
    return JSON.parse(json) as Record<string, unknown>;
  } catch {
    return {};
  }
}

export const OAUTH_PROVIDERS: Record<OAuthProvider, ProviderDef> = {
  google: {
    label: "Google",
    configured: () => Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
    authorizeUrl: (state, redirectUri) =>
      `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(process.env.GOOGLE_CLIENT_ID ?? "")}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=${encodeURIComponent("openid email profile")}&state=${state}`,
    exchange: async (code, redirectUri) => {
      const res = await formPost("https://oauth2.googleapis.com/token", {
        code,
        client_id: process.env.GOOGLE_CLIENT_ID ?? "",
        client_secret: process.env.GOOGLE_CLIENT_SECRET ?? "",
        redirect_uri: redirectUri,
        grant_type: "authorization_code",
      });
      const data = (await res.json()) as { access_token?: string };
      return { accessToken: data.access_token };
    },
    profile: async (tokens) => {
      const res = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
        headers: { authorization: `Bearer ${tokens.accessToken ?? ""}` },
      });
      const p = (await res.json()) as { sub?: string; email?: string; name?: string };
      return { id: p.sub ?? "", email: p.email ?? "", name: p.name ?? p.email ?? "Гость" };
    },
  },
  apple: {
    label: "Apple",
    configured: () => Boolean(process.env.APPLE_CLIENT_ID && process.env.APPLE_CLIENT_SECRET),
    authorizeUrl: (state, redirectUri) =>
      `https://appleid.apple.com/auth/authorize?client_id=${encodeURIComponent(process.env.APPLE_CLIENT_ID ?? "")}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=${encodeURIComponent("name email")}&response_mode=form_post&state=${state}`,
    exchange: async (code, redirectUri) => {
      const res = await formPost("https://appleid.apple.com/auth/token", {
        code,
        client_id: process.env.APPLE_CLIENT_ID ?? "",
        client_secret: process.env.APPLE_CLIENT_SECRET ?? "",
        redirect_uri: redirectUri,
        grant_type: "authorization_code",
      });
      const data = (await res.json()) as { access_token?: string; id_token?: string };
      return { accessToken: data.access_token, idToken: data.id_token };
    },
    profile: async (tokens) => {
      const claims = decodeJwtPayload(tokens.idToken ?? "");
      const email = String(claims.email ?? "");
      return { id: String(claims.sub ?? ""), email, name: email.split("@")[0] || "Гость" };
    },
  },
  github: {
    label: "GitHub",
    configured: () => Boolean(process.env.GITHUB_CLIENT_ID && process.env.GITHUB_CLIENT_SECRET),
    authorizeUrl: (state, redirectUri) =>
      `https://github.com/login/oauth/authorize?client_id=${encodeURIComponent(process.env.GITHUB_CLIENT_ID ?? "")}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${encodeURIComponent("read:user user:email")}&state=${state}`,
    exchange: async (code) => {
      const res = await formPost("https://github.com/login/oauth/access_token", {
        code,
        client_id: process.env.GITHUB_CLIENT_ID ?? "",
        client_secret: process.env.GITHUB_CLIENT_SECRET ?? "",
      });
      const data = (await res.json()) as { access_token?: string };
      return { accessToken: data.access_token };
    },
    profile: async (tokens) => {
      const headers = { authorization: `Bearer ${tokens.accessToken ?? ""}`, accept: "application/vnd.github+json" };
      const res = await fetch("https://api.github.com/user", { headers });
      const p = (await res.json()) as { id?: number; login?: string; name?: string; email?: string | null };
      let email = p.email ?? "";
      if (!email) {
        const emailsRes = await fetch("https://api.github.com/user/emails", { headers });
        const emails = (await emailsRes.json()) as { email: string; primary: boolean }[];
        email = emails.find((e) => e.primary)?.email ?? emails[0]?.email ?? "";
      }
      return { id: String(p.id ?? p.login ?? ""), email, name: p.name ?? p.login ?? "Гость" };
    },
  },
  yandex: {
    label: "Яндекс",
    configured: () => Boolean(process.env.YANDEX_CLIENT_ID && process.env.YANDEX_CLIENT_SECRET),
    authorizeUrl: (state, redirectUri) =>
      `https://oauth.yandex.ru/authorize?client_id=${encodeURIComponent(process.env.YANDEX_CLIENT_ID ?? "")}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&state=${state}`,
    exchange: async (code, redirectUri) => {
      const res = await formPost(
        "https://oauth.yandex.ru/token",
        { code, grant_type: "authorization_code", redirect_uri: redirectUri },
        {
          authorization: `Basic ${Buffer.from(`${process.env.YANDEX_CLIENT_ID}:${process.env.YANDEX_CLIENT_SECRET}`).toString("base64")}`,
        },
      );
      const data = (await res.json()) as { access_token?: string };
      return { accessToken: data.access_token };
    },
    profile: async (tokens) => {
      const res = await fetch("https://login.yandex.ru/info?format=json", {
        headers: { authorization: `OAuth ${tokens.accessToken ?? ""}` },
      });
      const p = (await res.json()) as { id?: string; default_email?: string; real_name?: string; display_name?: string; login?: string };
      return {
        id: String(p.id ?? p.login ?? ""),
        email: p.default_email ?? "",
        name: p.real_name ?? p.display_name ?? p.login ?? "Гость",
      };
    },
  },
};

export function isOAuthProvider(v: string): v is OAuthProvider {
  return v === "google" || v === "apple" || v === "github" || v === "yandex";
}

/* ------------------------------ state-защита ----------------------------- */

const states = new Map<string, { provider: OAuthProvider; expiresAt: number }>();

export function createState(provider: OAuthProvider): string {
  const state = crypto.randomBytes(16).toString("hex");
  states.set(state, { provider, expiresAt: Date.now() + 10 * 60 * 1000 });
  if (states.size > 500) {
    for (const [key, value] of states) {
      if (value.expiresAt < Date.now()) states.delete(key);
    }
  }
  return state;
}

export function consumeState(state: string): OAuthProvider | null {
  const entry = states.get(state);
  if (!entry || entry.expiresAt < Date.now()) return null;
  states.delete(state);
  return entry.provider;
}

/* ------------------------------ пользователи ----------------------------- */

export async function findOrCreateSocialUser(provider: OAuthProvider, profile: SocialProfile): Promise<UserRow> {
  const providerKey = `${provider}:${profile.id}`;
  const byProviderId = await db.select().from(users).where(eq(users.providerId, providerKey)).limit(1);
  if (byProviderId[0]) return byProviderId[0];
  const email = profile.email || `${provider}-${profile.id}@svarma.app`;
  const byEmail = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (byEmail[0]) {
    await db.update(users).set({ provider, providerId: providerKey }).where(eq(users.id, byEmail[0].id));
    return byEmail[0];
  }
  const [created] = await db
    .insert(users)
    .values({
      email,
      name: profile.name || email.split("@")[0],
      passwordHash: "",
      provider,
      providerId: providerKey,
    })
    .returning();
  return created;
}

/** Публичный origin — для redirect_uri (учитывает обратный прокси). */
export function publicOrigin(request: Request): string {
  if (process.env.OAUTH_REDIRECT_BASE) return process.env.OAUTH_REDIRECT_BASE.replace(/\/+$/, "");
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host");
  const proto = request.headers.get("x-forwarded-proto") ?? "http";
  if (host) return `${proto}://${host}`;
  return new URL(request.url).origin;
}
