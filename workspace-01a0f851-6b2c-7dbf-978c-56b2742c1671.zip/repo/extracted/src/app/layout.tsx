import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SUPER ROY — vibe IDE в браузере",
  description:
    "Онлайн-IDE уровня Cursor: чат с роем агентов, правки файлов, панель ключей ко всем моделям и скачивание готового ZIP.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
