type Vec = Map<number, number>;

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function fnv1a(str: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

export class FlyIndex {
  private inputDim: number;
  private outputDim: number;
  private conn: number;
  private k: number;
  private edges: { input: number; sign: number }[][] = [];
  private store: { id: string; text: string; tag: number[]; meta: unknown }[] = [];

  constructor(opts: { seed?: number; inputDim?: number; outputDim?: number; conn?: number; k?: number } = {}) {
    this.inputDim = opts.inputDim ?? 2048;
    this.outputDim = opts.outputDim ?? 16384;
    this.conn = opts.conn ?? 24;
    this.k = opts.k ?? Math.max(16, Math.round(this.outputDim * 0.008));
    const rng = mulberry32(opts.seed ?? 20240917);
    for (let j = 0; j < this.outputDim; j++) {
      const row: { input: number; sign: number }[] = [];
      for (let e = 0; e < this.conn; e++) {
        row.push({ input: Math.floor(rng() * this.inputDim), sign: rng() < 0.5 ? -1 : 1 });
      }
      this.edges.push(row);
    }
  }

  private tokenize(text: string): string[] {
    const words = text.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((w) => w.length > 1);
    const out = [...words];
    for (let i = 0; i < words.length - 1; i++) out.push(words[i] + '_' + words[i + 1]);
    const joined = words.join(' ');
    for (let i = 0; i + 4 <= joined.length; i += 2) out.push(joined.slice(i, i + 4));
    return out;
  }

  private encode(text: string): Vec {
    const vec: Vec = new Map();
    for (const tok of this.tokenize(text)) {
      const h = fnv1a(tok);
      const i = h % this.inputDim;
      vec.set(i, (vec.get(i) ?? 0) + 1);
      vec.set((i ^ (h >>> 13)) % this.inputDim, (vec.get((i ^ (h >>> 13)) % this.inputDim) ?? 0) + 0.5);
    }
    return vec;
  }

  tag(text: string): number[] {
    const vec = this.encode(text);
    const sums = new Float64Array(this.outputDim);
    for (let j = 0; j < this.outputDim; j++) {
      let acc = 0;
      const row = this.edges[j];
      for (let e = 0; e < row.length; e++) {
        const v = vec.get(row[e].input);
        if (v !== undefined) acc += v * row[e].sign;
      }
      sums[j] = acc;
    }
    const idx = Array.from(sums.keys());
    idx.sort((a, b) => sums[b] - sums[a]);
    return idx.slice(0, this.k).sort((a, b) => a - b);
  }

  add(id: string, text: string, meta: unknown = null): void {
    this.store.push({ id, text, tag: this.tag(text), meta });
  }

  search(query: string, limit = 5): { id: string; score: number; text: string; meta: unknown }[] {
    const q = this.tag(query);
    return this.store
      .map((item) => ({ id: item.id, text: item.text, meta: item.meta, score: similarity(q, item.tag) }))
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  get size(): number {
    return this.store.length;
  }
}

export function similarity(a: number[], b: number[]): number {
  let i = 0;
  let j2 = 0;
  let inter = 0;
  while (i < a.length && j2 < b.length) {
    if (a[i] === b[j2]) { inter++; i++; j2++; }
    else if (a[i] < b[j2]) i++;
    else j2++;
  }
  return inter / (a.length + b.length - inter || 1);
}