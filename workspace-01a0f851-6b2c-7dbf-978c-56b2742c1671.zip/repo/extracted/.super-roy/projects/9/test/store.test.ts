import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createRepository, type StoredRecord } from '../src/store.js';

test('JSONL-хранилище пишет и читает', async () => {
  process.env.DATA_DIR = await mkdtemp(join(tmpdir(), 'store-'));
  const repo = createRepository<StoredRecord & { title: string }>('tasks');
  const created = await repo.create({ title: 'первая' });
  const read = await repo.get(created.id);
  assert.equal(read?.title, 'первая');
  const removed = await repo.remove(created.id);
  assert.equal(removed, true);
});