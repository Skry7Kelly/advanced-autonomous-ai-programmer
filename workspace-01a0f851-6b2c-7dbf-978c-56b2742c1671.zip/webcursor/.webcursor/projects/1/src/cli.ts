import { createLogger } from './modules/logger.js';
import { parseArgs, helpText } from './modules/cli-args.js';
import { attempt } from './modules/result.js';
import { appConfig } from './config.js';
import { repositories } from './entities.js';
import { buildApp, state } from './app.js';

const log = createLogger(appConfig.LOG_LEVEL as 'debug' | 'info' | 'warn' | 'error', { component: 'cli' });

const COMMANDS = [
  { command: 'start', description: 'поднять HTTP-сервис', flags: ['--port 8787'] },
  { command: 'doctor', description: 'проверить конфигурацию и хранилище' },
  { command: 'import <файл>', description: 'импорт JSONL в хранилище' },
  { command: 'export <файл>', description: 'экспорт хранилища в JSONL' },
  { command: 'pull-models', description: 'показать команды скачивания локальных моделей' },
];

async function doctor(): Promise<void> {
  log.info('конфигурация', { port: appConfig.PORT, dataDir: appConfig.DATA_DIR, proxy: appConfig.PROXY_LIST ? 'задан' : 'не задан' });
  for (const [name, repo] of Object.entries(repositories)) {
    const res = await attempt(async () => repo.count());
    log.info('хранилище ' + name, res.ok ? { file: repo.file, records: res.value } : { error: res.error.message });
  }
  const memory = state.memory.search('проверка памяти', 1);
  log.info('память роя отвечает', { size: state.memory.size, probe: memory.length });
}

async function importFile(path: string): Promise<void> {
  const { readFile } = await import('node:fs/promises');
  const raw = await readFile(path, 'utf8');
  const name = Object.keys(repositories)[0];
  const repo = repositories[name as keyof typeof repositories];
  let count = 0;
  for (const line of raw.split('\n').filter(Boolean)) {
    try {
      await repo.create(JSON.parse(line));
      count += 1;
    } catch (error) {
      log.warn('строка пропущена', { error: String(error) });
    }
  }
  log.info('импорт завершён', { file: path, imported: count, target: name });
}

async function exportFile(path: string): Promise<void> {
  const { writeFile } = await import('node:fs/promises');
  const name = Object.keys(repositories)[0];
  const repo = repositories[name as keyof typeof repositories];
  const { items } = await repo.list({ limit: 10000 });
  await writeFile(path, items.map((i) => JSON.stringify(i)).join('\n'), 'utf8');
  log.info('экспорт завершён', { file: path, records: items.length });
}

export async function main(argv: string[]): Promise<void> {
  const parsed = parseArgs(argv);
  switch (parsed.command) {
    case 'start': {
      const port = Number(parsed.flags.port ?? appConfig.PORT);
      const app = buildApp();
      await app.listen(port);
      log.info('сервис запущен', { port, routes: app.routes().length });
      break;
    }
    case 'doctor':
      await doctor();
      break;
    case 'import':
      await importFile(parsed.positionals[0] ?? 'data/import.jsonl');
      break;
    case 'export':
      await exportFile(parsed.positionals[0] ?? 'data/export.jsonl');
      break;
    case 'pull-models':
      console.log('aria2c --seed-ratio=1.0 --select-file=1-99 \"magnet:?xt=urn:btih:d91faad0a0a8fcb9eece9441d49b011e423f418d&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FISTA-DASLab%2FQwen3.8-Flash-Next-GSQ-RCO-Coder-GGUF%2F04d8b36b50cc0479fda9214a378336f89b356d67%2F\"');
      console.log('aria2c --seed-ratio=1.0 --select-file=1-99 \"magnet:?xt=urn:btih:556995f1e8b9265253ca819f8f6b5133ba427848&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FQwen%2FQwen2.5-Coder-7B-Instruct-GGUF%2F13fb94bfda8c8cf22497dc57b78f391a9acb426a%2F\"');
      console.log('aria2c --seed-ratio=1.0 --select-file=1-99 \"magnet:?xt=urn:btih:0b7c54e97fef910575c92974f8cd88d713401962&tr=udp%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.pirateface.co%3A6969%2Fannounce&ws=https%3A%2F%2Fpirateface.co%2Fapi%2Fws%2FQwen%2FQwen2.5-Coder-1.5B-Instruct-GGUF%2Ff86cb2c1fa58255f8052cc32aeede1b7482d4361%2F\"');
      break;
    default:
      console.log(helpText('REST API трекера привычек: пользователи', COMMANDS));
      break;
  }
}

if (process.argv[1] && process.argv[1].endsWith('cli.ts')) {
  await main(process.argv.slice(2));
}