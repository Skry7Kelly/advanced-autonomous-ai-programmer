import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { projects } from "@/db/schema";
import ZipButton from "@/components/ZipButton";

export const dynamic = "force-dynamic";

export default async function ProjectsPage() {
  const rows = await db
    .select({
      id: projects.id,
      name: projects.name,
      brief: projects.brief,
      status: projects.status,
      kind: projects.kind,
      progress: projects.progress,
      stats: projects.stats,
      qa: projects.qa,
    })
    .from(projects)
    .orderBy(desc(projects.id))
    .limit(100);

  return (
    <main className="mx-auto max-w-[1100px] px-4 py-8 sm:px-6">
      <div className="mb-6 flex items-center justify-between gap-4">
        <h1 className="text-xl font-bold text-[#e8f1fa]">Проекты роя</h1>
        <Link href="/" className="rounded-lg border border-[#26344a] bg-[#111a26] px-3 py-2 text-[12px] text-[#a9c3da] hover:border-sky-500/50 hover:text-sky-300">
          ← к консоли
        </Link>
      </div>
      {rows.length === 0 && <p className="text-[13px] text-[#7d93ab]">Ещё нет ни одного проекта. Вернитесь в консоль и запустите рой.</p>}
      <div className="space-y-3">
        {rows.map((p) => (
          <div key={p.id} className="rounded-xl border border-[#1b2531] bg-[#0b1017]/80 px-4 py-3 transition hover:border-sky-500/40">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <Link href={`/projects/${p.id}`} className="text-[14px] font-semibold text-[#dbe4ee] hover:text-sky-300">
                #{p.id} {p.name}
              </Link>
              <div className="flex items-center gap-2">
                <span
                  className={`rounded-md border px-2 py-0.5 text-[10px] uppercase ${
                    p.status === "done"
                      ? "border-lime-500/40 bg-lime-500/10 text-lime-300"
                      : p.status === "failed"
                        ? "border-red-500/40 bg-red-500/10 text-red-300"
                        : "border-sky-500/40 bg-sky-500/10 text-sky-300"
                  }`}
                >
                  {p.status} · {p.kind}
                </span>
                <ZipButton projectId={p.id} disabled={p.status !== "done"} />
              </div>
            </div>
            <p className="mt-1 line-clamp-2 text-[12px] text-[#7d93ab]">{p.brief}</p>
            <div className="mt-2 h-1 w-full overflow-hidden rounded bg-[#141d27]">
              <div className="h-full rounded bg-lime-400" style={{ width: `${p.progress}%` }} />
            </div>
            {p.stats && (
              <div className="mt-1 text-[10px] text-[#5f738a]">
                файлов {p.stats.files} · {(p.stats.bytes / 1024).toFixed(1)} КБ · QA {p.stats.qaScore}/100 · выковано модулей {p.stats.forged} · источников {p.stats.sources} · моделей {p.stats.models}
              </div>
            )}
          </div>
        ))}
      </div>
    </main>
  );
}
