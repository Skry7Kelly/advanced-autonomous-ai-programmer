"use client";

import { useEffect, useRef, useState } from "react";
import { Icon } from "./icons";
import type { ProjectRow, PublicUser, UsageInfo } from "./types";

const STAGE_LABELS: Record<string, string> = {
  bootstrap: "запуск",
  fly: "память роя",
  brief: "разбор брифа",
  llm: "усиление LLM",
  scout: "разведка в сети",
  forge: "кузница модулей",
  plan: "план",
  codegen: "генерация кода",
  qa: "контроль качества",
  done: "готово",
  failed: "ошибка",
  queued: "в очереди",
  vibe: "vibe-правки",
};

export default function TitleBar({
  project,
  live,
  running,
  projects,
  activeId,
  user,
  usage,
  onSelectProject,
  onNewProject,
  onBuild,
  onDownload,
  onSettings,
  onPlans,
  onLogout,
  onRefreshProviders,
  providerLabel,
  llmAvailable,
}: {
  project: ProjectRow | null;
  live: { status: string; stage: string; progress: number };
  running: boolean;
  projects: ProjectRow[];
  activeId: number;
  user: PublicUser | null;
  usage: UsageInfo | null;
  onSelectProject: (id: number) => void;
  onNewProject: () => void;
  onBuild: () => void;
  onDownload: () => void;
  onSettings: () => void;
  onPlans: () => void;
  onLogout: () => void;
  onRefreshProviders: () => Promise<void>;
  providerLabel: string;
  llmAvailable: boolean | null;
}) {
  const [switcherOpen, setSwitcherOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const switcherRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (switcherRef.current && !switcherRef.current.contains(e.target as Node)) setSwitcherOpen(false);
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) setUserMenuOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const stageLabel = STAGE_LABELS[live.stage] ?? live.stage;
  const avatarLetter = (user?.name ?? "?").trim().charAt(0).toUpperCase() || "?";

  return (
    <header className="relative z-40 flex h-12 shrink-0 items-center gap-3 border-b border-ink-800 bg-ink-900/95 px-3 backdrop-blur">
      {/* лого */}
      <div className="flex items-center gap-2.5">
        <Icon name="logo" size={22} className="shrink-0" />
        <span className="hidden text-[14px] font-bold tracking-[0.18em] sm:block">
          SVAR<span className="text-gradient">MA</span>
        </span>
        <span className="chip hidden !border-accent2/30 !py-0.5 !text-[8.5px] !text-accent2 sm:inline-flex">v1.2</span>
      </div>

      <div className="h-5 w-px bg-ink-700" />

      {/* переключатель проектов */}
      <div className="relative" ref={switcherRef}>
        <button
          onClick={() => setSwitcherOpen((v) => !v)}
          className="ring-focus flex max-w-64 items-center gap-2 rounded-lg px-2.5 py-1.5 text-[12.5px] font-medium text-ink-200 transition-colors hover:bg-ink-800"
        >
          <span className="truncate">{project?.name ?? "Проект"}</span>
          <Icon name="chevronDown" size={13} className="shrink-0 text-ink-400" />
        </button>
        {switcherOpen && (
          <div className="absolute left-0 top-10 z-50 w-80 animate-pop overflow-hidden rounded-xl border border-ink-650 bg-ink-850 shadow-2xl">
            <div className="max-h-72 overflow-y-auto p-1.5">
              {projects.length === 0 ? (
                <div className="px-3 py-4 text-center text-xs text-ink-400">Проектов пока нет</div>
              ) : (
                projects.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      onSelectProject(p.id);
                      setSwitcherOpen(false);
                    }}
                    className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition-colors ${
                      p.id === activeId ? "bg-ink-750" : "hover:bg-ink-800"
                    }`}
                  >
                    <span
                      className={`h-1.5 w-1.5 shrink-0 rounded-full ${
                        p.status === "running" || p.status === "queued"
                          ? "animate-blink bg-accent2"
                          : p.status === "done"
                            ? "bg-ok"
                            : p.status === "failed"
                              ? "bg-danger"
                              : "bg-ink-500"
                      }`}
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[12.5px] text-ink-100">{p.name}</span>
                      <span className="block text-[10.5px] text-ink-400">
                        {p.kind}
                        {p.stats?.files ? ` · ${p.stats.files} файлов` : ""}
                      </span>
                    </span>
                    {p.id === activeId ? <Icon name="check" size={13} className="text-accent2" /> : null}
                  </button>
                ))
              )}
            </div>
            <button
              onClick={() => {
                setSwitcherOpen(false);
                onNewProject();
              }}
              className="flex w-full items-center gap-2 border-t border-ink-700 px-3.5 py-2.5 text-[12.5px] text-accent2 transition-colors hover:bg-ink-800"
            >
              <Icon name="plus" size={14} /> Новый проект
            </button>
          </div>
        )}
      </div>

      {/* прогресс конвейера */}
      {running && (
        <div className="hidden min-w-44 max-w-72 flex-1 animate-fade-in items-center gap-2.5 md:flex">
          <Icon name="swarm" size={14} className="animate-glow text-accent2" />
          <div className="min-w-0 flex-1">
            <div className="flex items-baseline justify-between text-[10.5px] text-ink-300">
              <span className="truncate">{stageLabel}…</span>
              <span className="font-mono">{live.progress}%</span>
            </div>
            <div className="mt-1 h-1 overflow-hidden rounded-full bg-ink-750">
              <div className="shimmer h-full rounded-full transition-all duration-500" style={{ width: `${Math.max(4, live.progress)}%` }} />
            </div>
          </div>
        </div>
      )}

      <div className="ml-auto flex items-center gap-1.5">
        {/* провайдер */}
        <button
          onClick={() => void onRefreshProviders()}
          title="Проверить доступность моделей"
          className="chip ring-focus hidden !py-1.5 hover:border-accent2/40 lg:flex"
        >
          <Icon name="cpu" size={12} className={llmAvailable ? "text-ok" : "text-warn"} />
          <span className="max-w-44 truncate font-mono text-[10.5px] normal-case">{providerLabel || "встроенный движок"}</span>
        </button>

        {running ? (
          <span className="chip !border-accent2/30 !bg-accent2/10 !py-1.5 !text-accent2">
            <span className="h-1.5 w-1.5 animate-blink rounded-full bg-accent2" />
            рой работает
          </span>
        ) : (
          <button className="btn btn-accent !py-1.5" onClick={onBuild} title="Запустить полный конвейер роя">
            <Icon name="zap" size={13} />
            Собрать
          </button>
        )}
        <button className="btn !py-1.5" onClick={onDownload} title="Скачать проект ZIP-архивом">
          <Icon name="download" size={13} />
          <span className="hidden lg:inline">ZIP</span>
        </button>
        <button className="btn btn-ghost !py-1.5" onClick={onSettings} title="Настройки: модели и ключи">
          <Icon name="settings" size={15} />
        </button>

        {/* меню пользователя */}
        {user ? (
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setUserMenuOpen((v) => !v)}
              className="ring-focus ml-1 flex items-center gap-2 rounded-full py-0.5 pl-0.5 pr-2.5 transition-colors hover:bg-ink-800"
            >
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-accent2/80 to-accent3/80 text-[12px] font-bold text-ink-950">
                {avatarLetter}
              </span>
              <span className="hidden max-w-28 truncate text-[12px] text-ink-200 xl:block">{user.name}</span>
              <span
                className={`chip !px-1.5 !py-0.5 !text-[9px] ${
                  user.plan === "free" ? "" : "!border-accent3/40 !text-accent3"
                }`}
              >
                {user.planName}
              </span>
            </button>

            {userMenuOpen && (
              <div className="absolute right-0 top-11 z-50 w-64 animate-pop overflow-hidden rounded-xl border border-ink-650 bg-ink-850 shadow-2xl">
                <div className="border-b border-ink-700 px-3.5 py-3">
                  <div className="truncate text-[13px] font-semibold text-ink-50">{user.name}</div>
                  <div className="truncate text-[11px] text-ink-400">{user.email}</div>
                  <div className="mt-1.5 flex items-center gap-1.5 text-[10.5px] text-ink-500">
                    <span className="chip !py-0.5">{user.provider === "email" ? "e-mail" : user.provider}</span>
                    {usage ? (
                      <span className="font-mono">
                        {usage.projects}/{usage.projectLimit >= 100000 ? "∞" : usage.projectLimit} пр. ·{" "}
                        {usage.chatUsedToday}/{usage.chatLimit >= 5000 ? "∞" : usage.chatLimit} запр.
                      </span>
                    ) : null}
                  </div>
                </div>
                <button
                  onClick={() => {
                    setUserMenuOpen(false);
                    onPlans();
                  }}
                  className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-left text-[12.5px] text-ink-100 transition-colors hover:bg-ink-800"
                >
                  <Icon name="sparkles" size={14} className="text-accent3" />
                  Тарифы и подписка
                </button>
                <button
                  onClick={() => {
                    setUserMenuOpen(false);
                    onSettings();
                  }}
                  className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-left text-[12.5px] text-ink-100 transition-colors hover:bg-ink-800"
                >
                  <Icon name="settings" size={14} className="text-ink-400" />
                  Настройки
                </button>
                <button
                  onClick={() => {
                    setUserMenuOpen(false);
                    onLogout();
                  }}
                  className="flex w-full items-center gap-2.5 border-t border-ink-700 px-3.5 py-2.5 text-left text-[12.5px] text-danger transition-colors hover:bg-danger/10"
                >
                  <Icon name="external" size={14} />
                  Выйти
                </button>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </header>
  );
}
