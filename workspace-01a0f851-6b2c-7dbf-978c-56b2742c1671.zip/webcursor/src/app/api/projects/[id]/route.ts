import { asc, desc, eq } from "@/db/orm";
import { db } from "@/db";
import { artifacts, chats, events, forgedModules, projects, runs, sources, tasks } from "@/db/schema";
import { getAuthUser } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request);
  if (!user) return Response.json({ error: "Требуется вход", auth: true }, { status: 401 });
  const { id } = await ctx.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) return Response.json({ error: "плохой id" }, { status: 400 });
  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project || project.userId !== user.id) return Response.json({ error: "проект не найден" }, { status: 404 });

  const [fileList, sourceRows, forgeRows, taskRows, eventRows, chatRows, runRows] = await Promise.all([
    db
      .select({
        id: artifacts.id,
        path: artifacts.path,
        language: artifacts.language,
        bytes: artifacts.bytes,
        sha256: artifacts.sha256,
        origin: artifacts.origin,
        agent: artifacts.agent,
      })
      .from(artifacts)
      .where(eq(artifacts.projectId, projectId))
      .orderBy(asc(artifacts.path)),
    db.select().from(sources).where(eq(sources.projectId, projectId)).orderBy(desc(sources.score)).limit(120),
    db
      .select({
        id: forgedModules.id,
        capability: forgedModules.capability,
        name: forgedModules.name,
        rationale: forgedModules.rationale,
        bytes: forgedModules.bytes,
      })
      .from(forgedModules)
      .where(eq(forgedModules.projectId, projectId)),
    db.select().from(tasks).where(eq(tasks.projectId, projectId)).orderBy(asc(tasks.ordinal)),
    db.select().from(events).where(eq(events.projectId, projectId)).orderBy(asc(events.id)).limit(400),
    db.select().from(chats).where(eq(chats.projectId, projectId)).orderBy(asc(chats.id)).limit(400),
    db.select().from(runs).where(eq(runs.projectId, projectId)).orderBy(desc(runs.id)).limit(10),
  ]);

  return Response.json({
    project,
    files: fileList,
    sources: sourceRows,
    forged: forgeRows,
    tasks: taskRows,
    events: eventRows,
    chats: chatRows,
    runs: runRows,
  });
}

export async function PATCH(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request);
  if (!user) return Response.json({ error: "Требуется вход", auth: true }, { status: 401 });
  const { id } = await ctx.params;
  const projectId = Number(id);
  const body = (await request.json().catch(() => ({}))) as {
    name?: string;
    brief?: string;
    settings?: Record<string, unknown>;
  };
  if (!Number.isFinite(projectId)) return Response.json({ error: "плохой id" }, { status: 400 });
  const [owned] = await db.select({ id: projects.id }).from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!owned) return Response.json({ error: "проект не найден" }, { status: 404 });
  const patch: Record<string, unknown> = { updatedAt: new Date() };
  if (typeof body.name === "string" && body.name.trim()) patch.name = body.name.trim().slice(0, 80);
  if (typeof body.brief === "string" && body.brief.trim()) patch.brief = body.brief.trim();
  if (body.settings && typeof body.settings === "object") patch.settings = body.settings;
  await db.update(projects).set(patch).where(eq(projects.id, projectId));
  const [row] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!row || row.userId !== user.id) return Response.json({ error: "проект не найден" }, { status: 404 });
  return Response.json({ project: row });
}

export async function DELETE(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request);
  if (!user) return Response.json({ error: "Требуется вход", auth: true }, { status: 401 });
  const { id } = await ctx.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) return Response.json({ error: "плохой id" }, { status: 400 });
  const [owned] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!owned || owned.userId !== user.id) return Response.json({ error: "проект не найден" }, { status: 404 });
  await Promise.all([
    db.delete(artifacts).where(eq(artifacts.projectId, projectId)),
    db.delete(events).where(eq(events.projectId, projectId)),
    db.delete(sources).where(eq(sources.projectId, projectId)),
    db.delete(tasks).where(eq(tasks.projectId, projectId)),
    db.delete(forgedModules).where(eq(forgedModules.projectId, projectId)),
    db.delete(chats).where(eq(chats.projectId, projectId)),
    db.delete(runs).where(eq(runs.projectId, projectId)),
  ]);
  await db.delete(projects).where(eq(projects.id, projectId));
  return Response.json({ ok: true });
}
