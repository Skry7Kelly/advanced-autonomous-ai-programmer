"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Badge, Panel, statusTone } from "@/components/ui";

interface ProviderRow {
  key: string;
  label: string;
  kind: string;
  status: string;
  latencyMs: number | null;
  detail: string;
  model: string;
  envKey: string;
  hasKey: boolean;
  keyless?: boolean;
}
interface FlyInfo {
  active: { name: string; generation: number; fitness: number; note: string; outputDim: number; conn: number; k: number };
  population: { id: number; name: string; generation: number; fitness: number; active: boolean; note: string }[];
  memories: number;
  bestFitness: number;
  algorithm: { paper: string; idea: string; genetics: string };
  demo: { query: string; tagSize: number; top: { text: string; score: number }[] } | null;
}
interface ProxyRow {
  id: number;
  url: string;
  protocol: string;
  status: string;
  latencyMs: number | null;
  failCount: number;
  okCount: number;
}
interface ProjectRow {
  id: number;
  name: string;
  status: string;
  kind: string;
  progress: number;
  stats: Record<string, number> | null;
}
interface ScoutItem {
  provider: string;
  title: string;
  url: string;
  subtitle: string;
  metric: number;
  metricLabel: string;
  score: number;
  flyScore: number;
}
interface ModelItem {
  name: string;
  sizeGB: number;
  seeds: number;
  magnet: string;
}

const EXAMPLES = [
  "Рой агентов для поиска репозиториев на PirateFace и GitHub, который собирает из них локальный ИИ-инструмент для парсинга цен конкурентов с ротацией прокси",
  "Telegram-бот-финансист: учитывает расходы, строит отчёты и подсказывает бюджет на неделю, работает на локальной LLM",
  "CLI-утилита, которая скачивает GGUF модели по магнет-ссылкам, проверяет чексуммы и запускает их через llama.cpp",
  "Маркетплейс услуг с ролями заказчик/исполнитель, чатом, сделками и отзывами на Postgres",
  "Сервис аналитики логов: принимает JSONL, ищет аномалии, строит дашборд и шлёт алерты в Telegram",
];

const TABS = [
  { key: "brief", label: "Задание" },
  { key: "scout", label: "Разведка" },
  { key: "fly", label: "Мозг мухи" },
  { key: "forge", label: "Кузница" },
  { key: "net", label: "Сеть и прокси" },
] as const;

type TabKey = (typeof TABS)[number]["key"];

export default function SwarmConsole() {
  const router = useRouter();
  const [tab, setTab] = useState<TabKey>("brief");
  const [brief, setBrief] = useState("");
  const [settings, setSettings] = useState({
    searchDepth: 2,
    maxAdopt: 4,
    useProxy: false,
    flyBoost: true,
    allowForge: true,
    cloudLlm: true,
    localLlm: true,
    targetLanguage: "typescript",
  });
  const [providers, setProviders] = useState<ProviderRow[]>([]);
  const [fly, setFly] = useState<FlyInfo | null>(null);
  const [flyDemoQuery, setFlyDemoQuery] = useState("ротация прокси при сборе данных");
  const [proxies, setProxies] = useState<ProxyRow[]>([]);
  const [proxyInput, setProxyInput] = useState("");
  const [projects, setProjects] = useState<ProjectRow[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [log, setLog] = useState<string[]>([]);
  const [scoutQuery, setScoutQuery] = useState("");
  const [scoutResult, setScoutResult] = useState<{ items: ScoutItem[]; models: ModelItem[]; queries: string[]; failures: string[] } | null>(null);
  const [forgeCapability, setForgeCapability] = useState("custom-module");
  const [forgeDescription, setForgeDescription] = useState("");
  const [forgeResult, setForgeResult] = useState<{ code: string; test: string; rationale: string; name: string } | null>(null);
  const [catalog, setCatalog] = useState<string[]>([]);
  const [zipBusy, setZipBusy] = useState<number | null>(null);

  const pushLog = useCallback((line: string) => {
    setLog((prev) => [`${new Date().toLocaleTimeString("ru-RU")} · ${line}`, ...prev].slice(0, 40));
  }, []);

  const refresh = useCallback(async () => {
    try {
      const [p, f, pr, list] = await Promise.all([
        fetch("/api/providers").then((r) => r.json()),
        fetch(`/api/fly?q=${encodeURIComponent(flyDemoQuery)}`).then((r) => r.json()),
        fetch("/api/proxies").then((r) => r.json()),
        fetch("/api/projects").then((r) => r.json()),
      ]);
      setProviders(p.providers ?? []);
      setFly(f as FlyInfo);
      setProxies(pr.proxies ?? []);
      setProjects(list.projects ?? []);
    } catch (error) {
      pushLog(`ошибка загрузки состояния: ${String(error)}`);
    }
  }, [flyDemoQuery, pushLog]);

  useEffect(() => {
    void refresh();
    fetch("/api/forge")
      .then((r) => r.json())
      .then((d) => setCatalog(d.catalog ?? []))
      .catch(() => undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const id = setInterval(() => {
      fetch("/api/fly")
        .then((r) => r.json())
        .then((d) => setFly(d as FlyInfo))
        .catch(() => undefined);
    }, 20000);
    return () => clearInterval(id);
  }, []);

  const launch = useCallback(async () => {
    if (brief.trim().length < 12) {
      pushLog("опишите задачу подробнее — минимум 12 символов");
      return;
    }
    setBusy("swarm");
    pushLog("создаю проект и поднимаю рой…");
    try {
      const created = await fetch("/api/projects", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ brief, settings }),
      }).then((r) => r.json());
      if (created.error) {
        pushLog(`отказ: ${created.error}`);
        setBusy(null);
        return;
      }
      const id = created.project.id as number;
      await fetch(`/api/projects/${id}/build`, { method: "POST" });
      pushLog(`рой запущен по проекту #${id}`);
      router.push(`/projects/${id}`);
    } catch (error) {
      pushLog(`не удалось запустить: ${String(error)}`);
      setBusy(null);
    }
  }, [brief, settings, pushLog, router]);

  const breed = useCallback(async () => {
    setBusy("breed");
    try {
      const res = await fetch("/api/fly", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "breed", generations: 2 }),
      }).then((r) => r.json());
      pushLog(`скрещивание мозгов: ${res.history?.map((h: { generation: number; fitness: number; improved: boolean }) => `G${h.generation}=${h.fitness}${h.improved ? "↑" : ""}`).join(", ")}`);
      await refresh();
    } catch (error) {
      pushLog(`ошибка скрещивания: ${String(error)}`);
    }
    setBusy(null);
  }, [pushLog, refresh]);

  const runScout = useCallback(async () => {
    if (scoutQuery.trim().length < 3) return;
    setBusy("scout");
    pushLog(`разведка: ${scoutQuery}`);
    try {
      const res = await fetch("/api/scout", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ query: scoutQuery, depth: settings.searchDepth, useProxy: settings.useProxy }),
      }).then((r) => r.json());
      if (res.error) {
        pushLog(`разведка отказала: ${res.error}`);
      } else {
        setScoutResult(res);
        pushLog(`найдено ${res.items?.length ?? 0} источников, моделей ${res.models?.length ?? 0} за ${res.ms} мс`);
      }
    } catch (error) {
      pushLog(`ошибка разведки: ${String(error)}`);
    }
    setBusy(null);
  }, [scoutQuery, settings.searchDepth, settings.useProxy, pushLog]);

  const forge = useCallback(async () => {
    if (forgeDescription.trim().length < 5) return;
    setBusy("forge");
    try {
      const res = await fetch("/api/forge", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ capability: forgeCapability, description: forgeDescription }),
      }).then((r) => r.json());
      if (res.error) pushLog(`кузница: ${res.error}`);
      else {
        setForgeResult(res.module ? { ...res, rationale: res.module.rationale, name: res.module.name } : res);
        pushLog(`выкован модуль ${res.module?.name ?? ""} (${res.module?.bytes ?? 0} байт + тесты)`);
      }
    } catch (error) {
      pushLog(`ошибка кузницы: ${String(error)}`);
    }
    setBusy(null);
  }, [forgeCapability, forgeDescription, pushLog]);

  const proxyAction = useCallback(
    async (action: string) => {
      setBusy("proxy");
      try {
        const res = await fetch("/api/proxies", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(action === "add" ? { action, urls: proxyInput } : { action }),
        }).then((r) => r.json());
        if (res.error) pushLog(`прокси: ${res.error}`);
        else pushLog(action === "add" ? `добавлено прокси: ${res.added}` : `проверено прокси: ${res.checked}`);
        setProxies(res.proxies ?? proxies);
        setProxyInput("");
      } catch (error) {
        pushLog(`ошибка прокси: ${String(error)}`);
      }
      setBusy(null);
    },
    [proxyInput, proxies, pushLog],
  );

  const downloadZip = useCallback(async (id: number) => {
    setZipBusy(id);
    try {
      const res = await fetch(`/api/projects/${id}/bundle`, { cache: "no-store" });
      const type = res.headers.get("content-type") ?? "";
      if (!res.ok || !type.includes("zip")) {
        pushLog(`zip #${id}: ${(await res.text()).slice(0, 160)}`);
        return;
      }
      const blob = await res.blob();
      const cd = res.headers.get("content-disposition") ?? "";
      const match = cd.match(/filename="([^"]+)"/);
      const name = match?.[1] ?? `super-roy-${id}.zip`;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      pushLog(`zip #${id} скачан (${Math.round(blob.size / 1024)} КБ)`);
    } catch (error) {
      pushLog(`zip #${id}: ${String(error)}`);
    } finally {
      setZipBusy(null);
    }
  }, [pushLog]);

  const pingAll = useCallback(async () => {
    setBusy("probe");
    pushLog("проверяю живые модели…");
    try {
      const res = await fetch("/api/providers", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" }).then((r) => r.json());
      setProviders(res.providers ?? []);
      pushLog(`готовы: ${(res.ready ?? []).join(", ") || "только встроенный движок"}`);
    } catch (error) {
      pushLog(`ошибка проверки моделей: ${String(error)}`);
    }
    setBusy(null);
  }, [pushLog]);

  const pingOne = useCallback(async (key: string) => {
    setBusy(`ping:${key}`);
    try {
      const res = await fetch("/api/providers", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "ping", key }),
      }).then((r) => r.json());
      pushLog(`${key}: ${res.status} · ${res.sample}`);
      await refresh();
    } catch (error) {
      pushLog(`${key}: ${String(error)}`);
    }
    setBusy(null);
  }, [pushLog, refresh]);

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_360px]">
      <div className="space-y-4">
        <nav className="flex flex-wrap gap-2">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`rounded-lg border px-3 py-1.5 text-[11px] tracking-wide uppercase transition ${
                tab === t.key
                  ? "border-sky-500/60 bg-sky-500/10 text-sky-300"
                  : "border-[#1b2531] bg-[#0b1017] text-[#7d93ab] hover:border-[#2f4159] hover:text-[#a9c3da]"
              }`}
            >
              {t.label}
            </button>
          ))}
        </nav>

        {tab === "brief" && (
          <Panel title="Опишите программу — рой спроектирует и соберёт её">
            <textarea
              value={brief}
              onChange={(e) => setBrief(e.target.value)}
              rows={7}
              placeholder="Например: нужно приложение, которое по запросу ищет репозитории на PirateFace и GitHub, скачивает подходящую GGUF модель и запускает локального агента, который парсит цены конкурентов через пул прокси и складывает их в базу с дашбордом…"
              className="w-full resize-y rounded-lg border border-[#1b2531] bg-[#070b11] p-3 text-[13px] text-[#dbe4ee] outline-none focus:border-sky-500/60"
            />
            <div className="mt-3 flex flex-wrap gap-2">
              {EXAMPLES.map((ex, i) => (
                <button
                  key={i}
                  onClick={() => setBrief(ex)}
                  className="rounded-md border border-[#1b2531] bg-[#0a0f16] px-2 py-1 text-[11px] text-[#7d93ab] hover:border-sky-500/40 hover:text-sky-300"
                >
                  пример {i + 1}
                </button>
              ))}
            </div>

            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <label className="flex items-center justify-between gap-2 rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2 text-[12px] text-[#a9c3da]">
                Глубина разведки
                <select
                  value={settings.searchDepth}
                  onChange={(e) => setSettings((s) => ({ ...s, searchDepth: Number(e.target.value) }))}
                  className="rounded border border-[#26344a] bg-[#070b11] px-2 py-1 text-[12px]"
                >
                  <option value={1}>1 — быстро</option>
                  <option value={2}>2 — стандарт</option>
                  <option value={3}>3 — глубоко</option>
                </select>
              </label>
              <label className="flex items-center justify-between gap-2 rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2 text-[12px] text-[#a9c3da]">
                Внедрять репозиториев
                <input
                  type="number"
                  min={0}
                  max={8}
                  value={settings.maxAdopt}
                  onChange={(e) => setSettings((s) => ({ ...s, maxAdopt: Number(e.target.value) }))}
                  className="w-16 rounded border border-[#26344a] bg-[#070b11] px-2 py-1 text-right"
                />
              </label>
              {(
                [
                  ["flyBoost", "мозг мухи: переранжирование и память"],
                  ["allowForge", "кузница: создавать несуществующие модули"],
                  ["useProxy", "ходить в интернет через пул прокси"],
                  ["localLlm", "локальные LLM (Ollama / llama.cpp)"],
                  ["cloudLlm", "облачные LLM (Pollinations без ключа + Groq/OpenRouter при наличии ключа)"],
                ] as const
              ).map(([key, label]) => (
                <label key={key} className="flex items-center gap-2 rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2 text-[12px] text-[#a9c3da]">
                  <input
                    type="checkbox"
                    checked={settings[key]}
                    onChange={(e) => setSettings((s) => ({ ...s, [key]: e.target.checked }))}
                    className="h-4 w-4 accent-lime-400"
                  />
                  {label}
                </label>
              ))}
            </div>

            <button
              onClick={() => void launch()}
              disabled={busy === "swarm"}
              className="mt-4 w-full rounded-lg border border-lime-500/50 bg-lime-500/10 px-4 py-3 text-sm font-semibold tracking-wide text-lime-300 uppercase transition hover:bg-lime-500/20 disabled:opacity-50"
            >
              {busy === "swarm" ? "рой поднимается…" : "Запустить рой"}
            </button>
          </Panel>
        )}

        {tab === "scout" && (
          <Panel title="Разведка: PirateFace.co · GitHub · npm · Hacker News · StackOverflow" subtitle="Ищем готовые репозитории, библиотеки и веса моделей, которые можно внедрить.">
            <div className="flex flex-wrap gap-2">
              <input
                value={scoutQuery}
                onChange={(e) => setScoutQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") void runScout();
                }}
                placeholder="что искать? например: qwen coder gguf, proxy pool, ratelimit"
                className="min-w-[240px] flex-1 rounded-lg border border-[#1b2531] bg-[#070b11] px-3 py-2 text-[13px] outline-none focus:border-sky-500/60"
              />
              <button
                onClick={() => void runScout()}
                disabled={busy === "scout"}
                className="rounded-lg border border-sky-500/50 bg-sky-500/10 px-4 py-2 text-[12px] tracking-wide text-sky-300 uppercase hover:bg-sky-500/20 disabled:opacity-50"
              >
                {busy === "scout" ? "ищу…" : "Искать"}
              </button>
              <button
                onClick={() => {
                  setScoutQuery("coder gguf");
                  void runScout();
                }}
                className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2 text-[11px] text-[#7d93ab] hover:text-[#a9c3da]"
              >
                pirateface: coder
              </button>
            </div>

            {scoutResult && (
              <div className="mt-4 space-y-3">
                <div className="flex flex-wrap gap-2 text-[11px] text-[#5f738a]">
                  {scoutResult.queries.map((q) => (
                    <span key={q} className="rounded border border-[#1b2531] bg-[#0a0f16] px-2 py-0.5">
                      {q}
                    </span>
                  ))}
                  {scoutResult.failures.map((f) => (
                    <Badge key={f} tone="amber">
                      {f} недоступен
                    </Badge>
                  ))}
                </div>

                {scoutResult.models.length > 0 && (
                  <div className="rounded-lg border border-[#1b2531] bg-[#070b11] p-3">
                    <div className="mb-2 text-[11px] tracking-wider text-lime-300 uppercase">Веса моделей с PirateFace.co</div>
                    <ul className="space-y-2 text-[12px]">
                      {scoutResult.models.slice(0, 6).map((m) => (
                        <li key={m.name} className="border-b border-[#141d27] pb-2 last:border-0">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span className="text-[#dbe4ee]">{m.name}</span>
                            <span className="text-[#5f738a]">
                              {m.sizeGB} GB · {m.seeds} сидов
                            </span>
                          </div>
                          <code className="mt-1 block overflow-x-auto rounded bg-[#0a0f16] p-1 text-[10px] text-[#7d93ab]">
                            aria2c --seed-ratio=1.0 &quot;{m.magnet.slice(0, 90)}…&quot;
                          </code>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="overflow-hidden rounded-lg border border-[#1b2531]">
                  <table className="w-full text-left text-[12px]">
                    <thead className="bg-[#0a0f16] text-[10px] tracking-wider text-[#5f738a] uppercase">
                      <tr>
                        <th className="px-3 py-2">источник</th>
                        <th className="px-3 py-2">найденное</th>
                        <th className="px-3 py-2">метрика</th>
                        <th className="px-3 py-2">score / муха</th>
                      </tr>
                    </thead>
                    <tbody>
                      {scoutResult.items.slice(0, 25).map((item) => (
                        <tr key={item.url} className="border-t border-[#141d27] align-top">
                          <td className="px-3 py-2">
                            <Badge tone={item.provider === "github" ? "cyan" : item.provider === "pirateface" ? "lime" : "slate"}>{item.provider}</Badge>
                          </td>
                          <td className="px-3 py-2">
                            <a href={item.url} target="_blank" rel="noreferrer" className="text-sky-300 hover:underline">
                              {item.title}
                            </a>
                            <div className="text-[11px] text-[#5f738a]">{item.subtitle.slice(0, 140)}</div>
                          </td>
                          <td className="px-3 py-2 text-[#a9c3da]">
                            {item.metric} {item.metricLabel}
                          </td>
                          <td className="px-3 py-2 text-[#a9c3da]">
                            {item.score} / {item.flyScore}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </Panel>
        )}

        {tab === "fly" && (
          <Panel title="Мозг мухи: LSH по обонятельной системе + генетика" subtitle="Ускорение поиска и памяти роя без векторных БД и без обучения.">
            {fly && (
              <>
                <div className="grid gap-3 sm:grid-cols-4">
                  <div className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
                    <div className="text-[10px] text-[#5f738a] uppercase">Поколение</div>
                    <div className="text-lg font-semibold text-lime-300">G{fly.active.generation}</div>
                  </div>
                  <div className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
                    <div className="text-[10px] text-[#5f738a] uppercase">Fitness</div>
                    <div className="text-lg font-semibold text-sky-300">{fly.active.fitness.toFixed(4)}</div>
                  </div>
                  <div className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
                    <div className="text-[10px] text-[#5f738a] uppercase">Нейронов</div>
                    <div className="text-lg font-semibold text-[#dbe4ee]">{fly.active.outputDim}</div>
                  </div>
                  <div className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
                    <div className="text-[10px] text-[#5f738a] uppercase">Память роя</div>
                    <div className="text-lg font-semibold text-[#dbe4ee]">{fly.memories}</div>
                  </div>
                </div>

                <p className="mt-3 text-[12px] leading-relaxed text-[#7d93ab]">
                  {fly.algorithm.idea}
                  <br />
                  <span className="text-[#5f738a]">{fly.algorithm.paper}</span>
                  <br />
                  <span className="text-[#a9c3da]">Генетика:</span> {fly.algorithm.genetics}
                </p>

                <div className="mt-4 flex flex-wrap gap-2">
                  <input
                    value={flyDemoQuery}
                    onChange={(e) => setFlyDemoQuery(e.target.value)}
                    className="min-w-[220px] flex-1 rounded-lg border border-[#1b2531] bg-[#070b11] px-3 py-2 text-[12px] outline-none focus:border-sky-500/60"
                  />
                  <button
                    onClick={() => void refresh()}
                    className="rounded-lg border border-[#26344a] bg-[#111a26] px-3 py-2 text-[11px] text-[#a9c3da] uppercase hover:text-sky-300"
                  >
                    проверить близость
                  </button>
                  <button
                    onClick={() => void breed()}
                    disabled={busy === "breed"}
                    className="rounded-lg border border-lime-500/50 bg-lime-500/10 px-3 py-2 text-[11px] tracking-wide text-lime-300 uppercase hover:bg-lime-500/20 disabled:opacity-50"
                  >
                    {busy === "breed" ? "скрещиваю…" : "скрестить мозги (2 поколения)"}
                  </button>
                </div>

                {fly.demo && (
                  <div className="mt-3 rounded-lg border border-[#1b2531] bg-[#070b11] p-3 text-[12px]">
                    <div className="mb-2 text-[10px] tracking-wider text-[#5f738a] uppercase">
                      ближайшие по тегу мухи ({fly.demo.tagSize} активных нейронов)
                    </div>
                    {fly.demo.top.map((t) => (
                      <div key={t.text} className="flex items-center gap-2 border-b border-[#141d27] py-1 last:border-0">
                        <div className="h-1.5 w-24 overflow-hidden rounded bg-[#141d27]">
                          <div className="h-full rounded bg-sky-400" style={{ width: `${Math.round(t.score * 100)}%` }} />
                        </div>
                        <span className="text-[#a9c3da]">{t.score.toFixed(3)}</span>
                        <span className="text-[#7d93ab]">{t.text}</span>
                      </div>
                    ))}
                  </div>
                )}

                <div className="mt-3 overflow-hidden rounded-lg border border-[#1b2531]">
                  <table className="w-full text-left text-[12px]">
                    <thead className="bg-[#0a0f16] text-[10px] tracking-wider text-[#5f738a] uppercase">
                      <tr>
                        <th className="px-3 py-2">мозг</th>
                        <th className="px-3 py-2">поколение</th>
                        <th className="px-3 py-2">fitness</th>
                        <th className="px-3 py-2">статус</th>
                      </tr>
                    </thead>
                    <tbody>
                      {fly.population.map((b) => (
                        <tr key={b.id} className="border-t border-[#141d27]">
                          <td className="px-3 py-2 text-[#dbe4ee]">{b.name}</td>
                          <td className="px-3 py-2">G{b.generation}</td>
                          <td className="px-3 py-2 text-sky-300">{b.fitness.toFixed(4)}</td>
                          <td className="px-3 py-2">
                            <Badge tone={b.active ? "lime" : "slate"}>{b.active ? "активен" : "в популяции"}</Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </Panel>
        )}

        {tab === "forge" && (
          <Panel title="Кузница: создаём модули, которых не существует" subtitle="Каждый модуль — рабочий код с тестами под node:test, без внешних зависимостей.">
            <div className="flex flex-wrap gap-2">
              <select
                value={forgeCapability}
                onChange={(e) => setForgeCapability(e.target.value)}
                className="rounded-lg border border-[#1b2531] bg-[#070b11] px-3 py-2 text-[12px]"
              >
                <option value="custom-module">с нуля (generic composer)</option>
                {catalog.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              <input
                value={forgeDescription}
                onChange={(e) => setForgeDescription(e.target.value)}
                placeholder="что должен уметь модуль?"
                className="min-w-[220px] flex-1 rounded-lg border border-[#1b2531] bg-[#070b11] px-3 py-2 text-[12px] outline-none focus:border-sky-500/60"
              />
              <button
                onClick={() => void forge()}
                disabled={busy === "forge"}
                className="rounded-lg border border-amber-500/50 bg-amber-500/10 px-4 py-2 text-[11px] tracking-wide text-amber-300 uppercase hover:bg-amber-500/20 disabled:opacity-50"
              >
                {busy === "forge" ? "кую…" : "Выковать"}
              </button>
            </div>
            {forgeResult && (
              <div className="mt-3 space-y-3">
                <p className="text-[12px] text-[#a9c3da]">{forgeResult.rationale}</p>
                <pre className="max-h-72 overflow-auto rounded-lg border border-[#1b2531] bg-[#070b11] p-3 text-[11px] text-[#c9d7e5]">
                  <code>{forgeResult.code}</code>
                </pre>
                <pre className="max-h-52 overflow-auto rounded-lg border border-[#1b2531] bg-[#070b11] p-3 text-[11px] text-[#9fc7a8]">
                  <code>{forgeResult.test}</code>
                </pre>
              </div>
            )}
          </Panel>
        )}

        {tab === "net" && (
          <Panel title="Допуск в интернет: прямое соединение + пул прокси" subtitle="Рой ходит в сеть напрямую, а при сбоях и банах переключается на прокси из пула.">
            <div className="flex flex-wrap gap-2">
              <input
                value={proxyInput}
                onChange={(e) => setProxyInput(e.target.value)}
                placeholder="http://user:pass@host:port, socks5://host:1080"
                className="min-w-[240px] flex-1 rounded-lg border border-[#1b2531] bg-[#070b11] px-3 py-2 text-[12px] outline-none focus:border-sky-500/60"
              />
              <button
                onClick={() => void proxyAction("add")}
                className="rounded-lg border border-[#26344a] bg-[#111a26] px-3 py-2 text-[11px] tracking-wide text-[#a9c3da] uppercase hover:text-sky-300"
              >
                добавить
              </button>
              <button
                onClick={() => void proxyAction("check")}
                className="rounded-lg border border-sky-500/50 bg-sky-500/10 px-3 py-2 text-[11px] tracking-wide text-sky-300 uppercase hover:bg-sky-500/20"
              >
                проверить живость
              </button>
            </div>
            <div className="mt-3 space-y-2">
              {proxies.length === 0 && <p className="text-[12px] text-[#5f738a]">Пул пуст. Можно также задать PROXY_LIST в окружении — рой подхватит автоматически.</p>}
              {proxies.map((p) => (
                <div key={p.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2 text-[12px]">
                  <code className="text-[#a9c3da]">{p.url}</code>
                  <div className="flex items-center gap-2">
                    <Badge tone={statusTone(p.status)}>{p.status}</Badge>
                    <span className="text-[#5f738a]">{p.latencyMs ? `${p.latencyMs} мс` : "—"} · ок {p.okCount} / ошибок {p.failCount}</span>
                  </div>
                </div>
              ))}
            </div>
          </Panel>
        )}
      </div>

      <aside className="space-y-4">
        <Panel
          title="Провайдеры мышления"
          subtitle="Без ключа работает Pollinations. Остальные каналы подключаются, если ключ есть в окружении — мёртвые не блокируют рой."
          right={
            <button
              type="button"
              onClick={() => void pingAll()}
              disabled={busy === "probe"}
              className="rounded border border-[#26344a] px-2 py-1 text-[10px] uppercase text-[#a9c3da] hover:text-lime-300 disabled:opacity-40"
            >
              {busy === "probe" ? "…" : "проверить"}
            </button>
          }
        >
          <div className="space-y-2">
            {providers.map((p) => (
              <div key={p.key} className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[12px] text-[#dbe4ee]">{p.label}</span>
                  <div className="flex items-center gap-1">
                    <Badge tone={statusTone(p.status)}>{p.status}</Badge>
                    {p.kind === "chat" && p.key !== "builtin" && (
                      <button
                        type="button"
                        onClick={() => void pingOne(p.key)}
                        disabled={busy === `ping:${p.key}` || (Boolean(p.envKey) && !p.hasKey)}
                        className="rounded border border-[#26344a] px-1.5 py-0.5 text-[9px] uppercase text-[#7d93ab] hover:text-sky-300 disabled:opacity-30"
                      >
                        ping
                      </button>
                    )}
                  </div>
                </div>
                <p className="mt-1 text-[11px] leading-relaxed text-[#5f738a]">{p.detail}</p>
                {p.envKey ? (
                  <p className="mt-1 text-[10px] text-[#4d5f74]">
                    ключ {p.envKey}: {p.hasKey ? "есть" : "нет — канал пропускается"}
                  </p>
                ) : (
                  <p className="mt-1 text-[10px] text-[#4d5f74]">{p.keyless ? "без ключа" : ""}{p.latencyMs ? ` · ${p.latencyMs} мс` : ""}</p>
                )}
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Последние проекты">
          <div className="space-y-2">
            {projects.length === 0 && <p className="text-[12px] text-[#5f738a]">Пока пусто — запустите рой по первому брифу.</p>}
            {projects.slice(0, 8).map((p) => (
              <div key={p.id} className="rounded-lg border border-[#1b2531] bg-[#0a0f16] px-3 py-2">
                <a href={`/projects/${p.id}`} className="block hover:text-sky-300">
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate text-[12px] text-[#dbe4ee]">#{p.id} {p.name}</span>
                    <Badge tone={statusTone(p.status)}>{p.status}</Badge>
                  </div>
                </a>
                <div className="mt-1 h-1 w-full overflow-hidden rounded bg-[#141d27]">
                  <div className="h-full rounded bg-lime-400 transition-all" style={{ width: `${p.progress}%` }} />
                </div>
                <div className="mt-1 flex items-center justify-between gap-2">
                  {p.stats ? (
                    <div className="text-[10px] text-[#5f738a]">
                      файлов {p.stats.files} · QA {p.stats.qaScore}/100
                    </div>
                  ) : <span />}
                  <button
                    type="button"
                    onClick={() => void downloadZip(p.id)}
                    disabled={zipBusy === p.id || p.status !== "done"}
                    className="rounded border border-lime-500/40 px-2 py-0.5 text-[10px] uppercase text-lime-300 hover:bg-lime-500/10 disabled:opacity-30"
                  >
                    {zipBusy === p.id ? "zip…" : "zip"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Журнал роя">
          <div className="max-h-64 space-y-1 overflow-auto text-[11px] text-[#7d93ab]">
            {log.length === 0 && <p className="text-[#4d5f74]">События появятся здесь.</p>}
            {log.map((line, i) => (
              <div key={i} className="border-b border-[#121a24] py-1 last:border-0">
                {line}
              </div>
            ))}
          </div>
        </Panel>
      </aside>
    </div>
  );
}
