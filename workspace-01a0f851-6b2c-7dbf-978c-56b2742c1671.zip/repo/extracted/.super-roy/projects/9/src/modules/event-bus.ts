export type Handler<T> = (payload: T) => void | Promise<void>;

export class AsyncEventBus<E extends Record<string, unknown>> {
  private handlers = new Map<keyof E, Set<Handler<never>>>();
  private history: { event: keyof E; payload: unknown; at: number }[] = [];

  on<K extends keyof E>(event: K, handler: Handler<E[K]>): () => void {
    const set = this.handlers.get(event) ?? new Set();
    set.add(handler as Handler<never>);
    this.handlers.set(event, set);
    return () => this.off(event, handler);
  }

  once<K extends keyof E>(event: K, handler: Handler<E[K]>): () => void {
    const off = this.on(event, async (payload) => {
      off();
      await handler(payload);
    });
    return off;
  }

  off<K extends keyof E>(event: K, handler: Handler<E[K]>): void {
    this.handlers.get(event)?.delete(handler as Handler<never>);
  }

  async emit<K extends keyof E>(event: K, payload: E[K]): Promise<void> {
    this.history.push({ event, payload, at: Date.now() });
    if (this.history.length > 5000) this.history.splice(0, this.history.length - 5000);
    const set = this.handlers.get(event);
    if (!set) return;
    await Promise.all([...set].map(async (handler) => {
      try {
        await (handler as Handler<E[K]>)(payload);
      } catch (error) {
        console.error('[bus] handler failed', event, error);
      }
    }));
  }

  tail<K extends keyof E>(event: K, limit = 50): { payload: E[K]; at: number }[] {
    return this.history.filter((h) => h.event === event).slice(-limit) as { payload: E[K]; at: number }[];
  }
}