import SvarmaApp from "@/components/svarma/SvarmaApp";

export const dynamic = "force-dynamic";

export default function Home() {
  return <SvarmaApp />;
}
