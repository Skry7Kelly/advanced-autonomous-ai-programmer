"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Icon, type IconName } from "./icons";

export type Command = {
  id: string;
  title: string;
  hint?: string;
  icon: IconName;
  color?: string;
  run: () => void;
  disabled?: boolean;
};

export default function CommandPalette({
  open,
  onClose,
  commands,
}: {
  open: boolean;
  onClose: () => void;
  commands: Command[];
}) {
  const [query, setQuery] = useState("");
  const [index, setIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQuery("");
      setIndex(0);
      setTimeout(() => inputRef.current?.focus(), 10);
    }
  }, [open]);

  const filtered = useMemo(() => {
    if (!query.trim()) return commands.slice(0, 14);
    const q = query.toLowerCase();
    const scored = commands
      .map((c) => {
        const t = c.title.toLowerCase();
        let score = 0;
        if (t.includes(q)) score += 10 - Math.min(9, t.indexOf(q) / 10);
        if (t.startsWith(q)) score += 5;
        // нечёткое совпадение символов
        let qi = 0;
        for (const ch of t) {
          if (qi < q.length && ch === q[qi]) qi += 1;
        }
        if (qi === q.length) score += 3;
        return { c, score };
      })
      .filter((x) => x.score > 2)
      .sort((a, b) => b.score - a.score);
    return scored.slice(0, 14).map((x) => x.c);
  }, [commands, query]);

  useEffect(() => {
    setIndex(0);
  }, [query]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-start justify-center pt-[14vh]" onMouseDown={onClose}>
      <div className="absolute inset-0 bg-ink-950/70 backdrop-blur-sm" />
      <div
        className="relative w-[560px] max-w-[92vw] animate-pop overflow-hidden rounded-2xl border border-ink-650 bg-ink-850 shadow-2xl"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 border-b border-ink-700 px-4">
          <Icon name="search" size={16} className="text-ink-400" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "ArrowDown") {
                e.preventDefault();
                setIndex((i) => Math.min(i + 1, filtered.length - 1));
              } else if (e.key === "ArrowUp") {
                e.preventDefault();
                setIndex((i) => Math.max(i - 1, 0));
              } else if (e.key === "Enter") {
                e.preventDefault();
                const cmd = filtered[index];
                if (cmd && !cmd.disabled) {
                  cmd.run();
                  onClose();
                }
              } else if (e.key === "Escape") {
                onClose();
              }
            }}
            placeholder="Команда или файл…"
            className="w-full bg-transparent py-3.5 text-[14px] text-ink-50 outline-none placeholder:text-ink-500"
          />
          <kbd className="shrink-0 rounded border border-ink-650 bg-ink-800 px-1.5 py-0.5 font-mono text-[10px] text-ink-400">esc</kbd>
        </div>

        <div className="max-h-80 overflow-y-auto p-1.5">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-[12.5px] text-ink-500">Ничего не найдено</div>
          ) : (
            filtered.map((cmd, i) => (
              <button
                key={cmd.id}
                onMouseEnter={() => setIndex(i)}
                onClick={() => {
                  if (!cmd.disabled) {
                    cmd.run();
                    onClose();
                  }
                }}
                className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors ${
                  i === index ? "bg-ink-750" : "hover:bg-ink-800"
                } ${cmd.disabled ? "opacity-40" : ""}`}
              >
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-ink-650 bg-ink-900" style={{ color: cmd.color ?? "#8b95ad" }}>
                  <Icon name={cmd.icon} size={13} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className={`block truncate ${cmd.title.includes("/") ? "font-mono text-[12px]" : "text-[13px]"} text-ink-100`}>{cmd.title}</span>
                  {cmd.hint ? <span className="block text-[10.5px] text-ink-500">{cmd.hint}</span> : null}
                </span>
                {i === index ? <Icon name="chevronRight" size={13} className="shrink-0 text-ink-500" /> : null}
              </button>
            ))
          )}
        </div>

        <div className="flex items-center gap-3 border-t border-ink-700 px-4 py-2 text-[10.5px] text-ink-500">
          <span>↑↓ выбрать</span>
          <span>⏎ выполнить</span>
          <span className="ml-auto">Svarma · палитра команд</span>
        </div>
      </div>
    </div>
  );
}
