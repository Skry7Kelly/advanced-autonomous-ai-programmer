import { desc, eq } from "@/db/orm";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { getAuthUser, planOf, projectCountOf } from "@/lib/auth";
import { DEFAULT_SETTINGS } from "@/lib/pipeline";
import type { ProjectSettings } from "@/lib/types";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request) {
  const user = await getAuthUser(request);
  if (!user) return Response.json({ error: "Требуется вход", auth: true }, { status: 401 });
  const rows = await db
    .select()
    .from(projects)
    .where(eq(projects.userId, user.id))
    .orderBy(desc(projects.id))
    .limit(40);
  const light = rows.map(({ spec: _spec, briefParsed: _briefParsed, ...rest }) => rest);
  return Response.json({ projects: light });
}

export async function POST(request: Request) {
  const user = await getAuthUser(request);
  if (!user) return Response.json({ error: "Требуется вход", auth: true }, { status: 401 });

  /* квота тарифа */
  const plan = planOf(user);
  const count = await projectCountOf(user.id);
  if (count >= plan.projectLimit) {
    return Response.json(
      {
        error: `Лимит тарифа ${plan.name}: ${plan.projectLimit} проектов. Оформите Pro или Team, чтобы создавать больше.`,
        upgrade: true,
      },
      { status: 402 },
    );
  }

  let body: { brief?: string; settings?: Partial<ProjectSettings>; autostart?: boolean } = {};
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return Response.json({ error: "некорректный JSON" }, { status: 400 });
  }
  const brief = (body.brief ?? "").trim();
  if (brief.length < 12) {
    return Response.json({ error: "Опишите задачу подробнее (минимум 12 символов)" }, { status: 400 });
  }
  const settings: ProjectSettings = { ...DEFAULT_SETTINGS, ...(body.settings ?? {}) };
  const name = brief.split("\n")[0].slice(0, 70).replace(/^\p{Ll}/u, (c) => c.toUpperCase());
  const [row] = await db
    .insert(projects)
    .values({ userId: user.id, name, brief, settings, status: "queued", stage: "queued", progress: 0 })
    .returning();
  if (body.autostart !== false) {
    const { runPipeline } = await import("@/lib/pipeline");
    void runPipeline(row.id);
  }
  return Response.json({ project: { ...row, spec: null, briefParsed: null } }, { status: 201 });
}
