import { sql } from "drizzle-orm";
import { db } from "@/db";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  const started = Date.now();
  try {
    await db.execute(sql`select 1`);
    return Response.json({
      ok: true,
      db: "up",
      ms: Date.now() - started,
      swarm: "SUPER ROY ready",
      agents: ["ARCHITECT", "SCOUT", "FLY", "FORGE", "ENGINEER", "CRITIC", "INTEGRATOR"],
      time: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json(
      { ok: false, db: "down", error: error instanceof Error ? error.message : String(error) },
      { status: 500 },
    );
  }
}
