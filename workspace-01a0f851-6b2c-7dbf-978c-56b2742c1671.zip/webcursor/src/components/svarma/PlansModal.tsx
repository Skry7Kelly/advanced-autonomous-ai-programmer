"use client";

import { useEffect, useState } from "react";
import { Icon } from "./icons";
import { authApi } from "./api";
import type { PlanCard, PublicUser, UsageInfo } from "./types";

export default function PlansModal({
  open,
  onClose,
  user,
  usage,
  onSubscribed,
  onToast,
}: {
  open: boolean;
  onClose: () => void;
  user: PublicUser | null;
  usage: UsageInfo | null;
  onSubscribed: (user: PublicUser, usage: UsageInfo) => void;
  onToast: (kind: "ok" | "error" | "info", text: string) => void;
}) {
  const [plans, setPlans] = useState<PlanCard[]>([]);
  const [busyPlan, setBusyPlan] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    fetch("/api/billing/plans")
      .then((r) => r.json())
      .then((d: { plans: PlanCard[] }) => setPlans(d.plans))
      .catch(() => undefined);
  }, [open]);

  if (!open) return null;

  const subscribe = async (plan: string) => {
    if (busyPlan) return;
    setBusyPlan(plan);
    try {
      const result = await authApi.subscribe(plan);
      onSubscribed(result.user, result.usage);
      onToast("ok", `Тариф ${result.user.planName} активирован на 30 дней (демо-режим оплаты)`);
    } catch (e) {
      onToast("error", e instanceof Error ? e.message : String(e));
    } finally {
      setBusyPlan(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4" onMouseDown={onClose}>
      <div className="absolute inset-0 bg-ink-950/75 backdrop-blur-sm" />
      <div
        className="relative flex max-h-[88vh] w-[760px] max-w-full animate-pop flex-col overflow-hidden rounded-2xl border border-ink-650 bg-ink-850 shadow-2xl"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 border-b border-ink-700 px-5 py-4">
          <Icon name="sparkles" size={17} className="text-accent3" />
          <span className="text-[15px] font-semibold text-ink-50">Тарифы и подписка</span>
          {user ? (
            <span className="chip ml-2">
              сейчас: <b className={user.plan === "free" ? "text-ink-300" : "text-accent3"}>{user.planName}</b>
            </span>
          ) : null}
          <button onClick={onClose} className="ml-auto rounded-lg p-1.5 text-ink-400 transition-colors hover:bg-ink-800 hover:text-ink-100">
            <Icon name="close" size={15} />
          </button>
        </div>

        {usage ? (
          <div className="grid grid-cols-2 gap-3 border-b border-ink-700 px-5 py-3.5 sm:grid-cols-2">
            <div>
              <div className="mb-1 flex items-baseline justify-between text-[11px] text-ink-400">
                <span>Проекты</span>
                <span className="font-mono">
                  {usage.projects} / {usage.projectLimit >= 100000 ? "∞" : usage.projectLimit}
                </span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-ink-750">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-accent2 to-accent3"
                  style={{ width: `${Math.min(100, (usage.projects / Math.min(usage.projectLimit, 100)) * 100)}%` }}
                />
              </div>
            </div>
            <div>
              <div className="mb-1 flex items-baseline justify-between text-[11px] text-ink-400">
                <span>Запросы агенту сегодня</span>
                <span className="font-mono">
                  {usage.chatUsedToday} / {usage.chatLimit >= 5000 ? "∞" : usage.chatLimit}
                </span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-ink-750">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-accent to-accent2"
                  style={{ width: `${Math.min(100, (usage.chatUsedToday / Math.min(usage.chatLimit, 500)) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        ) : null}

        <div className="scroll-y flex-1 p-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {plans.map((plan) => {
              const isCurrent = (usage?.plan ?? user?.plan) === plan.id;
              return (
                <div
                  key={plan.id}
                  className={`relative flex flex-col rounded-2xl border p-4 transition-all ${
                    plan.highlight
                      ? "border-accent3/40 bg-gradient-to-b from-accent3/10 to-transparent shadow-[0_0_40px_-15px_rgba(167,139,250,0.5)]"
                      : "border-ink-750 bg-ink-900"
                  }`}
                >
                  {plan.highlight ? (
                    <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-accent2 to-accent3 px-2.5 py-0.5 text-[9.5px] font-bold uppercase tracking-wider text-ink-950">
                      популярный
                    </span>
                  ) : null}
                  <div className="text-[15px] font-bold text-ink-50">{plan.name}</div>
                  <div className="mt-1 text-2xl font-bold text-gradient">{plan.priceLabel}</div>
                  <ul className="mt-3 flex-1 space-y-1.5">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-start gap-1.5 text-[11.5px] leading-snug text-ink-300">
                        <Icon name="check" size={12} className="mt-0.5 shrink-0 text-ok" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  {plan.id === "free" ? (
                    <div className="mt-3.5 rounded-lg border border-ink-700 py-2 text-center text-[11.5px] text-ink-500">
                      {isCurrent ? "ваш текущий тариф" : "базовый тариф"}
                    </div>
                  ) : (
                    <button
                      className={`btn mt-3.5 w-full justify-center ${plan.highlight ? "btn-accent" : ""}`}
                      disabled={busyPlan !== null || isCurrent}
                      onClick={() => void subscribe(plan.id)}
                    >
                      {busyPlan === plan.id ? (
                        <span className="h-3.5 w-3.5 animate-spin-slow rounded-full border-2 border-accent2/30 border-t-accent2" />
                      ) : (
                        <Icon name="zap" size={13} />
                      )}
                      {isCurrent ? "Активен ✓" : `Оформить ${plan.name}`}
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          <p className="mt-4 rounded-xl border border-warn/25 bg-warn/5 px-3.5 py-2.5 text-[11px] leading-relaxed text-ink-400">
            <b className="text-warn">Демо-режим оплаты:</b> подписка активируется мгновенно и бесплатно — платёжный
            провайдер не подключён. Для боевых платежей добавьте Stripe/ЮKassa в <span className="font-mono">/api/billing/subscribe</span>.
          </p>
        </div>
      </div>
    </div>
  );
}
