# retry
`retryWithBackoff(fn, { retries, timeoutMs })` — экспоненциальный бэкофф с джиттером и уважением к Retry-After.

> Сеть и LLM шумные: нужны ретраи с джиттером, уважением к Retry-After и таймаутом на попытку.
