/**
 * Скиллы Svarma — агентные навыки в открытом формате vercel-labs/skills
 * (папка со SKILL.md: YAML-frontmatter name/description + инструкции;
 * опциональные файлы-помощники). Совместимы с навыками Claude Code,
 * vercel-labs/agent-skills, anthropics/skills и любыми репозиториями GitHub.
 *
 * Роутер моделей автоматически пропускает неподключённых провайдеров,
 * а агент автоматически подключает скиллы, релевантные запросу.
 */
import fs from "node:fs";
import path from "node:path";
import { loadSecrets, secretValue } from "@/lib/secrets";

export const SKILLS_DIR = path.join(process.cwd(), "skills");
const STATE_FILE = path.join(process.cwd(), ".data", "skills-state.json");

export type SkillSource = "builtin" | "github";

export type SkillMeta = {
  name: string;
  description: string;
  source: SkillSource;
  enabled: boolean;
  files: number;
  bytes: number;
};

type SkillState = { disabled: string[]; sources: Record<string, SkillSource> };

/* ------------------------------ состояние ------------------------------- */

function readState(): SkillState {
  try {
    const parsed = JSON.parse(fs.readFileSync(STATE_FILE, "utf8")) as Partial<SkillState>;
    return { disabled: parsed.disabled ?? [], sources: parsed.sources ?? {} };
  } catch {
    return { disabled: [], sources: {} };
  }
}

function writeState(state: SkillState): void {
  fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

/* ------------------------------ парсинг --------------------------------- */

export type ParsedSkill = { name: string; description: string; body: string };

export function parseSkillMd(md: string): ParsedSkill | null {
  const match = md.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!match) return null;
  const front = match[1];
  const body = match[2].trim();
  const name = front.match(/^name:\s*(.+)$/m)?.[1]?.trim().replace(/^["']|["']$/g, "");
  const description = front.match(/^description:\s*(.+)$/m)?.[1]?.trim().replace(/^["']|["']$/g, "");
  if (!name) return null;
  return { name, description: description ?? "", body };
}

function listSkillDirs(): string[] {
  if (!fs.existsSync(SKILLS_DIR)) return [];
  return fs
    .readdirSync(SKILLS_DIR, { withFileTypes: true })
    .filter((d) => d.isDirectory() && !d.name.startsWith("."))
    .map((d) => d.name)
    .sort();
}

function dirStats(dir: string): { files: number; bytes: number } {
  let files = 0;
  let bytes = 0;
  const walk = (d: string) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p);
      else {
        files += 1;
        bytes += fs.statSync(p).size;
      }
    }
  };
  try {
    walk(dir);
  } catch {
    /* каталог мог исчезнуть */
  }
  return { files, bytes };
}

/* ------------------------------ публичный API ---------------------------- */

export function listSkillsSync(): SkillMeta[] {
  const state = readState();
  const result: SkillMeta[] = [];
  for (const dir of listSkillDirs()) {
    const mdPath = path.join(SKILLS_DIR, dir, "SKILL.md");
    let parsed: ParsedSkill | null = null;
    try {
      parsed = parseSkillMd(fs.readFileSync(mdPath, "utf8"));
    } catch {
      continue;
    }
    if (!parsed) continue;
    const stats = dirStats(path.join(SKILLS_DIR, dir));
    result.push({
      name: parsed.name,
      description: parsed.description,
      source: state.sources[dir] ?? "builtin",
      enabled: !state.disabled.includes(dir),
      files: stats.files,
      bytes: stats.bytes,
    });
  }
  return result;
}

export async function listSkills(): Promise<SkillMeta[]> {
  return listSkillsSync();
}

function loadSkill(dir: string): ParsedSkill | null {
  try {
    return parseSkillMd(fs.readFileSync(path.join(SKILLS_DIR, dir, "SKILL.md"), "utf8"));
  } catch {
    return null;
  }
}

/**
 * Подбор скиллов под запрос пользователя: совпадение токенов запроса
 * с именем/описанием скилла. Возвращает контекст для системного промпта.
 */
export async function skillsContextFor(
  text: string,
): Promise<{ names: string[]; prompt: string } | null> {
  const state = readState();
  const tokens = [...new Set(text.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((w) => w.length >= 3))];
  if (!tokens.length) return null;

  const scored: { dir: string; skill: ParsedSkill; score: number }[] = [];
  for (const dir of listSkillDirs()) {
    if (state.disabled.includes(dir)) continue;
    const skill = loadSkill(dir);
    if (!skill) continue;
    const nameLc = skill.name.toLowerCase();
    const descLc = skill.description.toLowerCase();
    let score = 0;
    for (const t of tokens) {
      if (nameLc.includes(t)) score += 3;
      else if (descLc.includes(t)) score += 1;
    }
    if (score >= 2) scored.push({ dir, skill, score });
  }
  if (!scored.length) return null;

  const top = scored.sort((a, b) => b.score - a.score).slice(0, 3);
  const sections = top.map(({ skill }) => {
    const body = skill.body.length > 2000 ? `${skill.body.slice(0, 2000)}\n…(сокращено)` : skill.body;
    return `### Скилл: ${skill.name}\n${skill.description}\n\n${body}`;
  });
  return {
    names: top.map((t) => t.skill.name),
    prompt: `\n\n## Скиллы (agent skills, следуй их инструкциям при решении задачи)\n\n${sections.join("\n\n")}`,
  };
}

export async function setSkillEnabled(name: string, enabled: boolean): Promise<boolean> {
  const state = readState();
  const dirs = listSkillDirs();
  const dir = dirs.find((d) => loadSkill(d)?.name === name) ?? (dirs.includes(name) ? name : null);
  if (!dir) return false;
  state.disabled = enabled ? state.disabled.filter((d) => d !== dir) : [...new Set([...state.disabled, dir])];
  writeState(state);
  return true;
}

export async function deleteSkill(name: string): Promise<boolean> {
  const state = readState();
  const dirs = listSkillDirs();
  const dir = dirs.find((d) => loadSkill(d)?.name === name) ?? (dirs.includes(name) ? name : null);
  if (!dir) return false;
  fs.rmSync(path.join(SKILLS_DIR, dir), { recursive: true, force: true });
  state.disabled = state.disabled.filter((d) => d !== dir);
  delete state.sources[dir];
  writeState(state);
  return true;
}

/* --------------------------- установка с GitHub -------------------------- */

const ALLOWED_EXT = new Set([
  ".md", ".txt", ".py", ".js", ".mjs", ".ts", ".tsx", ".jsx", ".sh", ".json",
  ".yml", ".yaml", ".sql", ".html", ".css", ".toml", ".xml", ".csv", ".cfg", ".ini",
]);
const MAX_FILE_BYTES = 150_000;
const MAX_FILES_PER_SKILL = 16;
const MAX_SKILLS_PER_INSTALL = 24;

async function ghHeaders(): Promise<Record<string, string>> {
  await loadSecrets();
  const token = secretValue("GITHUB_TOKEN") ?? process.env.GITHUB_TOKEN;
  const headers: Record<string, string> = {
    accept: "application/vnd.github+json",
    "user-agent": "svarma-ide",
  };
  if (token) headers.authorization = `Bearer ${token}`;
  return headers;
}

/** source: owner/repo | URL (github.com, возможно с /tree/branch/subpath). */
export async function installSkillsFromGithub(
  source: string,
): Promise<{ installed: string[]; totalFound: number; message: string }> {
  let owner = "";
  let repo = "";
  let subpath = "";
  let branchHint = "";
  const trimmed = source.trim().replace(/\.git$/, "");
  const urlMatch = trimmed.match(/github\.com\/([^/]+)\/([^/]+)(?:\/tree\/([^/]+)(\/.*)?)?/);
  if (urlMatch) {
    owner = urlMatch[1];
    repo = urlMatch[2];
    branchHint = urlMatch[3] ?? "";
    subpath = (urlMatch[4] ?? "").replace(/^\/+/, "").replace(/\/+$/, "");
  } else {
    const short = trimmed.match(/^([\w.-]+)\/([\w.-]+)$/);
    if (!short) throw new Error("Формат: owner/repo или ссылка github.com/owner/repo[/tree/ветка/путь]");
    owner = short[1];
    repo = short[2];
  }

  const headers = await ghHeaders();
  const metaRes = await fetch(`https://api.github.com/repos/${owner}/${repo}`, {
    headers,
    signal: AbortSignal.timeout(20_000),
  });
  if (!metaRes.ok) {
    throw new Error(metaRes.status === 404 ? `Репозиторий ${owner}/${repo} не найден` : `GitHub API ${metaRes.status}`);
  }
  const meta = (await metaRes.json()) as { default_branch?: string };
  const branch = branchHint || meta.default_branch || "main";

  const treeRes = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/git/trees/${encodeURIComponent(branch)}?recursive=1`,
    { headers, signal: AbortSignal.timeout(30_000) },
  );
  if (!treeRes.ok) throw new Error(`Не удалось прочитать дерево репозитория (${treeRes.status})`);
  const tree = (await treeRes.json()) as { tree?: { path: string; type: string; size?: number }[] };
  const entries = (tree.tree ?? []).filter((e) => e.type === "blob");

  const prefix = subpath ? `${subpath}/` : "";
  const skillDirs = new Map<string, { path: string; size: number }[]>();
  for (const e of entries) {
    if (!e.path.startsWith(prefix)) continue;
    const rel = e.path.slice(prefix.length);
    if (rel.startsWith(".") || rel.includes("/.")) continue;
    const m = rel.match(/^(.+\/)?SKILL\.md$/i);
    if (!m) continue;
    const dir = m[1] ? m[1].replace(/\/$/, "") : "";
    if (!dir && !prefix) continue; // SKILL.md в корне без подпапки — пропускаем
    if (!skillDirs.has(dir)) skillDirs.set(dir, []);
  }

  const found = [...skillDirs.keys()];
  if (!found.length) {
    throw new Error(`В ${owner}/${repo} не найдено ни одного SKILL.md${subpath ? ` в ${subpath}` : ""}`);
  }

  const installed: string[] = [];
  const skipped: string[] = [];
  for (const dir of found.slice(0, MAX_SKILLS_PER_INSTALL)) {
    const files = entries.filter((e) => {
      const rel = e.path.slice(prefix.length);
      return rel.startsWith(`${dir}/`) && rel.slice(dir.length + 1).indexOf("/") === -1;
    });
    const skillMd = files.find((f) => f.path.endsWith("SKILL.md"));
    if (!skillMd) continue;

    const rawBase = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${prefix}${dir}`;
    const mdRes = await fetch(`${rawBase}/SKILL.md`, { signal: AbortSignal.timeout(20_000) });
    if (!mdRes.ok) continue;
    const parsed = parseSkillMd(await mdRes.text());
    if (!parsed) continue;

    const safeName = parsed.name
      .toLowerCase()
      .replace(/[^a-z0-9а-яё-]+/gi, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 64) || `skill-${Date.now()}`;
    const targetDir = path.join(SKILLS_DIR, safeName);
    if (fs.existsSync(path.join(targetDir, "SKILL.md"))) {
      skipped.push(parsed.name); // уже установлен — пропускаем
      continue;
    }
    fs.mkdirSync(targetDir, { recursive: true });
    fs.writeFileSync(path.join(targetDir, "SKILL.md"), `---\nname: ${parsed.name}\ndescription: ${parsed.description}\n---\n\n${parsed.body}\n`);

    let copied = 0;
    for (const f of files) {
      if (copied >= MAX_FILES_PER_SKILL) break;
      if (f === skillMd) continue;
      const ext = path.extname(f.path).toLowerCase();
      if (!ALLOWED_EXT.has(ext)) continue;
      if ((f.size ?? 0) > MAX_FILE_BYTES) continue;
      const res = await fetch(
        `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${f.path}`,
        { signal: AbortSignal.timeout(20_000) },
      );
      if (!res.ok) continue;
      const content = await res.text();
      if (content.length > MAX_FILE_BYTES) continue;
      fs.writeFileSync(path.join(targetDir, path.basename(f.path)), content);
      copied += 1;
    }

    const state = readState();
    state.sources[safeName] = "github";
    state.disabled = state.disabled.filter((d) => d !== safeName);
    writeState(state);
    installed.push(parsed.name);
  }

  if (!installed.length) {
    if (skipped.length) {
      return { installed: [], totalFound: found.length, message: `Все скиллы из ${owner}/${repo} уже установлены (${skipped.length})` };
    }
    throw new Error("Скиллы найдены, но ни один не установился (битые SKILL.md)");
  }
  return {
    installed,
    totalFound: found.length,
    message: `Из ${owner}/${repo}: новых ${installed.length}${skipped.length ? `, уже установленных ${skipped.length}` : ""}${found.length > installed.length + skipped.length ? ` (найдено ${found.length}, за раз — ${MAX_SKILLS_PER_INSTALL}, повторите для остальных)` : ""}`,
  };
}
