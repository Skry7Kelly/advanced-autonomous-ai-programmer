import { listProviders, pingProvider, probeProviders } from "@/lib/providers";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const probe = url.searchParams.get("probe") === "1";
  const rows = probe ? await probeProviders(url.searchParams.get("proxy") === "1") : await listProviders();
  const usable = rows.filter((r) => r.status === "ready" && r.kind !== "model-index");
  return Response.json({
    providers: rows,
    ready: usable.map((r) => r.key),
    llmAvailable: usable.some((r) => r.key !== "builtin"),
    keylessReady: usable.filter((r) => r.keyless && r.key !== "builtin").map((r) => r.key),
  });
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as {
    action?: string;
    key?: string;
    proxy?: boolean;
  };
  if (body.action === "ping" && body.key) {
    const result = await pingProvider(body.key);
    return Response.json(result);
  }
  const rows = await probeProviders(Boolean(body.proxy));
  return Response.json({
    providers: rows,
    ready: rows.filter((r) => r.status === "ready").map((r) => r.key),
  });
}
