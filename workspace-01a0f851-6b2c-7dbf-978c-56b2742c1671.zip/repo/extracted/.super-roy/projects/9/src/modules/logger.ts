export type Level = 'debug' | 'info' | 'warn' | 'error';

const ORDER: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };

const SECRET_RE = /(api[_-]?key|token|secret|password|authorization|cookie|magnet\?xt)/i;

function redact(value: unknown, depth = 0): unknown {
  if (depth > 4) return '[depth]';
  if (typeof value === 'string') return SECRET_RE.test(value) ? '[redacted]' : value;
  if (Array.isArray(value)) return value.map((v) => redact(v, depth + 1));
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = SECRET_RE.test(k) ? '[redacted]' : redact(v, depth + 1);
    }
    return out;
  }
  return value;
}

export interface Logger { debug: (msg: string, data?: unknown) => void; info: (msg: string, data?: unknown) => void; warn: (msg: string, data?: unknown) => void; error: (msg: string, data?: unknown) => void; child: (ctx: Record<string, unknown>) => Logger }

export function createLogger(minLevel: Level = 'info', context: Record<string, unknown> = {}, sink: (line: string) => void = (l) => console.log(l)): Logger {
  const write = (level: Level, msg: string, data?: unknown): void => {
    if (ORDER[level] < ORDER[minLevel]) return;
    sink(JSON.stringify({ at: new Date().toISOString(), level, msg, ...context, data: data === undefined ? undefined : redact(data) }));
  };
  return {
    debug: (m, d) => write('debug', m, d),
    info: (m, d) => write('info', m, d),
    warn: (m, d) => write('warn', m, d),
    error: (m, d) => write('error', m, d),
    child: (ctx) => createLogger(minLevel, { ...context, ...ctx }, sink),
  };
}