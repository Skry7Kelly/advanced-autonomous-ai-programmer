import { createReadStream } from 'node:fs';
import { appendFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import { createInterface } from 'node:readline';
import { dirname, resolve } from 'node:path';

export interface JsonlQuery { where?: (record: Record<string, unknown>) => boolean; limit?: number; reverse?: boolean }

export class JsonlStore<T extends Record<string, unknown>> {
  constructor(public readonly filePath: string) {}

  async append(record: T): Promise<T> {
    await mkdir(dirname(resolve(this.filePath)), { recursive: true });
    await appendFile(this.filePath, JSON.stringify(record) + '\n', 'utf8');
    return record;
  }

  async readAll(): Promise<T[]> {
    try {
      const raw = await readFile(this.filePath, 'utf8');
      return raw.split('\n').filter(Boolean).map((line) => JSON.parse(line) as T);
    } catch {
      return [];
    }
  }

  async query(q: JsonlQuery = {}): Promise<T[]> {
    const out: T[] = [];
    const stream = createReadStream(this.filePath, 'utf8');
    const rl = createInterface({ input: stream, crlfDelay: Infinity });
    for await (const line of rl) {
      if (!line.trim()) continue;
      let parsed: T;
      try {
        parsed = JSON.parse(line) as T;
      } catch {
        continue;
      }
      if (!q.where || q.where(parsed as Record<string, unknown>)) out.push(parsed);
      if (q.limit && out.length >= q.limit && !q.reverse) break;
    }
    return q.reverse ? out.reverse().slice(0, q.limit ?? out.length) : out;
  }

  async rewrite(records: T[]): Promise<void> {
    await mkdir(dirname(resolve(this.filePath)), { recursive: true });
    await writeFile(this.filePath, records.map((r) => JSON.stringify(r)).join('\n') + (records.length ? '\n' : ''), 'utf8');
  }
}