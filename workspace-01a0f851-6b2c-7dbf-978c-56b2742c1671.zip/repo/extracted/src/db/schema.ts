import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import type {
  Brief,
  ProjectSettings,
  QaReport,
  Spec,
} from "@/lib/types";

export const projects = pgTable(
  "projects",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    brief: text("brief").notNull(),
    kind: text("kind").notNull().default("tool"),
    language: text("language").notNull().default("typescript"),
    status: text("status").notNull().default("queued"),
    stage: text("stage").notNull().default("init"),
    progress: integer("progress").notNull().default(0),
    spec: jsonb("spec").$type<Spec>(),
    briefParsed: jsonb("brief_parsed").$type<Brief>(),
    qa: jsonb("qa").$type<QaReport>(),
    settings: jsonb("settings").$type<ProjectSettings>(),
    stats: jsonb("stats").$type<Record<string, number>>(),
    error: text("error"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("projects_created_idx").on(t.createdAt)],
);

export const runs = pgTable("runs", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  status: text("status").notNull().default("running"),
  summary: jsonb("summary").$type<Record<string, number>>(),
  startedAt: timestamp("started_at", { withTimezone: true }).defaultNow().notNull(),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
});

export const events = pgTable(
  "events",
  {
    id: serial("id").primaryKey(),
    projectId: integer("project_id").notNull(),
    runId: integer("run_id"),
    level: text("level").notNull().default("info"),
    agent: text("agent").notNull().default("ARCHITECT"),
    stage: text("stage").notNull().default("init"),
    message: text("message").notNull(),
    data: jsonb("data"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("events_project_idx").on(t.projectId, t.id)],
);

export const tasks = pgTable(
  "tasks",
  {
    id: serial("id").primaryKey(),
    projectId: integer("project_id").notNull(),
    ordinal: integer("ordinal").notNull().default(0),
    title: text("title").notNull(),
    detail: text("detail").notNull().default(""),
    agent: text("agent").notNull().default("ENGINEER"),
    status: text("status").notNull().default("pending"),
    artifactPath: text("artifact_path"),
    dependsOn: jsonb("depends_on").$type<string[]>(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("tasks_project_idx").on(t.projectId, t.ordinal)],
);

export const artifacts = pgTable(
  "artifacts",
  {
    id: serial("id").primaryKey(),
    projectId: integer("project_id").notNull(),
    path: text("path").notNull(),
    language: text("language").notNull().default("typescript"),
    content: text("content").notNull(),
    bytes: integer("bytes").notNull().default(0),
    sha256: text("sha256").notNull().default(""),
    origin: text("origin").notNull().default("generated"),
    agent: text("agent").notNull().default("ENGINEER"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("artifacts_project_idx").on(t.projectId, t.path)],
);

export const sources = pgTable(
  "sources",
  {
    id: serial("id").primaryKey(),
    projectId: integer("project_id").notNull(),
    provider: text("provider").notNull(), // pirateface | github | npm | hn | stackoverflow | web
    query: text("query").notNull().default(""),
    title: text("title").notNull(),
    url: text("url").notNull(),
    subtitle: text("subtitle").notNull().default(""),
    metric: integer("metric").notNull().default(0), // stars or seeds
    metricLabel: text("metric_label").notNull().default("stars"),
    score: real("score").notNull().default(0),
    flyScore: real("fly_score").notNull().default(0),
    decision: text("decision").notNull().default("reference"), // adopted | reference | rejected | model
    reason: text("reason").notNull().default(""),
    payload: jsonb("payload"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("sources_project_idx").on(t.projectId, t.provider)],
);

export const forgedModules = pgTable("forged_modules", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id"),
  capability: text("capability").notNull(),
  name: text("name").notNull(),
  rationale: text("rationale").notNull().default(""),
  code: text("code").notNull(),
  testCode: text("test_code").notNull().default(""),
  doc: text("doc").notNull().default(""),
  bytes: integer("bytes").notNull().default(0),
  used: boolean("used").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const memories = pgTable(
  "memories",
  {
    id: serial("id").primaryKey(),
    projectId: integer("project_id"),
    brainId: integer("brain_id"),
    kind: text("kind").notNull().default("note"), // brief | module | source | decision | lesson
    text: text("text").notNull(),
    meta: jsonb("meta"),
    tag: jsonb("tag").$type<number[]>(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("memories_kind_idx").on(t.kind)],
);

export const flyBrains = pgTable("fly_brains", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  generation: integer("generation").notNull().default(0),
  parents: jsonb("parents").$type<number[]>(),
  inputDim: integer("input_dim").notNull().default(4096),
  outputDim: integer("output_dim").notNull().default(32768),
  conn: integer("conn").notNull().default(32),
  k: integer("k").notNull().default(128),
  seed: integer("seed").notNull().default(1),
  weights: jsonb("weights").$type<number[]>(), // flat triples: inIdx, outIdx, sign
  fitness: real("fitness").notNull().default(0),
  evals: integer("evals").notNull().default(0),
  active: boolean("active").notNull().default(false),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const proxies = pgTable("proxies", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  protocol: text("protocol").notNull().default("http"),
  status: text("status").notNull().default("unknown"),
  latencyMs: integer("latency_ms"),
  failCount: integer("fail_count").notNull().default(0),
  okCount: integer("ok_count").notNull().default(0),
  note: text("note").notNull().default(""),
  lastCheckedAt: timestamp("last_checked_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const secrets = pgTable("secrets", {
  id: serial("id").primaryKey(),
  envKey: text("env_key").notNull(),
  label: text("label").notNull().default(""),
  value: text("value").notNull().default(""),
  hint: text("hint").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const chats = pgTable(
  "chats",
  {
    id: serial("id").primaryKey(),
    projectId: integer("project_id").notNull(),
    role: text("role").notNull().default("user"),
    content: text("content").notNull(),
    provider: text("provider").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("chats_project_idx").on(t.projectId, t.id)],
);

export const providers = pgTable("providers", {
  id: serial("id").primaryKey(),
  key: text("key").notNull(),
  label: text("label").notNull(),
  kind: text("kind").notNull().default("chat"), // chat | model-index | local
  baseUrl: text("base_url").notNull().default(""),
  model: text("model").notNull().default(""),
  envKey: text("env_key").notNull().default(""),
  enabled: boolean("enabled").notNull().default(true),
  status: text("status").notNull().default("unknown"),
  latencyMs: integer("latency_ms"),
  detail: text("detail").notNull().default(""),
  priority: integer("priority").notNull().default(100),
  lastCheckedAt: timestamp("last_checked_at", { withTimezone: true }),
});

export type ProjectRow = typeof projects.$inferSelect;
export type EventSelect = typeof events.$inferSelect;
export type ArtifactRow = typeof artifacts.$inferSelect;
export type SourceRow = typeof sources.$inferSelect;
export type ForgedModuleRow = typeof forgedModules.$inferSelect;
export type FlyBrainRow = typeof flyBrains.$inferSelect;
export type ProviderRow = typeof providers.$inferSelect;
export type ProxyRow = typeof proxies.$inferSelect;
export type TaskRow = typeof tasks.$inferSelect;
