"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import TitleBar from "./TitleBar";
import Sidebar from "./Sidebar";
import EditorPane, { type OpenTab } from "./EditorPane";
import ChatPanel from "./ChatPanel";
import ConsolePanel from "./ConsolePanel";
import Welcome from "./Welcome";
import AuthScreen from "./AuthScreen";
import PlansModal from "./PlansModal";
import CommandPalette, { type Command } from "./CommandPalette";
import SettingsModal from "./SettingsModal";
import { Icon } from "./icons";
import { api, authApi, extColor } from "./api";
import {
  AGENTS,
  type AgentEvent,
  type ChatMode,
  type EventRow,
  type ProjectDetail,
  type ProjectRow,
  type PublicUser,
  type RawPatch,
  type UiMessage,
  type UsageInfo,
} from "./types";

type Toast = { id: number; kind: "ok" | "error" | "info"; text: string };

let localId = -1;
const nextLocalId = () => localId--;

export default function SvarmaApp() {
  /* ------------------------------- данные ------------------------------- */
  const [ready, setReady] = useState(false);
  const [bootSlow, setBootSlow] = useState(false);
  const [bootError, setBootError] = useState<string | null>(null);
  const [user, setUser] = useState<PublicUser | null>(null);
  const [usage, setUsage] = useState<UsageInfo | null>(null);
  const [plansOpen, setPlansOpen] = useState(false);
  const [projects, setProjects] = useState<ProjectRow[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [detail, setDetail] = useState<ProjectDetail | null>(null);
  const [events, setEvents] = useState<EventRow[]>([]);
  const [live, setLive] = useState({ status: "", stage: "", progress: 0 });
  const [streamEpoch, setStreamEpoch] = useState(0);

  /* -------------------------------- UI --------------------------------- */
  const [sidebarTab, setSidebarTab] = useState<"files" | "swarm" | "sources">("files");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [chatOpen, setChatOpen] = useState(true);
  const [consoleOpen, setConsoleOpen] = useState(true);
  const [consoleTab, setConsoleTab] = useState<"console" | "tasks">("console");
  const [agentFilter, setAgentFilter] = useState<string | null>(null);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);

  /* ------------------------------- чат --------------------------------- */
  const [chatMessages, setChatMessages] = useState<UiMessage[]>([]);
  const [chatMode, setChatMode] = useState<ChatMode>("agent");
  const [chatBusy, setChatBusy] = useState(false);
  const [providerLabel, setProviderLabel] = useState("");
  const [llmAvailable, setLlmAvailable] = useState<boolean | null>(null);

  /* ------------------------------ редактор ------------------------------ */
  const [tabs, setTabs] = useState<OpenTab[]>([]);
  const [activePath, setActivePath] = useState<string | null>(null);
  const [previewEpoch, setPreviewEpoch] = useState(0);
  const [creating, setCreating] = useState(false);
  const lastChatProject = useRef<number | null>(null);

  const toast = useCallback((kind: Toast["kind"], text: string) => {
    const id = nextLocalId();
    setToasts((prev) => [...prev.slice(-3), { id, kind, text }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 3800);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const me = await authApi.me();
      if (me.user) {
        setUser(me.user);
        setUsage(me.usage);
      }
    } catch {
      /* сессия могла истечь — разрулит следующий запрос */
    }
  }, []);

  const handleAuthed = useCallback(
    async (authedUser: PublicUser, authedUsage: UsageInfo) => {
      setUser(authedUser);
      setUsage(authedUsage);
      try {
        const list = await api.listProjects();
        setProjects(list);
        setActiveId(list[0]?.id ?? null);
      } catch {
        /* проекты подгрузятся при создании */
      }
    },
    [],
  );

  const logout = useCallback(async () => {
    await authApi.logout().catch(() => undefined);
    setUser(null);
    setUsage(null);
    setProjects([]);
    setActiveId(null);
    setDetail(null);
    setEvents([]);
    setChatMessages([]);
    setTabs([]);
    setActivePath(null);
    setLive({ status: "", stage: "", progress: 0 });
    toast("info", "Вы вышли из аккаунта");
  }, [toast]);

  /** 402 upgrade → тарифы; 401 auth → выход; иначе тост ошибки. Возвращает текст ошибки. */
  const authAwareMessage = useCallback(
    (e: unknown): string => {
      const err = e as { upgrade?: boolean; auth?: boolean; message?: string };
      if (err?.upgrade) setPlansOpen(true);
      if (err?.auth) {
        setUser(null);
        setUsage(null);
        return "Сессия истекла — войдите снова";
      }
      return e instanceof Error ? e.message : String(e);
    },
    [],
  );

  /* ---------------------------- инициализация ---------------------------- */
  useEffect(() => {
    let cancelled = false;
    const watchdog = setTimeout(() => {
      if (!cancelled) setBootSlow(true);
    }, 8000);
    (async () => {
      try {
        const me = await authApi.me();
        if (cancelled) return;
        setUser(me.user);
        setUsage(me.usage);
        if (me.user) {
          const list = await api.listProjects();
          if (cancelled) return;
          setProjects(list);
          const last = list[0];
          if (last) setActiveId(last.id);
        }
      } catch (e) {
        if (cancelled) return;
        if ((e as { auth?: boolean })?.auth) {
          setUser(null); // сессия истекла — покажем экран входа
        } else {
          setBootError(e instanceof Error ? e.message : String(e));
        }
      } finally {
        if (!cancelled) setReady(true);
      }
      // провайдеры грузим в фоне — они не должны задерживать открытие IDE
      api
        .providers()
        .then((prov) => {
          if (cancelled) return;
          setLlmAvailable(prov.llmAvailable);
          setProviderLabel(prov.ready[0] ?? "встроенный движок");
        })
        .catch(() => undefined);
    })();
    return () => {
      cancelled = true;
      clearTimeout(watchdog);
    };
  }, [toast]);

  /* ---------------------- загрузка активного проекта --------------------- */
  const loadDetail = useCallback(
    async (id: number, keepChat: boolean) => {
      const data = await api.getProject(id);
      setDetail(data);
      setEvents((prev) => {
        const seen = new Set(prev.map((e) => e.id));
        const merged = [...prev];
        for (const e of data.events) if (!seen.has(e.id)) merged.push(e);
        merged.sort((a, b) => a.id - b.id);
        return merged.slice(-600);
      });
      setLive({ status: data.project.status, stage: data.project.stage, progress: data.project.progress });
      if (!keepChat || lastChatProject.current !== id) {
        setChatMessages(data.chats.map((row) => ({ kind: "row", row })));
        lastChatProject.current = id;
      }
      return data;
    },
    [],
  );

  useEffect(() => {
    if (activeId == null) {
      setDetail(null);
      setTabs([]);
      setActivePath(null);
      setEvents([]);
      setChatMessages([]);
      lastChatProject.current = null;
      return;
    }
    let cancelled = false;
    setTabs([]);
    setActivePath(null);
    loadDetail(activeId, false).catch((e) => toast("error", `Ошибка загрузки: ${e instanceof Error ? e.message : e}`));
    void cancelled;
    return () => {
      cancelled = true;
    };
  }, [activeId, loadDetail, toast]);

  /* --------------------------- SSE конвейера ---------------------------- */
  useEffect(() => {
    if (activeId == null) return;
    const es = new EventSource(`/api/projects/${activeId}/stream`);
    let lastEventId = 0;
    let finishTimer: ReturnType<typeof setTimeout> | null = null;

    es.onmessage = (msg) => {
      try {
        const payload = JSON.parse(msg.data) as {
          type: string;
          event?: EventRow;
          status?: string;
          progress?: number;
          stage?: string;
        };
        if (payload.type === "event" && payload.event) {
          const ev = payload.event;
          lastEventId = Math.max(lastEventId, ev.id);
          setEvents((prev) => (prev.some((e) => e.id === ev.id) ? prev : [...prev, ev].slice(-600)));
          if (ev.stage === "done" || ev.stage === "error") {
            if (finishTimer) clearTimeout(finishTimer);
            finishTimer = setTimeout(() => {
              if (activeId != null) {
                loadDetail(activeId, true)
                  .then(() => {
                    setPreviewEpoch((n) => n + 1);
                    setTabs((prevTabs) => prevTabs); // вкладки обновятся при переключении
                  })
                  .catch(() => undefined);
              }
            }, 500);
          }
        } else if (payload.type === "state") {
          setLive({ status: payload.status ?? "", stage: payload.stage ?? "", progress: payload.progress ?? 0 });
          if ((payload.status === "done" || payload.status === "failed") && payload.stage !== "running") {
            // сервер закроет поток; обновим проект целиком
            if (finishTimer) clearTimeout(finishTimer);
            finishTimer = setTimeout(() => {
              if (activeId != null) {
                loadDetail(activeId, true)
                  .then(() => setPreviewEpoch((n) => n + 1))
                  .catch(() => undefined);
              }
            }, 600);
            es.close();
          }
        }
      } catch {
        /* игнорируем битые сообщения */
      }
    };

    es.onerror = () => {
      /* EventSource сам переподключится; при «done» мы закрываем сами */
    };

    return () => {
      if (finishTimer) clearTimeout(finishTimer);
      es.close();
    };
  }, [activeId, streamEpoch, loadDetail]);

  /* ------------------------------ действия ------------------------------ */

  const refreshProjects = useCallback(async () => {
    const list = await api.listProjects().catch(() => []);
    setProjects(list);
    return list;
  }, []);

  const createProject = useCallback(
    async (brief: string, settings: Record<string, unknown>) => {
      setCreating(true);
      try {
        const project = await api.createProject(brief, settings);
        await refreshProjects();
        lastChatProject.current = project.id;
        setChatMessages([{ kind: "build", id: nextLocalId() }]);
        setActiveId(project.id);
        setSidebarTab("files");
        setChatOpen(true);
        setConsoleOpen(true);
        setStreamEpoch((n) => n + 1);
        toast("ok", `Проект «${project.name}» создан — рой начал сборку`);
      } finally {
        setCreating(false);
      }
    },
    [refreshProjects, toast],
  );

  const runBuild = useCallback(async () => {
    if (activeId == null) return;
    try {
      await api.build(activeId);
      setStreamEpoch((n) => n + 1);
      setConsoleOpen(true);
      setConsoleTab("console");
      toast("ok", "Конвейер роя запущен");
    } catch (e) {
      const msg = authAwareMessage(e);
      if (msg) toast("error", msg);
    }
  }, [activeId, authAwareMessage, toast]);

  const openFile = useCallback(
    async (path: string) => {
      if (activeId == null) return;
      const existing = tabs.find((t) => t.path === path);
      if (existing) {
        // обновляем содержимое, если вкладка не «грязная»
        setActivePath(path);
        if (!existing.dirty) {
          try {
            const content = await api.getFile(activeId, path);
            setTabs((prev) => prev.map((t) => (t.path === path && !t.dirty ? { ...t, content } : t)));
          } catch {
            /* файл мог исчезнуть */
          }
        }
        return;
      }
      try {
        const content = await api.getFile(activeId, path);
        setTabs((prev) => [...prev, { path, content, dirty: false }]);
        setActivePath(path);
      } catch (e) {
        toast("error", `Не удалось открыть ${path}: ${e instanceof Error ? e.message : e}`);
      }
    },
    [activeId, tabs, toast],
  );

  const closeTab = useCallback(
    (path: string) => {
      const idx = tabs.findIndex((t) => t.path === path);
      const next = tabs.filter((t) => t.path !== path);
      setTabs(next);
      if (activePath === path) {
        setActivePath(next[Math.min(idx, next.length - 1)]?.path ?? null);
      }
    },
    [tabs, activePath],
  );

  const changeTabContent = useCallback((path: string, content: string) => {
    setTabs((prev) => prev.map((t) => (t.path === path ? { ...t, content, dirty: true } : t)));
  }, []);

  const saveActiveTab = useCallback(async () => {
    if (activeId == null || activePath == null) return;
    const tab = tabs.find((t) => t.path === activePath);
    if (!tab || !tab.dirty) return;
    try {
      await api.saveFile(activeId, activePath, tab.content);
      setTabs((prev) => prev.map((t) => (t.path === activePath ? { ...t, dirty: false } : t)));
      setPreviewEpoch((n) => n + 1);
      toast("ok", `${activePath} сохранён`);
    } catch (e) {
      toast("error", `Ошибка сохранения: ${e instanceof Error ? e.message : e}`);
    }
  }, [activeId, activePath, tabs, toast]);

  /* -------------------------------- чат --------------------------------- */

  const sendChat = useCallback(
    async (text: string) => {
      if (activeId == null || !text.trim() || chatBusy) return;
      const statusId = nextLocalId();
      const userMsg: UiMessage = { kind: "row", row: { id: nextLocalId(), projectId: activeId, role: "user", content: text, provider: "", createdAt: new Date().toISOString() } };
      setChatMessages((prev) => [...prev, userMsg]);
      setChatBusy(true);
      try {
        await api.chatTurn(activeId, text, chatMode, (evt: AgentEvent) => {
          if (evt.type === "provider") {
            setProviderLabel(`${evt.provider}:${evt.model}`.slice(0, 42));
            return;
          }
          setChatMessages((prev) => {
            // заменяем висящий статус
            const base = prev.filter((m) => !(m.kind === "status" && m.id === statusId));
            switch (evt.type) {
              case "status":
                return [...base, { kind: "status", id: statusId, text: evt.text, icon: evt.icon }];
              case "skills":
                return [...base, { kind: "skills", id: nextLocalId(), skills: evt.skills }];
              case "build-started":
                return [...base, { kind: "build", id: nextLocalId() }];
              case "answer":
                return [
                  ...base,
                  { kind: "row", row: { id: nextLocalId(), projectId: activeId, role: "assistant", content: evt.text, provider: "agent", createdAt: new Date().toISOString() } },
                ];
              case "patches":
                return [...base, { kind: "patches", id: nextLocalId(), summary: evt.summary, patches: evt.patches, raw: evt.raw, provider: evt.provider, applied: "pending" }];
              case "spec":
                return [...base, { kind: "spec", id: nextLocalId(), spec: evt.spec, notes: evt.notes }];
              case "error":
                return [...base, { kind: "error", id: nextLocalId(), message: evt.message }];
              default:
                return prev;
            }
          });
        });
      } catch (e) {
        setChatMessages((prev) => [...prev, { kind: "error", id: nextLocalId(), message: authAwareMessage(e) }]);
      } finally {
        setChatBusy(false);
        setChatMessages((prev) => prev.filter((m) => m.kind !== "status"));
        void refreshUser(); // обновляем счётчик запросов на сегодня
      }
    },
    [activeId, authAwareMessage, chatBusy, chatMode, refreshUser],
  );

  const applyPatches = useCallback(
    async (msgId: number, patches: RawPatch[], summary: string, provider: string) => {
      if (activeId == null) return;
      setChatMessages((prev) => prev.map((m) => (m.kind === "patches" && m.id === msgId ? { ...m, applied: "applied" } : m)));
      try {
        const changed = await api.applyPatches(activeId, patches, summary, provider);
        await loadDetail(activeId, true);
        setPreviewEpoch((n) => n + 1);
        setChatMessages((prev) => [
          ...prev,
          {
            kind: "row",
            row: {
              id: nextLocalId(),
              projectId: activeId,
              role: "assistant",
              content: `Правки применены ✓\n\nИзменены: ${changed.join(", ") || "—"}`,
              provider,
              createdAt: new Date().toISOString(),
            },
          },
        ]);
        toast("ok", `Применено: ${changed.length} файл(ов)`);
      } catch (e) {
        setChatMessages((prev) => prev.map((m) => (m.kind === "patches" && m.id === msgId ? { ...m, applied: "pending" } : m)));
        toast("error", e instanceof Error ? e.message : String(e));
      }
    },
    [activeId, loadDetail, toast],
  );

  const rejectPatches = useCallback((msgId: number) => {
    setChatMessages((prev) => prev.map((m) => (m.kind === "patches" && m.id === msgId ? { ...m, applied: "rejected" } : m)));
  }, []);

  /* --------------------------- клавиатура -------------------------------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen((v) => !v);
      } else if (mod && e.key.toLowerCase() === "s") {
        e.preventDefault();
        void saveActiveTab();
      } else if (mod && e.key.toLowerCase() === "b") {
        e.preventDefault();
        setSidebarOpen((v) => !v);
      } else if (mod && e.key.toLowerCase() === "j") {
        e.preventDefault();
        setConsoleOpen((v) => !v);
      } else if (mod && e.key.toLowerCase() === "i") {
        e.preventDefault();
        setChatOpen((v) => !v);
      } else if (e.key === "Escape") {
        setPaletteOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [saveActiveTab]);

  /* ---------------------------- палитра команд --------------------------- */
  const commands = useMemo<Command[]>(() => {
    const list: Command[] = [
      { id: "new", title: "Новый проект", hint: "создать и собрать", icon: "plus", run: () => setActiveId(null) },
      { id: "build", title: "Собрать проект (рой)", hint: "Ctrl+⏎", icon: "zap", run: () => void runBuild(), disabled: activeId == null },
      { id: "preview", title: "Открыть превью", icon: "eye", run: () => setActivePath("__preview__"), disabled: activeId == null },
      { id: "zip", title: "Скачать ZIP", icon: "download", run: () => activeId != null && window.open(`/api/projects/${activeId}/bundle`, "_blank"), disabled: activeId == null },
      { id: "settings", title: "Настройки: модели и ключи", icon: "settings", run: () => setSettingsOpen(true) },
      { id: "chat", title: chatOpen ? "Скрыть чат" : "Показать чат", hint: "Ctrl+I", icon: "chat", run: () => setChatOpen((v) => !v) },
      { id: "console", title: consoleOpen ? "Скрыть консоль" : "Показать консоль", hint: "Ctrl+J", icon: "terminal", run: () => setConsoleOpen((v) => !v) },
      { id: "sidebar", title: sidebarOpen ? "Скрыть боковую панель" : "Показать боковую панель", hint: "Ctrl+B", icon: "panelLeft", run: () => setSidebarOpen((v) => !v) },
    ];
    for (const f of detail?.files ?? []) {
      list.push({
        id: `file:${f.path}`,
        title: f.path,
        hint: "открыть файл",
        icon: "file",
        color: extColor(f.path),
        run: () => void openFile(f.path),
      });
    }
    return list;
  }, [activeId, chatOpen, consoleOpen, detail, openFile, runBuild, sidebarOpen]);

  /* ------------------------------- рендер -------------------------------- */

  if (!ready || bootError) {
    return (
      <div className="flex h-screen items-center justify-center bg-ink-950">
        <div className="flex flex-col items-center gap-4 animate-fade-in px-6 text-center">
          <div className="relative">
            <Icon name="logo" size={52} className={bootError ? "opacity-60" : "animate-glow"} />
            <span className="absolute -right-7 -top-1 rounded-full border border-accent2/40 bg-ink-850 px-1.5 py-px font-mono text-[9px] text-accent2">v1.2</span>
          </div>
          {bootError ? (
            <>
              <div className="text-sm font-semibold text-danger">Не удалось загрузить проекты</div>
              <div className="max-w-sm font-mono text-[11px] leading-relaxed text-ink-400">{bootError}</div>
              <button
                className="btn btn-accent !px-5 !py-2"
                onClick={() => {
                  setBootError(null);
                  setBootSlow(false);
                  setReady(false);
                  window.location.reload();
                }}
              >
                <Icon name="refresh" size={13} /> Повторить
              </button>
            </>
          ) : (
            <>
              <div className="text-sm text-ink-300">Svarma просыпается…</div>
              {bootSlow ? (
                <div className="mt-2 flex flex-col items-center gap-3">
                  <p className="max-w-sm text-[12px] leading-relaxed text-ink-500">
                    Загрузка затянулась. Обычно это первый компиляционный прогон dev-сервера —
                    дайте ему ещё 10–20 секунд или обновите страницу.
                  </p>
                  <button className="btn" onClick={() => window.location.reload()}>
                    <Icon name="refresh" size={13} /> Обновить
                  </button>
                </div>
              ) : null}
            </>
          )}
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <AuthScreen onAuthed={(u, us) => void handleAuthed(u, us)} />
        <Toasts toasts={toasts} onDismiss={dismissToast} />
      </>
    );
  }

  if (activeId == null) {
    return (
      <>
        <Welcome
          usage={usage}
          onOpenPlans={() => setPlansOpen(true)}
          projects={projects}
          busy={creating}
          onCreate={async (brief, settings) => {
            try {
              await createProject(brief, settings);
            } catch (e) {
              const msg = authAwareMessage(e);
              if (msg) toast("error", msg);
            }
          }}
          onOpen={(id) => setActiveId(id)}
          onDelete={async (id) => {
            try {
              await api.deleteProject(id);
              const list = await refreshProjects();
              if (activeId === id) setActiveId(list[0]?.id ?? null);
              toast("ok", "Проект удалён");
            } catch (e) {
              const msg = authAwareMessage(e);
              if (msg) toast("error", msg);
            }
          }}
        />
        <PlansModal
          open={plansOpen}
          onClose={() => setPlansOpen(false)}
          user={user}
          usage={usage}
          onSubscribed={(u, us) => {
            setUser(u);
            setUsage(us);
            void refreshProjects();
          }}
          onToast={toast}
        />
        <Toasts toasts={toasts} onDismiss={dismissToast} />
      </>
    );
  }

  const running = live.status === "running" || live.status === "queued";
  const dirtyPaths = new Set(tabs.filter((t) => t.dirty).map((t) => t.path));

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-ink-950 text-ink-100">
      <TitleBar
        project={detail?.project ?? null}
        live={live}
        running={running}
        projects={projects}
        activeId={activeId}
        user={user}
        usage={usage}
        onSelectProject={(id) => setActiveId(id)}
        onNewProject={() => setActiveId(null)}
        onBuild={runBuild}
        onDownload={() => window.open(`/api/projects/${activeId}/bundle`, "_blank")}
        onSettings={() => setSettingsOpen(true)}
        onPlans={() => setPlansOpen(true)}
        onLogout={() => void logout()}
        onRefreshProviders={async () => {
          try {
            const prov = await api.probeProviders();
            setLlmAvailable(prov.ready.length > 0);
            setProviderLabel(prov.ready[0] ?? "встроенный движок");
            toast("ok", `Готово провайдеров: ${prov.ready.length}`);
          } catch (e) {
            toast("error", e instanceof Error ? e.message : String(e));
          }
        }}
        providerLabel={providerLabel}
        llmAvailable={llmAvailable}
      />

      <div className="flex min-h-0 flex-1">
        {/* рельс иконок */}
        <div className="flex w-12 flex-col items-center gap-1 border-r border-ink-800 bg-ink-900 py-2">
          {(
            [
              ["files", "files", "Проводник (Ctrl+B)"],
              ["swarm", "swarm", "Рой: агенты"],
              ["sources", "sources", "Источники"],
            ] as const
          ).map(([tab, icon, title]) => (
            <button
              key={tab}
              title={title}
              onClick={() => {
                setSidebarTab(tab);
                setSidebarOpen(true);
              }}
              className={`ring-focus flex h-9 w-9 items-center justify-center rounded-lg transition-colors ${
                sidebarOpen && sidebarTab === tab ? "bg-ink-750 text-accent2" : "text-ink-400 hover:bg-ink-800 hover:text-ink-200"
              }`}
            >
              <Icon name={icon} size={18} />
            </button>
          ))}
          <div className="mt-auto flex flex-col gap-1">
            <button
              title="Палитра команд (Ctrl+K)"
              onClick={() => setPaletteOpen(true)}
              className="ring-focus flex h-9 w-9 items-center justify-center rounded-lg text-ink-400 transition-colors hover:bg-ink-800 hover:text-ink-200"
            >
              <Icon name="command" size={18} />
            </button>
            <button
              title="Настройки"
              onClick={() => setSettingsOpen(true)}
              className="ring-focus flex h-9 w-9 items-center justify-center rounded-lg text-ink-400 transition-colors hover:bg-ink-800 hover:text-ink-200"
            >
              <Icon name="settings" size={18} />
            </button>
          </div>
        </div>

        {sidebarOpen && detail && (
          <Sidebar
            tab={sidebarTab}
            files={detail.files}
            activePath={activePath}
            dirtyPaths={dirtyPaths}
            onOpenFile={(p) => void openFile(p)}
            events={events}
            sources={detail.sources}
            forged={detail.forged}
            onAgentClick={(agent) => {
              setConsoleOpen(true);
              setConsoleTab("console");
              setAgentFilter(agent);
            }}
          />
        )}

        <main className="flex min-w-0 flex-1 flex-col">
          <EditorPane
            projectId={activeId}
            tabs={tabs}
            activePath={activePath}
            onSelectTab={setActivePath}
            onCloseTab={closeTab}
            onChangeContent={changeTabContent}
            onSave={saveActiveTab}
            previewEpoch={previewEpoch}
            fileCount={detail?.files.length ?? 0}
            onOpenFile={(p) => void openFile(p)}
            running={running}
          />
          {consoleOpen && detail && (
            <ConsolePanel
              events={events}
              tasks={detail.tasks}
              qa={detail.project.qa}
              tab={consoleTab}
              setTab={setConsoleTab}
              agentFilter={agentFilter}
              setAgentFilter={setAgentFilter}
              onClose={() => setConsoleOpen(false)}
              onOpenFile={(p) => void openFile(p)}
            />
          )}
        </main>

        {chatOpen && (
          <ChatPanel
            messages={chatMessages}
            busy={chatBusy}
            mode={chatMode}
            setMode={setChatMode}
            onSend={(text) => void sendChat(text)}
            onApply={(id, patches, summary, provider) => void applyPatches(id, patches, summary, provider)}
            onReject={rejectPatches}
            onOpenFile={(p) => void openFile(p)}
            files={detail?.files ?? []}
            running={running}
            onMinimize={() => setChatOpen(false)}
          />
        )}
      </div>

      {/* строка состояния */}
      <div className="flex h-7 shrink-0 items-center gap-3 border-t border-ink-800 bg-ink-900 px-3 text-[11px] text-ink-400">
        <span className={`flex items-center gap-1.5 ${running ? "text-accent2" : live.status === "done" ? "text-ok" : live.status === "failed" ? "text-danger" : ""}`}>
          <span className={`inline-block h-1.5 w-1.5 rounded-full ${running ? "animate-blink bg-accent2" : live.status === "done" ? "bg-ok" : live.status === "failed" ? "bg-danger" : "bg-ink-500"}`} />
          {running ? `рой работает · ${live.stage} · ${live.progress}%` : live.status === "done" ? "рой завершил сборку" : live.status === "failed" ? "сборка упала" : "ожидание"}
        </span>
        <span className="text-ink-500">|</span>
        <span>{detail?.project.kind ?? "—"} · {detail?.project.language ?? "—"}</span>
        <span className="text-ink-500">|</span>
        <span>{detail?.files.length ?? 0} файлов</span>
        {detail?.project.qa ? (
          <>
            <span className="text-ink-500">|</span>
            <span className={detail.project.qa.score >= 80 ? "text-ok" : "text-warn"}>QA {detail.project.qa.score}/100</span>
          </>
        ) : null}
        {activePath && activePath !== "__preview__" ? (
          <>
            <span className="text-ink-500">|</span>
            <span className="font-mono">{activePath}</span>
          </>
        ) : null}
        <span className="ml-auto flex items-center gap-3">
          {usage ? (
            <span className="flex items-center gap-1.5" title="Использование сегодня">
              <Icon name="cpu" size={12} className="text-ink-400" />
              <span className="font-mono">
                {usage.chatUsedToday}/{usage.chatLimit >= 5000 ? "∞" : usage.chatLimit} запр.
              </span>
            </span>
          ) : null}
          <span className="text-ink-500">|</span>
          <span className="font-mono">{providerLabel || "встроенный движок"}</span>
          <span className="text-ink-500">|</span>
          <span>Ctrl+K команды</span>
        </span>
      </div>

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} commands={commands} />
      <PlansModal
        open={plansOpen}
        onClose={() => setPlansOpen(false)}
        user={user}
        usage={usage}
        onSubscribed={(u, us) => {
          setUser(u);
          setUsage(us);
          void refreshProjects();
        }}
        onToast={toast}
      />
      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        onToast={toast}
        onProvidersChanged={async () => {
          try {
            const prov = await api.providers();
            setLlmAvailable(prov.llmAvailable);
          } catch {
            /* пропускаем */
          }
        }}
      />
      <Toasts toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

function Toasts({ toasts, onDismiss }: { toasts: Toast[]; onDismiss: (id: number) => void }) {
  return (
    <div className="pointer-events-none fixed bottom-10 right-4 z-50 flex flex-col gap-2">
      {toasts.map((t) => (
        <button
          key={t.id}
          onClick={() => onDismiss(t.id)}
          className={`pointer-events-auto animate-slide-in flex items-center gap-2 rounded-xl border px-4 py-2.5 text-left text-[12.5px] shadow-2xl backdrop-blur ${
            t.kind === "ok"
              ? "border-ok/30 bg-ink-850/95 text-ink-100"
              : t.kind === "error"
                ? "border-danger/40 bg-ink-850/95 text-ink-100"
                : "border-ink-650 bg-ink-850/95 text-ink-100"
          }`}
        >
          <Icon name={t.kind === "ok" ? "check" : t.kind === "error" ? "alert" : "info"} size={14} className={t.kind === "ok" ? "text-ok" : t.kind === "error" ? "text-danger" : "text-accent2"} />
          <span className="max-w-80">{t.text}</span>
        </button>
      ))}
    </div>
  );
}
