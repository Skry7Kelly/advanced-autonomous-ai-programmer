import { eq } from "drizzle-orm";
import { db } from "@/db";
import { secrets } from "@/db/schema";

const cache = new Map<string, string>();
let loadedAt = 0;

export async function loadSecrets(force = false) {
  if (!force && Date.now() - loadedAt < 2000 && cache.size >= 0) {
    // still refresh if never loaded
    if (loadedAt !== 0) return;
  }
  try {
    const rows = await db.select().from(secrets);
    cache.clear();
    for (const row of rows) {
      if (row.envKey && row.value && row.value.length > 3) cache.set(row.envKey, row.value);
    }
    loadedAt = Date.now();
  } catch {
    loadedAt = Date.now();
  }
}

export function secretValue(envKey: string): string | undefined {
  if (!envKey) return undefined;
  const env = process.env[envKey];
  if (env && env.length > 3) return env;
  const stored = cache.get(envKey);
  if (stored && stored.length > 3) return stored;
  return undefined;
}

export function maskKey(value: string): string {
  if (!value) return "";
  if (value.length <= 8) return "••••";
  return `${value.slice(0, 3)}…${value.slice(-4)}`;
}

export async function listSecrets() {
  await loadSecrets(true);
  const rows = await db.select().from(secrets);
  return rows.map((r) => ({
    envKey: r.envKey,
    label: r.label,
    hint: r.hint,
    hasValue: r.value.length > 3,
    masked: r.value.length > 3 ? maskKey(r.value) : "",
    fromEnv: Boolean(process.env[r.envKey] && process.env[r.envKey]!.length > 3),
    updatedAt: r.updatedAt,
  }));
}

export async function upsertSecret(envKey: string, value: string, label = "", hint = "") {
  const key = envKey.trim();
  if (!/^[A-Z][A-Z0-9_]{2,80}$/.test(key)) throw new Error("имя ключа: латиница, цифры, подчёркивание (ENV_NAME)");
  const existing = await db.select({ id: secrets.id }).from(secrets).where(eq(secrets.envKey, key)).limit(1);
  if (existing.length) {
    await db
      .update(secrets)
      .set({ value: value.trim(), label: label || key, hint, updatedAt: new Date() })
      .where(eq(secrets.envKey, key));
  } else {
    await db.insert(secrets).values({ envKey: key, value: value.trim(), label: label || key, hint });
  }
  cache.set(key, value.trim());
  loadedAt = Date.now();
}

export async function deleteSecret(envKey: string) {
  await db.delete(secrets).where(eq(secrets.envKey, envKey));
  cache.delete(envKey);
  loadedAt = Date.now();
}
