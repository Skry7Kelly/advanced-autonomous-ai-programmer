import type { Brief } from "@/lib/types";

const RU_EN_STOP = new Set([
  "и","в","на","с","по","для","что","это","как","не","а","из","у","же","то","к","о","за","от","до","при","чтобы","нужно","надо","можно","быть","есть","мне","мой","наш","они","она","он","так","там","еще","ещён","или","если","тогда","который","которые","которая",
  "the","a","an","of","to","in","for","on","and","or","is","are","be","with","that","this","it","we","you","i","my","our","their","as","at","by","from","will","should","would","can","could","need","want","make","made","use","using",
]);

interface FeatureRule {
  key: string;
  title: string;
  detail: string;
  re: RegExp;
}

const FEATURE_RULES: FeatureRule[] = [
  { key: "auth", title: "Аутентификация и роли", detail: "Регистрация, вход, JWT-сессии, refresh-токены, роли (RBAC) и защита маршрутов.", re: /авторизац|аутентиф|регистрац|логин|вход по|auth|login|signup|jwt|сесси|роли|пользовател/i },
  { key: "database", title: "Хранение данных", detail: "Схема, миграции, индексы, транзакции, репозиторный слой.", re: /база|баз|данн|postgres|mysql|sqlite|mongo|таблиц|хранил|persist|database|db|sql/i },
  { key: "api", title: "HTTP API", detail: "REST-эндпоинты, валидация входа, коды ошибок, OpenAPI-описание.", re: /api|эндпоинт|endpoint|rest|grpc|backend|бэкенд|сервер/i },
  { key: "web-ui", title: "Веб-интерфейс", detail: "Экраны, формы, таблицы, состояние, тёмная тема, адаптив.", re: /интерфейс|фронтенд|frontend|ui|dashboard|панель|экран|страниц|сайт|лендинг/i },
  { key: "cli", title: "CLI-команды", detail: "Аргументы, флаги, подкоманды, коды выхода, помощь.", re: /cli|командн|терминал|консоль|скрипт|command|аргумент/i },
  { key: "bot", title: "Бот-интерфейс", detail: "Диалоговые сценарии, команды, кнопки, состояние беседы.", re: /бот|bot|telegram|discord|slack|whatsapp/i },
  { key: "scraper", title: "Сбор данных из интернета", detail: "Краулер, парсинг HTML, ротация прокси, уважение к robots.txt и лимитам.", re: /парс|скрейп|scraper|scrap|crawl|краул|монитор|сайт|gather|collect/i },
  { key: "search", title: "Поиск и ранжирование", detail: "Полнотекстовый поиск, фильтры, сортировка, релевантность.", re: /поиск|search|найти|фильтр|ранжир|relevan|фильтрац/i },
  { key: "ai", title: "ИИ-слой", detail: "Подключение LLM (облачные бесплатные или локальные GGUF), промпты, стриминг, память.", re: /ии|нейросет|llm|gpt|модел|model|ollama|openrouter|agent|агент|prompt|инференс/i },
  { key: "vector", title: "Векторная память", detail: "Эмбеддинги, LSH/векторный индекс, семантический поиск по истории.", re: /вектор|embedding|semantic|сема́н|семант|память|memory|rag|похож/i },
  { key: "files", title: "Работа с файлами", detail: "Загрузка, хранение, экспорт/импорт, стриминг больших файлов.", re: /файл|upload|загруз|экспорт|импорт|csv|excel|pdf|download|скач/i },
  { key: "payments", title: "Платежи и биллинг", detail: "Тарифы, счета, вебхуки платёжной системы, идемпотентность.", re: /платеж|оплат|billing|stripe|юкасс|yookassa|подписк|тариф|цена/i },
  { key: "notify", title: "Уведомления", detail: "Email, push, Telegram-алерты, дайджесты, шаблоны сообщений.", re: /уведомл|notif|email|почт|алерт|alert|push|рассылк/i },
  { key: "queue", title: "Фоновые задачи", detail: "Очередь задач, воркеры, повторы, dead-letter, идемпотентность.", re: /очеред|queue|воркер|worker|фонов|background|cron|расписан|scheduler|задач/i },
  { key: "cache", title: "Кэш и производительность", detail: "LRU/TTL-кэш, прогрев, метрики попаданий.", re: /кэш|кеш|cache|быстр|производ|скорост|оптимизац|latency/i },
  { key: "proxy", title: "Сетевой слой с прокси", detail: "Пул прокси, ротация, health-check, таймауты и ретраи.", re: /прокси|proxy|socks|ротаци|ban|блокировк|обход/i },
  { key: "local-first", title: "Локальный/оффлайн режим", detail: "Работа без облака: локальные модели, локальное хранилище, синхронизация.", re: /локальн|оффлайн|offline|без облака|local|self.?host|автономн/i },
  { key: "i18n", title: "Мультиязычность", detail: "Локали, словари, формат чисел и дат, RTL-готовность.", re: /мультиязыч|i18n|локализ|перевод|язык|locale/i },
  { key: "realtime", title: "Реальное время", detail: "WebSocket/SSE, live-обновления, присутствие, конфликты.", re: /реальн|realtime|real.?time|websocket|sse|стрим|live|чат/i },
  { key: "observability", title: "Наблюдаемость", detail: "Структурные логи, метрики, трейсинг запросов, health-check.", re: /лог|метрик|монитор|observab|tracing|health|телеметр/i },
  { key: "security", title: "Безопасность", detail: "Санитизация входа, лимиты запросов, секреты в env, шифрование чувствительного.", re: /безопасн|security|санитиз|xss|sql.?инъекц|секрет|токен|шифр/i },
  { key: "admin", title: "Админ-панель", detail: "Управление сущностями, роли, аудит действий, ручные операции.", re: /админ|admin|модерац|управлен|backoffice/i },
  { key: "analytics", title: "Аналитика и отчёты", detail: "Метрики продукта, воронки, агрегации, экспорт отчётов.", re: /аналитик|analytics|отчет|отчёт|статист|метрик|дашборд|dashboard|график/i },
  { key: "docker", title: "Упаковка и деплой", detail: "Dockerfile, docker-compose, health-check, конфигурация через env.", re: /docker|деплой|deploy|контейнер|ci|cd|pipeline|сборк/i },
];

const KIND_RULES: { kind: Brief["kind"]; re: RegExp }[] = [
  { kind: "bot", re: /бот|bot|telegram|discord/i },
  { kind: "scraper", re: /парс|скрейп|scrap|crawl|краул|мониторинг цен|агрегатор/i },
  { kind: "agent", re: /агент|agent|автономн|swarm|рой|автоном/i },
  { kind: "cli", re: /cli|консол|терминал|командн/i },
  { kind: "library", re: /библиотек|library|пакет|npm|модул|sdk/i },
  { kind: "game", re: /игр|game|гейм|платформер|шутер/i },
  { kind: "web", re: /сайт|лендинг|интерфейс|frontend|веб|магазин|маркетплейс|соцсет/i },
  { kind: "api", re: /api|бэкенд|backend|сервер|сервис/i },
  { kind: "desktop", re: /десктоп|desktop|приложение дляwindows|electron/i },
];

const DOMAIN_RULES: { domain: string; re: RegExp }[] = [
  { domain: "ai", re: /ии|нейросет|llm|модел|agent|агент|инференс|prompt/i },
  { domain: "devtools", re: /разработ|код|репозитор|github|ci|сборк|debug|программирован/i },
  { domain: "ecommerce", re: /магаз|товар|заказ|корзин|платеж|маркетплейс|продаж/i },
  { domain: "social", re: /соц|чат|комментари|подписк|лента|друз|профил/i },
  { domain: "fintech", re: /финанс|бюджет|счет|инвестиц|валют|транзакц|банк/i },
  { domain: "security", re: /безопасн|уязвим|пентест|прокси|анонимн|шифр|vpn/i },
  { domain: "media", re: /видео|аудио|музык|изображ|фото|стрим|торрент/i },
  { domain: "education", re: /обучен|курс|учеб|задач|тест|школ|универ/i },
  { domain: "health", re: /здоров|медиц|прием|таблетк|тренировк|калорий/i },
  { domain: "productivity", re: /задач|todo|планиров|заметк|календар|трекер|привыч/i },
  { domain: "iot", re: /датчик|устройств|iot|gpio|умный дом|телеметр/i },
];

const INTEGRATION_RULES: { name: string; re: RegExp }[] = [
  { name: "telegram", re: /telegram|телеграм/i },
  { name: "discord", re: /discord/i },
  { name: "openai-compatible llm", re: /openai|gpt|openrouter|deepseek|qwen|llm/i },
  { name: "postgres", re: /postgres|pg|drizzle/i },
  { name: "sqlite", re: /sqlite/i },
  { name: "s3", re: /s3|minio|bucket/i },
  { name: "stripe", re: /stripe/i },
  { name: "github api", re: /github|репозитор/i },
  { name: "pirateface", re: /pirateface|торрент|magnet/i },
  { name: "smtp/email", re: /email|почт|smtp/i },
  { name: "oauth providers", re: /oauth|google login|vk id|авториз/i },
  { name: "docker", re: /docker|контейнер/i },
];

function titleFromBrief(text: string): string {
  const firstLine = text.trim().split("\n")[0] ?? text.trim();
  const cleaned = firstLine
    .replace(/^(нужно|надо|создай|создать|сделай|сделать|напиши|написать|разработай|разработать|хочу|давай|плиз|пожалуйста)\s+/i, "")
    .replace(/^(программу|программа|приложение|приложение|сервис|систему|система|бота|бот|инструмент|утилиту)\s+/i, "")
    .trim();
  const short = cleaned.split(/[.,;!?\n]/)[0].slice(0, 70).trim();
  return (short || "Проект Роя").replace(/^\p{Ll}/u, (c) => c.toUpperCase());
}

function detectLocale(text: string): "ru" | "en" {
  const cyr = (text.match(/[\u0400-\u04FF]/g) ?? []).length;
  const lat = (text.match(/[a-zA-Z]/g) ?? []).length;
  return cyr >= lat ? "ru" : "en";
}

function topKeywords(text: string, limit = 12): string[] {
  const freq = new Map<string, number>();
  const words = text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s_-]/gu, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && w.length < 26 && !RU_EN_STOP.has(w) && !/^\d+$/.test(w));
  for (const w of words) freq.set(w, (freq.get(w) ?? 0) + 1);
  return [...freq.entries()]
    .sort((a, b) => b[1] - a[1] || b[0].length - a[0].length)
    .slice(0, limit)
    .map(([w]) => w);
}

const ENTITY_HINTS: { name: string; fields: string[]; re: RegExp }[] = [
  { name: "users", fields: ["id", "email", "password_hash", "role", "created_at"], re: /пользовател|user|аккаунт|клиент/i },
  { name: "sessions", fields: ["id", "user_id", "token", "expires_at", "ip"], re: /сесси|auth|login|jwt|токен/i },
  { name: "projects", fields: ["id", "owner_id", "name", "status", "created_at"], re: /проект|project|репозитор/i },
  { name: "tasks", fields: ["id", "project_id", "title", "status", "priority", "due_at"], re: /задач|task|todo|спринт/i },
  { name: "messages", fields: ["id", "chat_id", "author_id", "body", "sent_at"], re: /сообщен|chat|чат|письм/i },
  { name: "orders", fields: ["id", "user_id", "total", "status", "created_at"], re: /заказ|order|корзин|покупк/i },
  { name: "products", fields: ["id", "sku", "title", "price", "stock"], re: /товар|product|каталог|скидк/i },
  { name: "transactions", fields: ["id", "user_id", "amount", "currency", "status", "created_at"], re: /платеж|транзакц|оплат|finance|бюджет/i },
  { name: "documents", fields: ["id", "title", "source_url", "content", "hash"], re: /документ|стат|заметк|файл|article/i },
  { name: "models", fields: ["id", "name", "size_gb", "seeds", "magnet", "verified"], re: /модел|model|gguf|торрент|вес/i },
  { name: "proxies", fields: ["id", "url", "protocol", "status", "latency_ms", "fail_count"], re: /прокси|proxy/i },
  { name: "events_log", fields: ["id", "actor", "action", "payload", "created_at"], re: /лог|журнал|событи|audit|истори/i },
];

export function parseBrief(text: string, language = "typescript"): Brief {
  const t = text.trim();
  const lower = t.toLowerCase();
  const features = FEATURE_RULES.filter((r) => r.re.test(t)).map((r) => ({
    key: r.key,
    title: r.title,
    detail: r.detail,
  }));
  let kind: Brief["kind"] = "tool";
  for (const rule of KIND_RULES) {
    if (rule.re.test(lower)) {
      kind = rule.kind;
      break;
    }
  }
  if (kind === "tool" && features.some((f) => f.key === "api")) kind = "api";
  if (kind === "tool" && features.some((f) => f.key === "web-ui")) kind = "web";
  if (kind === "tool" && features.some((f) => f.key === "cli")) kind = "cli";

  const domain = DOMAIN_RULES.find((d) => d.re.test(lower))?.domain ?? "devtools";
  const runtime: Brief["runtime"] = language === "python" ? "python" : kind === "web" ? "node" : "node";
  const lang = lower.includes("python") || language === "python" ? "python" : "typescript";

  const entities = ENTITY_HINTS.filter((e) => e.re.test(t)).map((e) => ({ name: e.name, fields: [...e.fields] }));
  if (entities.length === 0) {
    entities.push(
      { name: "items", fields: ["id", "title", "status", "payload", "created_at"] },
      { name: "runs", fields: ["id", "target_id", "state", "log", "started_at", "finished_at"] },
    );
  }
  if (!entities.some((e) => e.name === "events_log")) {
    entities.push({ name: "events_log", fields: ["id", "actor", "action", "payload", "created_at"] });
  }

  const integrations = INTEGRATION_RULES.filter((i) => i.re.test(lower)).map((i) => i.name);
  if (lang === "typescript" && !integrations.includes("postgres") && features.some((f) => f.key === "database")) {
    integrations.push("postgres");
  }

  const personas = new Set<string>();
  const personaMatch = t.match(/для\s+([^.,;\n]{4,60})/gi);
  (personaMatch ?? []).slice(0, 3).forEach((p) => personas.add(p.replace(/^для\s+/i, "").trim()));
  if (personas.size === 0) {
    personas.add(
      kind === "cli" ? "разработчик в терминале" : kind === "bot" ? "пользователь мессенджера" : "оператор продукта",
    );
    personas.add("инженер сопровождения");
  }

  const nonFunctional = ["p95 ответа < 300 мс на локальных данных", "структурные логи и health-check", "тесты на критические пути", "секреты только через env"];
  if (features.some((f) => f.key === "proxy")) nonFunctional.push("устойчивость к банам: ротация прокси и бэкофф");
  if (features.some((f) => f.key === "ai")) nonFunctional.push("работа без платных API: локальные GGUF или бесплатные модели");
  if (features.some((f) => f.key === "security")) nonFunctional.push("санитизация входа и лимиты запросов");

  const keywords = topKeywords(`${t} ${features.map((f) => f.key).join(" ")}`);

  return {
    title: titleFromBrief(t),
    summary: t.slice(0, 900),
    kind,
    runtime,
    language: lang,
    domain,
    features,
    entities,
    integrations,
    personas: [...personas],
    nonFunctional,
    keywords,
    locale: detectLocale(t),
  };
}
