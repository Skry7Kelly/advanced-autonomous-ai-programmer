/**
 * Аутентификация и подписки Svarma.
 * Пароли — scrypt; сессии — собственные cookie-токены в БД.
 * Подписка — активация тарифа в демо-режиме (без реального платёжного провайдера).
 */
import crypto from "node:crypto";
import { eq } from "@/db/orm";
import { db } from "@/db";
import { projects, sessions, users, type UserRow } from "@/db/schema";

export const SESSION_COOKIE = "svarma_session";
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

/* -------------------------------- тарифы -------------------------------- */

export interface PlanInfo {
  id: string;
  name: string;
  priceLabel: string;
  projectLimit: number;
  chatPerDay: number;
  features: string[];
  highlight?: boolean;
}

export const PLANS: Record<"free" | "pro" | "team", PlanInfo> = {
  free: {
    id: "free",
    name: "Free",
    priceLabel: "0 ₽",
    projectLimit: 3,
    chatPerDay: 20,
    features: [
      "3 проекта",
      "20 запросов агенту в день",
      "Все 7 агентов роя",
      "Превью и ZIP-экспорт",
    ],
  },
  pro: {
    id: "pro",
    name: "Pro",
    priceLabel: "19 $/мес",
    projectLimit: 100,
    chatPerDay: 500,
    highlight: true,
    features: [
      "100 проектов",
      "500 запросов агенту в день",
      "Приоритет на LLM-провайдерах",
      "Всё из Free",
    ],
  },
  team: {
    id: "team",
    name: "Team",
    priceLabel: "49 $/мес",
    projectLimit: 100000,
    chatPerDay: 5000,
    features: [
      "Проекты без ограничений",
      "5000 запросов в день",
      "Общие проекты команды (скоро)",
      "Приоритетная поддержка",
    ],
  },
};

export type PlanId = keyof typeof PLANS;

export function planOf(user: Pick<UserRow, "plan" | "planUntil">): PlanInfo {
  const id = user.plan as PlanId;
  if (id === "pro" || id === "team") {
    const until = user.planUntil ? new Date(user.planUntil).getTime() : 0;
    if (until > Date.now()) return PLANS[id];
  }
  return PLANS.free;
}

/* ------------------------------ публичные типы --------------------------- */

export interface PublicUser {
  id: number;
  email: string;
  name: string;
  provider: string;
  plan: string;
  planName: string;
  planUntil: string | null;
  projectLimit: number;
  chatPerDay: number;
}

export interface UsageInfo {
  projects: number;
  projectLimit: number;
  chatUsedToday: number;
  chatLimit: number;
  plan: string;
}

/* -------------------------------- пароли --------------------------------- */

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && crypto.timingSafeEqual(candidate, expected);
}

/* -------------------------------- сессии --------------------------------- */

export async function createSession(userId: number): Promise<{ token: string; expiresAt: Date }> {
  const token = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  await db.insert(sessions).values({ token, userId, expiresAt });
  return { token, expiresAt };
}

export async function destroySession(token: string): Promise<void> {
  await db.delete(sessions).where(eq(sessions.token, token));
}

export function parseCookies(request: Request): Record<string, string> {
  const header = request.headers.get("cookie") ?? "";
  const out: Record<string, string> = {};
  for (const part of header.split(";")) {
    const idx = part.indexOf("=");
    if (idx < 0) continue;
    out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
  }
  return out;
}

export function sessionCookieHeader(token: string): string {
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}`;
}

export function clearSessionCookieHeader(): string {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}

export async function getAuthUser(request: Request): Promise<UserRow | null> {
  await ensureSeed();
  const token = parseCookies(request)[SESSION_COOKIE];
  if (!token) return null;
  const [session] = await db.select().from(sessions).where(eq(sessions.token, token)).limit(1);
  if (!session) return null;
  if (new Date(session.expiresAt).getTime() < Date.now()) {
    await destroySession(token);
    return null;
  }
  const [user] = await db.select().from(users).where(eq(users.id, session.userId)).limit(1);
  return user ?? null;
}

/* ------------------------------- использование --------------------------- */

export async function projectCountOf(userId: number): Promise<number> {
  const rows = await db.select({ id: projects.id }).from(projects).where(eq(projects.userId, userId));
  return rows.length;
}

export function publicUser(user: UserRow): PublicUser {
  const plan = planOf(user);
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    provider: user.provider,
    plan: plan.id,
    planName: plan.name,
    planUntil: user.planUntil ? new Date(user.planUntil).toISOString() : null,
    projectLimit: plan.projectLimit,
    chatPerDay: plan.chatPerDay,
  };
}

export async function usageOf(user: UserRow): Promise<UsageInfo> {
  const plan = planOf(user);
  const today = new Date().toISOString().slice(0, 10);
  const usedToday = (user.chatDay ?? "") === today ? user.chatUsed ?? 0 : 0;
  return {
    projects: await projectCountOf(user.id),
    projectLimit: plan.projectLimit,
    chatUsedToday: usedToday,
    chatLimit: plan.chatPerDay,
    plan: plan.id,
  };
}

/** Списать один запрос агента. Возвращает ok=false, если дневной лимит исчерпан. */
export async function consumeChatQuota(user: UserRow): Promise<{ ok: boolean; used: number; limit: number; plan: string }> {
  const today = new Date().toISOString().slice(0, 10);
  let used = user.chatUsed ?? 0;
  let day = user.chatDay ?? "";
  if (day !== today) {
    used = 0;
    day = today;
  }
  const plan = planOf(user);
  if (used >= plan.chatPerDay) {
    return { ok: false, used, limit: plan.chatPerDay, plan: plan.id };
  }
  await db.update(users).set({ chatUsed: used + 1, chatDay: day }).where(eq(users.id, user.id));
  return { ok: true, used: used + 1, limit: plan.chatPerDay, plan: plan.id };
}

/* ------------------------ демо-аккаунт и миграция ------------------------ */

let seeded = false;

/**
 * Создаёт демо-аккаунт (demo@svarma.app / demo1234, тариф Pro) и привязывает
 * к нему «бесхозные» проекты (созданные до появления аккаунтов).
 */
export async function ensureSeed(): Promise<void> {
  if (seeded) return;
  seeded = true;
  try {
    let [demo] = await db.select().from(users).where(eq(users.email, "demo@svarma.app")).limit(1);
    if (!demo) {
      [demo] = await db
        .insert(users)
        .values({
          email: "demo@svarma.app",
          name: "Демо",
          passwordHash: hashPassword("demo1234"),
          provider: "email",
          providerId: "",
          plan: "pro",
          planUntil: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
          chatUsed: 0,
          chatDay: "",
        })
        .returning();
    }
    if (demo) {
      const all = await db.select().from(projects);
      for (const p of all) {
        if (!p.userId) {
          await db.update(projects).set({ userId: demo.id }).where(eq(projects.id, p.id));
        }
      }
    }
  } catch {
    // не критично для работы
  }
}
