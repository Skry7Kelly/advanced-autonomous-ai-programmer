import { NextResponse } from "next/server";
import { getAuthUser } from "@/lib/auth";
import {
  deleteSkill,
  installSkillsFromGithub,
  listSkills,
  setSkillEnabled,
} from "@/lib/skills";

export const dynamic = "force-dynamic";

/** GET — список скиллов. */
export async function GET(request: Request) {
  const user = await getAuthUser(request);
  if (!user) return NextResponse.json({ error: "Требуется вход", auth: true }, { status: 401 });
  const skills = await listSkills();
  return NextResponse.json({
    skills,
    enabledCount: skills.filter((s) => s.enabled).length,
  });
}

/** POST — действия: install | toggle | delete. */
export async function POST(request: Request) {
  const user = await getAuthUser(request);
  if (!user) return NextResponse.json({ error: "Требуется вход", auth: true }, { status: 401 });

  let body: { action?: string; source?: string; name?: string; enabled?: boolean } = {};
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: "Некорректный JSON" }, { status: 400 });
  }

  try {
    if (body.action === "install") {
      if (!body.source) return NextResponse.json({ error: "Укажите owner/repo" }, { status: 400 });
      const result = await installSkillsFromGithub(body.source);
      return NextResponse.json({ ok: true, installed: result.installed, message: result.message });
    }
    if (body.action === "toggle") {
      if (!body.name) return NextResponse.json({ error: "Укажите name" }, { status: 400 });
      const ok = await setSkillEnabled(body.name, body.enabled !== false);
      if (!ok) return NextResponse.json({ error: "Скилл не найден" }, { status: 404 });
      return NextResponse.json({ ok: true });
    }
    if (body.action === "delete") {
      if (!body.name) return NextResponse.json({ error: "Укажите name" }, { status: 400 });
      const ok = await deleteSkill(body.name);
      if (!ok) return NextResponse.json({ error: "Скилл не найден" }, { status: 404 });
      return NextResponse.json({ ok: true });
    }
    return NextResponse.json({ error: "Неизвестное действие" }, { status: 400 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : String(e) },
      { status: 400 },
    );
  }
}
