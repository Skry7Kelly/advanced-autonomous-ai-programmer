import { and, asc, eq, gt } from "@/db/orm";
import { db } from "@/db";
import { events, projects } from "@/db/schema";
import { getAuthUser } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request);
  if (!user) return new Response("unauthorized", { status: 401 });
  const { id } = await ctx.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) return new Response("bad id", { status: 400 });
  const [owned] = await db.select({ id: projects.id }).from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!owned) return new Response("not found", { status: 404 });
  const url = new URL(request.url);
  let cursor = Number(url.searchParams.get("after") ?? "0");
  if (!Number.isFinite(cursor)) cursor = 0;

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false;
      const send = (payload: unknown) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}\n\n`));
        } catch {
          closed = true;
        }
      };
      request.signal.addEventListener("abort", () => {
        closed = true;
      });
      send({ type: "hello", cursor, at: Date.now() });
      let idleTicks = 0;
      try {
        while (!closed && idleTicks < 40) {
          const rows = await db
            .select()
            .from(events)
            .where(and(eq(events.projectId, projectId), gt(events.id, cursor)))
            .orderBy(asc(events.id))
            .limit(200);
          for (const row of rows) {
            cursor = row.id;
            send({ type: "event", event: row });
          }
          const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
          if (rows.length > 0) idleTicks = 0;
          else idleTicks += 1;
          send({
            type: "state",
            cursor,
            status: project?.status ?? "unknown",
            progress: project?.progress ?? 0,
            stage: project?.stage ?? "",
          });
          if ((project?.status === "done" || project?.status === "failed") && rows.length === 0) break;
          await new Promise((resolve) => setTimeout(resolve, 650));
        }
      } catch (error) {
        send({ type: "error", message: error instanceof Error ? error.message : String(error) });
      }
      closed = true;
      try {
        controller.close();
      } catch {
        // уже закрыт
      }
    },
  });

  return new Response(stream, {
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-store, no-transform",
      connection: "keep-alive",
      "x-accel-buffering": "no",
    },
  });
}
