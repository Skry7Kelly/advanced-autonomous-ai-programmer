import { createLogger } from './modules/logger.js';
import { appConfig } from './config.js';

export const logger = createLogger(appConfig.LOG_LEVEL as 'debug' | 'info' | 'warn' | 'error');