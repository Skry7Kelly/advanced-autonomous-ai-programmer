"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { Badge } from "@/components/ui";

type ProjectRow = {
  id: number;
  name: string;
  brief: string;
  status: string;
  stage: string;
  progress: number;
  kind: string;
  stats: Record<string, number> | null;
};
type FileRow = { path: string; language: string; bytes: number };
type ChatRow = { id: number; role: string; content: string; provider: string; createdAt: string };
type KeySlot = {
  provider: string;
  label: string;
  envKey: string;
  model: string;
  note: string;
  hasValue: boolean;
  masked: string;
  fromEnv: boolean;
};
type EventRow = { id: number; agent: string; stage: string; message: string; level: string; createdAt: string | null };

const STARTERS = [
  "CLI, который читает CSV с продажами, чистит дубли и пишет JSON-отчёт",
  "Telegram-бот учёта расходов с недельным бюджетом на локальной LLM",
  "Веб-сервис очереди задач с REST API, воркером и дашбордом",
  "Парсер цен с ротацией прокси, CSV-экспортом и алертами",
];

export default function VibeIde() {
  const [projects, setProjects] = useState<ProjectRow[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [files, setFiles] = useState<FileRow[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [content, setContent] = useState("");
  const [dirty, setDirty] = useState(false);
  const [chats, setChats] = useState<ChatRow[]>([]);
  const [events, setEvents] = useState<EventRow[]>([]);
  const [draft, setDraft] = useState("");
  const [status, setStatus] = useState({ status: "", stage: "", progress: 0, name: "" });
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [keysOpen, setKeysOpen] = useState(false);
  const [slots, setSlots] = useState<KeySlot[]>([]);
  const [keyDrafts, setKeyDrafts] = useState<Record<string, string>>({});
  const [zipBusy, setZipBusy] = useState(false);
  const chatEnd = useRef<HTMLDivElement | null>(null);
  const esRef = useRef<EventSource | null>(null);

  const loadProjects = useCallback(async () => {
    const res = await fetch("/api/projects").then((r) => r.json());
    setProjects(res.projects ?? []);
    return res.projects as ProjectRow[];
  }, []);

  const loadKeys = useCallback(async () => {
    const res = await fetch("/api/keys").then((r) => r.json());
    setSlots(res.slots ?? []);
  }, []);

  const loadProject = useCallback(async (id: number) => {
    const res = await fetch(`/api/projects/${id}`).then((r) => r.json());
    if (res.error) return;
    setFiles(res.files ?? []);
    setChats(res.chats ?? []);
    setEvents(res.events ?? []);
    setStatus({
      status: res.project.status,
      stage: res.project.stage,
      progress: res.project.progress,
      name: res.project.name,
    });
    setSelected((prev) => prev && (res.files ?? []).some((f: FileRow) => f.path === prev) ? prev : res.files?.[0]?.path ?? null);
  }, []);

  const openFile = useCallback(async (id: number, path: string) => {
    setSelected(path);
    setDirty(false);
    const res = await fetch(`/api/projects/${id}/file?path=${encodeURIComponent(path)}`).then((r) => r.json());
    setContent(res.content ?? `// ${res.error ?? "пусто"}`);
  }, []);

  useEffect(() => {
    void (async () => {
      const rows = await loadProjects();
      await loadKeys();
      const params = new URLSearchParams(window.location.search);
      const qid = Number(params.get("p"));
      const pick = Number.isFinite(qid) && qid > 0 ? qid : rows[0]?.id;
      if (pick) {
        setActiveId(pick);
        await loadProject(pick);
      }
    })();
  }, [loadProjects, loadKeys, loadProject]);

  useEffect(() => {
    if (!activeId || !selected) return;
    void openFile(activeId, selected);
  }, [activeId, selected, openFile]);

  useEffect(() => {
    if (!activeId) return;
    esRef.current?.close();
    const es = new EventSource(`/api/projects/${activeId}/stream`);
    esRef.current = es;
    es.onmessage = (message) => {
      try {
        const payload = JSON.parse(message.data) as {
          type: string;
          event?: EventRow;
          status?: string;
          progress?: number;
          stage?: string;
        };
        if (payload.type === "event" && payload.event) {
          setEvents((prev) => (prev.some((e) => e.id === payload.event!.id) ? prev : [...prev, payload.event!]));
        }
        if (payload.type === "state" && payload.status) {
          setStatus((s) => ({
            ...s,
            status: payload.status ?? s.status,
            progress: payload.progress ?? s.progress,
            stage: payload.stage ?? s.stage,
          }));
          if (payload.status === "done" || payload.progress === 100) {
            void loadProject(activeId);
            void loadProjects();
          }
        }
      } catch {
        /* ignore */
      }
    };
    return () => es.close();
  }, [activeId, loadProject, loadProjects]);

  useEffect(() => {
    chatEnd.current?.scrollIntoView({ behavior: "smooth" });
  }, [chats, events]);

  const send = useCallback(async () => {
    const text = draft.trim();
    if (text.length < 3) {
      setNotice("напишите, что собрать или что поменять — хотя бы несколько слов");
      return;
    }
    setBusy("chat");
    setNotice(null);
    try {
      let id = activeId;
      if (!id) {
        const created = await fetch("/api/projects", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ brief: text }),
        }).then((r) => r.json());
        if (created.error || !created.project) {
          setNotice(created.error ?? "не удалось создать проект");
          return;
        }
        id = created.project.id as number;
        setActiveId(id);
        await fetch(`/api/projects/${id}/build`, { method: "POST" });
        setChats([{ id: 0, role: "assistant", content: "Рой собирает проект. Смотрите файлы слева, когда конвейер закончит.", provider: "swarm", createdAt: new Date().toISOString() }]);
        setDraft("");
        await loadProjects();
        await loadProject(id);
        return;
      }
      const res = await fetch(`/api/projects/${id}/vibe`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ message: text }),
      }).then((r) => r.json());
      if (res.error) {
        setNotice(res.error);
        return;
      }
      setDraft("");
      await loadProject(id);
      await loadProjects();
    } finally {
      setBusy(null);
    }
  }, [draft, activeId, loadProject, loadProjects]);

  const saveFile = useCallback(async () => {
    if (!activeId || !selected) return;
    setBusy("save");
    try {
      await fetch(`/api/projects/${activeId}/file`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ path: selected, content }),
      });
      setDirty(false);
      setNotice(`сохранено ${selected}`);
    } finally {
      setBusy(null);
    }
  }, [activeId, selected, content]);

  const downloadZip = useCallback(async () => {
    if (!activeId) return;
    setZipBusy(true);
    try {
      const res = await fetch(`/api/projects/${activeId}/bundle`, { cache: "no-store" });
      const type = res.headers.get("content-type") ?? "";
      if (!res.ok || !type.includes("zip")) {
        setNotice((await res.text()).slice(0, 200));
        return;
      }
      const blob = await res.blob();
      const cd = res.headers.get("content-disposition") ?? "";
      const match = cd.match(/filename="([^"]+)"/);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = match?.[1] ?? `project-${activeId}.zip`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1500);
    } finally {
      setZipBusy(false);
    }
  }, [activeId]);

  const saveKey = useCallback(async (envKey: string) => {
    const value = (keyDrafts[envKey] ?? "").trim();
    if (value.length < 8) {
      setNotice("ключ слишком короткий");
      return;
    }
    setBusy(`key:${envKey}`);
    try {
      const res = await fetch("/api/keys", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ envKey, value }),
      }).then((r) => r.json());
      if (res.error) setNotice(res.error);
      else {
        setKeyDrafts((d) => ({ ...d, [envKey]: "" }));
        await loadKeys();
        setNotice(`${envKey} сохранён — модель не удаляется, она просто ждёт ключ`);
      }
    } finally {
      setBusy(null);
    }
  }, [keyDrafts, loadKeys]);

  const deleteKey = useCallback(async (envKey: string) => {
    await fetch(`/api/keys?envKey=${encodeURIComponent(envKey)}`, { method: "DELETE" });
    await loadKeys();
  }, [loadKeys]);

  const tree = useMemo(() => {
    const dirs = new Map<string, FileRow[]>();
    for (const file of files) {
      const dir = file.path.split("/").slice(0, -1).join("/") || "/";
      const list = dirs.get(dir) ?? [];
      list.push(file);
      dirs.set(dir, list);
    }
    return [...dirs.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [files]);

  const keyed = slots.filter((s) => s.hasValue || s.fromEnv).length;
  const running = status.status === "running" || status.status === "queued";

  return (
    <div className="flex h-[100dvh] flex-col">
      <header className="flex flex-wrap items-center gap-2 border-b border-[#1b2531] bg-[#0b1017] px-3 py-2">
        <span className="dot-live h-2 w-2 rounded-full bg-lime-400" />
        <h1 className="text-sm font-bold tracking-tight text-[#e8f1fa]">SUPER ROY</h1>
        <span className="hidden text-[10px] uppercase tracking-widest text-[#5f738a] sm:inline">vibe ide · cursor-like в браузере</span>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <button type="button" onClick={() => setKeysOpen(true)} className="rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[10px] uppercase text-amber-200">
            ключи {keyed}/{slots.length}
          </button>
          <button
            type="button"
            onClick={() => void downloadZip()}
            disabled={!activeId || zipBusy || files.length === 0}
            className="rounded-md border border-lime-500/40 bg-lime-500/10 px-2 py-1 text-[10px] uppercase text-lime-300 disabled:opacity-30"
          >
            {zipBusy ? "zip…" : "скачать zip"}
          </button>
          <Link href="/lab" className="rounded-md border border-[#26344a] px-2 py-1 text-[10px] uppercase text-[#8ba3bb] hover:text-sky-300">
            лаборатория
          </Link>
          <Link href="/projects" className="rounded-md border border-[#26344a] px-2 py-1 text-[10px] uppercase text-[#8ba3bb] hover:text-sky-300">
            проекты
          </Link>
        </div>
      </header>

      {notice && (
        <div className="border-b border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-[11px] text-amber-200">{notice}</div>
      )}

      <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[220px_minmax(0,1fr)_340px]">
        <aside className="min-h-0 overflow-auto border-r border-[#1b2531] bg-[#080c12]">
          <div className="border-b border-[#1b2531] px-3 py-2 text-[10px] uppercase tracking-wider text-[#5f738a]">проекты</div>
          <button
            type="button"
            onClick={() => {
              setActiveId(null);
              setFiles([]);
              setChats([]);
              setSelected(null);
              setContent("");
              setStatus({ status: "", stage: "", progress: 0, name: "" });
            }}
            className="w-full px-3 py-2 text-left text-[11px] text-lime-300 hover:bg-lime-500/10"
          >
            + новый чат
          </button>
          {projects.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => {
                setActiveId(p.id);
                setDirty(false);
                void loadProject(p.id);
              }}
              className={`block w-full truncate px-3 py-2 text-left text-[11px] ${
                activeId === p.id ? "bg-sky-500/10 text-sky-200" : "text-[#9fb3c7] hover:bg-white/5"
              }`}
            >
              #{p.id} {p.name}
              <span className="ml-2 text-[9px] uppercase text-[#5f738a]">{p.status}</span>
            </button>
          ))}
          <div className="border-y border-[#1b2531] px-3 py-2 text-[10px] uppercase tracking-wider text-[#5f738a]">файлы {files.length}</div>
          {tree.map(([dir, list]) => (
            <div key={dir} className="px-2 py-1">
              <div className="truncate px-1 text-[9px] uppercase text-[#4d5f74]">{dir}</div>
              {list.map((f) => (
                <button
                  key={f.path}
                  type="button"
                  onClick={() => setSelected(f.path)}
                  className={`block w-full truncate rounded px-2 py-0.5 text-left text-[11px] ${
                    selected === f.path ? "bg-[#152033] text-sky-200" : "text-[#8ba3bb] hover:text-[#dbe4ee]"
                  }`}
                >
                  {f.path.split("/").pop()}
                </button>
              ))}
            </div>
          ))}
        </aside>

        <section className="flex min-h-0 flex-col bg-[#070b11]">
          <div className="flex items-center justify-between gap-2 border-b border-[#1b2531] px-3 py-1.5 text-[11px] text-[#7d93ab]">
            <span className="truncate">{selected ?? "выберите файл или опишите программу в чате →"}</span>
            <div className="flex items-center gap-2">
              {dirty && <span className="text-amber-300">не сохранено</span>}
              <button
                type="button"
                onClick={() => void saveFile()}
                disabled={!dirty || busy === "save"}
                className="rounded border border-[#26344a] px-2 py-0.5 text-[10px] uppercase disabled:opacity-30"
              >
                сохранить
              </button>
            </div>
          </div>
          {running && (
            <div className="h-1 bg-[#141d27]">
              <div className="h-full bg-lime-400 transition-all" style={{ width: `${Math.max(4, status.progress)}%` }} />
            </div>
          )}
          <textarea
            value={content}
            onChange={(e) => {
              setContent(e.target.value);
              setDirty(true);
            }}
            spellCheck={false}
            className="min-h-0 flex-1 resize-none bg-transparent p-4 font-mono text-[12px] leading-relaxed text-[#dbe4ee] outline-none"
            placeholder="Здесь появится код. Напишите в чате справа, что собрать — как в Cursor."
          />
        </section>

        <aside className="flex min-h-0 flex-col border-l border-[#1b2531] bg-[#0b1017]">
          <div className="border-b border-[#1b2531] px-3 py-2 text-[10px] uppercase tracking-wider text-[#5f738a]">
            агент {status.name ? `· ${status.name}` : ""} {running ? `· ${status.stage} ${status.progress}%` : ""}
          </div>
          <div className="min-h-0 flex-1 space-y-2 overflow-auto p-3 text-[12px]">
            {chats.length === 0 && events.length === 0 && (
              <div className="space-y-2 text-[#7d93ab]">
                <p>Как Cursor, только в браузере: опишите программу — рой соберёт репозиторий. Потом допишите «добавь тесты / смени CLI» — агент правит файлы.</p>
                <div className="flex flex-wrap gap-1">
                  {STARTERS.map((s) => (
                    <button key={s} type="button" onClick={() => setDraft(s)} className="rounded border border-[#1b2531] px-2 py-1 text-[10px] text-[#8ba3bb] hover:text-sky-300">
                      {s.slice(0, 42)}…
                    </button>
                  ))}
                </div>
              </div>
            )}
            {chats.map((c) => (
              <div key={`c${c.id}`} className={`rounded-lg px-2 py-1.5 ${c.role === "user" ? "bg-sky-500/10 text-sky-100" : "bg-[#111a26] text-[#c9d7e5]"}`}>
                <div className="mb-1 text-[9px] uppercase text-[#5f738a]">
                  {c.role} {c.provider ? `· ${c.provider}` : ""}
                </div>
                <div className="whitespace-pre-wrap">{c.content}</div>
              </div>
            ))}
            {events.slice(-8).map((e) => (
              <div key={`e${e.id}`} className="text-[10px] text-[#5f738a]">
                <span className="text-[#7d93ab]">{e.agent}</span> · {e.message}
              </div>
            ))}
            <div ref={chatEnd} />
          </div>
          <form
            className="border-t border-[#1b2531] p-2"
            onSubmit={(e) => {
              e.preventDefault();
              void send();
            }}
          >
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                  e.preventDefault();
                  void send();
                }
              }}
              rows={4}
              placeholder="Опишите программу или правку… Ctrl+Enter"
              className="w-full resize-none rounded-lg border border-[#1b2531] bg-[#070b11] p-2 text-[12px] outline-none focus:border-sky-500/50"
            />
            <button
              type="submit"
              disabled={busy === "chat"}
              className="mt-2 w-full rounded-lg bg-lime-500/90 py-2 text-[12px] font-bold text-black disabled:opacity-40"
            >
              {busy === "chat" ? "агент думает…" : activeId ? "отправить правку" : "собрать проект"}
            </button>
          </form>
        </aside>
      </div>

      {keysOpen && (
        <div className="fixed inset-0 z-20 flex items-start justify-center overflow-auto bg-black/70 p-4">
          <div className="w-full max-w-3xl rounded-xl border border-[#26344a] bg-[#0b1017] p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-semibold uppercase tracking-wide text-amber-200">Панель ключей — модели не удаляются</h2>
              <button type="button" onClick={() => setKeysOpen(false)} className="text-[11px] text-[#8ba3bb]">
                закрыть
              </button>
            </div>
            <p className="mb-3 text-[12px] text-[#7d93ab]">
              Каждая модель остаётся в списке. Без ключа она просто ждёт. Вставьте ключ — канал сразу участвует в vibe-кодинге. Безключевые (Pollinations, встроенный движок) работают и так.
            </p>
            <div className="max-h-[70vh] space-y-2 overflow-auto">
              {slots.map((s) => (
                <div key={s.envKey} className="rounded-lg border border-[#1b2531] bg-[#080c12] p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="text-[12px] text-[#dbe4ee]">{s.label}</div>
                      <div className="text-[10px] text-[#5f738a]">
                        {s.envKey} · {s.model || "модель по умолчанию"}
                      </div>
                    </div>
                    <Badge tone={s.hasValue || s.fromEnv ? "lime" : "amber"}>{s.hasValue || s.fromEnv ? "ключ есть" : "нет ключа"}</Badge>
                  </div>
                  <p className="mt-1 text-[11px] text-[#5f738a]">{s.note}</p>
                  {s.masked && <p className="mt-1 text-[10px] text-[#4d5f74]">сейчас: {s.masked}{s.fromEnv ? " (из env)" : ""}</p>}
                  <div className="mt-2 flex flex-wrap gap-2">
                    <input
                      type="password"
                      value={keyDrafts[s.envKey] ?? ""}
                      onChange={(e) => setKeyDrafts((d) => ({ ...d, [s.envKey]: e.target.value }))}
                      placeholder="вставьте API-ключ"
                      className="min-w-[220px] flex-1 rounded border border-[#26344a] bg-[#070b11] px-2 py-1 text-[12px] outline-none focus:border-amber-500/50"
                    />
                    <button
                      type="button"
                      onClick={() => void saveKey(s.envKey)}
                      disabled={busy === `key:${s.envKey}`}
                      className="rounded border border-lime-500/40 px-2 py-1 text-[10px] uppercase text-lime-300"
                    >
                      сохранить
                    </button>
                    {s.hasValue && !s.fromEnv && (
                      <button type="button" onClick={() => void deleteKey(s.envKey)} className="rounded border border-red-500/30 px-2 py-1 text-[10px] uppercase text-red-300">
                        удалить
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
