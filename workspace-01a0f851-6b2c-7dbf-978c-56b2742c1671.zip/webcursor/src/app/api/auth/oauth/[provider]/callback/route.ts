import { createSession, ensureSeed, sessionCookieHeader } from "@/lib/auth";
import { consumeState, findOrCreateSocialUser, isOAuthProvider, OAUTH_PROVIDERS, publicOrigin } from "@/lib/oauth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

async function handle(request: Request, providerParam: string, code: string | null, state: string | null) {
  if (!isOAuthProvider(providerParam)) return redirectError("unknown");
  const def = OAUTH_PROVIDERS[providerParam];
  if (!code || !state) return redirectError("cancelled");
  const provider = consumeState(state);
  if (!provider || provider !== providerParam) return redirectError("state");
  try {
    const redirectUri = `${publicOrigin(request)}/api/auth/oauth/${providerParam}/callback`;
    const tokens = await def.exchange(code, redirectUri);
    const profile = await def.profile(tokens);
    if (!profile.id) return redirectError("profile");
    await ensureSeed();
    const user = await findOrCreateSocialUser(providerParam, profile);
    const { token } = await createSession(user.id);
    return new Response(null, {
      status: 302,
      headers: { location: "/", "set-cookie": sessionCookieHeader(token) },
    });
  } catch {
    return redirectError("failed");
  }
}

function redirectError(reason: string): Response {
  return new Response(null, { status: 302, headers: { location: `/?oauthError=${reason}` } });
}

export async function GET(request: Request, ctx: { params: Promise<{ provider: string }> }) {
  const { provider } = await ctx.params;
  const url = new URL(request.url);
  return handle(request, provider, url.searchParams.get("code"), url.searchParams.get("state"));
}

/* Apple присылает колбэк формой (response_mode=form_post) */
export async function POST(request: Request, ctx: { params: Promise<{ provider: string }> }) {
  const { provider } = await ctx.params;
  const form = await request.formData().catch(() => null);
  const code = form ? String(form.get("code") ?? "") : null;
  const state = form ? String(form.get("state") ?? "") : null;
  return handle(request, provider, code, state);
}
