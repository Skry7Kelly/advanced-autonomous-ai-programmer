import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { proxies } from "@/db/schema";
import { checkEndpoint } from "@/lib/net";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  const rows = await db.select().from(proxies).orderBy(desc(proxies.id));
  return Response.json({
    proxies: rows,
    envHint: "Добавьте прокси в PROXY_LIST (через запятую) или здесь — рой будет ходить в интернет через них.",
  });
}

export async function POST(request: Request) {
  let body: { action?: string; urls?: string; id?: number } = {};
  try {
    body = (await request.json()) as { action?: string; urls?: string; id?: number };
  } catch {
    return Response.json({ error: "некорректный JSON" }, { status: 400 });
  }

  if (body.action === "add" || (!body.action && body.urls)) {
    const urls = (body.urls ?? "")
      .split(/[\s,\n]+/)
      .map((u) => u.trim())
      .filter((u) => /^(http|https|socks4|socks5):\/\//i.test(u));
    if (urls.length === 0) return Response.json({ error: "нет валидных адресов (нужен префикс http:// или socks5://)" }, { status: 400 });
    const inserted = await db
      .insert(proxies)
      .values(urls.map((url) => ({ url, protocol: url.split(":")[0].toLowerCase(), status: "unknown" })))
      .returning();
    return Response.json({ added: inserted.length, proxies: inserted }, { status: 201 });
  }

  if (body.action === "check") {
    const rows = body.id
      ? await db.select().from(proxies).where(eq(proxies.id, body.id))
      : await db.select().from(proxies).orderBy(desc(proxies.id)).limit(20);
    const results: { url: string; status: string; ms: number | null }[] = [];
    for (const row of rows) {
      const target = row.protocol === "http" || row.protocol === "https"
        ? "https://api.github.com/zen"
        : "https://pirateface.co/s/qwen";
      const res = await checkEndpoint(target, true).catch(() => ({ ok: false, ms: 0, status: 0, error: "fail", via: row.url, text: "" }));
      const alive = res.ok && res.via === row.url;
      const status = alive ? "alive" : res.ok ? "suspicious" : "dead";
      await db
        .update(proxies)
        .set({
          status,
          latencyMs: res.via === row.url ? res.ms : null,
          okCount: alive ? row.okCount + 1 : row.okCount,
          failCount: alive ? row.failCount : row.failCount + 1,
          lastCheckedAt: new Date(),
        })
        .where(eq(proxies.id, row.id));
      results.push({ url: row.url, status, ms: res.via === row.url ? res.ms : null });
    }
    const fresh = await db.select().from(proxies).orderBy(desc(proxies.id));
    return Response.json({ checked: results.length, results, proxies: fresh });
  }

  if (body.action === "remove" && body.id) {
    await db.delete(proxies).where(eq(proxies.id, body.id));
    return Response.json({ ok: true });
  }

  return Response.json({ error: "неизвестное действие" }, { status: 400 });
}
