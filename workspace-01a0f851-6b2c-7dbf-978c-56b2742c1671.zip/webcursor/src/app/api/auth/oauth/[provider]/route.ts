import { createSession, ensureSeed, sessionCookieHeader } from "@/lib/auth";
import { createState, findOrCreateSocialUser, isOAuthProvider, OAUTH_PROVIDERS, publicOrigin } from "@/lib/oauth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request, ctx: { params: Promise<{ provider: string }> }) {
  const { provider } = await ctx.params;
  if (!isOAuthProvider(provider)) return Response.json({ error: "Неизвестный провайдер" }, { status: 404 });
  const def = OAUTH_PROVIDERS[provider];

  /* Настоящий OAuth: ключи заданы в окружении */
  if (def.configured()) {
    const redirectUri = `${publicOrigin(request)}/api/auth/oauth/${provider}/callback`;
    const state = createState(provider);
    return new Response(null, { status: 302, headers: { location: def.authorizeUrl(state, redirectUri) } });
  }

  /* Демо-режим: ключей нет — вход в демо-аккаунт провайдера */
  await ensureSeed();
  const user = await findOrCreateSocialUser(provider, {
    id: `demo-${provider}`,
    email: `demo.${provider}@svarma.app`,
    name: `Гость · ${def.label}`,
  });
  const { token } = await createSession(user.id);
  return new Response(null, {
    status: 302,
    headers: { location: "/?welcome=1", "set-cookie": sessionCookieHeader(token) },
  });
}
