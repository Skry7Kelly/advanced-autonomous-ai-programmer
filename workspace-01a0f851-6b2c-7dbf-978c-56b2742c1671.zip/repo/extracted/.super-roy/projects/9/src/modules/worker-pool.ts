export interface PoolStats { items: number; done: number; failed: number; concurrency: number }

export async function mapPool<T, R>(
  items: T[],
  concurrency: number,
  worker: (item: T, index: number) => Promise<R>,
  onProgress?: (stats: PoolStats) => void,
): Promise<{ results: R[]; errors: { index: number; error: unknown }[] }> {
  const results = new Array<R>(items.length);
  const errors: { index: number; error: unknown }[] = [];
  let cursor = 0;
  let done = 0;
  let failed = 0;
  const lanes = Array.from({ length: Math.max(1, Math.min(concurrency, items.length || 1)) }, async () => {
    while (cursor < items.length) {
      const index = cursor++;
      try {
        results[index] = await worker(items[index], index);
        done += 1;
      } catch (error) {
        failed += 1;
        errors.push({ index, error });
      }
      onProgress?.({ items: items.length, done: done + failed, failed, concurrency });
    }
  });
  await Promise.all(lanes);
  return { results, errors };
}

export function chunk<T>(items: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < items.length; i += size) out.push(items.slice(i, i + size));
  return out;
}