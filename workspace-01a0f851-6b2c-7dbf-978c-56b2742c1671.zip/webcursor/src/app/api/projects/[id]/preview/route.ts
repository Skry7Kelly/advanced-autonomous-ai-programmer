import { eq } from "@/db/orm";
import { db } from "@/db";
import { artifacts, projects } from "@/db/schema";
import { getAuthUser } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/**
 * Живое превью сгенерированного приложения: index.html из артефактов
 * (с инлайном локальных css/js) либо интерактивный дашборд спецификации.
 */
export async function GET(request: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(request);
  if (!user) return new Response("unauthorized", { status: 401 });
  const { id } = await ctx.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) return new Response("bad id", { status: 400 });
  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project || project.userId !== user.id) return new Response("проект не найден", { status: 404 });
  const rows = await db.select().from(artifacts).where(eq(artifacts.projectId, projectId));
  const byPath = new Map(rows.map((r) => [r.path, r]));

  /* 1) Настоящий index.html в артефактах */
  const html = byPath.get("index.html") ?? byPath.get("public/index.html") ?? byPath.get("src/public/index.html");
  if (html) {
    let content = html.content;
    content = content.replace(/<link[^>]+href=["']([^"']+\.css)["'][^>]*>/gi, (m, href: string) => {
      const asset = byPath.get(href.replace(/^\.?\//, ""));
      return asset ? `<style>\n${asset.content}\n</style>` : m;
    });
    content = content.replace(/<script[^>]+src=["']([^"']+\.m?js)["'][^>]*>\s*<\/script>/gi, (m, src: string) => {
      const asset = byPath.get(src.replace(/^\.?\//, ""));
      return asset ? `<script>\n${asset.content}\n</script>` : m;
    });
    return new Response(content, {
      headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" },
    });
  }

  /* 2) Дашборд-превью проекта */
  const spec = project.spec;
  const stats = project.stats ?? {};
  const endpoints = spec?.endpoints ?? [];
  const modules = spec?.modules ?? [];
  const tables = spec?.tables ?? [];
  const milestones = spec?.milestones ?? [];

  const card = (title: string, value: string | number, sub = "") =>
    `<div class="card"><div class="card-title">${escapeHtml(title)}</div><div class="card-value">${escapeHtml(String(value))}</div>${
      sub ? `<div class="card-sub">${escapeHtml(sub)}</div>` : ""
    }</div>`;

  const endpointRow = (e: (typeof endpoints)[number]) =>
    `<div class="row"><span class="method m-${e.method.toLowerCase()}">${e.method}</span><span class="path">${escapeHtml(e.path)}</span><span class="purpose">${escapeHtml(e.purpose)}</span></div>`;

  const moduleRow = (m: (typeof modules)[number]) =>
    `<div class="row"><span class="chip">${escapeHtml(m.name)}</span><span class="purpose">${escapeHtml(m.purpose)}</span><span class="origin o-${m.origin}">${m.origin}</span></div>`;

  const milestoneRow = (ms: (typeof milestones)[number]) =>
    `<div class="ms"><div class="ms-title">M${ms.index + 1}. ${escapeHtml(ms.title)}</div><div class="ms-done">${escapeHtml(ms.doneWhen)}</div></div>`;

  const page = `<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Превью — ${escapeHtml(project.name)}</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
    background: #0b0e14; color: #dbe2f0; padding: 28px; line-height: 1.55; }
  .wrap { max-width: 980px; margin: 0 auto; }
  h1 { font-size: 22px; letter-spacing: -0.02em; margin-bottom: 4px;
    background: linear-gradient(90deg, #7dd3fc, #a78bfa); -webkit-background-clip: text; background-clip: text; color: transparent; }
  .sub { color: #8b95ab; font-size: 13px; margin-bottom: 24px; }
  .status { display: inline-block; padding: 2px 10px; border-radius: 99px; font-size: 11px; font-weight: 600;
    background: rgba(125, 211, 252, .12); color: #7dd3fc; border: 1px solid rgba(125, 211, 252, .25); vertical-align: 2px; margin-left: 8px; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; margin-bottom: 28px; }
  .card { background: #12161f; border: 1px solid #232a38; border-radius: 14px; padding: 14px 16px; }
  .card-title { font-size: 11px; text-transform: uppercase; letter-spacing: .08em; color: #7d879c; }
  .card-value { font-size: 26px; font-weight: 700; margin-top: 4px; color: #eef2fa; }
  .card-sub { font-size: 11px; color: #7d879c; margin-top: 2px; }
  h2 { font-size: 13px; text-transform: uppercase; letter-spacing: .1em; color: #8b95ab; margin: 26px 0 12px; }
  .row { display: flex; gap: 10px; align-items: baseline; padding: 8px 12px; border-radius: 10px; background: #12161f;
    border: 1px solid #1d2432; margin-bottom: 6px; font-size: 13px; }
  .method { font-weight: 700; font-size: 11px; min-width: 52px; }
  .m-get { color: #6ee7b9; } .m-post { color: #7dd3fc; } .m-put, .m-patch { color: #fbbf24; } .m-delete { color: #fb7185; }
  .path { font-family: ui-monospace, 'JetBrains Mono', monospace; color: #eef2fa; min-width: 180px; }
  .purpose { color: #8b95ab; flex: 1; }
  .chip { font-family: ui-monospace, 'JetBrains Mono', monospace; font-size: 12px; color: #c4b5fd; min-width: 140px; }
  .origin { font-size: 10px; text-transform: uppercase; padding: 2px 8px; border-radius: 99px; border: 1px solid; }
  .o-generated { color: #7dd3fc; border-color: rgba(125,211,252,.3); }
  .o-forged { color: #fbbf24; border-color: rgba(251,191,36,.3); }
  .o-adopted { color: #6ee7b9; border-color: rgba(110,231,185,.3); }
  .ms { padding: 10px 14px; border-left: 2px solid #a78bfa; background: linear-gradient(90deg, rgba(167,139,250,.08), transparent); border-radius: 0 10px 10px 0; margin-bottom: 8px; }
  .ms-title { font-weight: 600; font-size: 13px; color: #eef2fa; }
  .ms-done { font-size: 12px; color: #8b95ab; }
  .empty { color: #7d879c; font-size: 13px; padding: 18px; text-align: center; border: 1px dashed #2a3242; border-radius: 12px; }
  .bar { height: 6px; border-radius: 99px; background: #1d2432; overflow: hidden; margin: 10px 0 26px; }
  .bar > div { height: 100%; border-radius: 99px; background: linear-gradient(90deg, #7dd3fc, #a78bfa); transition: width .6s ease; }
</style>
</head>
<body><div class="wrap">
  <h1>${escapeHtml(project.name)} <span class="status">${escapeHtml(project.status)}</span></h1>
  <div class="sub">${escapeHtml(spec?.summary ?? project.brief.slice(0, 160))}</div>
  <div class="bar"><div style="width:${Math.max(4, project.progress)}%"></div></div>
  <div class="grid">
    ${card("Файлов", stats.files ?? rows.length)}
    ${card("Модулей", modules.length, spec ? "в спецификации" : "")}
    ${card("Эндпоинтов", endpoints.length)}
    ${card("Таблиц", tables.length)}
    ${card("QA", stats.qaScore ?? "—", "из 100")}
    ${card("Размер", `${((stats.bytes ?? rows.reduce((a, r) => a + r.bytes, 0)) / 1024).toFixed(1)} КБ`)}
  </div>
  ${endpoints.length ? `<h2>REST API</h2>${endpoints.map(endpointRow).join("")}` : ""}
  ${modules.length ? `<h2>Модули</h2>${modules.map(moduleRow).join("")}` : ""}
  ${milestones.length ? `<h2>Вехи</h2>${milestones.map(milestoneRow).join("")}` : ""}
  ${rows.length === 0 ? `<div class="empty">Рой ещё не сгенерировал файлы. Запустите сборку — превью обновится автоматически.</div>` : ""}
</div></body></html>`;

  return new Response(page, {
    headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" },
  });
}
