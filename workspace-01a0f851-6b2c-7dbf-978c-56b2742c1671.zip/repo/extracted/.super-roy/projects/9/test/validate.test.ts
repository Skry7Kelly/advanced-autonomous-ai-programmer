import test from 'node:test';
import assert from 'node:assert/strict';
import { validate } from '../src/modules/validate.js';

test('ловит неверный вход', () => {
  const issues = validate({ q: '' }, { type: 'object', fields: { q: { type: 'string', min: 2 } } });
  assert.equal(issues.length, 1);
  assert.equal(issues[0].path, '$.q');
});