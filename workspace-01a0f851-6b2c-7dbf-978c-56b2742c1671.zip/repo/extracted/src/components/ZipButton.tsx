"use client";

import { useState } from "react";

export default function ZipButton({ projectId, disabled }: { projectId: number; disabled?: boolean }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  return (
    <span className="inline-flex flex-col items-end">
      <button
        type="button"
        disabled={disabled || busy}
        onClick={async (event) => {
          event.preventDefault();
          event.stopPropagation();
          setBusy(true);
          setError(null);
          try {
            const res = await fetch(`/api/projects/${projectId}/bundle`, { cache: "no-store" });
            const type = res.headers.get("content-type") ?? "";
            if (!res.ok || !type.includes("zip")) {
              setError((await res.text()).slice(0, 120));
              return;
            }
            const blob = await res.blob();
            const cd = res.headers.get("content-disposition") ?? "";
            const match = cd.match(/filename="([^"]+)"/);
            const name = match?.[1] ?? `super-roy-${projectId}.zip`;
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = name;
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1500);
          } catch (err) {
            setError(err instanceof Error ? err.message : String(err));
          } finally {
            setBusy(false);
          }
        }}
        className="rounded-md border border-lime-500/40 bg-lime-500/10 px-2 py-1 text-[10px] uppercase tracking-wide text-lime-300 hover:bg-lime-500/20 disabled:opacity-40"
      >
        {busy ? "zip…" : "скачать zip"}
      </button>
      {error && <span className="mt-1 max-w-[180px] text-[10px] text-amber-300">{error}</span>}
    </span>
  );
}
