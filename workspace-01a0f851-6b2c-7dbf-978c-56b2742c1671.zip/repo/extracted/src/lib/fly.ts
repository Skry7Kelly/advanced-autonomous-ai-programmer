import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { flyBrains, memories } from "@/db/schema";

/**
 * МОЗГ МУХИ (FlyHash / FlyLSH)
 * ------------------------------------------------------------------
 * Реализация алгоритма из Dasgupta, Sheehan, Stevens, Navlakha,
 * "A neural algorithm for a fundamental computing problem", Science 2017:
 *   1. вход (запах / текст) кодируется разреженным вектором (N=2048),
 *   2. случайная разреженная проекция в ~8x большее пространство (M=16384),
 *   3. winner-take-all: остаётся только k самых сильных нейронов
 *      (кеноциды / Kenyon cells) -> бинарный "тег",
 *   4. похожие входы дают пересекающиеся теги => LSH-поиск за O(k).
 *
 * ГЕНЕТИКА: матрица проекции детерминированно выводится из генома
 * (массив сидов блоков). Поэтому мозги можно СКРЕЩИВАТЬ:
 * равномерный кроссовер блоков двух родителей + точечные мутации,
 * отбор по fitness = recall@10 против "учителя" (косинус по сырым векторам).
 */

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function fnv1a(str: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

const STOP = new Set([
  "и","в","на","с","по","для","что","это","как","не","а","из","у","же","то","к","о","за","от","до",
  "the","a","an","of","to","in","for","on","and","or","is","are","be","with","that","this","it",
]);

export function tokenize(text: string): string[] {
  const raw = text
    .toLowerCase()
    .replace(/[`"'()\[\]{}<>;,!:?.]/g, " ")
    .split(/[\s_/\\|+*#&$@%~^\-]+/g);
  const words = raw
    .map((w) => w.trim())
    .filter((w) => w.length > 1 && w.length < 40 && !STOP.has(w) && !/^\d+$/.test(w));
  const out: string[] = [...words];
  // биграммы слов — они несут синтаксис запроса
  for (let i = 0; i < words.length - 1; i++) out.push(`${words[i]}_${words[i + 1]}`);
  // символьные 4-граммы — ловят опечатки, код, идентификаторы
  const joined = words.join(" ");
  for (let i = 0; i + 4 <= joined.length; i += 2) out.push(joined.slice(i, i + 4));
  return out;
}

export function hashText(text: string, dim = 2048): Map<number, number> {
  const vec = new Map<number, number>();
  for (const tok of tokenize(text)) {
    const h = fnv1a(tok);
    const idx = h % dim;
    // две "сенсорные" ячейки на токен — как ORN, отвечающие на несколько рецепторов
    const idx2 = (idx ^ (h >>> 13)) % dim;
    vec.set(idx, (vec.get(idx) ?? 0) + 1);
    vec.set(idx2, (vec.get(idx2) ?? 0) + 0.5);
  }
  return vec;
}

export interface FlyGenome {
  seed: number;
  blocks: number[];
  inputDim: number;
  outputDim: number;
  conn: number;
  k: number;
}

export function randomGenome(opts: {
  seed: number;
  inputDim?: number;
  outputDim?: number;
  conn?: number;
  blocks?: number;
}): FlyGenome {
  const inputDim = opts.inputDim ?? 2048;
  const outputDim = opts.outputDim ?? 16384;
  const conn = opts.conn ?? 24;
  const blocks = opts.blocks ?? 64;
  const rng = mulberry32(opts.seed);
  return {
    seed: opts.seed,
    blocks: Array.from({ length: blocks }, () => Math.floor(rng() * 0xfffffff) + 1),
    inputDim,
    outputDim,
    conn,
    k: Math.max(16, Math.round(outputDim * 0.008)),
  };
}

/** Проекция "антеннальная доля -> грибовидное тело" + winner-take-all. */
export function flyTag(genome: FlyGenome, vec: Map<number, number>): number[] {
  const blockSize = Math.max(1, Math.floor(genome.outputDim / genome.blocks.length));
  const sums = new Float64Array(genome.blocks.length * blockSize);
  for (let b = 0; b < genome.blocks.length; b++) {
    const rng = mulberry32(genome.blocks[b]);
    const base = b * blockSize;
    for (let j = 0; j < blockSize; j++) {
      let acc = 0;
      for (let e = 0; e < genome.conn; e++) {
        const inIdx = Math.floor(rng() * genome.inputDim);
        const sign = rng() < 0.5 ? -1 : 1;
        const v = vec.get(inIdx);
        if (v !== undefined) acc += v * sign;
      }
      sums[base + j] = acc;
    }
  }
  // winner-take-all: k самых активных нейронов
  const idx = Array.from(sums.keys());
  idx.sort((a, b) => sums[b] - sums[a]);
  const tag = idx.slice(0, genome.k).sort((a, b) => a - b);
  return tag;
}

export function tagSimilarity(a: number[], b: number[]): number {
  if (a.length === 0 || b.length === 0) return 0;
  let i = 0;
  let j = 0;
  let inter = 0;
  while (i < a.length && j < b.length) {
    if (a[i] === b[j]) {
      inter++;
      i++;
      j++;
    } else if (a[i] < b[j]) i++;
    else j++;
  }
  return inter / (a.length + b.length - inter);
}

export function cosineSparse(a: Map<number, number>, b: Map<number, number>): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (const [, v] of a) na += v * v;
  for (const [k, v] of b) {
    nb += v * v;
    const av = a.get(k);
    if (av !== undefined) dot += av * v;
  }
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

/** Учебный корпус для отбора мозгов: темы по разработке ПО, RU+EN. */
const TOPICS: { topic: string; samples: string[] }[] = [
  { topic: "proxy", samples: ["http socks5 прокси ротация пул запросов", "rotating proxy pool undici dispatcher socks5", "прокси чекер латентность таймаут бан"] },
  { topic: "llm", samples: ["локальная llm gguf ollama инференс токены", "quantized gguf model inference llama.cpp context", "openrouter free models api ключ лимиты"] },
  { topic: "torrent", samples: ["magnet торрент раздача сиды пиры трекер", "bittorrent tracker seeds peers magnet link", "торрент клиент закачка модели webseed"] },
  { topic: "db", samples: ["postgres миграции drizzle схема таблиц индексы", "sql schema migration index primary key foreign", "база данных транзакции изоляция уровни"] },
  { topic: "api", samples: ["rest api endpoint роуты обработчики json валидация", "http route handler json schema validation middleware", "api лимит запросов rate limit throttling"] },
  { topic: "frontend", samples: ["react компоненты состояние хуки рендер интерфейс", "ui components hooks state rendering tailwind css", "интерфейс форма таблица модальное окно тема"] },
  { topic: "vector", samples: ["векторный поиск эмбеддинги косинус близость индекс", "embedding similarity search cosine nearest neighbor", "lsh хэширование ближайших соседей бакеты"] },
  { topic: "testing", samples: ["юнит тесты покрытие моки ассерты ci прогон", "unit test coverage mocks assertions pipeline", "интеграционные тесты фикстуры снапшоты"] },
  { topic: "scraping", samples: ["парсинг html страницы селекторы краулинг роботс", "html parser selector crawler scraping etiquette", "скрейпинг сайтов обход страниц лимиты запросов"] },
  { topic: "auth", samples: ["аутентификация jwt сессии токены роли доступ", "jwt session auth refresh token rbac permissions", "пароли хэш bcrypt соль двухфакторка"] },
  { topic: "agent", samples: ["агент планировщик задачи инструменты оркестрация рой", "agent planner tools orchestration swarm loop", "мультиагентная система роли память рефлексия"] },
  { topic: "codegen", samples: ["генерация кода шаблоны аст трансформация файлов", "code generation templates ast transform emit", "скаффолд проекта файлы сборка модули"] },
];

export function calibrationCorpus(): { text: string; topic: string }[] {
  const corpus: { text: string; topic: string }[] = [];
  TOPICS.forEach((t, ti) => {
    t.samples.forEach((s, si) => {
      corpus.push({ text: `${s} ${TOPICS[(ti + si) % TOPICS.length].samples[si % 3]}`, topic: t.topic });
    });
    // зашумлённая вариация той же темы — проверка устойчивости
    corpus.push({ text: `${t.samples[0]} ${t.samples[2]} шум данные логи`, topic: t.topic });
  });
  return corpus;
}

export interface FlyEval {
  fitness: number;
  recall: number;
  contrast: number;
  samples: number;
}

export function evaluateGenome(genome: FlyGenome): FlyEval {
  const corpus = calibrationCorpus();
  const inputVecs = corpus.map((c) => hashText(c.text, genome.inputDim));
  const tags = inputVecs.map((v) => flyTag(genome, v));
  let recallSum = 0;
  let contrastSum = 0;
  let samples = 0;
  const K = 8;
  for (let qi = 0; qi < corpus.length; qi++) {
    // учитель: косинус по сырым входным векторам
    const teacher: { i: number; s: number }[] = [];
    for (let ci = 0; ci < corpus.length; ci++) {
      if (ci === qi) continue;
      teacher.push({ i: ci, s: cosineSparse(inputVecs[qi], inputVecs[ci]) });
    }
    teacher.sort((a, b) => b.s - a.s);
    const truth = new Set(teacher.slice(0, K).map((t) => t.i));
    const flyRanking = tags
      .map((tag, i) => ({ i, s: i === qi ? -1 : tagSimilarity(tags[qi], tag) }))
      .sort((a, b) => b.s - a.s)
      .slice(0, K)
      .map((x) => x.i);
    const hits = flyRanking.filter((i) => truth.has(i)).length;
    recallSum += hits / K;
    // контраст: насколько близкие точки реально дальше случайных
    const sameTopicMean =
      corpus
        .map((c, i) => ({ i, same: c.topic === corpus[qi].topic }))
        .filter((x) => x.i !== qi && x.same)
        .reduce((acc, x, _i, arr) => acc + tagSimilarity(tags[qi], tags[x.i]) / arr.length, 0) || 0;
    const diffTopicMean =
      corpus
        .map((c, i) => ({ i, same: c.topic === corpus[qi].topic }))
        .filter((x) => x.i !== qi && !x.same)
        .reduce((acc, x, _i, arr) => acc + tagSimilarity(tags[qi], tags[x.i]) / arr.length, 0) || 0;
    contrastSum += diffTopicMean === 0 ? 0 : sameTopicMean / diffTopicMean;
    samples++;
  }
  const recall = recallSum / Math.max(1, samples);
  const contrast = contrastSum / Math.max(1, samples);
  const fitness = recall * 0.7 + Math.min(2, contrast) * 0.3;
  return { fitness, recall, contrast, samples };
}

export function crossover(a: FlyGenome, b: FlyGenome, mutationRate = 0.14): FlyGenome {
  const rng = mulberry32((a.seed ^ b.seed ^ Date.now()) >>> 0);
  const blocks = a.blocks.map((blk, i) => {
    const fromB = i < b.blocks.length && rng() < 0.5;
    let gene = fromB ? b.blocks[i] : blk;
    if (rng() < mutationRate) gene = Math.floor(rng() * 0xfffffff) + 1;
    return gene;
  });
  return {
    seed: Math.floor(rng() * 0xfffffff) + 1,
    blocks,
    inputDim: a.inputDim,
    outputDim: a.outputDim,
    conn: rng() < 0.25 ? a.conn + (rng() < 0.5 ? -4 : 4) : a.conn,
    k: a.k,
  };
}

export async function ensureFlyBrains(): Promise<void> {
  const existing = await db.select({ id: flyBrains.id }).from(flyBrains).limit(1);
  if (existing.length > 0) return;
  const founders = [
    randomGenome({ seed: 20240917 }),
    randomGenome({ seed: 777001 }),
    randomGenome({ seed: 31337 }),
  ];
  let best = { fitness: -1, index: 0 };
  const rows = founders.map((g, i) => {
    const ev = evaluateGenome(g);
    if (ev.fitness > best.fitness) best = { fitness: ev.fitness, index: i };
    return {
      name: `Musca-domestica-${i + 1}`,
      generation: 0,
      parents: [] as number[],
      inputDim: g.inputDim,
      outputDim: g.outputDim,
      conn: g.conn,
      k: g.k,
      seed: g.seed,
      weights: g.blocks,
      fitness: ev.fitness,
      evals: 1,
      active: false,
      note: `основатель · recall=${ev.recall.toFixed(3)} contrast=${ev.contrast.toFixed(3)}`,
    };
  });
  rows[best.index].active = true;
  await db.insert(flyBrains).values(rows);
}

export async function getActiveBrain() {
  await ensureFlyBrains();
  const rows = await db
    .select()
    .from(flyBrains)
    .where(eq(flyBrains.active, true))
    .orderBy(desc(flyBrains.fitness))
    .limit(1);
  if (rows.length > 0) return rows[0];
  const fallback = await db.select().from(flyBrains).orderBy(desc(flyBrains.fitness)).limit(1);
  return fallback[0];
}

export function genomeOf(row: {
  seed: number;
  weights: number[] | null;
  inputDim: number;
  outputDim: number;
  conn: number;
  k: number;
}): FlyGenome {
  const blocks = row.weights && row.weights.length > 0 ? row.weights : randomGenome({ seed: row.seed }).blocks;
  return {
    seed: row.seed,
    blocks,
    inputDim: row.inputDim,
    outputDim: row.outputDim,
    conn: row.conn,
    k: row.k,
  };
}

/** Скрещивание двух лучших мозгов -> новое поколение (реальный ГА). */
export async function breedGeneration(note = "") {
  await ensureFlyBrains();
  const parents = await db.select().from(flyBrains).orderBy(desc(flyBrains.fitness)).limit(2);
  if (parents.length < 2) throw new Error("нужно минимум 2 мозга для скрещивания");
  const childGenome = crossover(genomeOf(parents[0]), genomeOf(parents[1]));
  const ev = evaluateGenome(childGenome);
  const generation = Math.max(...parents.map((p) => p.generation)) + 1;
  const becomesActive = ev.fitness > parents[0].fitness;
  if (becomesActive) {
    await db.update(flyBrains).set({ active: false }).where(eq(flyBrains.active, true));
  }
  const [child] = await db
    .insert(flyBrains)
    .values({
      name: `Musca-hybrida-G${generation}-${childGenome.seed % 9999}`,
      generation,
      parents: parents.map((p) => p.id),
      inputDim: childGenome.inputDim,
      outputDim: childGenome.outputDim,
      conn: childGenome.conn,
      k: childGenome.k,
      seed: childGenome.seed,
      weights: childGenome.blocks,
      fitness: ev.fitness,
      evals: 1,
      active: becomesActive,
      note:
        note ||
        `кроссовер ${parents[0].name} × ${parents[1].name} · recall=${ev.recall.toFixed(3)} contrast=${ev.contrast.toFixed(3)}`,
    })
    .returning();
  return { child, eval: ev, parents, improved: becomesActive };
}

export async function remember(input: {
  projectId?: number | null;
  kind: string;
  text: string;
  meta?: unknown;
  brainId?: number | null;
}) {
  const brain = await getActiveBrain();
  const tag = flyTag(genomeOf(brain), hashText(input.text, brain.inputDim));
  const [row] = await db
    .insert(memories)
    .values({
      projectId: input.projectId ?? null,
      brainId: brain.id,
      kind: input.kind,
      text: input.text.slice(0, 8000),
      meta: (input.meta ?? null) as Record<string, unknown> | null,
      tag,
    })
    .returning();
  return row;
}

export async function recall(query: string, opts: { limit?: number; projectId?: number | null; kind?: string } = {}) {
  const brain = await getActiveBrain();
  const genome = genomeOf(brain);
  const qTag = flyTag(genome, hashText(query, brain.inputDim));
  const rows = await db
    .select()
    .from(memories)
    .where(
      opts.projectId
        ? and(eq(memories.projectId, opts.projectId))
        : opts.kind
          ? and(eq(memories.kind, opts.kind))
          : undefined,
    )
    .limit(4000);
  return rows
    .map((r) => ({
      id: r.id,
      kind: r.kind,
      text: r.text,
      meta: r.meta,
      createdAt: r.createdAt,
      score: r.tag ? tagSimilarity(qTag, r.tag) : 0,
    }))
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, opts.limit ?? 8);
}

/** Переранжирование списка по близости к запросу — то самое "ускорение мышления". */
export async function flyRerank<T>(
  query: string,
  items: T[],
  textOf: (item: T) => string,
  weight = 0.35,
): Promise<{ items: T[]; scores: number[] }> {
  const brain = await getActiveBrain();
  const genome = genomeOf(brain);
  const qTag = flyTag(genome, hashText(query, brain.inputDim));
  const scored = items.map((item) => {
    const tag = flyTag(genome, hashText(textOf(item), brain.inputDim));
    return { item, score: tagSimilarity(qTag, tag) };
  });
  scored.sort((a, b) => b.score - a.score);
  return { items: scored.map((s) => s.item), scores: scored.map((s) => s.score * weight) };
}
