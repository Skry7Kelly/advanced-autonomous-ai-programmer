import { eq } from "@/db/orm";
import { db } from "@/db";
import { providers } from "@/db/schema";
import { checkEndpoint } from "@/lib/net";
import { loadSecrets, secretValue } from "@/lib/secrets";

export interface ProviderDef {
  key: string;
  label: string;
  kind: "chat" | "model-index" | "local";
  baseUrl: string;
  model: string;
  envKey: string;
  priority: number;
  note: string;
  keyless: boolean;
}

export const PROVIDER_DEFS: ProviderDef[] = [
  {
    key: "pollinations",
    label: "Pollinations (без ключа, gpt-oss)",
    kind: "chat",
    baseUrl: "https://text.pollinations.ai/openai",
    model: process.env.POLLINATIONS_MODEL ?? "openai",
    envKey: "",
    priority: 12,
    keyless: true,
    note: "Бесплатный OpenAI-совместимый шлюз. Работает сразу, без регистрации.",
  },
  {
    key: "pollinations-mistral",
    label: "Pollinations (без ключа, mistral)",
    kind: "chat",
    baseUrl: "https://text.pollinations.ai/openai",
    model: "mistral",
    envKey: "",
    priority: 14,
    keyless: true,
    note: "Запасной безключевой канал на другой модели.",
  },
  {
    key: "ollama",
    label: "Ollama (локально)",
    kind: "local",
    baseUrl: process.env.OLLAMA_BASE_URL ?? "http://127.0.0.1:11434",
    model: process.env.OLLAMA_MODEL ?? "",
    envKey: "",
    priority: 8,
    keyless: true,
    note: "Локальные веса: OLLAMA_MODEL=qwen2.5-coder:7b и ollama serve.",
  },
  {
    key: "llamacpp",
    label: "llama.cpp server (локально)",
    kind: "local",
    baseUrl: process.env.LLAMACPP_BASE_URL ?? "http://127.0.0.1:8080",
    model: process.env.LLAMACPP_MODEL ?? "local-gguf",
    envKey: "",
    priority: 16,
    keyless: true,
    note: "GGUF с PirateFace: llama-server -m model.gguf --port 8080",
  },
  {
    key: "lmstudio",
    label: "LM Studio (локально)",
    kind: "local",
    baseUrl: process.env.LMSTUDIO_BASE_URL ?? "http://127.0.0.1:1234",
    model: process.env.LMSTUDIO_MODEL ?? "local",
    envKey: "",
    priority: 18,
    keyless: true,
    note: "OpenAI-совместимый /v1/chat/completions",
  },
  {
    key: "openrouter",
    label: "OpenRouter :free",
    kind: "chat",
    baseUrl: "https://openrouter.ai/api/v1",
    model: process.env.OPENROUTER_MODEL ?? "",
    envKey: "OPENROUTER_API_KEY",
    priority: 40,
    keyless: false,
    note: "Бесплатные модели с суффиксом :free. Нужен OPENROUTER_API_KEY.",
  },
  {
    key: "groq",
    label: "Groq (free tier)",
    kind: "chat",
    baseUrl: "https://api.groq.com/openai/v1",
    model: process.env.GROQ_MODEL ?? "llama-3.3-70b-versatile",
    envKey: "GROQ_API_KEY",
    priority: 42,
    keyless: false,
    note: "Очень быстрый бесплатный тариф. Нужен GROQ_API_KEY.",
  },
  {
    key: "gemini",
    label: "Google Gemini (free tier)",
    kind: "chat",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
    model: process.env.GEMINI_MODEL ?? "gemini-2.0-flash",
    envKey: "GEMINI_API_KEY",
    priority: 44,
    keyless: false,
    note: "OpenAI-совместимый эндпоинт. Нужен GEMINI_API_KEY.",
  },
  {
    key: "cerebras",
    label: "Cerebras (free tier)",
    kind: "chat",
    baseUrl: "https://api.cerebras.ai/v1",
    model: process.env.CEREBRAS_MODEL ?? "llama-3.3-70b",
    envKey: "CEREBRAS_API_KEY",
    priority: 46,
    keyless: false,
    note: "Нужен CEREBRAS_API_KEY.",
  },
  {
    key: "huggingface",
    label: "Hugging Face Router",
    kind: "chat",
    baseUrl: "https://router.huggingface.co/v1",
    model: process.env.HF_MODEL ?? "Qwen/Qwen2.5-Coder-32B-Instruct",
    envKey: "HF_TOKEN",
    priority: 48,
    keyless: false,
    note: "Нужен HF_TOKEN.",
  },
  {
    key: "mistral",
    label: "Mistral (free tier)",
    kind: "chat",
    baseUrl: "https://api.mistral.ai/v1",
    model: process.env.MISTRAL_MODEL ?? "mistral-small-latest",
    envKey: "MISTRAL_API_KEY",
    priority: 50,
    keyless: false,
    note: "Ключ с console.mistral.ai — вставьте в панели ключей.",
  },
  {
    key: "openai",
    label: "OpenAI (GPT)",
    kind: "chat",
    baseUrl: "https://api.openai.com/v1",
    model: process.env.OPENAI_MODEL ?? "gpt-4o-mini",
    envKey: "OPENAI_API_KEY",
    priority: 52,
    keyless: false,
    note: "Ключ с platform.openai.com — вставьте в панели ключей.",
  },
  {
    key: "deepseek",
    label: "DeepSeek",
    kind: "chat",
    baseUrl: "https://api.deepseek.com",
    model: process.env.DEEPSEEK_MODEL ?? "deepseek-chat",
    envKey: "DEEPSEEK_API_KEY",
    priority: 54,
    keyless: false,
    note: "Ключ с platform.deepseek.com — вставьте в панели ключей.",
  },
  {
    key: "together",
    label: "Together AI",
    kind: "chat",
    baseUrl: "https://api.together.xyz/v1",
    model: process.env.TOGETHER_MODEL ?? "Qwen/Qwen2.5-Coder-32B-Instruct",
    envKey: "TOGETHER_API_KEY",
    priority: 56,
    keyless: false,
    note: "Ключ с api.together.xyz — вставьте в панели ключей.",
  },
  {
    key: "fireworks",
    label: "Fireworks AI",
    kind: "chat",
    baseUrl: "https://api.fireworks.ai/inference/v1",
    model: process.env.FIREWORKS_MODEL ?? "accounts/fireworks/models/llama-v3p1-8b-instruct",
    envKey: "FIREWORKS_API_KEY",
    priority: 58,
    keyless: false,
    note: "Ключ с fireworks.ai — вставьте в панели ключей.",
  },
  {
    key: "nvidia",
    label: "NVIDIA NIM",
    kind: "chat",
    baseUrl: "https://integrate.api.nvidia.com/v1",
    model: process.env.NVIDIA_MODEL ?? "meta/llama-3.1-8b-instruct",
    envKey: "NVIDIA_API_KEY",
    priority: 60,
    keyless: false,
    note: "Ключ с build.nvidia.com — вставьте в панели ключей.",
  },
  {
    key: "anthropic",
    label: "Anthropic Claude",
    kind: "chat",
    baseUrl: "https://api.anthropic.com/v1",
    model: process.env.ANTHROPIC_MODEL ?? "claude-3-5-haiku-20241022",
    envKey: "ANTHROPIC_API_KEY",
    priority: 62,
    keyless: false,
    note: "Ключ с console.anthropic.com — вставьте в панели ключей.",
  },
  {
    key: "vllm",
    label: "vLLM (локально)",
    kind: "local",
    baseUrl: process.env.VLLM_BASE_URL ?? "http://127.0.0.1:8000/v1",
    model: process.env.VLLM_MODEL ?? "",
    envKey: "",
    priority: 19,
    keyless: true,
    note: "vllm serve <модель> --port 8000. Модель задайте через VLLM_MODEL.",
  },
  {
    key: "jan",
    label: "Jan (локально)",
    kind: "local",
    baseUrl: process.env.JAN_BASE_URL ?? "http://127.0.0.1:1337/v1",
    model: process.env.JAN_MODEL ?? "",
    envKey: "",
    priority: 20,
    keyless: true,
    note: "Jan.app с локальным сервером API. Модель — через JAN_MODEL.",
  },
  {
    key: "xai",
    label: "xAI Grok",
    kind: "chat",
    baseUrl: "https://api.x.ai/v1",
    model: process.env.XAI_MODEL ?? "grok-4",
    envKey: "XAI_API_KEY",
    priority: 63,
    keyless: false,
    note: "Ключ с console.x.ai — вставьте в панели ключей.",
  },
  {
    key: "cohere",
    label: "Cohere",
    kind: "chat",
    baseUrl: "https://api.cohere.ai/compatibility/v1",
    model: process.env.COHERE_MODEL ?? "command-a-03-2025",
    envKey: "COHERE_API_KEY",
    priority: 64,
    keyless: false,
    note: "OpenAI-совместимый эндпоинт Cohere. Ключ с dashboard.cohere.com.",
  },
  {
    key: "perplexity",
    label: "Perplexity (Sonar)",
    kind: "chat",
    baseUrl: "https://api.perplexity.ai",
    model: process.env.PERPLEXITY_MODEL ?? "sonar",
    envKey: "PERPLEXITY_API_KEY",
    priority: 65,
    keyless: false,
    note: "Модели с онлайн-поиском: sonar, sonar-pro, sonar-reasoning.",
  },
  {
    key: "moonshot",
    label: "Moonshot AI (Kimi)",
    kind: "chat",
    baseUrl: "https://api.moonshot.ai/v1",
    model: process.env.MOONSHOT_MODEL ?? "kimi-k2-0905-preview",
    envKey: "MOONSHOT_API_KEY",
    priority: 66,
    keyless: false,
    note: "Kimi K2. Ключ с platform.moonshot.ai.",
  },
  {
    key: "zai",
    label: "Z.AI GLM (междунар.)",
    kind: "chat",
    baseUrl: "https://api.z.ai/api/paas/v4",
    model: process.env.ZAI_MODEL ?? "glm-4.5",
    envKey: "ZAI_API_KEY",
    priority: 67,
    keyless: false,
    note: "GLM-4.5/4.6 от Z.AI (интернациональный домен).",
  },
  {
    key: "glm",
    label: "Zhipu GLM (Китай)",
    kind: "chat",
    baseUrl: "https://open.bigmodel.cn/api/paas/v4",
    model: process.env.GLM_MODEL ?? "glm-4.5",
    envKey: "GLM_API_KEY",
    priority: 68,
    keyless: false,
    note: "GLM с bigmodel.cn (бесплатный glm-4-flash через GLM_MODEL).",
  },
  {
    key: "qwen",
    label: "Alibaba Qwen (DashScope)",
    kind: "chat",
    baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1",
    model: process.env.QWEN_MODEL ?? "qwen-max",
    envKey: "DASHSCOPE_API_KEY",
    priority: 69,
    keyless: false,
    note: "Qwen3/Qwen-Coder. Ключ с dashscope.console.aliyun.com.",
  },
  {
    key: "deepinfra",
    label: "DeepInfra",
    kind: "chat",
    baseUrl: "https://api.deepinfra.com/v1/openai",
    model: process.env.DEEPINFRA_MODEL ?? "Qwen/Qwen2.5-Coder-32B-Instruct",
    envKey: "DEEPINFRA_API_KEY",
    priority: 70,
    keyless: false,
    note: "Дешёвый хостинг open-source моделей. Ключ с deepinfra.com.",
  },
  {
    key: "novita",
    label: "Novita AI",
    kind: "chat",
    baseUrl: "https://api.novita.ai/v3/openai",
    model: process.env.NOVITA_MODEL ?? "qwen/qwen-2.5-72b-instruct",
    envKey: "NOVITA_API_KEY",
    priority: 71,
    keyless: false,
    note: "Агрегатор open-source моделей. Ключ с novita.ai.",
  },
  {
    key: "hyperbolic",
    label: "Hyperbolic",
    kind: "chat",
    baseUrl: "https://api.hyperbolic.xyz/v1",
    model: process.env.HYPERBOLIC_MODEL ?? "Qwen/Qwen2.5-Coder-32B-Instruct",
    envKey: "HYPERBOLIC_API_KEY",
    priority: 72,
    keyless: false,
    note: "GPU-облако с OpenAI-совместимым API. Ключ с hyperbolic.xyz.",
  },
  {
    key: "sambanova",
    label: "SambaNova",
    kind: "chat",
    baseUrl: "https://api.sambanova.ai/v1",
    model: process.env.SAMBANOVA_MODEL ?? "Meta-Llama-3.3-70B-Instruct",
    envKey: "SAMBANOVA_API_KEY",
    priority: 73,
    keyless: false,
    note: "Очень быстрый RDU-инференс. Ключ с cloud.sambanova.ai.",
  },
  {
    key: "lambda",
    label: "Lambda Labs",
    kind: "chat",
    baseUrl: "https://api.lambda.ai/v1",
    model: process.env.LAMBDA_MODEL ?? "llama3.3-70b-instruct",
    envKey: "LAMBDA_API_KEY",
    priority: 74,
    keyless: false,
    note: "Lambda Inference API. Ключ с cloud.lambdalabs.com.",
  },
  {
    key: "ai21",
    label: "AI21 (Jamba)",
    kind: "chat",
    baseUrl: "https://api.ai21.com/studio/v1",
    model: process.env.AI21_MODEL ?? "jamba-1.5-mini",
    envKey: "AI21_API_KEY",
    priority: 75,
    keyless: false,
    note: "Семейство Jamba. Ключ с studio.ai21.com.",
  },
  {
    key: "yi",
    label: "01.AI (Yi)",
    kind: "chat",
    baseUrl: "https://api.lingyiwanwu.com/v1",
    model: process.env.YI_MODEL ?? "yi-large",
    envKey: "YI_API_KEY",
    priority: 76,
    keyless: false,
    note: "Модели Yi от 01.AI. Ключ с platform.lingyiwanwu.com.",
  },
  {
    key: "ernie",
    label: "Baidu ERNIE",
    kind: "chat",
    baseUrl: "https://qianfan.baidubce.com/v2",
    model: process.env.ERNIE_MODEL ?? "ernie-4.5-turbo-128k",
    envKey: "QIANFAN_API_KEY",
    priority: 77,
    keyless: false,
    note: "ERNIE 4.5/5.0 через Qianfan v2 (OpenAI-совместимый).",
  },
  {
    key: "stepfun",
    label: "StepFun",
    kind: "chat",
    baseUrl: "https://api.stepfun.com/v1",
    model: process.env.STEPFUN_MODEL ?? "step-2-16k",
    envKey: "STEPFUN_API_KEY",
    priority: 78,
    keyless: false,
    note: "Китайские модели Step. Ключ с platform.stepfun.com.",
  },
  {
    key: "siliconflow",
    label: "SiliconFlow",
    kind: "chat",
    baseUrl: "https://api.siliconflow.cn/v1",
    model: process.env.SILICONFLOW_MODEL ?? "Qwen/Qwen2.5-Coder-32B-Instruct",
    envKey: "SILICONFLOW_API_KEY",
    priority: 79,
    keyless: false,
    note: "Крупный китайский агрегатор моделей. Ключ с cloud.siliconflow.cn.",
  },
  {
    key: "modelscope",
    label: "ModelScope",
    kind: "chat",
    baseUrl: "https://api-inference.modelscope.cn/v1",
    model: process.env.MODELSCOPE_MODEL ?? "Qwen/Qwen2.5-Coder-32B-Instruct",
    envKey: "MODELSCOPE_API_KEY",
    priority: 80,
    keyless: false,
    note: "Inference API от ModelScope (Alibaba). Бесплатный токен на modelscope.cn.",
  },
  {
    key: "doubao",
    label: "ByteDance Doubao",
    kind: "chat",
    baseUrl: "https://ark.cn-beijing.volces.com/api/v3",
    model: process.env.DOUBAO_MODEL ?? "doubao-1-5-pro-32k",
    envKey: "DOUBAO_API_KEY",
    priority: 81,
    keyless: false,
    note: "Volcengine Ark: модель или endpoint-id через DOUBAO_MODEL.",
  },
  {
    key: "minimax",
    label: "MiniMax",
    kind: "chat",
    baseUrl: "https://api.minimaxi.com",
    model: process.env.MINIMAX_MODEL ?? "MiniMax-Text-01",
    envKey: "MINIMAX_API_KEY",
    priority: 82,
    keyless: false,
    note: "MiniMax-Text-01. Ключ с intl.minimaxi.com / platform.minimaxi.com.",
  },
  {
    key: "iflytek",
    label: "iFlytek Spark",
    kind: "chat",
    baseUrl: "https://spark-api-open.xf-yun.com/v1",
    model: process.env.IFLYTEK_MODEL ?? "generalv3.5",
    envKey: "IFLYTEK_API_KEY",
    priority: 83,
    keyless: false,
    note: "Spark от iFlytek: ключ формата key:secret (APIPassword).",
  },
  {
    key: "nebius",
    label: "Nebius AI Studio",
    kind: "chat",
    baseUrl: "https://api.studio.nebius.ai/v1",
    model: process.env.NEBIUS_MODEL ?? "meta-llama/Meta-Llama-3.1-70B-Instruct",
    envKey: "NEBIUS_API_KEY",
    priority: 84,
    keyless: false,
    note: "Ключ с studio.nebius.ai.",
  },
  {
    key: "chutes",
    label: "Chutes",
    kind: "chat",
    baseUrl: "https://llm.chutes.ai/v1",
    model: process.env.CHUTES_MODEL ?? "Qwen/Qwen2.5-Coder-32B-Instruct",
    envKey: "CHUTES_API_KEY",
    priority: 85,
    keyless: false,
    note: "Децентрализованный инференс на Bittensor. Ключ с chutes.ai.",
  },
  {
    key: "kluster",
    label: "Kluster.ai",
    kind: "chat",
    baseUrl: "https://api.kluster.ai/v1",
    model: process.env.KLUSTER_MODEL ?? "meta-llama/Meta-Llama-3.1-8B-Instruct",
    envKey: "KLUSTER_API_KEY",
    priority: 86,
    keyless: false,
    note: "Ключ с kluster.ai.",
  },
  {
    key: "github-models",
    label: "GitHub Models",
    kind: "chat",
    baseUrl: "https://models.github.ai/inference",
    model: process.env.GITHUB_MODELS_MODEL ?? "openai/gpt-4o-mini",
    envKey: "GITHUB_TOKEN",
    priority: 87,
    keyless: false,
    note: "Бесплатные модели через GitHub PAT (fine-grained, Models: Read).",
  },
  {
    key: "azure-openai",
    label: "Azure OpenAI",
    kind: "chat",
    baseUrl: process.env.AZURE_OPENAI_BASE_URL ?? "",
    model: process.env.AZURE_OPENAI_MODEL ?? "gpt-4o-mini",
    envKey: "AZURE_OPENAI_API_KEY",
    priority: 88,
    keyless: false,
    note: "AZURE_OPENAI_BASE_URL=https://RES.openai.azure.com/openai/deployments/DEPLOY",
  },
  {
    key: "vercel-gateway",
    label: "Vercel AI Gateway",
    kind: "chat",
    baseUrl: "https://ai-gateway.vercel.sh/v1",
    model: process.env.VERCEL_GATEWAY_MODEL ?? "openai/gpt-4o-mini",
    envKey: "AI_GATEWAY_API_KEY",
    priority: 89,
    keyless: false,
    note: "Единый ключ на все модели через ai-gateway.vercel.sh.",
  },
  {
    key: "pirateface",
    label: "PirateFace.co — индекс моделей",
    kind: "model-index",
    baseUrl: "https://pirateface.co",
    model: "",
    envKey: "",
    priority: 5,
    keyless: true,
    note: "Поиск GGUF + магнет-ссылки для локального запуска без облака.",
  },
  {
    key: "builtin",
    label: "Встроенный детерминированный движок",
    kind: "chat",
    baseUrl: "local://engine",
    model: "super-roy-engine",
    envKey: "",
    priority: 900,
    keyless: true,
    note: "Всегда доступен: планирование и кодогенерация без сети и ключей.",
  },
];

export type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

export interface ChatResult {
  text: string;
  provider: string;
  model: string;
  ms: number;
}

export type ProviderStatus = {
  key: string;
  label: string;
  kind: string;
  status: string;
  latencyMs: number | null;
  detail: string;
  model: string;
  envKey: string;
  hasKey: boolean;
  keyless: boolean;
  priority: number;
  note: string;
};

function keyFor(def: ProviderDef): string | undefined {
  if (!def.envKey) return undefined;
  return secretValue(def.envKey);
}

function chatUrl(def: ProviderDef): string {
  if (def.key === "azure-openai")
    return `${def.baseUrl.replace(/\/$/, "")}/chat/completions?api-version=2024-10-21`;
  if (def.key === "minimax") return `${def.baseUrl.replace(/\/$/, "")}/v1/text/chatcompletion_v2`;
  if (def.key === "pollinations" || def.key === "pollinations-mistral") return def.baseUrl;
  if (def.key === "ollama") return `${def.baseUrl.replace(/\/$/, "")}/api/chat`;
  if (def.key === "anthropic") return `${def.baseUrl.replace(/\/$/, "")}/messages`;
  return `${def.baseUrl.replace(/\/$/, "")}/chat/completions`;
}

export async function syncProviders() {
  await loadSecrets();
  const existing = await db.select({ key: providers.key }).from(providers);
  const known = new Set(existing.map((e) => e.key));
  const missing = PROVIDER_DEFS.filter((d) => !known.has(d.key));
  if (missing.length > 0) {
    await db.insert(providers).values(
      missing.map((d) => ({
        key: d.key,
        label: d.label,
        kind: d.kind,
        baseUrl: d.baseUrl,
        model: d.model,
        envKey: d.envKey,
        priority: d.priority,
        detail: d.note,
        status: d.key === "builtin" ? "ready" : "unknown",
      })),
    );
  }
  for (const def of PROVIDER_DEFS) {
    await db
      .update(providers)
      .set({
        label: def.label,
        kind: def.kind,
        baseUrl: def.baseUrl,
        envKey: def.envKey,
        priority: def.priority,
      })
      .where(eq(providers.key, def.key));
  }
}

async function jsonPost(
  url: string,
  headers: Record<string, string>,
  body: unknown,
  timeoutMs: number,
): Promise<{ ok: boolean; status: number; json: unknown; text: string; ms: number }> {
  const started = Date.now();
  try {
    const res = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs),
    });
    const text = await res.text();
    let json: unknown = null;
    try {
      json = JSON.parse(text);
    } catch {
      json = null;
    }
    return { ok: res.ok, status: res.status, json, text, ms: Date.now() - started };
  } catch (error) {
    return {
      ok: false,
      status: 0,
      json: null,
      text: error instanceof Error ? error.message : String(error),
      ms: Date.now() - started,
    };
  }
}

function contentFrom(def: ProviderDef, json: unknown, raw: string): string {
  if (def.key === "ollama") {
    const parsed = json as { message?: { content?: string } } | null;
    return parsed?.message?.content ?? "";
  }
  if (def.key === "anthropic") {
    const parsed = json as { content?: { type?: string; text?: string }[] } | null;
    return (parsed?.content ?? []).map((b) => b.text ?? "").join("").trim();
  }
  const parsed = json as { choices?: { message?: { content?: string } }[] } | null;
  const fromChoices = parsed?.choices?.[0]?.message?.content ?? "";
  if (fromChoices.trim()) return fromChoices;
  if (typeof json === "string") return json;
  return raw && !raw.startsWith("{") ? raw : "";
}

async function chatWithProvider(
  def: ProviderDef,
  messages: ChatMessage[],
  opts: { maxTokens?: number; temperature?: number; model?: string; timeoutMs?: number },
): Promise<ChatResult | null> {
  const key = keyFor(def);
  if (def.envKey && !key) return null;
  if (!def.baseUrl) return null;
  const model = opts.model || def.model;
  if (!model && def.key !== "pollinations" && def.key !== "pollinations-mistral") return null;

  const headers: Record<string, string> = { "content-type": "application/json" };
  if (def.key === "anthropic") {
    if (key) {
      headers["x-api-key"] = key;
      headers["anthropic-version"] = "2023-06-01";
    }
  } else if (def.key === "azure-openai") {
    if (key) headers["api-key"] = key;
  } else if (key) {
    headers.authorization = `Bearer ${key}`;
  }
  if (def.key === "openrouter") {
    headers["http-referer"] = "http://localhost:3000";
    headers["x-title"] = "SuperRoy Swarm";
  }

  let body: unknown;
  if (def.key === "ollama") {
    body = {
      model,
      messages,
      stream: false,
      options: { temperature: opts.temperature ?? 0.3, num_predict: opts.maxTokens ?? 1400 },
    };
  } else if (def.key === "anthropic") {
    const system = messages.find((m) => m.role === "system")?.content;
    body = {
      model,
      max_tokens: opts.maxTokens ?? 1400,
      temperature: opts.temperature ?? 0.3,
      system: system || undefined,
      messages: messages.filter((m) => m.role !== "system"),
    };
  } else {
    body = {
      model: model || "openai",
      messages,
      max_tokens: opts.maxTokens ?? 1400,
      temperature: opts.temperature ?? 0.3,
      stream: false,
    };
  }

  const res = await jsonPost(chatUrl(def), headers, body, opts.timeoutMs ?? 55_000);
  if (!res.ok) return null;
  const text = contentFrom(def, res.json, res.text).trim();
  if (!text) return null;
  return { text, provider: def.key, model: model || def.model, ms: res.ms };
}

async function probeOne(def: ProviderDef, useProxy: boolean): Promise<ProviderStatus> {
  const hasKey = Boolean(!def.envKey || keyFor(def));
  const base: ProviderStatus = {
    key: def.key,
    label: def.label,
    kind: def.kind,
    status: "unknown",
    latencyMs: null,
    detail: def.note,
    model: def.model,
    envKey: def.envKey,
    hasKey,
    keyless: def.keyless,
    priority: def.priority,
    note: def.note,
  };

  if (def.key === "builtin") {
    return { ...base, status: "ready", detail: "Локальный движок активен: работает без сети и ключей." };
  }

  if (def.envKey && !hasKey) {
    return {
      ...base,
      status: "no-key",
      detail: `Ключа нет (${def.envKey}). Модель на месте — вставьте ключ в панели «Ключи», канал сразу заработает.`,
    };
  }

  if (def.key === "pirateface") {
    const r = await checkEndpoint("https://pirateface.co/s/qwen", useProxy);
    return {
      ...base,
      status: r.ok ? "ready" : "unreachable",
      latencyMs: r.ms,
      detail: r.ok ? `Индекс моделей доступен (${r.via}, ${r.ms} мс).` : `Недоступен: ${r.error ?? r.status}`,
    };
  }

  if (def.key === "ollama") {
    const r = await checkEndpoint(`${def.baseUrl.replace(/\/$/, "")}/api/tags`, false);
    if (!r.ok) {
      return { ...base, status: "offline", detail: "Ollama не запущена (ожидается http://127.0.0.1:11434). Это нормально." };
    }
    try {
      const parsed = JSON.parse(r.text) as { models?: { name: string }[] };
      const names = (parsed.models ?? []).map((m) => m.name);
      return {
        ...base,
        status: names.length ? "ready" : "empty",
        latencyMs: r.ms,
        model: def.model || names[0] || "",
        detail: names.length ? `Локальные модели: ${names.slice(0, 6).join(", ")}` : "Ollama запущена, моделей нет",
      };
    } catch {
      return { ...base, status: "ready", latencyMs: r.ms, detail: "Ollama отвечает." };
    }
  }

  if (def.key === "llamacpp" || def.key === "lmstudio" || def.key === "vllm" || def.key === "jan") {
    const suffix = def.key === "vllm" || def.key === "jan" ? "/models" : "/v1/models";
    const r = await checkEndpoint(`${def.baseUrl.replace(/\/$/, "")}${suffix}`, false);
    if (r.ok && def.key === "vllm") {
      try {
        const parsed = JSON.parse(r.text) as { data?: { id?: string }[] };
        const first = parsed.data?.[0]?.id;
        if (first && !def.model) {
          return { ...base, status: "ready", latencyMs: r.ms, model: first, detail: `vLLM отвечает, модель ${first}.` };
        }
      } catch {
        /* просто покажем онлайн */
      }
    }
    return {
      ...base,
      status: r.ok ? "ready" : "offline",
      latencyMs: r.ok ? r.ms : null,
      detail: r.ok
        ? `Локальный сервер отвечает (${r.ms} мс).`
        : "Сервер не найден. Скачайте GGUF с PirateFace и запустите llama-server / LM Studio.",
    };
  }

  if (def.keyless && def.kind === "chat") {
    const ping = await chatWithProvider(
      def,
      [
        { role: "system", content: "Reply with exactly: ONLINE" },
        { role: "user", content: "ONLINE" },
      ],
      { maxTokens: 16, temperature: 0, timeoutMs: 18_000 },
    );
    return {
      ...base,
      status: ping ? "ready" : "error",
      latencyMs: ping?.ms ?? null,
      detail: ping ? `Живой чат без ключа (${ping.ms} мс, модель ${ping.model}).` : "Безключевой канал сейчас не отвечает — пробую следующий.",
    };
  }

  if (def.kind === "chat" && hasKey) {
    const ping = await chatWithProvider(
      def,
      [
        { role: "system", content: "Reply with exactly: ONLINE" },
        { role: "user", content: "ONLINE" },
      ],
      { maxTokens: 16, temperature: 0, timeoutMs: 18_000 },
    );
    return {
      ...base,
      status: ping ? "ready" : "key-error",
      latencyMs: ping?.ms ?? null,
      detail: ping ? `Ключ работает, модель ${ping.model} (${ping.ms} мс).` : "Ключ есть, но чат не ответил — проверьте модель/квоту.",
    };
  }

  return base;
}

export async function probeProviders(useProxy = false): Promise<ProviderStatus[]> {
  await loadSecrets(true);
  await syncProviders();
  const results = await Promise.all(
    PROVIDER_DEFS.map(async (def) => {
      try {
        return await probeOne(def, useProxy);
      } catch (error) {
        return {
          key: def.key,
          label: def.label,
          kind: def.kind,
          status: "error",
          latencyMs: null,
          detail: error instanceof Error ? error.message : String(error),
          model: def.model,
          envKey: def.envKey,
          hasKey: Boolean(!def.envKey || keyFor(def)),
          keyless: def.keyless,
          priority: def.priority,
          note: def.note,
        } satisfies ProviderStatus;
      }
    }),
  );

  for (const row of results) {
    await db
      .update(providers)
      .set({
        status: row.status,
        latencyMs: row.latencyMs,
        detail: row.detail,
        model: row.model,
        lastCheckedAt: new Date(),
      })
      .where(eq(providers.key, row.key));
  }
  return results.sort((a, b) => a.priority - b.priority);
}

export async function listProviders(): Promise<ProviderStatus[]> {
  await loadSecrets(true);
  await syncProviders();
  const rows = await db.select().from(providers);
  const byKey = new Map(rows.map((r) => [r.key, r]));
  return PROVIDER_DEFS.map((def) => {
    const row = byKey.get(def.key);
    const hasKey = Boolean(!def.envKey || keyFor(def));
    return {
      key: def.key,
      label: def.label,
      kind: def.kind,
      status: row?.status ?? (def.key === "builtin" ? "ready" : hasKey ? "unknown" : "no-key"),
      latencyMs: row?.latencyMs ?? null,
      detail: row?.detail || def.note,
      model: row?.model || def.model,
      envKey: def.envKey,
      hasKey,
      keyless: def.keyless,
      priority: def.priority,
      note: def.note,
    };
  }).sort((a, b) => a.priority - b.priority);
}

export async function pingProvider(key: string): Promise<{ ok: boolean; sample: string; ms: number; status: string }> {
  await loadSecrets(true);
  const def = PROVIDER_DEFS.find((d) => d.key === key);
  if (!def) return { ok: false, sample: "неизвестный провайдер", ms: 0, status: "error" };
  const row = await probeOne(def, false);
  await db
    .update(providers)
    .set({
      status: row.status,
      latencyMs: row.latencyMs,
      detail: row.detail,
      model: row.model,
      lastCheckedAt: new Date(),
    })
    .where(eq(providers.key, key));
  return {
    ok: row.status === "ready",
    sample: row.detail,
    ms: row.latencyMs ?? 0,
    status: row.status,
  };
}

async function cachedRows(): Promise<string[]> {
  const res = await checkEndpoint("https://openrouter.ai/api/v1/models", false);
  if (!res.ok) return [];
  try {
    const parsed = JSON.parse(res.text) as {
      data?: { id: string; pricing?: { prompt?: string; completion?: string } }[];
    };
    return (parsed.data ?? [])
      .filter(
        (m) =>
          m.pricing &&
          Number(m.pricing.prompt ?? "1") === 0 &&
          Number(m.pricing.completion ?? "1") === 0,
      )
      .map((m) => m.id)
      .sort((a, b) => {
        const score = (s: string) => (/coder|code|qwen|deepseek|llama|mistral/gi.test(s) ? 0 : 1);
        return score(a) - score(b);
      })
      .slice(0, 24);
  } catch {
    return [];
  }
}

export async function freeOpenRouterModels(limit = 6): Promise<string[]> {
  const rows = await cachedRows();
  return rows.slice(0, limit);
}

/**
 * Роутер: сначала живые безключевые/локальные, потом облака с ключом.
 * Если никто не ответил — null, и пайплайн спокойно идёт на встроенный движок.
 */
export async function chat(
  messages: ChatMessage[],
  opts: {
    role?: string;
    maxTokens?: number;
    temperature?: number;
    allowed?: string[];
    model?: string;
  } = {},
): Promise<ChatResult | null> {
  await loadSecrets();
  await syncProviders();
  const rows = await db.select().from(providers);
  const byKey = new Map(rows.map((r) => [r.key, r]));

  const ordered = PROVIDER_DEFS.filter((d) => d.kind !== "model-index" && d.key !== "builtin")
    .filter((d) => (opts.allowed ? opts.allowed.includes(d.key) : true))
    .sort((a, b) => {
      const sa = byKey.get(a.key)?.status === "ready" ? 0 : byKey.get(a.key)?.status === "error" ? 2 : 1;
      const sb = byKey.get(b.key)?.status === "ready" ? 0 : byKey.get(b.key)?.status === "error" ? 2 : 1;
      return sa - sb || a.priority - b.priority;
    });

  for (const def of ordered) {
    if (def.envKey && !keyFor(def)) continue;
    if (def.kind === "local") {
      const st = byKey.get(def.key)?.status;
      if (st !== "ready") continue;
    }
    let model = opts.model ?? def.model;
    if (!model && def.key !== "pollinations" && def.key !== "pollinations-mistral") continue;
    if (def.key === "openrouter" && !model) {
      const free = await freeOpenRouterModels(1);
      model = free[0] ?? "";
      if (!model) continue;
    }
    const result = await chatWithProvider(def, messages, { ...opts, model });
    if (result) {
      await db
        .update(providers)
        .set({ latencyMs: result.ms, status: "ready", detail: `Успешный вызов (${result.ms} мс)`, lastCheckedAt: new Date() })
        .where(eq(providers.key, def.key));
      return result;
    }
    await db.update(providers).set({ status: "error", lastCheckedAt: new Date() }).where(eq(providers.key, def.key));
  }
  return null;
}

export function extractJson<T>(text: string): T | null {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = fenced ? fenced[1] : text;
  const start = candidate.search(/[[{]/);
  if (start < 0) return null;
  for (let end = candidate.length; end > start; end--) {
    const slice = candidate.slice(start, end);
    const last = slice.trim().slice(-1);
    if (last !== "}" && last !== "]") continue;
    try {
      return JSON.parse(slice) as T;
    } catch {
      continue;
    }
  }
  return null;
}
