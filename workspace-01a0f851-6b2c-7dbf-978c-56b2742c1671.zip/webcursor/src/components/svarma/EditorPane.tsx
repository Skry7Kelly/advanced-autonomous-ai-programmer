"use client";

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { Icon } from "./icons";
import { extColor } from "./api";

const CodeEditor = dynamic(() => import("./CodeEditor"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full items-center justify-center text-ink-500">
      <Icon name="file" size={20} className="animate-pulse" />
    </div>
  ),
});

export type OpenTab = { path: string; content: string; dirty: boolean };

const LANG_LABELS: Record<string, string> = {
  typescript: "TypeScript",
  javascript: "JavaScript",
  json: "JSON",
  markdown: "Markdown",
  css: "CSS",
  html: "HTML",
  python: "Python",
  sql: "SQL",
  text: "Текст",
};

function langOf(path: string): string {
  if (/\.tsx?$/.test(path)) return "typescript";
  if (/\.m?[jc]sx?$/.test(path)) return "javascript";
  if (path.endsWith(".json")) return "json";
  if (path.endsWith(".md")) return "markdown";
  if (path.endsWith(".css")) return "css";
  if (path.endsWith(".html")) return "html";
  if (path.endsWith(".py")) return "python";
  if (path.endsWith(".sql")) return "sql";
  return "text";
}

export default function EditorPane({
  projectId,
  tabs,
  activePath,
  onSelectTab,
  onCloseTab,
  onChangeContent,
  onSave,
  previewEpoch,
  fileCount,
  onOpenFile,
  running,
}: {
  projectId: number;
  tabs: OpenTab[];
  activePath: string | null;
  onSelectTab: (path: string | null) => void;
  onCloseTab: (path: string) => void;
  onChangeContent: (path: string, content: string) => void;
  onSave: () => void;
  previewEpoch: number;
  fileCount: number;
  onOpenFile: (path: string) => void;
  running: boolean;
}) {
  const [cursor, setCursor] = useState({ line: 1, col: 1 });
  const activeTab = tabs.find((t) => t.path === activePath);
  const isPreview = activePath === "__preview__";

  useEffect(() => {
    const line = (activeTab?.content.split("\n").length ?? 1);
    setCursor({ line, col: 1 });
  }, [activeTab?.path]);

  return (
    <div className="flex min-h-0 flex-1 flex-col bg-ink-900">
      {/* строка вкладок */}
      <div className="flex h-9 shrink-0 items-stretch border-b border-ink-800 bg-ink-880">
        <div className="flex min-w-0 flex-1 items-stretch overflow-x-auto">
          {tabs.map((tab) => {
            const isActive = tab.path === activePath;
            const name = tab.path.split("/").pop() ?? tab.path;
            return (
              <div
                key={tab.path}
                className={`group relative flex shrink-0 cursor-pointer items-center gap-1.5 border-r border-ink-800 px-3 text-[12px] transition-colors ${
                  isActive ? "bg-ink-900 text-ink-50" : "text-ink-300 hover:bg-ink-850 hover:text-ink-100"
                }`}
                onClick={() => onSelectTab(tab.path)}
                title={tab.path}
              >
                <span className={`h-1.5 w-1.5 shrink-0 rounded-[2px] ${tab.dirty ? "bg-accent2" : ""}`} style={tab.dirty ? undefined : { background: extColor(tab.path) }} />
                <span className="max-w-40 truncate">{name}</span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onCloseTab(tab.path);
                  }}
                  className="ml-1 flex h-4 w-4 items-center justify-center rounded text-ink-500 opacity-0 transition-all hover:bg-ink-700 hover:text-ink-100 group-hover:opacity-100"
                >
                  <Icon name="close" size={11} />
                </button>
                {isActive ? <span className="absolute bottom-0 left-0 right-0 h-px bg-accent2/60" /> : null}
              </div>
            );
          })}

          {/* вкладка превью */}
          <div
            className={`relative flex shrink-0 cursor-pointer items-center gap-1.5 border-r border-ink-800 px-3 text-[12px] transition-colors ${
              isPreview ? "bg-ink-900 text-ink-50" : "text-ink-300 hover:bg-ink-850 hover:text-ink-100"
            }`}
            onClick={() => onSelectTab("__preview__")}
          >
            <Icon name="eye" size={12} className={isPreview ? "text-accent2" : ""} />
            <span>Превью</span>
            {running ? <span className="h-1.5 w-1.5 animate-blink rounded-full bg-accent2" /> : null}
            {isPreview ? <span className="absolute bottom-0 left-0 right-0 h-px bg-accent2/60" /> : null}
          </div>
        </div>

        {activeTab?.dirty ? (
          <button className="btn btn-accent my-1 mr-2 !py-1" onClick={onSave} title="Сохранить (Ctrl+S)">
            <Icon name="check" size={12} /> Сохранить
          </button>
        ) : null}
      </div>

      {/* содержимое */}
      <div className="relative min-h-0 flex-1">
        {isPreview ? (
          <div className="flex h-full flex-col">
            <div className="flex items-center gap-2 border-b border-ink-800 bg-ink-880 px-3 py-1.5">
              <span className="flex gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-danger/70" />
                <span className="h-2.5 w-2.5 rounded-full bg-warn/70" />
                <span className="h-2.5 w-2.5 rounded-full bg-ok/70" />
              </span>
              <span className="mx-auto flex items-center gap-1.5 rounded-md bg-ink-950 px-3 py-0.5 font-mono text-[10.5px] text-ink-400">
                <Icon name="eye" size={10} /> svarma://projects/{projectId}/preview
              </span>
              <span className="font-mono text-[10.5px] text-ink-500">{fileCount} файлов</span>
            </div>
            <iframe
              key={previewEpoch}
              src={`/api/projects/${projectId}/preview?v=${previewEpoch}`}
              className="min-h-0 flex-1 bg-white"
              sandbox="allow-scripts allow-forms allow-popups"
              title="Превью приложения"
            />
          </div>
        ) : activeTab ? (
          <div className="flex h-full flex-col">
            <div className="min-h-0 flex-1 overflow-hidden">
              <CodeEditor
                path={activeTab.path}
                value={activeTab.content}
                language={langOf(activeTab.path)}
                onChange={(v) => onChangeContent(activeTab.path, v)}
                onSave={onSave}
              />
            </div>
            <div className="flex h-6 shrink-0 items-center gap-3 border-t border-ink-800 bg-ink-880 px-3 text-[10.5px] text-ink-400">
              <span className="font-mono">{LANG_LABELS[langOf(activeTab.path)] ?? "Текст"}</span>
              <span className="text-ink-600">|</span>
              <span className="font-mono">Ln {cursor.line}, Col {cursor.col}</span>
              <span className="text-ink-600">|</span>
              <span className="font-mono">{(new TextEncoder().encode(activeTab.content).length / 1024).toFixed(1)} КБ</span>
              <span className="ml-auto font-mono">
                {activeTab.dirty ? <span className="text-warn">● не сохранён — Ctrl+S</span> : <span className="text-ink-500">сохранён ✓</span>}
              </span>
            </div>
          </div>
        ) : (
          <div className="grid-bg flex h-full flex-col items-center justify-center gap-4 p-8">
            <Icon name="logo" size={56} className="animate-glow opacity-90" />
            <div className="text-center">
              <p className="mb-1 text-[15px] font-semibold text-ink-100">Откройте файл из проводника</p>
              <p className="max-w-sm text-[12px] leading-relaxed text-ink-400">
                или нажмите <kbd className="rounded border border-ink-650 bg-ink-800 px-1.5 py-0.5 font-mono text-[10.5px]">Ctrl+K</kbd> для быстрого поиска ·{" "}
                <kbd className="rounded border border-ink-650 bg-ink-800 px-1.5 py-0.5 font-mono text-[10.5px]">Ctrl+I</kbd> — чат с роем
              </p>
            </div>
            <div className="mt-2 flex gap-2">
              <button className="btn" onClick={() => onSelectTab("__preview__")}>
                <Icon name="eye" size={13} /> Превью проекта
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
