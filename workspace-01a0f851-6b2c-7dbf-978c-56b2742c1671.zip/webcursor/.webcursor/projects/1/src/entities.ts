import { createRepository, type Repository, type StoredRecord } from './store.js';

// Сущности выведены из брифа архитектором роя.
export interface User extends StoredRecord {
  email: string;
  password_hash: string;
  role: string;
  created_at: string;
}
export interface Session extends StoredRecord {
  user_id: number;
  token: string;
  expires_at: string;
  ip: string;
}
export interface Document extends StoredRecord {
  title: string;
  source_url: string;
  content: string;
  hash: string;
}
export interface EventsLog extends StoredRecord {
  actor: string;
  action: string;
  payload: string;
  created_at: string;
}

export const repositories = {
  users: createRepository<User>('users'),
  sessions: createRepository<Session>('sessions'),
  documents: createRepository<Document>('documents'),
  events_log: createRepository<EventsLog>('events_log'),
} satisfies Record<string, Repository<StoredRecord>>;

export type RepositoryMap = typeof repositories;