// Shared domain types for the SUPER ROY swarm (Роевой Интеллект).
// Kept dependency-free so both server and client bundles can import it.

export type AgentId =
  | "ARCHITECT"
  | "SCOUT"
  | "FLY"
  | "FORGE"
  | "ENGINEER"
  | "CRITIC"
  | "INTEGRATOR";

export type ProjectStatus = "queued" | "running" | "done" | "failed";

export interface ProjectSettings {
  targetLanguage: string;
  searchDepth: number; // 1..3 -> how wide the scout casts its net
  maxAdopt: number; // how many external repos to adopt
  useProxy: boolean;
  flyBoost: boolean; // use fly-brain re-ranking + memory
  allowForge: boolean; // allow creating modules that do not exist yet
  cloudLlm: boolean; // allow free cloud providers when keys exist
  localLlm: boolean; // allow ollama / llama.cpp / lm-studio
}

export interface Brief {
  title: string;
  summary: string;
  kind:
    | "api"
    | "cli"
    | "web"
    | "bot"
    | "scraper"
    | "agent"
    | "library"
    | "desktop"
    | "game"
    | "tool";
  runtime: "node" | "deno" | "bun" | "python" | "browser";
  language: string;
  domain: string;
  features: { key: string; title: string; detail: string }[];
  entities: { name: string; fields: string[] }[];
  integrations: string[];
  personas: string[];
  nonFunctional: string[];
  keywords: string[];
  locale: "ru" | "en";
  notes?: string[];
}

export interface ModelPick {
  name: string;
  sizeGB: number;
  seeds: number;
  magnet: string;
  webSeed?: string;
  url: string;
  role: string;
  cmd: string;
}

export interface SpecModule {
  name: string;
  path: string;
  purpose: string;
  publicApi: string[];
  deps: string[];
  origin: "forged" | "adopted" | "generated";
  sourceUrl?: string;
}

export interface SpecTable {
  name: string;
  reason: string;
  columns: { name: string; type: string; note: string }[];
}

export interface SpecEndpoint {
  method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  path: string;
  purpose: string;
  handler: string;
  request?: string;
  response: string;
}

export interface SpecCli {
  command: string;
  purpose: string;
}

export interface SpecTest {
  name: string;
  path: string;
  asserts: string[];
}

export interface SpecMilestone {
  index: number;
  title: string;
  tasks: string[];
  doneWhen: string;
}

export interface SpecRisk {
  risk: string;
  impact: "low" | "medium" | "high";
  mitigation: string;
}

export interface SpecIntegration {
  name: string;
  url: string;
  provider: string;
  stars: number;
  score: number;
  why: string;
  install: string;
  usage: string;
}

export interface Spec {
  title: string;
  slug: string;
  summary: string;
  brief: Brief;
  goals: string[];
  nonGoals: string[];
  modules: SpecModule[];
  tables: SpecTable[];
  endpoints: SpecEndpoint[];
  cli: SpecCli[];
  tests: SpecTest[];
  milestones: SpecMilestone[];
  risks: SpecRisk[];
  integrations: SpecIntegration[];
  models: ModelPick[];
  fly: {
    brains: number;
    generation: number;
    fitness: number;
    note: string;
    accelerations: string[];
  };
  localFirst: boolean;
  notes: string[];
}

export interface QaFinding {
  id: string;
  severity: "blocker" | "warn" | "info" | "ok";
  file?: string;
  message: string;
  fixed: boolean;
}

export interface QaReport {
  score: number;
  findings: QaFinding[];
  files: number;
  bytes: number;
  checks: string[];
}

export interface EventRow {
  id: number;
  projectId: number;
  level: "info" | "warn" | "error" | "success";
  agent: AgentId;
  stage: string;
  message: string;
  data: unknown;
  createdAt: string | null;
}

export const AGENT_LABELS: Record<AgentId, string> = {
  ARCHITECT: "АРХИТЕКТОР",
  SCOUT: "РАЗВЕДЧИК",
  FLY: "МОЗГ МУХИ",
  FORGE: "КУЗНЕЦ",
  ENGINEER: "ИНЖЕНЕР",
  CRITIC: "КРИТИК",
  INTEGRATOR: "ИНТЕГРАТОР",
};
