import { db } from "@/db";
import { sources } from "@/db/schema";
import { cachedJson, netFetch } from "@/lib/net";
import { flyRerank } from "@/lib/fly";
import type { Brief, ProjectSettings } from "@/lib/types";

export interface RawSource {
  provider: "pirateface" | "github" | "npm" | "hn" | "stackoverflow" | "web";
  query: string;
  title: string;
  url: string;
  subtitle: string;
  metric: number;
  metricLabel: string;
  payload?: Record<string, unknown>;
}

async function mapLimit<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const out: R[] = [];
  let cursor = 0;
  const workers = Array.from({ length: Math.min(limit, Math.max(1, items.length)) }, async () => {
    while (cursor < items.length) {
      const i = cursor++;
      out[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return out;
}

/* --------------------------------- PirateFace -------------------------------- */

export interface PirateModel {
  name: string;
  sizeGB: number;
  sizeLabel: string;
  seeds: number;
  magnet: string;
  webSeed?: string;
}

const SIZE_MULT: Record<string, number> = { KB: 1 / 1024 / 1024, MB: 1 / 1024, GB: 1, TB: 1024 };

export function parsePirateFace(text: string): PirateModel[] {
  const out: PirateModel[] = [];
  for (const line of text.split("\n")) {
    const mIdx = line.indexOf("magnet:");
    if (mIdx < 0) continue;
    const head = line.slice(0, mIdx).trim();
    const magnet = line.slice(mIdx).trim();
    const m = head.match(/^(.*?)\s+([\d.]+)\s*(KB|MB|GB|TB)\s+(\d+)\s+seeds?$/i);
    if (!m) continue;
    const sizeGB = Number(m[2]) * (SIZE_MULT[m[3].toUpperCase()] ?? 1);
    const wsMatch = magnet.match(/[?&]ws=([^&\s]+)/);
    out.push({
      name: m[1].trim(),
      sizeGB: Number(sizeGB.toFixed(3)),
      sizeLabel: `${m[2]} ${m[3].toUpperCase()}`,
      seeds: Number(m[4]),
      magnet,
      webSeed: wsMatch ? decodeURIComponent(wsMatch[1]) : undefined,
    });
  }
  return out;
}

export async function pirateFaceSearch(query: string, useProxy = false): Promise<PirateModel[]> {
  const q = query.trim().split(/\s+/).join("+");
  const url = `https://pirateface.co/s/${encodeURIComponent(q).replace(/%2B/g, "+")}`;
  const res = await netFetch(url, { useProxy, timeoutMs: 15000 });
  if (!res.ok) return [];
  return parsePirateFace(res.text);
}

/* ----------------------------------- GitHub ---------------------------------- */

export interface GithubRepo {
  fullName: string;
  url: string;
  description: string;
  stars: number;
  language: string;
  pushedAt: string;
  topics: string[];
  license: string;
}

export async function githubSearch(query: string, perPage = 8, useProxy = false): Promise<GithubRepo[]> {
  const data = await cachedJson<GithubRepo[]>(`gh:${query}:${perPage}`, 5 * 60_000, async () => {
    const url = `https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&sort=stars&order=desc&per_page=${perPage}`;
    const res = await netFetch(url, {
      useProxy,
      timeoutMs: 15000,
      headers: {
        accept: "application/vnd.github+json",
        ...(process.env.GITHUB_TOKEN ? { authorization: `Bearer ${process.env.GITHUB_TOKEN}` } : {}),
      },
    });
    if (!res.ok) return [];
    try {
      const parsed = JSON.parse(res.text) as {
        items?: {
          full_name: string;
          html_url: string;
          description: string | null;
          stargazers_count: number;
          language: string | null;
          pushed_at: string;
          topics?: string[];
          license?: { spdx_id?: string } | null;
        }[];
      };
      return (parsed.items ?? []).map((it) => ({
        fullName: it.full_name,
        url: it.html_url,
        description: it.description ?? "",
        stars: it.stargazers_count,
        language: it.language ?? "",
        pushedAt: it.pushed_at,
        topics: it.topics ?? [],
        license: it.license?.spdx_id && it.license.spdx_id !== "NOASSERTION" ? it.license.spdx_id : "",
      }));
    } catch {
      return [];
    }
  });
  return data;
}

/** Читаем README конкретного репозитория — чтобы внедрение было по делу, а не по названию. */
export async function githubReadme(fullName: string, useProxy = false): Promise<string> {
  const res = await netFetch(`https://raw.githubusercontent.com/${fullName}/HEAD/README.md`, {
    useProxy,
    timeoutMs: 12000,
  });
  if (res.ok && res.text.length > 80) return res.text.slice(0, 4000);
  const alt = await netFetch(`https://raw.githubusercontent.com/${fullName}/master/README.md`, {
    useProxy,
    timeoutMs: 12000,
  });
  return alt.ok ? alt.text.slice(0, 4000) : "";
}

/* ---------------------------- npm / HN / StackOverflow ----------------------- */

export async function npmSearch(query: string, useProxy = false): Promise<RawSource[]> {
  const res = await netFetch(
    `https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(query)}&size=6`,
    { useProxy, timeoutMs: 12000 },
  );
  if (!res.ok) return [];
  try {
    const parsed = JSON.parse(res.text) as {
      objects?: { package: { name: string; version: string; description?: string; links?: { repository?: string }; date?: string } }[];
    };
    return (parsed.objects ?? []).map((o) => ({
      provider: "npm" as const,
      query,
      title: o.package.name,
      url: o.package.links?.repository ?? `https://www.npmjs.com/package/${o.package.name}`,
      subtitle: o.package.description ?? "",
      metric: 0,
      metricLabel: "npm",
      payload: { version: o.package.version },
    }));
  } catch {
    return [];
  }
}

export async function hnSearch(query: string, useProxy = false): Promise<RawSource[]> {
  const res = await netFetch(
    `https://hn.algolia.com/api/v1/search?query=${encodeURIComponent(query)}&tags=story&hitsPerPage=6`,
    { useProxy, timeoutMs: 12000 },
  );
  if (!res.ok) return [];
  try {
    const parsed = JSON.parse(res.text) as { hits?: { title?: string; url?: string; objectID: string; points?: number }[] };
    return (parsed.hits ?? [])
      .filter((h) => h.title)
      .map((h) => ({
        provider: "hn" as const,
        query,
        title: h.title as string,
        url: h.url ?? `https://news.ycombinator.com/item?id=${h.objectID}`,
        subtitle: "обсуждение на Hacker News",
        metric: h.points ?? 0,
        metricLabel: "points",
      }));
  } catch {
    return [];
  }
}

export async function stackSearch(query: string, useProxy = false): Promise<RawSource[]> {
  const res = await netFetch(
    `https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=${encodeURIComponent(query)}&site=stackoverflow&pagesize=5`,
    { useProxy, timeoutMs: 12000 },
  );
  if (!res.ok) return [];
  try {
    const parsed = JSON.parse(res.text) as { items?: { title: string; link: string; score: number; is_answered: boolean }[] };
    return (parsed.items ?? []).map((it) => ({
      provider: "stackoverflow" as const,
      query,
      title: it.title.replace(/&quot;/g, '"').replace(/&#39;/g, "'"),
      url: it.link,
      subtitle: it.is_answered ? "есть принятый ответ" : "без ответа",
      metric: it.score,
      metricLabel: "votes",
    }));
  } catch {
    return [];
  }
}

/* ------------------------------ Поисковые запросы ---------------------------- */

export function buildQueries(brief: Brief, depth: number): string[] {
  const base = brief.keywords.slice(0, 6);
  const queries = new Set<string>();
  queries.add([brief.kind, brief.domain, ...base.slice(0, 2)].filter(Boolean).join(" "));
  base.forEach((k) => queries.add(k));
  if (depth >= 2) {
    brief.features.slice(0, 5).forEach((f) => queries.add(`${f.key} ${brief.language} library`));
    brief.integrations.forEach((i) => queries.add(i));
  }
  if (depth >= 3) {
    brief.entities.slice(0, 3).forEach((e) => queries.add(`${e.name} schema ${brief.language}`));
    queries.add(`${brief.kind} architecture ${brief.domain}`);
    queries.add(`${brief.domain} local llm gguf`);
  }
  return [...queries].filter((q) => q.trim().length > 2).slice(0, 4 + depth * 3);
}

export function modelQueries(brief: Brief, depth: number): string[] {
  const list = new Set<string>();
  list.add(brief.kind === "agent" || brief.domain.includes("ai") ? "coder gguf" : `${brief.domain} gguf`);
  list.add("coder gguf");
  if (depth >= 2) {
    list.add("embedding gguf");
    list.add(brief.language === "python" ? "code llama gguf" : "qwen coder gguf");
  }
  return [...list].slice(0, depth >= 3 ? 4 : 2);
}

export function scoreSource(item: RawSource, brief: Brief): number {
  let score = 0;
  const hay = `${item.title} ${item.subtitle}`.toLowerCase();
  for (const kw of brief.keywords) if (hay.includes(kw.toLowerCase())) score += 1.2;
  if (hay.includes(brief.domain.toLowerCase())) score += 0.8;
  if (hay.includes(brief.kind)) score += 0.6;
  score += Math.min(1.5, Math.log10(1 + item.metric) / 2);
  if (item.provider === "github") score += 0.8;
  if (item.provider === "npm") score += 0.5;
  if (item.provider === "pirateface") score += 0.4;
  return Number(score.toFixed(3));
}

export interface ScoutResult {
  items: (RawSource & { score: number; flyScore: number })[];
  queries: string[];
  failures: string[];
}

export async function runScout(brief: Brief, settings: ProjectSettings): Promise<ScoutResult> {
  const queries = buildQueries(brief, settings.searchDepth);
  const raw: RawSource[] = [];
  const failures: string[] = [];

  const gh = await mapLimit(queries, 3, async (q) => {
    const repos = await githubSearch(q, settings.searchDepth >= 2 ? 8 : 5, settings.useProxy);
    return repos.map<RawSource>((r) => ({
      provider: "github",
      query: q,
      title: r.fullName,
      url: r.url,
      subtitle: `${r.description} · ${r.language}${r.license ? ` · ${r.license}` : ""} · обновлён ${r.pushedAt.slice(0, 10)}${r.topics.length ? ` · ${r.topics.slice(0, 4).join(",")}` : ""}`,
      metric: r.stars,
      metricLabel: "stars",
      payload: { ...r, readme: "" },
    }));
  });
  gh.flat().forEach((r) => raw.push(r));
  if (gh.every((g) => g.length === 0)) failures.push("github");

  const npm = await mapLimit(queries.slice(0, 3), 3, (q) => npmSearch(q, settings.useProxy));
  npm.flat().forEach((r) => raw.push(r));

  const hn = await mapLimit(queries.slice(0, 2), 2, (q) => hnSearch(q, settings.useProxy));
  hn.flat().forEach((r) => raw.push(r));

  const so = await mapLimit(queries.slice(0, 2), 2, (q) => stackSearch(q, settings.useProxy));
  so.flat().forEach((r) => raw.push(r));

  // Мозг мухи: переранживаем находки по смысловой близости к брифу
  let flyScores = raw.map(() => 0);
  if (settings.flyBoost && raw.length > 0) {
    const reranked = await flyRerank(
      `${brief.title} ${brief.summary} ${brief.keywords.join(" ")}`,
      raw,
      (r) => `${r.title} ${r.subtitle} ${r.provider}`,
      1,
    );
    raw.sort((a, b) => reranked.items.indexOf(a) - reranked.items.indexOf(b));
    flyScores = reranked.scores;
  }

  const seen = new Set<string>();
  const items: (RawSource & { score: number; flyScore: number })[] = [];
  raw.forEach((r, i) => {
    if (seen.has(r.url)) return;
    seen.add(r.url);
    const base = scoreSource(r, brief);
    items.push({ ...r, score: Number((base + flyScores[i]).toFixed(3)), flyScore: Number(flyScores[i].toFixed(3)) });
  });
  items.sort((a, b) => b.score - a.score);
  return { items: items.slice(0, 80), queries, failures };
}

export async function searchModels(brief: Brief, settings: ProjectSettings) {
  const queries = modelQueries(brief, settings.searchDepth);
  const found = await mapLimit(queries, 2, (q) => pirateFaceSearch(q, settings.useProxy));
  const flat = found.flat().filter((m) => m.seeds > 0);
  const seen = new Set<string>();
  const unique = flat.filter((m) => {
    if (seen.has(m.name)) return false;
    seen.add(m.name);
    return true;
  });
  return unique
    .sort((a, b) => b.seeds - a.seeds)
    .slice(0, 8)
    .map((m) => ({ ...m, query: queries.find((q) => m.name.toLowerCase().includes(q.split(" ")[0])) ?? queries[0] }));
}

export async function persistSources(projectId: number, items: ScoutResult["items"], decisions: Map<string, { decision: string; reason: string }>) {
  if (items.length === 0) return;
  await db.insert(sources).values(
    items.map((it) => ({
      projectId,
      provider: it.provider,
      query: it.query,
      title: it.title,
      url: it.url,
      subtitle: it.subtitle.slice(0, 600),
      metric: it.metric,
      metricLabel: it.metricLabel,
      score: it.score,
      flyScore: it.flyScore,
      decision: decisions.get(it.url)?.decision ?? "reference",
      reason: decisions.get(it.url)?.reason ?? "",
      payload: (it.payload ?? null) as Record<string, unknown> | null,
    })),
  );
}
