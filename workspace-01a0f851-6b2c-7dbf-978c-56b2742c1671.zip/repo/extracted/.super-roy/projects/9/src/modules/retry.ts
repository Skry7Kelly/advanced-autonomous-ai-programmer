export interface RetryOptions {
  retries?: number;
  baseMs?: number;
  maxMs?: number;
  timeoutMs?: number;
  jitter?: boolean;
  isRetryable?: (error: unknown) => boolean;
  onRetry?: (info: { attempt: number; delayMs: number; error: unknown }) => void;
}

const defaultRetryable = (error: unknown): boolean => {
  const msg = error instanceof Error ? error.message : String(error);
  return /timeout|econn|socket|429|5\d\d|rate|temporarily/i.test(msg);
};

export async function retryWithBackoff<T>(fn: () => Promise<T>, options: RetryOptions = {}): Promise<T> {
  const retries = options.retries ?? 4;
  const baseMs = options.baseMs ?? 250;
  const maxMs = options.maxMs ?? 8000;
  const isRetryable = options.isRetryable ?? defaultRetryable;
  let lastError: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      if (!options.timeoutMs) return await fn();
      return await withTimeout(fn(), options.timeoutMs);
    } catch (error) {
      lastError = error;
      if (attempt === retries || !isRetryable(error)) break;
      const waitAfter = hintFromError(error) ?? Math.min(maxMs, baseMs * 2 ** attempt);
      const delayMs = options.jitter === false ? waitAfter : Math.round(waitAfter * (0.7 + Math.random() * 0.6));
      options.onRetry?.({ attempt: attempt + 1, delayMs, error });
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }
  throw lastError instanceof Error ? lastError : new Error(String(lastError));
}

export async function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => reject(new Error('timeout after ' + timeoutMs + 'ms')), timeoutMs);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function hintFromError(error: unknown): number | null {
  const msg = error instanceof Error ? error.message : String(error);
  const m = msg.match(/retry[- ]after[:\s]*(\d+)/i);
  return m ? Number(m[1]) * 1000 : null;
}