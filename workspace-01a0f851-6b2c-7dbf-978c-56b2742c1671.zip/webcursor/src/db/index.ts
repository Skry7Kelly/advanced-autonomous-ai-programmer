/**
 * Синглтон БД Svarma.
 * Zero-config: данные живут в памяти и автоматически сохраняются в .data/svarma-db.json.
 * Не нужен ни Postgres, ни DATABASE_URL — `npm run dev` и всё работает.
 * Поддерживает миграцию с прежнего имени файла (webcursor-db.json).
 */
import fs from "node:fs";
import path from "node:path";
import { MemDB } from "@/db/orm";

const dataDir = path.join(process.cwd(), ".data");
const persistPath = path.join(dataDir, "svarma-db.json");
const legacyPath = path.join(dataDir, "webcursor-db.json");

if (!fs.existsSync(persistPath) && fs.existsSync(legacyPath)) {
  fs.mkdirSync(dataDir, { recursive: true });
  fs.copyFileSync(legacyPath, persistPath);
}

const globalForDb = globalThis as typeof globalThis & { __svarmaDb?: MemDB };

export const db: MemDB = globalForDb.__svarmaDb ?? new MemDB(persistPath);

if (!globalForDb.__svarmaDb) {
  globalForDb.__svarmaDb = db;
  // прогоны, «зависшие» после перезапуска сервера, помечаем упавшими
  db.recoverStale();
}

export { db as database };
