import test from 'node:test';
import assert from 'node:assert/strict';
import { chunkText, estimateTokens } from '../src/modules/text-chunker.js';

test('режет длинный текст с перекрытием', () => {
  const text = Array.from({ length: 60 }, (_, i) => 'Предложение номер ' + i + ' рассказывает о ротации прокси и пула моделей.').join(' ');
  const chunks = chunkText(text, { maxTokens: 120, overlapTokens: 20 });
  assert.ok(chunks.length > 2);
  assert.ok(chunks[0].tokensApprox <= 130);
  assert.equal(estimateTokens('abcd'), 2);
});