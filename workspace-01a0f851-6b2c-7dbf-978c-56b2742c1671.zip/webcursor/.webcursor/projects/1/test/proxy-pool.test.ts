import test from 'node:test';
import assert from 'node:assert/strict';
import { RotatingProxyPool } from '../src/modules/proxy-pool.js';

test('карантин исключает нестабильный прокси', () => {
  const pool = new RotatingProxyPool(['http://127.0.0.1:9', 'http://127.0.0.1:10']);
  assert.equal(pool.size, 2);
  const pick = pool.next();
  assert.ok(pick);
  assert.ok(['http://127.0.0.1:9', 'http://127.0.0.1:10'].includes(pick.url));
});